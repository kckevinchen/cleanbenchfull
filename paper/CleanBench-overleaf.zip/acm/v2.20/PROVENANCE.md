# Bundled ACM Proceedings template

Unmodified production distribution retrieved on 2026-09-26. The class header
identifies **acmart 2.20, 2026/08/16**. Its source README contains an inconsistent
future changelog date; the file headers and hashes below identify this copy.

- Generated class and bibliography style: https://ctan.math.illinois.edu/systems/texlive/tlnet/archive/acmart.tar.xz
- Original source, installer and README: https://ctan.math.illinois.edu/macros/latex/contrib/acmart.zip
- Maintainer: https://github.com/borisveytsman/acmart

The class and source retain ACM's copyright and LaTeX Project Public License
notices. The bibliography style declares public-domain licensing. The original
`acmart.dtx` is included as required by the generated class's distribution notice.
These third-party files are not modified. The older files in the parent `acm/`
directory are historical and are not used or included in the Overleaf export.

`main.tex` and `appendix.tex` use `sigconf,anonymous,nonacm`. The documented
`nonacm` option suppresses fictitious publication metadata in the review draft.
The main title includes the SIGMOD E&A suffix. This does not establish artifact
anonymity, release rights, or other author-specific submission requirements.

## SHA-256

- `acmart.cls`: `784c4f2fb07a70d8a797ee9d1c63f441c10fbd2f915c9c615d28cda35c0b742a`
- `ACM-Reference-Format.bst`: `4342d27456645567ef1a027f6474e894715bc31d468f040142fa54540440ad04`
- `acmart.dtx`: `e29efd327f5c759f3d1f2e99dc8588c6a05b734c142f89c3e348161b893e44ff`
- `acmart.ins`: `fa7daaa9375775ce699f33f909667bdb83c0408fd8d67606926df86c346c4044`
- `README`: `5f4b13963e839e1df1783d70495d1ea485e58facf936cfea27841fad6bdda863`
