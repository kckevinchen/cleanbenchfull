"""Build the LLM size-scaling figure from completed, frozen API receipts.

No model calls. Plot median runtime and mean cost only for successful, valid
responses with nonempty issue lists; coverage and exclusions remain in CSV.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import statistics
from collections import Counter, defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from figure_style import (
    COLUMN_WIDTH,
    MODEL_COLORS,
    TWO_PANEL_HEIGHT,
    TWO_PANEL_MARGINS,
    configure,
    save,
)

PAPER = Path(__file__).resolve().parents[1]
MODELS = ["gpt-4.1", "gpt-5.2", "gpt-5.5", "gpt-6-astra"]
LEVELS = [25, 50, 100, 200, 500, 1000, 2000, 3000, 4000, 5000]
SOURCES = {
    "row_scaling_20261006": (
        ["gpt-4.1", "gpt-5.2", "gpt-6-astra"],
        [n for n in LEVELS if n not in (3000, 4000)],
    ),
    "row_scaling_3k4k_20261006": (["gpt-4.1", "gpt-5.2", "gpt-6-astra"], [3000, 4000]),
    "row_scaling_gpt55_20261006": (["gpt-5.5"], LEVELS),
}


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def included_response(receipt_status, attempt):
    """Validity means request/schema success, not ground-truth correctness."""
    return (
        receipt_status == "success"
        and attempt.get("status") == "returned"
        and attempt.get("valid_output") is True
        and attempt.get("complete") is True
        and not attempt.get("truncated", False)
        and (attempt.get("issues_count") or 0) > 0
    )


def resource_statistics(values):
    """Both resource metrics use precisely the same eligible responses."""
    result = {
        "mean_seconds": None,
        "median_seconds": None,
        "mean_public_price_usd": None,
        "mean_no_cache_scenario_usd": None,
        "cached_read_fraction": None,
        "long_price_fraction": None,
    }
    if not values:
        return result
    inp = sum(a["usage"]["input_tokens"] for a in values)
    result.update(
        mean_seconds=statistics.mean(a["elapsed_seconds"] for a in values),
        median_seconds=statistics.median(a["elapsed_seconds"] for a in values),
        mean_public_price_usd=statistics.mean(a["public_price_usd"] for a in values),
        mean_no_cache_scenario_usd=statistics.mean(a["no_cache_scenario_usd"] for a in values),
        cached_read_fraction=sum(a["usage"]["cached_read_tokens"] or 0 for a in values) / inp,
        long_price_fraction=sum(a.get("price_tier") == "long" for a in values) / len(values),
    )
    return result


def collect(repo):
    groups = defaultdict(list)
    evidence = {}
    cohort_identity = None
    prompt_hash = None
    for folder, (models, levels) in SOURCES.items():
        run = repo / "outputs/prompt_tuning" / folder
        manifest = read(run / "manifest.json")
        for name in ("cohort", "settings", "schedule", "design"):
            assert sha(run / f"{name}.json") == manifest[f"{name}_sha256"]
        assert sha(run / "system_prompt.txt") == manifest["prompt_sha256"]
        if prompt_hash is None:
            prompt_hash = manifest["prompt_sha256"]
        assert prompt_hash == manifest["prompt_sha256"]
        cohort = read(run / "cohort.json")
        identity = {t["table_id"]: t["selected_rows_sha256"] for t in cohort}
        assert len(identity) == 40
        if cohort_identity is None:
            cohort_identity = identity
        assert cohort_identity == identity
        payloads = {
            (t["table_id"], x["rows"]): x["payload_sha256"]
            for t in cohort
            for x in t["input_sizes"]
        }
        settings = read(run / "settings.json")
        source = {
            "manifest_sha256": sha(run / "manifest.json"),
            "models": {},
            "receipt_sha256": {},
            "returned_attempt_sha256": {},
        }
        for model in models:
            worker = read(run / f"worker_{model}.json")
            if worker["status"] != "complete":
                raise ValueError(f"{folder}/{model} has not completed all repetitions")
            paths = sorted((run / "receipts" / model).glob("r*/*.json"))
            assert len(paths) == 40 * len(levels) * 3
            seen = set()
            statuses = Counter()
            for path in paths:
                receipt = read(path)
                key = (receipt["table_id"], receipt["rows"], receipt["repetition"])
                assert key not in seen and receipt["rows"] in levels
                assert receipt["repetition"] in (1, 2, 3)
                seen.add(key)
                assert receipt["payload_sha256"] == payloads[key[:2]]
                source["receipt_sha256"][str(path.relative_to(run))] = sha(path)
                statuses[receipt["status"]] += 1
                if receipt["status"] not in ("success", "invalid_output"):
                    continue
                attempt = receipt["attempts"][-1]
                assert attempt["status"] == "returned"
                assert (
                    attempt["response_model"]
                    == settings["models"][model]["expected_response_model"]
                )
                ap = run / "attempts" / receipt["id"] / f'{attempt["attempt"]}.json'
                raw = read(ap)
                assert {k: v for k, v in raw.items() if k not in ("raw", "error_body")} == attempt
                source["returned_attempt_sha256"][str(ap.relative_to(run))] = sha(ap)
                assert attempt["public_price_usd"] is not None
                assert attempt["elapsed_seconds"] >= 0
                groups[(model, receipt["rows"])].append(
                    {**attempt, "source_run": folder, "receipt_status": receipt["status"]}
                )
            source["models"][model] = {
                "statuses": dict(statuses),
                "finished_at": worker["completed_at"],
            }
        evidence[folder] = source
    rows = []
    for model in MODELS:
        for n in LEVELS:
            returned = groups[(model, n)]
            counts = Counter(a["table_id"] for a in returned)
            # Audit the original returned coverage before response filtering.
            assert returned and set(counts.values()) == {3}
            full = set(counts) == set(cohort_identity)
            values = [a for a in returned if included_response(a["receipt_status"], a)]
            included = Counter(a["table_id"] for a in values)
            rows.append(
                {
                    "model": model,
                    "rows": n,
                    "returned_tables": len(counts),
                    "returned_requests": len(returned),
                    "valid_requests": sum(a["valid_output"] for a in returned),
                    "included_tables": len(included),
                    "included_requests": len(values),
                    "excluded_empty_requests": sum(
                        a["valid_output"] and a["issues_count"] == 0 for a in returned
                    ),
                    "excluded_invalid_requests": sum(not a["valid_output"] for a in returned),
                    "included_min_repetitions_per_table": min(included.values()) if included else 0,
                    "included_max_repetitions_per_table": max(included.values()) if included else 0,
                    **resource_statistics(values),
                    "full_table_coverage": full,
                    "included_full_table_coverage": set(included) == set(cohort_identity),
                    "plotted": bool(values),
                    "source_runs": ";".join(sorted({a["source_run"] for a in returned})),
                }
            )
    assert len(rows) == 40
    partial = [(r["model"], r["rows"]) for r in rows if not r["full_table_coverage"]]
    assert partial == [("gpt-5.2", n) for n in (3000, 4000, 5000)]
    return rows, {
        "sources": evidence,
        "prompt_sha256": prompt_hash,
        "source_table_hashes": cohort_identity,
        "aggregation": "Median runtime and mean cost over the same successful, complete, schema-valid responses with issues_count > 0 at each model and size. Exclude empty issue lists, invalid/truncated responses, API errors, and context rejections. Valid does not imply correct predictions: expanded source rows lack benchmark labels. The original three repetitions remain audited, but eligibility varies by response; included repetition counts and all exclusions are retained in CSV. These are conditional per-response resource estimates, not campaign costs or unconditional per-table latency.",
        "latency": "Non-streaming API send-to-return duration; local admission and auth preparation, failed attempts and retry backoff are outside the plotted returned-request duration.",
        "cost": "Frozen public Standard price equivalents from observed usage, including cached reads/writes and long-context tiers; not Azure invoices. Means cover only included nonempty valid responses. Excluded responses may still incur charges; these means are not total campaign expenditure.",
        "batch": "Original row levels, supplemental 3k/4k levels, and GPT-5.5 recovery were run in separate batches. Serving conditions and prompt caching are not controlled cold-cache trials.",
        "rows": rows,
    }


def draw(rows, *, axes=None, panel_labels=("a", "b")):
    configure()
    standalone = axes is None
    if standalone:
        fig, axes = plt.subplots(2, 1, figsize=(COLUMN_WIDTH, TWO_PANEL_HEIGHT))
        fig.subplots_adjust(**TWO_PANEL_MARGINS)
    styles = zip(
        MODELS,
        ["GPT-4.1", "GPT-5.2", "GPT-5.5", "GPT-6 Astra"],
        MODEL_COLORS,
        ["o", "s", "^", "D"],
        ["-", "--", "-.", ":"],
    )
    for model, label, color, marker, line in styles:
        data = [r for r in rows if r["model"] == model]
        for ax, metric in zip(axes, ["median_seconds", "mean_public_price_usd"]):
            ax.plot(
                [r["rows"] for r in data],
                [r[metric] if r["plotted"] else float("nan") for r in data],
                label=label,
                color=color,
                marker=marker,
                markersize=3,
                linewidth=1.35,
                linestyle=line,
            )
    for ax in axes:
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xlim(20, 6000)
        ax.set_xticks([25, 100, 500, 1000, 5000], ["25", "100", "500", "1k", "5k"])
        ax.set_xlabel("Rows per table (log scale)")
        ax.minorticks_off()
        ax.grid(linewidth=0.45)
    axes[0].set_title(f"({panel_labels[0]}) Median runtime", loc="left", pad=8)
    axes[0].set_ylabel("Time per table (s)")
    axes[0].set_yticks([3, 10, 30, 100], ["3", "10", "30", "100"])
    axes[1].set_title(f"({panel_labels[1]}) Mean cost", loc="left", pad=8)
    axes[1].set_ylabel("Cost per table (USD)")
    axes[1].set_yscale("log")
    axes[1].set_yticks([0.01, 0.1, 1, 10], ["0.01", "0.1", "1", "10"])
    axes[1].minorticks_off()
    if not standalone:
        return
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        loc="upper center",
        ncol=2,
        frameon=False,
        bbox_to_anchor=(0.52, 1.0),
        columnspacing=1.2,
    )
    save(fig, PAPER / "assets/generated/llm_scaling.pdf", width=COLUMN_WIDTH, check_layout=True)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=PAPER.parent)
    args = parser.parse_args()
    rows, evidence = collect(args.repo_root.resolve())
    path = PAPER / "assets/generated/llm_scaling.csv"
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    evidence["builder_sha256"] = sha(Path(__file__))
    target = PAPER / "build/generated/llm_scaling_evidence.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(evidence, indent=2) + "\n")
    draw(rows)
    print("Audited all 40 model/size aggregates; plotted valid nonempty responses only.")


if __name__ == "__main__":
    main()
