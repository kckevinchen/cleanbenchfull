"""Plot error-type counts and source-normalized error frequency.

Use frozen count tables. Pie denominators sum the three error-type counts;
a cell with two types contributes to both counts. No new labels are inferred.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

if __package__:
    from .tex_sources import generated_asset
else:
    from tex_sources import generated_asset

if __package__:
    from .figure_style import COLUMN_WIDTH, SOURCE_COLORS, configure, paired_pies, save
else:
    from figure_style import COLUMN_WIDTH, SOURCE_COLORS, configure, paired_pies, save

PAPER = Path(__file__).resolve().parents[1]
GENERATED = PAPER / "assets/generated"
FAMILIES = ("Spelling", "Formatting", "Inconsistency")
# Reserve blue/pink for sources; the three other colors identify error types.
COLORS = ("#73658f", "#b88136", "#397e75")
SOURCES = ("Relational", "Spreadsheet")
INPUTS = ("corpus_types.tex", "corpus_table.tex")
TYPE_PIES_HEIGHT = 1.60


def counts():
    families, population = {}, {}
    for file, target in ((INPUTS[0], families), (INPUTS[1], population)):
        for line in (generated_asset(file, directory=GENERATED)).read_text().splitlines():
            key = line.split(" & ", 1)[0]
            if key in (*FAMILIES, "Cells (excluding ambiguous/ignored)", "Labeled errors"):
                fields = line.removesuffix(r" \\").split(" & ")
                values = [int(v.replace(",", "")) for v in fields[1:]]
                assert len(values) == 3 and sum(values[:2]) == values[2]
                target[key] = values[:2]
    assert set(families) == set(FAMILIES)
    rows = []
    for i, source in enumerate(SOURCES):
        total = sum(families[family][i] for family in FAMILIES)
        unique = population["Labeled errors"][i]
        denominator = population["Cells (excluding ambiguous/ignored)"][i]
        assert denominator > unique > 0 and total >= unique
        for family in FAMILIES:
            n = families[family][i]
            rows.append(
                dict(
                    source=source,
                    family=family,
                    memberships=n,
                    source_memberships=total,
                    distinct_error_cells=unique,
                    scorable_cells=denominator,
                    membership_share=100 * n / total,
                    errors_per_1000_scorable_cells=1000 * n / denominator,
                )
            )
    assert sum(r["memberships"] for r in rows) == 1503
    assert sum(population["Labeled errors"]) == 1409
    return rows


def draw_type_pies(rows):
    """Show raw type counts; overlapping labels each contribute to a slice."""
    configure(font_size=7.5)
    fig = plt.figure(figsize=(COLUMN_WIDTH, TYPE_PIES_HEIGHT))
    families = ("Spelling", "Inconsistency", "Formatting")
    colors = dict(zip(FAMILIES, COLORS, strict=True))
    pie_colors = [colors[family] for family in families]
    for index, source in enumerate(SOURCES):
        group = [row for row in rows if row["source"] == source]
        assert [row["family"] for row in group] == list(FAMILIES)
        error_counts = {row["distinct_error_cells"] for row in group}
        assert len(error_counts) == 1
        error_count = error_counts.pop()
        counts_by_family = {row["family"]: row["memberships"] for row in group}
        values = [counts_by_family[family] for family in families]
        # Match the left panel's original pie size and top offsets.
        ax = fig.add_axes(
            [
                0.01 + index * 0.50,
                (TYPE_PIES_HEIGHT - 1.3875) / TYPE_PIES_HEIGHT,
                0.48,
                1.036 / TYPE_PIES_HEIGHT,
            ]
        )
        wedges, _, labels = ax.pie(
            values,
            colors=pie_colors,
            startangle=90,
            counterclock=False,
            autopct=lambda share: str(round(share * sum(values) / 100)),
            pctdistance=0.65,
            wedgeprops=dict(edgecolor="white", linewidth=0.6),
        )
        for label, value, color in zip(labels, values, ("white", "white", "black"), strict=True):
            assert label.get_text() == str(value)
            label.set_color(color)
        assert abs(sum(w.theta2 - w.theta1 for w in wedges) - 360) < 0.001
        ax.set_xlim(-1.12, 1.12)
        ax.set_ylim(-1.12, 1.12)
        ax.set_axis_off()
        fig.text(
            0.25 + index * 0.50,
            1 - 0.259 / TYPE_PIES_HEIGHT,
            f"{source} ({error_count:,} errors)",
            ha="center",
            va="bottom",
            weight="bold",
        )
    fig.text(
        0.5,
        1 - 0.0185 / TYPE_PIES_HEIGHT,
        "(b) Error-type counts",
        ha="center",
        va="top",
        weight="bold",
    )
    fig.legend(
        handles=[
            Patch(facecolor=color, label=family)
            for color, family in zip(pie_colors, families, strict=True)
        ],
        loc="lower center",
        bbox_to_anchor=(0.5, 2 / (72 * TYPE_PIES_HEIGHT)),
        ncol=3,
        frameon=False,
        handlelength=0.9,
        handletextpad=0.4,
        columnspacing=0.8,
        borderpad=0,
        borderaxespad=0,
    )
    save(
        fig,
        PAPER / "figures/paper/error_type_pies.pdf",
        width=COLUMN_WIDTH,
        font_size=7.5,
        check_layout=True,
    )
    plt.close(fig)


def draw(rows, *, target=None, cell_labels=True):
    configure(font_size=8)
    fig = plt.figure(figsize=(COLUMN_WIDTH, 2.8))
    fig.add_artist(
        plt.Line2D(
            [0.03, 0.98], [0.49, 0.49], transform=fig.transFigure, color="#d2d9e0", linewidth=0.6
        )
    )
    groups = []
    for source in SOURCES:
        group = [r for r in rows if r["source"] == source]
        assert [r["family"] for r in group] == list(FAMILIES)
        groups.append([r["memberships"] for r in group])
    paired_pies(
        fig,
        groups,
        sources=SOURCES,
        categories=FAMILIES,
        colors=COLORS,
        text_colors=("white", "black", "white"),
        title="Error types (%)",
    )
    ax = fig.add_axes([0.30, 0.23, 0.67, 0.20])
    for i, family in enumerate(FAMILIES):
        group = [r for r in rows if r["family"] == family]
        values = [r["errors_per_1000_scorable_cells"] for r in group]
        for j, (source, value) in enumerate(zip(SOURCES, values, strict=True)):
            y = 2 - i + (0.22 if j == 0 else -0.22)
            ax.barh(
                y,
                value,
                height=0.30,
                color=SOURCE_COLORS[source],
                label=source if i == 0 else None,
                zorder=3,
            )
            ax.text(value + 0.09, y, f"{value:.2f}", ha="left", va="center", color="#253342")
    fig.text(0.50, 0.48, "(c) Error frequency", ha="center", va="top", weight="bold")
    ax.set_yticks((2, 1, 0), FAMILIES)
    ax.tick_params(axis="y", length=0, pad=7)
    ax.set_xlim(0, 3.65)
    ax.set_ylim(-0.6, 2.6)
    ax.set_xticks((0, 1, 2, 3))
    ax.set_xlabel("Errors / 1,000 " + ("cells" if cell_labels else "entries"), labelpad=4)
    ax.spines[["left", "top", "right"]].set_visible(False)
    ax.grid(axis="x", linewidth=0.45)
    ax.set_axisbelow(True)
    handles, labels = ax.get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        loc="lower center",
        bbox_to_anchor=(0.55, 0.005),
        ncol=2,
        frameon=False,
        handletextpad=0.3,
        columnspacing=0.7,
        borderaxespad=0,
    )
    save(
        fig,
        target if target is not None else GENERATED / "family_distribution.pdf",
        width=COLUMN_WIDTH,
        font_size=8,
        check_layout=True,
    )
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--type-pies-only", action="store_true", help="Render the raw-count pie pair only."
    )
    args = parser.parse_args()
    hashes = {
        name: hashlib.sha256((generated_asset(name, directory=GENERATED)).read_bytes()).hexdigest()
        for name in INPUTS
    }
    rows = counts()
    if args.type_pies_only:
        draw_type_pies(rows)
        assert hashes == {
            name: hashlib.sha256(
                (generated_asset(name, directory=GENERATED)).read_bytes()
            ).hexdigest()
            for name in INPUTS
        }
        print(
            "Rendered raw error-type counts from unchanged frozen tables; overlapping types remain separate labels."
        )
        return
    draw(rows)
    with (GENERATED / "family_distribution.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    assert hashes == {
        name: hashlib.sha256((generated_asset(name, directory=GENERATED)).read_bytes()).hexdigest()
        for name in INPUTS
    }
    folder = PAPER / "build/family_distribution"
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "evidence.json").write_text(
        json.dumps(
            {
                "source_sha256": hashes,
                "rows": rows,
                "policy": "Pie percentages divide each error-type count by the sum of the three type counts within its source. A cell with two types contributes once to both counts. The caption explains this denominator. Grouped bars compare each type's errors per 1,000 detection-scorable cells. Counts and percentages are unchanged.",
                "design_references": [
                    {
                        "url": "https://aclanthology.org/2025.xllm-1.8.pdf#page=12",
                        "figure": 7,
                        "adaptation": "Paired solid pies, sector-internal percentages, shared categorical colors and legend.",
                    },
                    {
                        "url": "https://aclanthology.org/2022.acl-long.286.pdf#page=19",
                        "figure": 6,
                        "adaptation": "Aligned categorical comparisons and shared legends; rates use grouped bars because source-specific frequencies are not a partition.",
                    },
                ],
            },
            indent=2,
        )
        + "\n"
    )
    print("Rendered error-type percentages and source-frequency bars from unchanged frozen counts.")


if __name__ == "__main__":
    main()
