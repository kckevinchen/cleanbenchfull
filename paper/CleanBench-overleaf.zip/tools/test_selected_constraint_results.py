"""Check threshold selection independently of each evaluation fold."""

import pytest
from build_selected_constraint_results import fold_assignment


def metric(counts):
    return {"f1": sum(counts.values())}, None


def test_each_fold_uses_only_other_fold_scores():
    curves = {0: {"a": 10, "b": 0}, 80: {"a": 0, "b": 10}}
    assigned, thresholds = fold_assignment(curves, [[["a"]], [["b"]]], metric)
    assert assigned == {"a": 80, "b": 0}
    assert thresholds == [80, 0]


def test_ties_choose_higher_cutoff_and_duplicate_folds_are_rejected():
    curves = {0: {"a": 1, "b": 1}, 90: {"a": 1, "b": 1}}
    assert fold_assignment(curves, [[["a"]], [["b"]]], metric)[1] == [90, 90]
    with pytest.raises(ValueError, match="partition"):
        fold_assignment(curves, [[["a"]], [["a", "b"]]], metric)
