"""Apply the fixed bidirectional group rubric to the selected Table 3 cohort."""

from __future__ import annotations

import argparse
import ast
import json
import re
import statistics
from collections import defaultdict
from pathlib import Path

from build_constraint_score_analysis import DATA, PAPER, digest, read, write_csv


def build(root, audit):
    reference_path = audit / "recovered_group_scoring_reference.json"
    old_evidence = read(DATA / "bidirectional_group_results.json")
    assert digest(reference_path) == old_evidence["scoring_reference_sha256"]
    groups = read(reference_path)["groups"]
    assert len(groups) == 42
    # Load only the reviewed value predicates, without executing the old audit runner.
    source = audit / "score_recovered_groups.py"
    names = {"style_phone", "style_fund", "title_style", "resolved"}
    tree = ast.parse(source.read_text())
    predicates = ast.Module(
        body=[n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names],
        type_ignores=[],
    )
    assert len(predicates.body) == len(names)
    namespace = {"re": re}
    exec(compile(predicates, str(source), "exec"), namespace)
    manifest = read(root / "manifest.json")
    scores = defaultdict(list)
    evidence = []
    for run in manifest["runs"]:
        if not run["point_view"]:
            continue
        for key in ["predictions", "metadata"]:
            assert digest(root / run[key]) == manifest["sha256"][run[key]]
        predictions = {
            (r["dataset"], r["row"], r["col"]): r["corrected_value"].strip()
            for r in (
                json.loads(line)
                for line in (root / run["predictions"]).read_text().splitlines()
                if line.strip()
            )
            if isinstance(r.get("corrected_value"), str)
        }
        execution = read(root / run["metadata"])["execution"]
        resolved = []
        for group in groups:
            values = [
                predictions.get((m["table"], m["local_row"], m["col"]), m["original_value"])
                for m in group["members"]
            ]
            if all(execution[m["table"]] == "complete" for m in group["members"]) and namespace[
                "resolved"
            ](group, values):
                resolved.append(group["id"])
        scores[run["method"]].append(100 * len(resolved) / len(groups))
        evidence.append(dict(method=run["method"], run=run["run"], resolved_groups=resolved))
    rows = [
        dict(
            method=m,
            repetitions=len(s),
            resolution_rate=statistics.mean(s),
            sd=statistics.stdev(s) if len(s) > 1 else None,
        )
        for m, s in scores.items()
    ]
    write_csv(DATA / "bidirectional_group_scores_selected.csv", rows)
    path = PAPER / "bidirectional_results.tex"
    text = path.read_text()
    for method in manifest["constraint_selection"]:
        row = next(r for r in rows if r["method"] == method)
        pattern = r"(?m)^" + re.escape(method) + r" & .*?$"
        replacement = f"{method} & {row['repetitions']} & ${row['resolution_rate']:.2f}$ " + r"\\"
        text, n = re.subn(pattern, lambda match: replacement, text)
        assert n == 1
    path.write_text(text)
    (DATA / "bidirectional_group_selected_evidence.json").write_text(
        json.dumps(
            dict(
                scoring_reference_sha256=digest(reference_path),
                scorer_source_sha256=digest(source),
                table3_manifest_sha256=digest(root / "manifest.json"),
                runs=evidence,
            ),
            indent=2,
        )
        + "\n"
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--audit", type=Path, required=True)
    args = parser.parse_args()
    build(args.artifacts.resolve(), args.audit.resolve())


if __name__ == "__main__":
    main()
