"""Build full-version end-to-end figures from the public all-error score bundle."""

from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path

from build_defined_macro_results import run_scores
from build_diagnostic_task_tables import draw as draw_macro
from build_e2e_variance_table import METRICS
from build_e2e_variance_table import draw as draw_micro
from build_experiment_comparisons import METHODS, variation_figure
from build_failure_comparison import published_outcomes, write_outcomes
from build_resource_overview import draw_split, read_scaling

PAPER = Path(__file__).resolve().parents[1]
GENERATED = PAPER / "assets/generated"


def read_csv(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def macro_scores(tables):
    return run_scores(tables)[0]


def grouped_scores(runs, reference, scoring):
    source, exact = [], []
    for method, *_ in METHODS:
        local_runs = runs[method]
        for dimension in ("source", "columns", "rows"):
            grouped = defaultdict(list)
            for tables in local_runs:
                buckets = defaultdict(dict)
                for name, row in tables.items():
                    table = reference["tables"][name]
                    bucket = (
                        (
                            "Relational"
                            if table["source_path"].startswith("pbi_500/")
                            else "Spreadsheet"
                        )
                        if dimension == "source"
                        else table[dimension]
                    )
                    buckets[bucket][name] = row
                for bucket, counts in buckets.items():
                    values, totals = scoring.metrics(counts)
                    grouped[bucket].append((values, totals))
            for bucket, values in grouped.items():
                totals = values[0][1]
                assert all(row[1]["targets"] == totals["targets"] for row in values)
                row = {
                    "task": "e2e",
                    "method": method,
                    "dimension": dimension,
                    "tables": totals["tables"],
                    "targets": totals["targets"],
                    "f1": statistics.mean(row[0]["f1"] for row in values),
                }
                if dimension == "source":
                    source.append({**row, "bucket": bucket, "source_filter": "All"})
                else:
                    defined = any(row[1]["tp"] + row[1]["fp"] + row[1]["fn"] for row in values)
                    exact.append({**row, "size": bucket, "f1_defined": str(defined)})
    return source, exact


def resource_rows(name, scores, selected=None):
    rows = read_csv(GENERATED / name)
    for row in rows:
        method = row["model"]
        if method not in scores:
            method += " (Prompt-tuned)"
        row["f1_percent"] = scores[method]["f1"]
        for key in ("recorded_cost_usd", "estimated_cost_usd", "mean_seconds_per_table"):
            if key in row:
                row[key] = float(row[key]) if row[key] else None
        if selected and method in selected:
            timing = selected[method]
            row.update(
                configuration="GT-assisted constraints with five-fold score selection",
                mean_seconds_per_table=timing["seconds"] / 1000,
                estimated_cost_usd=timing["seconds"] / 3600 * 0.1,
                repetitions=1,
                timing_kind="selected_native_worker_elapsed",
                timing_tables_recorded=timing["native_tables"],
                failed_jobs_included=timing["failed_tables"],
            )
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifacts", type=Path, required=True)
    args = parser.parse_args()
    root = args.artifacts.resolve()
    module = root.parent.parent / "src/reproducibility/table3.py"
    spec = importlib.util.spec_from_file_location("table3_all_error_scoring", module)
    scoring = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scoring)
    manifest = scoring.verify(root)
    reference = scoring.read(root / "reference.json")
    assert reference["population"]["tables"] == 1000
    assert reference["population"]["targets"] == len(reference["targets"]) == 1409
    expected_point = read_csv(root / "expected/table3_point.csv")
    expected_variance = {
        row["method"]: row for row in read_csv(root / "expected/table3_variability.csv")
    }
    point_template = {row["method"]: row for row in read_csv(GENERATED / "e2e_table_point.csv")}
    runs = defaultdict(list)
    for run in manifest["runs"]:
        if not run["point_view"]:
            continue
        tables = {row["dataset"]: row for row in scoring.records(root / run["counts"])}
        assert len(tables) == 1000 and scoring.metrics(tables)[1]["targets"] == 1409
        runs[run["method"]].append(tables)
    point, variance, macro = [], [], []
    for expected in expected_point:
        method = expected["method"]
        local = runs[method]
        assert len(local) == int(expected["repetitions"])
        measured = [scoring.metrics(tables)[0] for tables in local]
        row = dict(point_template[method])
        for metric in METRICS:
            value = statistics.mean(scores[metric] for scores in measured)
            assert math.isclose(value, float(expected[metric]), abs_tol=1e-10)
            row[metric] = value
        row["repetitions"] = len(local)
        row["constraint_selection"] = method in manifest.get("constraint_selection", [])
        row["mean_fp_clean"] = statistics.mean(
            sum(table["fp_clean"] for table in tables.values()) for tables in local
        )
        point.append(row)
        other = expected_variance[method]
        deviation = dict(row, variance_requested=len(local) > 1)
        for metric in METRICS:
            deviation[f"sd_{metric}"] = (
                float(other[f"sd_{metric}"]) if other[f"sd_{metric}"] else None
            )
        variance.append(deviation)
        measured_macro = [macro_scores(list(tables.values())) for tables in local]
        macro.append(
            {
                key: (
                    statistics.mean(scores[key] for scores in measured_macro)
                    if key in measured_macro[0]
                    else row[key]
                )
                for key in read_csv(GENERATED / "e2e_macro_results.csv")[0]
            }
        )
    write_csv(GENERATED / "e2e_table_point_all_errors.csv", point)
    write_csv(GENERATED / "e2e_table_variability_all_errors.csv", variance)
    write_csv(GENERATED / "e2e_macro_all_errors.csv", macro)
    draw_micro(variance, output=PAPER / "figures/paper/e2e_type_all_errors.pdf")
    draw_macro(
        macro,
        "macro_e2e",
        overall_label="Overall macro (%)",
        output=PAPER / "figures/paper/macro_e2e_all_errors.pdf",
    )
    outcomes = published_outcomes(root)
    write_csv(GENERATED / "failure_outcomes_all_errors.csv", outcomes)
    write_outcomes(outcomes, scores=point, output=PAPER / "failure_outcomes_all_errors.tex")
    source, exact = grouped_scores(runs, reference, scoring)
    write_csv(GENERATED / "source_scores_all_errors.csv", source)
    write_csv(GENERATED / "size_scores_all_errors.csv", exact)
    variation_figure(
        source, exact, targets=1409, output=PAPER / "figures/paper/e2e_source_size_all_errors.pdf"
    )
    scores = {row["method"]: row for row in point}
    selection = (
        json.loads((GENERATED / "constraint_selected_results.json").read_text())
        if manifest.get("constraint_selection")
        else None
    )
    timings = {r["method"]: r for r in selection["runtime"]} if selection else {}
    quality = resource_rows("price_quality.csv", scores)
    traditional = resource_rows("price_quality_traditional.csv", scores, timings)
    write_csv(GENERATED / "price_quality_all_errors.csv", quality)
    write_csv(GENERATED / "price_quality_traditional_all_errors.csv", traditional)
    draw_split(
        read_scaling(),
        quality,
        traditional,
        figures=("resource_tradeoff",),
        output_suffix="_all_errors",
    )
    astra = next(r for r in quality if r["model"] == "GPT-6-astra")
    cost = astra.get("recorded_cost_usd") or astra["estimated_cost_usd"]
    ratio = cost / max(r["estimated_cost_usd"] for r in traditional)
    (PAPER / "resource_comparison_all_errors.tex").write_text(
        f"\\newcommand{{\\CBTraditionalCostRatio}}{{{ratio:,.0f}}}\n"
    )
    evidence = {
        "artifact_manifest_sha256": scoring.sha(root / "manifest.json"),
        "reference_sha256": scoring.sha(root / "reference.json"),
        "population": reference["population"],
        "scoring": reference["scoring"],
        "methods": len(point),
        "runs": sum(map(len, runs.values())),
    }
    (GENERATED / "all_error_results.json").write_text(json.dumps(evidence, indent=2) + "\n")
    print("Built full-version results from", evidence["runs"], "runs and 1,409 targets.")


if __name__ == "__main__":
    main()
