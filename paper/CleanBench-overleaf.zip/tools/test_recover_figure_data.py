"""Regression checks for evidence identity, tombstones and unknown billing."""

import json

import pytest
from recover_figure_data import Evidence, index_events, unpriced_reason
from recover_figure_examples import latest_annotations
from verify_figure_data import verify_pairing


def test_copied_ledgers_deduplicate_physical_events_but_retain_both_locations(tmp_path):
    event = dict(event_id="physical-call", event="sdk_invocation", repetition=4, request_sha256="r")
    roots = [tmp_path / name for name in ("old", "new")]
    for root in roots:
        root.mkdir()
        (root / "telemetry.jsonl").write_text(json.dumps(event) + "\n")
    index, locations, seen = index_events(Evidence(tmp_path), roots)
    assert len(index[4, "r"]) == len(seen) == 1
    assert {p["path"] for p in locations["physical-call"]} == {
        "old/telemetry.jsonl",
        "new/telemetry.jsonl",
    }
    (roots[1] / "telemetry.jsonl").write_text(json.dumps({**event, "repetition": 5}) + "\n")
    with pytest.raises(AssertionError):
        index_events(Evidence(tmp_path), roots)


def test_annotation_tombstone_revokes_previous_correction():
    record = dict(target="cell", target_id="x", source="x.csv", row=0, column="a")
    rows = [
        {**record, "status": "tp", "corrected_value": "fixed"},
        {**record, "status": "unlabeled"},
    ]
    assert latest_annotations(rows) == [(2, rows[1])]


def test_missing_billing_has_a_reason_separate_from_zero_usage():
    rate = dict(max_priced_input_tokens=128000, cache_write=None)
    zero = dict(input_tokens=0, cache_write_tokens=0)
    assert unpriced_reason(None, rate, None) == "missing_or_invalid_usage"
    assert unpriced_reason(zero, rate, None) == ""
    assert unpriced_reason(zero, None, None) == "no_frozen_model_rate"
    assert unpriced_reason(zero, rate, "priority") == "unsupported_service_tier"
    assert (
        unpriced_reason({**zero, "input_tokens": 128001}, rate, None)
        == "input_exceeds_frozen_pricing_limit"
    )
    assert unpriced_reason({**zero, "cache_write_tokens": 1}, rate, None) == "no_cache_write_rate"


def test_unknown_cost_cannot_silently_become_zero():
    call = dict(
        event_id="a", run_id="r", priced="False", cost_usd="0", unpriced_reason="missing_usage"
    )
    with pytest.raises(AssertionError, match="Unknown cost"):
        verify_pairing([], [call])


def test_cost_from_another_repetition_cannot_be_joined_to_quality():
    run = dict(
        run_id="r",
        task="e2e",
        model="m",
        configuration_id="c",
        prompt_sha256="p",
        repetition="1",
        original_repetition_id="1",
    )
    call = dict(**run, event_id="a", priced="False", cost_usd="", unpriced_reason="missing_usage")
    call["repetition"] = "2"
    with pytest.raises(AssertionError, match="Quality/cost join mismatch"):
        verify_pairing([run], [call])


def test_source_hash_mismatch_cannot_be_used(tmp_path):
    path = tmp_path / "source.json"
    path.write_text("{}")
    with pytest.raises(AssertionError, match="source hash mismatch"):
        Evidence(tmp_path).read(path, "wrong-digest")
