"""Reproduce the archived micro/all-table-macro F1 comparison.

The active table uses target-table macro scores. This historical scatter keeps
the all-table mean, including no-edit credit, and its unchanged-input reference.
"""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from figure_style import COLUMN_WIDTH, PRIMARY_COLOR, configure, save
from matplotlib.lines import Line2D
from matplotlib.text import Text
from matplotlib.transforms import Bbox

PAPER = Path(__file__).resolve().parents[1]
GENERATED = PAPER / "assets/generated"
GROUPS = {
    "Academic": dict(color="#949faa", marker="D", size=20, filled=True),
    "Industrial": dict(color="#9c6b25", marker="^", size=28, filled=True),
    "Direct LLMs": dict(color=PRIMARY_COLOR, marker="o", size=29, filled=True),
    "Coding agents": dict(color="#b65378", marker="s", size=28, filled=False),
}


def reference_name(row):
    method = row["method"].lower()
    if row["group"] == "Direct LLMs":
        if "gpt-6-astra" in method:
            return "Astra"
        if "gpt-5.5" in method:
            return "GPT-5.5"
    if row["group"] == "Coding agents" and "opus" in method and "claude" in method:
        return "Opus / Claude"
    return {"excel": "Excel", "cocoon": "Cocoon"}.get(method)


def label_points(fig, ax, rows, reserved):
    """Place short reference labels without moving any measured coordinates."""
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    bounds = ax.get_window_extent(renderer)
    points = [ax.transData.transform((r["micro_f1"], r["macro_f1"])) for r in rows]
    boxes = [Bbox.from_bounds(x - 4, y - 4, 8, 8) for x, y in points]
    occupied = [Text.get_window_extent(text, renderer).padded(2) for text in reserved]
    offsets = [
        (6, 0),
        (-6, 0),
        (5, 4),
        (5, -4),
        (-5, 4),
        (-5, -4),
        (5, 12),
        (5, -12),
        (-5, 12),
        (-5, -12),
        (14, 4),
        (14, -4),
        (-14, 4),
        (-14, -4),
        (5, 21),
        (5, -21),
        (-5, 21),
        (-5, -21),
    ]
    placements = []
    ordered = sorted(enumerate(rows), key=lambda pair: pair[1]["micro_f1"], reverse=True)
    for index, row in ordered:
        label = reference_name(row)
        if label is None:
            continue
        for dx, dy in offsets:
            annotation = ax.annotate(
                label,
                (row["micro_f1"], row["macro_f1"]),
                xytext=(dx, dy),
                textcoords="offset points",
                ha="left" if dx > 0 else "right",
                va="center" if dy == 0 else ("bottom" if dy > 0 else "top"),
                color="#263442",
                fontsize=8,
                arrowprops=dict(arrowstyle="-", color="#9aa3ad", lw=0.45),
                zorder=5,
            )
            annotation.update_positions(renderer)
            box = Text.get_window_extent(annotation, renderer).padded(1.5)
            fits = bounds.contains(box.x0, box.y0) and bounds.contains(box.x1, box.y1)
            overlaps = any(box.overlaps(other) for other in occupied)
            hits_point = any(box.overlaps(other) for j, other in enumerate(boxes) if j != index)
            if fits and not overlaps and not hits_point:
                occupied.append(box)
                placements.append(dict(method=row["method"], label=label, offset=[dx, dy]))
                break
            annotation.remove()
        else:
            raise ValueError(f"No clear label position for {label}")
    return placements


def main():
    source = GENERATED / "macro_metrics.csv"
    with source.open(newline="") as handle:
        rows = list(csv.DictReader(handle))
    assert len(rows) == 23
    assert len({r["method"] for r in rows}) == len(rows)
    for row in rows:
        row["macro_f1"] = row["all_table_macro_f1"]
        for key in ("micro_f1", "macro_f1"):
            row[key] = float(row[key])
            assert 0 <= row[key] <= 100
        assert int(row["tables"]) == 1000
        assert int(row["targets"]) == 1093
        assert int(row["zero_target_tables"]) == 836
        assert row["group"] in GROUPS
    configure(font_size=8)
    fig, ax = plt.subplots(figsize=(COLUMN_WIDTH, 2.4))
    fig.subplots_adjust(left=0.17, right=0.975, bottom=0.19, top=0.79)
    ax.set_axisbelow(True)
    ax.grid(color="#e6eaf0", linewidth=0.4)
    ax.set_xlim(-3, 100)
    ax.set_ylim(-3, 100)
    ax.set_xticks([0, 25, 50, 75, 100])
    ax.set_yticks([0, 25, 50, 75, 100])
    ax.set_xlabel(r"Micro $F_1$ (%)", labelpad=4)
    ax.set_ylabel(r"Macro $F_1$ (%)", labelpad=4)
    reference = 100 * int(rows[0]["zero_target_tables"]) / int(rows[0]["tables"])
    ax.axhline(reference, color="#89939e", linestyle=(0, (3, 2)), linewidth=0.7, zorder=1)
    handles = []
    for group, style in GROUPS.items():
        selected = [r for r in rows if r["group"] == group]
        assert selected
        face = style["color"] if style["filled"] else "none"
        ax.scatter(
            [r["micro_f1"] for r in selected],
            [r["macro_f1"] for r in selected],
            s=style["size"],
            marker=style["marker"],
            facecolors=face,
            edgecolors=style["color"],
            linewidths=0.7,
            zorder=3,
        )
        handles.append(
            Line2D(
                [],
                [],
                linestyle="none",
                marker=style["marker"],
                markerfacecolor=face,
                markeredgecolor=style["color"],
                markeredgewidth=0.7,
                markersize=4.5,
                label=group,
            )
        )
    ax.legend(
        handles=handles,
        frameon=False,
        ncol=2,
        loc="lower left",
        bbox_to_anchor=(0, 1.045, 1, 0.1),
        mode="expand",
        borderaxespad=0,
        handletextpad=0.45,
        columnspacing=0.7,
        labelspacing=0.35,
    )
    labels = label_points(fig, ax, rows, [])
    target = GENERATED / "micro_macro_correction.pdf"
    save(fig, target, width=COLUMN_WIDTH, check_layout=True)
    plt.close(fig)
    evidence = {
        "source": str(source.relative_to(PAPER)),
        "sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "methods": len(rows),
        "table_count": 1000,
        "keep_original": dict(micro_f1=0, macro_f1=reference),
        "coordinate_policy": "Unmodified observed scores; no jitter or run pooling",
        "labels": labels,
    }
    path = PAPER / "build/generated/macro_figure_evidence.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(evidence, indent=2) + "\n")
    print(target)


if __name__ == "__main__":
    main()
