"""Freeze and render clean-cell editing burden and table selection, offline."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
import sys
from collections import defaultdict
from itertools import chain
from pathlib import Path

if __package__:
    from .tex_sources import generated_asset
else:
    from tex_sources import generated_asset

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parent
GENERATED = PAPER / "assets/generated"
RUN_FILE = GENERATED / "false_edits_ba_runs.csv"
DISPLAY = [
    ("Keep original", "Keep original"),
    ("BigDansing", "BigDansing"),
    ("Holistic", "Holistic"),
    ("DaisyP", "DaisyP"),
    ("Horizon", "Horizon"),
    ("Relative Trust", "Relative Trust"),
    ("NADEEF", "NADEEF"),
    ("LLUNATIC", "LLUNATIC"),
    ("UniClean", "UniClean"),
    ("SymSpell", "SymSpell"),
    ("Excel", "Excel"),
    ("GPT-6-astra (Prompt-tuned)", "GPT-6-astra (API)"),
    ("GPT-6-astra (Codex)", "GPT-6-astra (Codex)"),
    ("GPT-6-astra (Copilot)", "GPT-6-astra (Copilot)"),
]


def read_csv(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_counts(tables):
    """Partition clean-cell edits and table alarms using canonical outcomes."""
    result = dict(
        tables=len(tables),
        clean_cells=0,
        tp=0,
        fp=0,
        fn=0,
        fp_clean=0,
        wrong_at_target=0,
        table_tp=0,
        table_fp=0,
        table_fn=0,
        table_tn=0,
        complete_tables=0,
        failed_tables=0,
        unknown_tables=0,
        target_tables_with_correct_repairs=0,
    )
    for table in tables.values():
        tp, fp, fn = (table[k] for k in ("tp", "fp", "fn"))
        wrong, outside = table["wrong_at_target"], table["outside_target"]
        clean = table["scorable_cells"] - tp - fn
        assert all(isinstance(n, int) and n >= 0 for n in (tp, fp, fn, wrong, outside, clean))
        assert fp == wrong + outside and outside <= clean
        status = table["execution"]
        assert status in {"complete", "failed", "unknown"}
        assert status == "complete" or tp + fp == 0
        for key, value in (
            ("tp", tp),
            ("fp", fp),
            ("fn", fn),
            ("wrong_at_target", wrong),
            ("fp_clean", outside),
            ("clean_cells", clean),
        ):
            result[key] += value
        result[status + "_tables"] += 1
        positive, alarm = tp + fn > 0, tp + fp > 0
        key = (
            ("table_tp" if alarm else "table_fn")
            if positive
            else ("table_fp" if alarm else "table_tn")
        )
        result[key] += 1
        result["target_tables_with_correct_repairs"] += tp > 0
    return result


def run_scores(counts):
    """All rates use complete reference populations, including failed outputs."""
    positive = counts["table_tp"] + counts["table_fn"]
    negative = counts["table_tn"] + counts["table_fp"]
    tp, fp, fn = (counts[k] for k in ("tp", "fp", "fn"))
    assert positive > 0 and negative > 0 and counts["clean_cells"] > 0
    assert positive + negative == counts["tables"]
    return {
        "fp_per_100_clean_cells": 100 * counts["fp_clean"] / counts["clean_cells"],
        "correction_recall": 100 * tp / (tp + fn),
        "table_balanced_accuracy": 50
        * (counts["table_tp"] / positive + counts["table_tn"] / negative),
        "completion": 100 * counts["complete_tables"] / counts["tables"],
        "micro_precision": 100 * tp / (tp + fp) if tp + fp else 0.0,
        "micro_f1": 200 * tp / (2 * tp + fp + fn),
    }


def refresh():
    sys.path[:0] = [str(ROOT), str(PAPER / "tools")]
    from build_macro_metrics import Inputs, agent_runs, api_runs, historical_runs

    from src.evaluation.paper_evaluation.analysis import GroundTruth

    inputs = Inputs()
    snapshot = ROOT / "outputs/baseline_campaign/20260910/snapshot"
    truth = GroundTruth(snapshot, inputs.read(snapshot / "_manifest.json"))
    assert len(truth.ids) == 1000 and len(truth.eligible) == 1093
    runs = []
    for run in chain(
        historical_runs(inputs, truth), api_runs(inputs, truth), agent_runs(inputs, truth)
    ):
        counts = run_counts(run["tables"])
        assert [counts[k] for k in ("tp", "fp", "fn")] == [
            run["expected"][k] for k in ("tp", "fp", "fn")
        ]
        runs.append(
            {"method": run["method"], "category": run["category"], "run": run["run"], **counts}
        )
    empty, _ = truth.analyze([], "e2e", dict.fromkeys(truth.ids, "complete"))
    runs.insert(
        0, {"method": "Keep original", "category": "Reference", "run": 1, **run_counts(empty)}
    )
    assert len(runs) == 38
    write_csv(RUN_FILE, runs)
    (PAPER / "build/generated/false_edits_ba_source_evidence.json").write_text(
        json.dumps({"source_sha256": inputs.hashes, "runs": len(runs), "model_calls": 0}, indent=2)
        + "\n"
    )


def summarize(raw):
    groups = defaultdict(list)
    for row in raw:
        counts = {k: int(v) for k, v in row.items() if k not in {"method", "category", "run"}}
        assert counts["tables"] == 1000 and counts["clean_cells"] == 362393
        assert counts["tp"] + counts["fn"] == 1093
        assert counts["fp"] == counts["fp_clean"] + counts["wrong_at_target"]
        assert counts["table_tp"] + counts["table_fn"] == 164
        assert counts["table_tn"] + counts["table_fp"] == 836
        assert (
            counts["complete_tables"] + counts["failed_tables"] + counts["unknown_tables"] == 1000
        )
        groups[row["method"], row["category"]].append({**counts, **run_scores(counts)})
    result = []
    for (method, category), runs in groups.items():
        result.append(
            {
                "method": method,
                "category": category,
                "runs": len(runs),
                **{key: statistics.mean(r[key] for r in runs) for key in runs[0]},
            }
        )
    assert len(result) == 24
    published = {
        r["method"]: r
        for r in read_csv(GENERATED / "task_type_metrics.csv")
        if r["task"] == "e2e" and not r["method"].endswith(" (Base)")
    }
    for row in result:
        if row["method"] == "Keep original":
            assert row["fp_per_100_clean_cells"] == row["correction_recall"] == row["micro_f1"] == 0
            assert row["table_balanced_accuracy"] == 50 and row["completion"] == 100
        else:
            for key, expected in (
                ("micro_precision", "precision"),
                ("correction_recall", "recall"),
                ("micro_f1", "f1"),
            ):
                assert math.isclose(
                    row[key], float(published[row["method"]][expected]), abs_tol=1e-10
                )
    return result


def render(rows):
    indexed = {r["method"]: r for r in rows}
    lines = [
        "% Generated by tools/build_false_edits_ba_table.py; rates are averaged across retained runs.",
        r"\begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}lrrrr@{}}",
        r"\toprule",
        r"Method & \shortstack{FP/100\\clean cells $\downarrow$} & \shortstack{Corr. R\\(\%) $\uparrow$} & \shortstack{Table BA\\(\%) $\uparrow$} & \shortstack{Complete\\(\%) $\uparrow$} \\",
        r"\midrule",
    ]
    for index, (method, label) in enumerate(DISPLAY):
        if index in {1, 9}:
            lines.extend(
                [
                    r"\midrule",
                    rf"\multicolumn{{5}}{{@{{}}l}}{{\textit{{{'Constraint-based' if index == 1 else 'Reference workflows'}}}}} \\",
                ]
            )
        row = indexed[method]
        lines.append(
            f"{label} & {row['fp_per_100_clean_cells']:.4f} & {row['correction_recall']:.2f} & {row['table_balanced_accuracy']:.2f} & {row['completion']:.2f}"
            + r" \\"
        )
    return "\n".join([*lines, r"\bottomrule", r"\end{tabular*}", ""])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--refresh", action="store_true", help="Recompute from selected raw runs, offline"
    )
    args = parser.parse_args()
    if args.refresh:
        refresh()
    rows = summarize(read_csv(RUN_FILE))
    write_csv(GENERATED / "false_edits_ba_metrics.csv", rows)
    (generated_asset("false_edits_ba_table.tex", directory=GENERATED)).write_text(render(rows))
    proof = {
        "source_sha256": {
            str(p.relative_to(PAPER)): digest(p)
            for p in (RUN_FILE, GENERATED / "task_type_metrics.csv", Path(__file__))
        },
        "methods": len(rows),
        "displayed_methods": len(DISPLAY),
        "clean_cells": 362393,
        "target_tables": 164,
        "no_target_tables": 836,
        "model_calls": 0,
        "fp": "False edits of benchmark-scorable clean cells only; exclude wrong replacements at true errors.",
        "ba": "Binary table selection: positive if a table has replacement targets, predicted positive if any scored edit is made. Empty/failed outputs predict negative. BA averages TPR and TNR over all 1000 tables.",
        "completion": "Fraction of reference tables with valid completed outputs; failures remain in the scoring population.",
        "aggregation": "Compute rates within each retained run, then average rates across runs. No change to existing micro or macro metrics.",
    }
    (PAPER / "build/generated/false_edits_ba_evidence.json").write_text(
        json.dumps(proof, indent=2) + "\n"
    )
    print("Validated 24 workflows and canonical micro scores; rendered 14 table rows.")


if __name__ == "__main__":
    main()
