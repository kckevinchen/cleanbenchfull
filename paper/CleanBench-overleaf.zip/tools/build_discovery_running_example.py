"""Draw an explicitly illustrative discovery trace using Figure 1(a)'s school names."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
from collections import Counter
from pathlib import Path

from figure_style import COLUMN_WIDTH, configure, save

PAPER = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def trace(config):
    assert config["illustrative"] is True
    assert digest(PAPER / config["source_image"]) == config["source_sha256"]
    estimator = (PAPER / config["estimator_source"]).resolve()
    assert digest(estimator) == config["estimator_sha256"]
    spec = importlib.util.spec_from_file_location("running_example_chao", estimator)
    core = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = core
    spec.loader.exec_module(core)
    ids = {c["id"] for c in config["candidates"]}
    counts, history = Counter(), []
    for number, hits in enumerate(config["queries"], 1):
        assert hits and len(hits) == len(set(hits)) and set(hits) <= ids
        new = set(hits) - set(counts)
        counts.update(hits)
        stats = core.compute_core(counts.values(), num_runs=number)
        gt = stats.good_turing_missing_mass
        chao = max(0, stats.chao1_ci_95_high - len(counts)) / len(counts)
        gt_met, chao_met = gt <= config["epsilon_gt"], chao <= config["epsilon_chao"]
        stop = gt_met and chao_met
        history.append(
            dict(
                number=number,
                hits=hits,
                new=sorted(new),
                counts=dict(counts),
                merged=len(counts),
                observations=stats.total_hits,
                frequency_counts=stats.frequency_counts,
                gt=gt,
                chao_total=stats.chao1_estimated_total,
                chao_upper=stats.chao1_ci_95_high,
                chao_gap=chao,
                gt_met=gt_met,
                chao_met=chao_met,
                stop=stop,
            )
        )
        assert not stop or number == len(config["queries"])
    actual = dict(
        good_turing=next(r["number"] for r in history if r["gt_met"]),
        chao1=next(r["number"] for r in history if r["chao_met"]),
        stop=next(r["number"] for r in history if r["stop"]),
    )
    assert actual == config["expected_milestones"]
    assert set(counts) == ids and history[-1]["merged"] == 4
    return history


def render(config, history):
    import matplotlib.pyplot as plt
    from matplotlib.patches import Circle, Rectangle

    configure()
    height = 2.055
    fig = plt.figure(figsize=(COLUMN_WIDTH, height))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set(xlim=(0, COLUMN_WIDTH), ylim=(0, height))
    ax.axis("off")
    left, label_width, row_height = 0.06, 1.12, 0.195
    width = COLUMN_WIDTH - 2 * left
    col_width = (width - label_width) / len(history)
    top = height - 0.24
    texts = []

    def text(x, y, value, **kwargs):
        artist = ax.text(x, y, value, va="center", fontsize=8, **kwargs)
        texts.append(artist)
        return artist

    def cell(row, col, value=None, *, face="white", color="#263442", bold=False):
        x = left if col < 0 else left + label_width + col * col_width
        w = label_width if col < 0 else col_width
        y = top - (row + 1) * row_height
        ax.add_patch(
            Rectangle((x, y), w, row_height, facecolor=face, edgecolor="#c9d2d9", linewidth=0.35)
        )
        if value is not None:
            text(
                x + 0.035 if col < 0 else x + w / 2,
                y + row_height / 2,
                value,
                ha="left" if col < 0 else "center",
                color=color,
                weight="bold" if bold else "normal",
            )
        return x + w / 2, y + row_height / 2

    for x, filled, label in [(left + 0.04, True, "New candidate"), (1.62, False, "Rediscovery")]:
        ax.add_patch(
            Circle(
                (x, height - 0.10),
                0.035,
                facecolor="#bd654e" if filled else "white",
                edgecolor="#bd654e" if filled else "#566f86",
                linewidth=1,
            )
        )
        text(x + 0.08, height - 0.10, label, ha="left")
    cell(0, -1, "School district", face="#156082", color="white", bold=True)
    for col, result in enumerate(history):
        cell(0, col, f"Query {result['number']}", face="#156082", color="white", bold=True)
    for row, candidate in enumerate(config["candidates"], 1):
        shade = "#eaf4f8" if row % 2 else "white"
        cell(row, -1, candidate["value"].removesuffix(" School District"), face=shade)
        for col, result in enumerate(history):
            x, y = cell(row, col, face=shade)
            if candidate["id"] in result["hits"]:
                new = candidate["id"] in result["new"]
                ax.add_patch(
                    Circle(
                        (x, y),
                        0.035,
                        facecolor="#bd654e" if new else "white",
                        edgecolor="#bd654e" if new else "#566f86",
                        linewidth=1,
                    )
                )
            else:
                text(x, y, "–", ha="center", color="#aab4bd")
    for row, label in [
        (5, "Merged candidates"),
        (6, "Good–Turing"),
        (7, "Chao1 (U−S)/S"),
        (8, "Decision"),
    ]:
        cell(row, -1, label, face="#f2f4f6", bold=row in (6, 7))
    for col, result in enumerate(history):
        cell(5, col, str(result["merged"]))
        for row, key, met in [(6, "gt", "gt_met"), (7, "chao_gap", "chao_met")]:
            cell(
                row,
                col,
                f"{result[key]:.2f}",
                face="#e0f1e7" if result[met] else "white",
                color="#167349" if result[met] else "#263442",
                bold=result[met],
            )
        cell(
            8,
            col,
            "STOP" if result["stop"] else "More",
            face="#9b5d20" if result["stop"] else "white",
            color="white" if result["stop"] else "#626f7c",
            bold=result["stop"],
        )
    ax.plot([left, left + width], [top - 5 * row_height] * 2, color="#91a2ae", linewidth=0.7)
    # Check actual text bounds on this native single-column canvas.
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    bounds = fig.bbox
    for artist in texts:
        box = artist.get_window_extent(renderer)
        assert box.x0 >= bounds.x0 - 1 and box.x1 <= bounds.x1 + 1, artist.get_text()
        assert box.y0 >= bounds.y0 - 1 and box.y1 <= bounds.y1 + 1, artist.get_text()
    target = PAPER / "figures/paper/discovery_running_example.pdf"
    save(fig, target, width=COLUMN_WIDTH, check_layout=True)
    plt.close(fig)
    return target


def main():
    source = PAPER / "figures/discovery_running_example.json"
    config = json.loads(source.read_text())
    history = trace(config)
    target = render(config, history)
    folder = PAPER / "build/algorithm_running"
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "audit.json").write_text(
        json.dumps(
            dict(
                illustrative=True,
                config_sha256=digest(source),
                figure_sha256=digest(target),
                history=history,
                milestones=config["expected_milestones"],
                additional_model_calls=0,
            ),
            indent=2,
        )
        + "\n"
    )
    print("Verified illustrative milestones: Good–Turing query 5, Chao1 query 5, stop query 5.")


if __name__ == "__main__":
    main()
