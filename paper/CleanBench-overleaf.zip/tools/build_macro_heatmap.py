"""Render the macro correction table from frozen overall and error-type scores.

The roster, typography, and color scale match the existing end-to-end correction
table. The full-width table retains its method subgroups; the archived compact
summary uses four broad workflow groups. This renderer never reads predictions
or scores model outputs; all displayed values come directly from the input CSV.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from build_accuracy_presentation import CMAP, NORM, TYPES, positions
from figure_style import COLUMN_WIDTH, FIGURE_WIDTH, configure, save
from matplotlib.cm import ScalarMappable
from matplotlib.patches import Rectangle

PAPER = Path(__file__).resolve().parents[1]
GENERATED = PAPER / "assets/generated"
SOURCE = GENERATED / "macro_type_metrics.csv"
ROSTER = GENERATED / "task_type_metrics.csv"
OVERALL = GENERATED / "macro_metrics.csv"
TARGET = GENERATED / "macro_e2e_type_heatmap.pdf"
SUMMARY_TARGET = GENERATED / "macro_e2e_overall_heatmap.pdf"
BLOCKS = (("overall", "Overall macro", ("P", "R", "F1")),) + tuple(
    (key, label, ("P", "R")) for key, label in TYPES
)
FULL_BLOCKS = BLOCKS + (("overall", "Preservation", ("Preservation",)),)
FIELDS = {
    "P": "macro_precision",
    "R": "macro_recall",
    "F1": "macro_f1",
    "Preservation": "preservation",
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def score(row: dict[str, str], field: str) -> float | None:
    raw = row[field].strip()
    if not raw:
        return None
    value = float(raw)
    if not math.isfinite(value) or not 0 <= value <= 100:
        raise ValueError(f"Invalid {field} for {row['method']}: {raw}")
    return value


def inputs():
    roster = [
        row
        for row in read_csv(ROSTER)
        if row["task"] == "e2e"
        and not (row["category"] == "Direct LLMs (API)" and row["method"].endswith(" (Base)"))
    ]
    if len(roster) != 23 or len({row["method"] for row in roster}) != 23:
        raise ValueError("The correction table must contain the 23 published workflows")
    rows = read_csv(SOURCE)
    indexed = {(row["method"], row["error_type"]): row for row in rows}
    expected = {(row["method"], key) for row in roster for key, _, _ in BLOCKS}
    if len(rows) != len(expected) or indexed.keys() != expected:
        raise ValueError(
            "Macro input must contain each published workflow and all four score groups once"
        )
    overall = {row["method"]: row for row in read_csv(OVERALL)}
    for row in roster:
        method = row["method"]
        for field in FIELDS.values():
            if score(indexed[method, "overall"], field) != score(overall[method], field):
                raise ValueError(f"Overall macro score changed: {method}, {field}")
        for key, _, metrics in BLOCKS:
            for metric in metrics:
                score(indexed[method, key], FIELDS[metric])
    for key, _, _ in BLOCKS:
        counts = {int(indexed[row["method"], key]["target_tables"]) for row in roster}
        if len(counts) != 1 or not 0 < next(iter(counts)) < 1000:
            raise ValueError(f"Inconsistent target-table population: {key}, {counts}")
    preservation_counts = {
        int(indexed[row["method"], "overall"]["preservation_tables"]) for row in roster
    }
    target_count = int(indexed[roster[0]["method"], "overall"]["target_tables"])
    if preservation_counts != {1000 - target_count}:
        raise ValueError(
            "Preservation must cover the complement of the overall target-table population"
        )
    return roster, indexed


def category_label(label: str) -> str:
    if label == "Industrial":
        return "Industrial workflows"
    if label in {"Direct LLMs", "Direct LLMs (API)"}:
        return "Direct LLMs (Prompt-tuned)"
    return label


def draw(roster, indexed):
    methods, categories, extent = positions(roster)
    grid_height = extent * 0.125
    height = grid_height + 0.86
    fig = plt.figure(figsize=(FIGURE_WIDTH, height))
    left, width, top = 0.29, 0.70, 1 - 0.53 / height
    ax = fig.add_axes([left, top - grid_height / height, width, grid_height / height])
    starts = []
    end = 0.0
    for _, label, metrics in FULL_BLOCKS:
        starts.append(end)
        end += (1.5 if label == "Preservation" else len(metrics)) + 0.16
    xmax = end - 0.16
    label_x = (0.01 - left) / width * xmax
    label_pad = 0.04 / (width * FIGURE_WIDTH) * xmax
    ink = "#253342"
    ax.set_xlim(0, xmax)
    ax.set_ylim(extent, 0)
    ax.axis("off")
    for y, thickness in ((-3.35, 0.8), (-0.05, 0.6), (extent, 0.8)):
        ax.plot([label_x, xmax], [y, y], color=ink, linewidth=thickness, clip_on=False)
    for start, (key, label, metrics) in zip(starts, FULL_BLOCKS, strict=True):
        block_width = 1.5 if label == "Preservation" else len(metrics)
        center = start + block_width / 2
        ax.text(
            center,
            -2.75,
            label,
            ha="center",
            va="center",
            weight="bold",
            color=ink,
        )
        population_field = "preservation_tables" if label == "Preservation" else "target_tables"
        population = int(indexed[roster[0]["method"], key][population_field])
        ax.text(center, -1.72, f"n = {population}", ha="center", va="center", color=ink)
        ax.plot(
            [start + 0.05, start + block_width - 0.05],
            [-1.20, -1.20],
            color="#a8b2bd",
            linewidth=0.45,
            clip_on=False,
        )
        for index, metric in enumerate(metrics):
            x = center if metric == "Preservation" else start + index + 0.5
            ax.text(
                x,
                -0.66,
                "(%)" if metric == "Preservation" else metric,
                ha="center",
                va="center",
                color=ink,
            )
    ax.text(label_x + label_pad, -0.66, "Method", ha="left", va="center", weight="bold", color=ink)
    for y, label in categories:
        ax.add_patch(
            Rectangle(
                (label_x, y - 0.4),
                xmax - label_x,
                0.8,
                facecolor="#edf1f5",
                edgecolor="none",
                clip_on=False,
            )
        )
        ax.text(
            label_x + label_pad,
            y,
            category_label(label),
            ha="left",
            va="center",
            weight="bold",
            color=ink,
        )
    displayed = []
    for y, row in methods:
        method = row["method"]
        display_method = method.removesuffix(" (Prompt-tuned)")
        ax.text(label_x + label_pad, y, display_method, ha="left", va="center")
        ax.plot(
            [label_x, xmax],
            [y + 0.5, y + 0.5],
            color="#e4e9ee",
            linewidth=0.3,
            clip_on=False,
            zorder=0,
        )
        for start, (key, _, metrics) in zip(starts, FULL_BLOCKS, strict=True):
            for index, metric in enumerate(metrics):
                value = score(indexed[method, key], FIELDS[metric])
                text = "—" if value is None else format(value, ".2f" if key == "overall" else ".1f")
                x = start + index
                cell_width = 1.5 if metric == "Preservation" else 1
                ax.add_patch(
                    Rectangle(
                        (x, y - 0.5),
                        cell_width,
                        1,
                        facecolor="white" if value is None else CMAP(NORM(value)),
                        edgecolor="white",
                        linewidth=0.45,
                    )
                )
                ax.text(
                    x + cell_width / 2,
                    y,
                    text,
                    ha="center",
                    va="center",
                    color="white" if value is not None and value >= 80 else "black",
                    weight="bold" if key == "overall" else "normal",
                )
                displayed.append(
                    {
                        "method": method,
                        "error_type": key,
                        "metric": metric,
                        "value": value,
                        "text": text,
                    }
                )
    color_ax = fig.add_axes([0.75, 0.22 / height, 0.22, 0.065 / height])
    bar = fig.colorbar(ScalarMappable(norm=NORM, cmap=CMAP), cax=color_ax, orientation="horizontal")
    bar.solids.set_rasterized(False)
    bar.solids.set_edgecolor("face")
    bar.set_ticks([0, 50, 100])
    bar.ax.tick_params(length=2, pad=2)
    bar.ax.text(-0.10, 0.5, "Score (%)", ha="right", va="center", transform=bar.ax.transAxes)
    bar.outline.set_linewidth(0.4)
    save(fig, TARGET, check_layout=True)
    plt.close(fig)
    return displayed, height


def draw_overall(roster, indexed):
    """Summarize all workflows at native single-column width for the short paper."""
    rows = [dict(row, category=indexed[row["method"], "overall"]["group"]) for row in roster]
    methods, categories, extent = positions(rows)
    grid_height = extent * 0.125
    height = grid_height + 0.44
    fig = plt.figure(figsize=(COLUMN_WIDTH, height))
    left, width, top = 0.55, 0.44, 1 - 0.17 / height
    ax = fig.add_axes([left, top - grid_height / height, width, grid_height / height])
    label_x = (0.01 - left) / width * 3
    label_pad = 0.04 / (width * COLUMN_WIDTH) * 3
    ink = "#253342"
    ax.set_xlim(0, 3)
    ax.set_ylim(extent, 0)
    ax.axis("off")
    for y, thickness in ((-1.1, 0.8), (-0.05, 0.6), (extent, 0.8)):
        ax.plot([label_x, 3], [y, y], color=ink, linewidth=thickness, clip_on=False)
    ax.text(label_x + label_pad, -0.55, "Method", ha="left", va="center", weight="bold", color=ink)
    metrics = ("P", "R", "F1")
    for index, metric in enumerate(metrics):
        ax.text(index + 0.5, -0.55, metric, ha="center", va="center", weight="bold", color=ink)
    for y, label in categories:
        ax.add_patch(
            Rectangle(
                (label_x, y - 0.4),
                3 - label_x,
                0.8,
                facecolor="#edf1f5",
                edgecolor="none",
                clip_on=False,
            )
        )
        label = "Industrial workflows" if label == "Industrial" else category_label(label)
        ax.text(label_x + label_pad, y, label, ha="left", va="center", weight="bold", color=ink)
    displayed = []
    for y, row in methods:
        method = row["method"]
        ax.text(
            label_x + label_pad,
            y,
            method.removesuffix(" (Prompt-tuned)"),
            ha="left",
            va="center",
        )
        ax.plot(
            [label_x, 3],
            [y + 0.5, y + 0.5],
            color="#e4e9ee",
            linewidth=0.3,
            clip_on=False,
            zorder=0,
        )
        for index, metric in enumerate(metrics):
            value = score(indexed[method, "overall"], FIELDS[metric])
            text = "—" if value is None else f"{value:.2f}"
            ax.add_patch(
                Rectangle(
                    (index, y - 0.5),
                    1,
                    1,
                    facecolor="white" if value is None else CMAP(NORM(value)),
                    edgecolor="white",
                    linewidth=0.45,
                )
            )
            ax.text(
                index + 0.5,
                y,
                text,
                ha="center",
                va="center",
                color="white" if value is not None and value >= 80 else "black",
                weight="bold",
            )
            displayed.append(
                {
                    "method": method,
                    "error_type": "overall",
                    "metric": metric,
                    "value": value,
                    "text": text,
                }
            )
    color_ax = fig.add_axes([0.66, 0.17 / height, 0.30, 0.065 / height])
    bar = fig.colorbar(ScalarMappable(norm=NORM, cmap=CMAP), cax=color_ax, orientation="horizontal")
    bar.solids.set_rasterized(False)
    bar.solids.set_edgecolor("face")
    bar.set_ticks([0, 50, 100])
    bar.ax.tick_params(length=2, pad=2)
    bar.ax.text(-0.10, 0.5, "Target macro (%)", ha="right", va="center", transform=bar.ax.transAxes)
    bar.outline.set_linewidth(0.4)
    save(fig, SUMMARY_TARGET, width=COLUMN_WIDTH, check_layout=True)
    plt.close(fig)
    return displayed, height


def main():
    configure()
    roster, indexed = inputs()
    displayed, height = draw(roster, indexed)
    if len(displayed) != 23 * 10:
        raise ValueError("The rendered table must contain ten metrics for each of the 23 workflows")
    evidence = {
        "sources_sha256": {
            path.name: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in (SOURCE, ROSTER, OVERALL)
        },
        "workflows": len(roster),
        "numeric_cells": sum(row["value"] is not None for row in displayed),
        "undefined_cells": sum(row["value"] is None for row in displayed),
        "width_inches": FIGURE_WIDTH,
        "height_inches": height,
        "font_size_bp": 8,
        "target_tables": {
            key: int(indexed[roster[0]["method"], key]["target_tables"]) for key, _, _ in BLOCKS
        },
        "preservation_tables": int(indexed[roster[0]["method"], "overall"]["preservation_tables"]),
        "displayed_values": displayed,
    }
    destination = PAPER / "build/generated/macro_heatmap_evidence.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(evidence, indent=2) + "\n", encoding="utf-8")
    summary, summary_height = draw_overall(roster, indexed)
    if len(summary) != 23 * 3:
        raise ValueError(
            "The macro summary must contain three metrics for each of the 23 workflows"
        )
    summary_evidence = {
        **evidence,
        "numeric_cells": sum(row["value"] is not None for row in summary),
        "undefined_cells": sum(row["value"] is None for row in summary),
        "width_inches": COLUMN_WIDTH,
        "height_inches": summary_height,
        "displayed_values": summary,
    }
    destination.with_name("macro_overall_heatmap_evidence.json").write_text(
        json.dumps(summary_evidence, indent=2) + "\n", encoding="utf-8"
    )
    print(
        f"Rendered {len(roster)} workflows and {len(displayed)} scores: {TARGET.relative_to(PAPER)}"
    )
    print(f"Rendered {len(summary)} overall scores: {SUMMARY_TARGET.relative_to(PAPER)}")


if __name__ == "__main__":
    main()
