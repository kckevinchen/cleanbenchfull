"""Check diagnostic complements and reported repair values without rescaling."""

import pytest
from build_false_edits_ba_heatmap import extend, reported_repairs


def baseline(**updates):
    return {
        "table_tp": 0,
        "table_fn": 164,
        "table_tn": 836,
        "table_fp": 0,
        "fp_per_100_clean_cells": 0,
        "table_balanced_accuracy": 50,
        **updates,
    }


def test_quiet_control_keeps_its_fifty_percent_selection_baseline():
    r = extend(baseline(), [0, 0])
    assert r["clean_kept"] == r["table_tnr"] == 100
    assert r["table_tpr"] == r["repair_precision"] == r["repair_recall"] == 0


def test_tiny_false_edit_rates_remain_distinguishable_from_zero():
    r = extend(baseline(fp_per_100_clean_cells=0.0038632092783249124), [0, 0])
    assert 99.99 < r["clean_kept"] < 100
    assert format(r["clean_kept"], ".3f") == "99.996"


def test_class_rates_must_match_the_existing_balanced_accuracy():
    r = extend(baseline(table_tp=82, table_fn=82, table_balanced_accuracy=75), None)
    assert r["table_tpr"] == 50 and r["table_tnr"] == 100
    assert r["repair_precision"] is r["repair_recall"] is None
    with pytest.raises(AssertionError):
        extend(baseline(table_tp=82, table_fn=82), None)


def test_supplied_location_precision_is_not_inflated_or_substituted_for_recall():
    r = extend(baseline(), [80, 0.73])
    assert r["repair_precision"] == 80 and r["repair_recall"] == 0.73
    assert r["table_balanced_accuracy"] == 50


def test_reported_repair_rows_are_read_without_including_headers():
    rows = reported_repairs("Method & P & R & F1 \\\\\nNADEEF & 80.00 & 0.73 & 1.45 \\\\\n")
    assert rows == {"NADEEF": [80, 0.73]}
