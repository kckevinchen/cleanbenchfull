"""Check zero-denominator cases and independent averaging of per-table F1."""

import pytest
from build_defined_macro_results import average_defined, table_scores


@pytest.mark.parametrize(
    "counts, expected",
    [
        ((0, 0, 0), (None, None, None)),
        ((0, 0, 3), (None, 0, 0)),
        ((0, 2, 0), (0, None, 0)),
        ((2, 1, 2), (2 / 3, 1 / 2, 4 / 7)),
    ],
)
def test_table_cases(counts, expected):
    result = table_scores(dict(zip(("tp", "fp", "fn"), counts, strict=True)))
    assert tuple(result.values()) == expected


def test_empty_tables_neither_raise_scores_nor_hide_false_alarms():
    rows = [table_scores(dict(tp=1, fp=0, fn=0)), table_scores(dict(tp=0, fp=3, fn=0))]
    rows.extend([table_scores(dict(tp=0, fp=0, fn=0))] * 100)
    assert average_defined(row["precision"] for row in rows) == (50, 2)
    assert average_defined(row["recall"] for row in rows) == (100, 1)
    assert average_defined(row["f1"] for row in rows) == (50, 2)
    assert average_defined([None, None]) == (None, 0)
