"""Build traditional reference points from matching saved quality and timing data.

Fresh triples use native batch logs or per-table job receipts. Methods without a
complete new triple use the original references. CPU charges use the configured
worker-hour rate; this report performs no inference.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import re
import statistics
from pathlib import Path

from build_error_types import IDENTITY

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parent
CONFIG = PAPER / "figures/traditional_resource_estimates.json"
TARGET = PAPER / "assets/generated/price_quality_traditional.csv"


def fresh_timing(run, read, raw):
    folder = Path(run["identity"])
    receipt = read(folder / "receipt.json", run["receipt_sha256"])
    if receipt["status"] != "complete" or receipt["tables"] != 1000:
        raise ValueError("Resource points require complete 1,000-table trials")
    if run["method"] in {"SymSpell", "NeuSpell"}:
        text = raw(folder / "native.log", receipt["output_sha256"]["native.log"]).decode()
        matches = re.findall(
            rf"^\s*{run['method'].lower()}: (\d+) cells flagged in ([0-9.]+)s$", text, re.M
        )
        if len(matches) != 1 or float(matches[0][1]) <= 0:
            raise ValueError("Native spell-checker processing time is missing")
        return dict(
            seconds=float(matches[0][1]),
            timing_kind="recorded_native_batch_elapsed",
            failed=0,
            jobs=1,
        )
    root = folder.parent.parent
    protocol = read(root / "protocol.json", receipt["protocol_sha256"])
    slug = folder.parent.name
    durations = []
    for dataset in sorted(
        read(ROOT / "outputs/baseline_campaign/20260910/snapshot/_manifest.json")["datasets"]
    ):
        name = f"{slug}__run{run['run']}__{dataset}"
        job = read(root / "jobs" / name / "receipt.json")
        elapsed = job["finished_at"] - job["started_at"]
        if not math.isfinite(elapsed) or elapsed <= 0:
            raise ValueError("Native job timing is invalid")
        if name not in protocol["bindings"]:
            raise ValueError("Timing job is not bound to the frozen trial")
        durations.append(elapsed)
    if len(durations) != 1000:
        raise ValueError("Native timing excludes benchmark tables")
    return dict(
        seconds=sum(durations),
        timing_kind="recorded_repeated_local_job_elapsed",
        failed=len(receipt["failed"]),
        jobs=1000,
    )


def repeated_resource_row(method, trials, rate, read, raw):
    if (
        len(trials) != 3
        or {r["run"] for r in trials} != {1, 2, 3}
        or len({r["identity"] for r in trials}) != 3
    ):
        raise ValueError("Resource replacement requires three independent trials")
    timings = [fresh_timing(run, read, raw) for run in trials]
    kinds = {timing["timing_kind"] for timing in timings}
    if len(kinds) != 1:
        raise ValueError("Resource trials use different timing definitions")
    seconds = statistics.mean(t["seconds"] for t in timings)
    return dict(
        task="e2e",
        model=method,
        configuration=str(Path(trials[0]["identity"]).parent.relative_to(ROOT)),
        f1_percent=statistics.mean(r["metrics"]["f1"] for r in trials),
        recorded_cost_usd="",
        estimated_cost_usd=seconds / 3600 * rate,
        mean_seconds_per_table=seconds / 1000,
        tables_per_run=1000,
        repetitions=3,
        timing_kind=kinds.pop(),
        timing_tables_recorded=3000,
        failed_jobs_included=sum(t["failed"] for t in timings),
        cpu_worker_usd_per_hour=rate,
    ), timings


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group()
    source.add_argument("--baseline-repeat-root", type=Path)
    source.add_argument("--recompute-original", action="store_true")
    args = parser.parse_args()
    if not (args.baseline_repeat_root or args.recompute_original) and TARGET.exists():
        print("Using published traditional resource references; no historical values overwritten.")
        return
    sources = {}

    def raw(path, expected=None):
        data = path.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        assert expected is None or digest == expected, path
        sources[str(path.relative_to(ROOT))] = digest
        return data

    def read(path, expected=None):
        return json.loads(raw(path, expected))

    config = read(CONFIG)
    replacements = {}
    if args.baseline_repeat_root:
        from repetition_inputs import load_baseline_runs, replacement_groups

        fresh = [
            r
            for r in load_baseline_runs(args.baseline_repeat_root)
            if r["method"] in config["methods"]
        ]
        replacements = replacement_groups(fresh, set(config["methods"]))
    folder = ROOT / config["selection_folder"]
    presentation = read(folder / "presentation_selection.json")
    selected = read(folder / "selected_results.json", presentation["source_manifest_sha256"])
    snapshot = ROOT / config["snapshot"]
    manifest = read(snapshot / "_manifest.json")
    datasets = manifest["datasets"]
    assert len(datasets) == 1000
    textual = cells = 0
    for ds, meta in datasets.items():
        text = raw(snapshot / ds / "dirty.csv", meta["dirty_sha256"]).decode("utf-8-sig")
        rows = list(csv.reader(io.StringIO(text)))
        assert rows[0] == meta["columns"] and len(rows) - 1 == meta["n_rows"]
        for row in rows[1:]:
            assert len(row) == meta["n_cols"]
            cells += len(row)
            textual += sum(bool(re.search("[A-Za-z]", value)) for value in row)
    assert cells == 364804 and textual == 138344
    notes = raw(ROOT / config["spellchecker_timing_source"]).decode()
    assert "~57k textual cells" in notes and "~17 min on CPU; SymSpell ~3s" in notes
    rows, audit = [], {}
    for method in config["methods"]:
        if method in replacements:
            row, timings = repeated_resource_row(
                method, replacements[method], config["cpu_worker_usd_per_hour"], read, raw
            )
            rows.append(row)
            audit[method] = {"independent_trials": timings, "runs": 3}
            continue
        entries = [r for r in presentation["main"]["e2e"] if r["method"] == method]
        assert len(entries) == 1
        entry = entries[0]
        matches = [r for r in selected["rows"] if all(r.get(k) == entry.get(k) for k in IDENTITY)]
        assert len(matches) == 1
        chosen = matches[0]
        assert chosen["analysis"]["full"] == entry["metrics"]
        prediction = Path(chosen["prediction_path"])
        if not prediction.is_absolute():
            prediction = ROOT / prediction
        raw(prediction, chosen["prediction_sha256"])
        metrics = entry["metrics"]
        assert metrics["tp"] + metrics["fn"] == 1093
        assert math.isclose(
            metrics["f1"], 2 * metrics["tp"] / (2 * metrics["tp"] + metrics["fp"] + metrics["fn"])
        )
        failures = ""
        if method in config["historical_seconds_approx"]:
            seconds = (
                config["historical_seconds_approx"][method]
                * textual
                / config["historical_textual_cells_approx"]
            )
            timing_kind = "estimated_from_historical_cpu_notes"
            timing_tables = 0
        else:
            timing = config["local_job_timing"][method]
            assert entry["configuration"] == timing["configurations"][-1]
            campaign = ROOT / "outputs/baseline_campaign/20260910"
            durations, failed = [], 0
            final_statuses = []
            for ds in datasets:
                status = None
                for configuration in timing["configurations"]:
                    path = campaign / "native" / configuration / "tables" / f"{ds}.json"
                    if not path.exists():
                        continue
                    record = read(path)
                    receipt = read(campaign / "jobs" / f"{configuration}__{ds}" / "receipt.json")
                    assert record["dataset"] == ds and record["status"] == receipt["status"]
                    assert receipt["started_at"] <= record["started_at"] <= receipt["finished_at"]
                    if "finished_at" in record:
                        assert (
                            record["started_at"] <= record["finished_at"] <= receipt["finished_at"]
                        )
                    duration = receipt["finished_at"] - receipt["started_at"]
                    assert math.isfinite(duration) and duration > 0
                    durations.append(duration)
                    status = record["status"]
                    if status == "complete":
                        assert (
                            receipt["artifacts"][str(path)] == sources[str(path.relative_to(ROOT))]
                        )
                    else:
                        assert status == "needs_investigation"
                        failed += 1
                assert status is not None, ds
                final_statuses.append(status)
            assert len(durations) == timing["expected_jobs"]
            assert failed == timing["expected_failed_jobs"]
            assert final_statuses.count("complete") == metrics["execution"]["complete"]
            assert final_statuses.count("needs_investigation") == metrics["execution"]["failed"]
            seconds, failures = sum(durations), failed
            timing_kind, timing_tables = "recorded_local_job_elapsed", len(datasets)
            audit[method] = {
                "mean_seconds": seconds / len(datasets),
                "jobs_included": len(durations),
                "failed_jobs_included": failed,
            }
        assert seconds > 0
        rows.append(
            dict(
                task="e2e",
                model=method,
                configuration=entry["configuration"],
                f1_percent=100 * metrics["f1"],
                recorded_cost_usd="",
                estimated_cost_usd=seconds / 3600 * config["cpu_worker_usd_per_hour"],
                mean_seconds_per_table=seconds / 1000,
                tables_per_run=1000,
                repetitions=1,
                timing_kind=timing_kind,
                timing_tables_recorded=timing_tables,
                failed_jobs_included=failures,
                cpu_worker_usd_per_hour=config["cpu_worker_usd_per_hour"],
            )
        )
    evidence = dict(
        config=config,
        source_sha256=sources,
        rows=rows,
        snapshot_cells=cells,
        snapshot_textual_cells=textual,
        audit=audit,
    )
    out = PAPER / "build/price_quality/traditional_evidence.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(evidence, indent=2) + "\n")
    with TARGET.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({"textual_cells": textual, "rows": rows}, indent=2))


if __name__ == "__main__":
    main()
