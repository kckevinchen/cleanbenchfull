"""Render P/R tables, source comparisons, size trends, and appendix tables.

Uses frozen aggregate CSVs only; does not rescore predictions or call models.
Figures use the shared font at their intended single- or double-column width.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path

import matplotlib
from build_false_edits_ba_table import summarize
from experiment_presentation import method_category, reported_method

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from figure_style import COLUMN_WIDTH, FIGURE_WIDTH, WORKFLOW_COLORS, configure, save
from matplotlib.cm import ScalarMappable
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle

if __package__:
    from .tex_sources import generated_asset
else:
    from tex_sources import generated_asset

PAPER = Path(__file__).resolve().parents[1]
GENERATED = PAPER / "assets/generated"
TASKS = {"e2e": "End-to-end correction", "detection": "Detection only"}
TYPES = (
    ("typo-spelling", "Spelling"),
    ("typo-formatting", "Formatting"),
    ("inconsistency", "Inconsistency"),
)
BUCKETS = {
    "columns": ("2-4", "5-8", "9-20"),
    "rows": ("10-24", "25-49", "50-100"),
    "source": ("Relational", "Spreadsheet"),
}
CMAP = LinearSegmentedColormap.from_list("cleanbench", ["#ffffff", "#145687"])
NORM = Normalize(0, 100)
ROW_INCHES = 0.145
SIZE_BANDWIDTH = {"columns": 2.0, "rows": 10.0}
CATEGORY_LABELS = {
    "Constraint-based": "Constraint-based data cleaning",
    "Knowledge-based": "Knowledge-based data cleaning",
    "Dictionary lookup": "Spelling correction methods",
    "Pretrained models/checks": "Spelling correction methods",
    "LLM workflows": "LLM-prompt cleaning",
    "Industrial workflows": "Commercial systems",
    "Direct LLMs (API)": "LLM-agent optimized with feedback",
    "Coding agents": "Coding agents",
}


def read(name):
    with (generated_asset(name, directory=GENERATED)).open() as handle:
        return list(csv.DictReader(handle))


def positions(rows, *, category_height=0.80):
    """Give each method a full tile row and categories a separate label row."""
    grouped = {}
    for row in rows:
        category = method_category(row["method"], row["category"])
        category = CATEGORY_LABELS.get(category, category)
        grouped.setdefault(category, []).append(row)
    order = list(grouped)
    spelling = CATEGORY_LABELS["Dictionary lookup"]
    knowledge = CATEGORY_LABELS["Knowledge-based"]
    if spelling in order and knowledge in order:
        order.remove(spelling)
        order.insert(order.index(knowledge) + 1, spelling)
    commercial = CATEGORY_LABELS["Industrial workflows"]
    if commercial in order:
        order.remove(commercial)
        order.append(commercial)

    y = 0
    methods, categories = [], []
    for category in order:
        categories.append((y + category_height / 2, category))
        y += category_height
        for row in grouped[category]:
            methods.append((y + 0.5, row))
            y += 1
    return methods, categories, y


def panel(
    fig,
    rows,
    groups,
    values,
    left,
    width,
    top,
    height,
    title=None,
    highlight_group=None,
    label_left=0.01,
    metrics_by_group=None,
    header_legend=False,
    category_height=0.80,
    method_labels=None,
    deviations=None,
    review_methods=None,
):
    methods, categories, extent = positions(rows, category_height=category_height)
    method_labels = method_labels or {}
    ax = fig.add_axes([left, top - height, width, height])
    metrics_by_group = metrics_by_group or [("P", "R") for _ in groups]
    assert len(metrics_by_group) == len(groups)
    starts, end = [], 0.0
    for metrics in metrics_by_group:
        starts.append(end)
        end += len(metrics) + 0.16
    xmax = end - 0.16
    ax.set_xlim(0, xmax)
    ax.set_ylim(extent, 0)
    ax.axis("off")
    # Use the full method-plus-metric width for table rules and category bands.
    # Labels are anchored to the page grid, not to the right edge of their text.
    label_x = (label_left - left) / width * xmax
    label_pad = 0.04 / (width * FIGURE_WIDTH) * xmax
    ink = "#253342"
    ax.plot(
        [0 if header_legend else label_x, xmax],
        [-2.45, -2.45],
        color=ink,
        linewidth=0.8,
        clip_on=False,
    )
    ax.plot([label_x, xmax], [-0.05, -0.05], color=ink, linewidth=0.6, clip_on=False)
    ax.plot([label_x, xmax], [extent, extent], color=ink, linewidth=0.8, clip_on=False)
    if title:
        ax.text(
            (label_x / xmax + 1) / 2,
            1 + 0.43 / (height * fig.get_figheight()),
            title,
            transform=ax.transAxes,
            ha="center",
            va="bottom",
            weight="bold",
        )
    for start, label, metrics in zip(starts, groups, metrics_by_group, strict=True):
        ax.text(
            start + len(metrics) / 2,
            -1.85,
            label,
            ha="center",
            va="center",
            weight="bold",
            color=ink,
        )
        ax.plot(
            [start + 0.05, start + len(metrics) - 0.05],
            [-1.26, -1.26],
            color="#a8b2bd",
            linewidth=0.45,
            clip_on=False,
        )
        for j, metric in enumerate(metrics):
            ax.text(start + j + 0.5, -0.66, metric, ha="center", va="center", color=ink)
    ax.text(label_x + label_pad, -0.66, "Method", ha="left", va="center", weight="bold", color=ink)
    for y, label in categories:
        ax.add_patch(
            Rectangle(
                (label_x, y - category_height / 2),
                xmax - label_x,
                category_height,
                facecolor="#edf1f5",
                edgecolor="none",
                clip_on=False,
            )
        )
        ax.text(
            label_x + label_pad,
            y,
            CATEGORY_LABELS.get(label, label.removesuffix(" (API)")),
            ha="left",
            va="center",
            weight="bold",
            color=ink,
        )
    for y, row in methods:
        reviewed = row["method"] in (review_methods or ())
        method = row["method"]
        if row["category"] == "Direct LLMs (API)":
            method = method.removesuffix(" (Prompt-tuned)")
        ax.text(label_x + label_pad, y, method_labels.get(method, method), ha="left", va="center", color="blue" if reviewed else "black")
        ax.plot(
            [label_x, xmax],
            [y + 0.5, y + 0.5],
            color="#e4e9ee",
            linewidth=0.3,
            clip_on=False,
            zorder=0,
        )
        scores = values(row)
        row_deviations = deviations(row) if deviations is not None else None
        spreads = row_deviations if row_deviations is not None else [None] * len(scores)
        columns = [
            (start + index, group == highlight_group, metric)
            for start, group, metrics in zip(starts, groups, metrics_by_group, strict=True)
            for index, metric in enumerate(metrics)
        ]
        assert len(scores) == len(columns)
        for value, spread, (x, highlighted, metric) in zip(scores, spreads, columns, strict=True):
            assert 0 <= value <= 100
            shaded = metric != "FPR ↓"
            ax.add_patch(
                Rectangle(
                    (x, y - 0.5),
                    1,
                    1,
                    facecolor=CMAP(NORM(value)) if shaded and not reviewed else "white",
                    edgecolor="white",
                    linewidth=0.45,
                )
            )
            if row_deviations is not None:
                places = 3 if not shaded else 2 if highlighted else 1
                deviation = r"\mathrm{—}" if spread is None else rf"\pm {spread:.{places}f}"
                display = rf"${value:.{places}f}_{{{deviation}}}$"
            else:
                display = (
                    f"{value:.4f}"
                    if not shaded
                    else f"{value:.2f}"
                    if highlighted
                    else f"{value:.1f}"
                )
            ax.text(
                x + 0.5,
                y,
                display,
                ha="center",
                va="center",
                color="blue" if reviewed else "white" if shaded and value >= 80 else "black",
                weight="bold" if highlighted else "normal",
            )
    return ax


def colorbar(fig, left, bottom, width, label="P/R (%)"):
    ax = fig.add_axes([left, bottom, width, 0.065 / fig.get_figheight()])
    bar = fig.colorbar(ScalarMappable(norm=NORM, cmap=CMAP), cax=ax, orientation="horizontal")
    # Keep the gradient vector-based too; Matplotlib otherwise rasterizes it.
    bar.solids.set_rasterized(False)
    bar.solids.set_edgecolor("face")
    bar.set_ticks([0, 50, 100])
    bar.ax.tick_params(length=2, pad=2)
    bar.ax.text(-0.10, 0.5, label, ha="right", va="center", transform=bar.ax.transAxes)
    bar.outline.set_linewidth(0.4)


def e2e_table_rows(roster, raw_runs):
    """Join unchanged P/R/F1 and type recall with clean-cell FPR by method."""
    rates = {row["method"]: row for row in summarize(raw_runs)}
    result = []
    for row in roster:
        if (
            row["task"] != "e2e"
            or row["method"].endswith(" (Base)")
            or not reported_method(row["method"])
        ):
            continue
        rate = rates[row["method"]]
        assert int(row["repetitions"]) == rate["runs"]
        result.append(
            {
                **row,
                "fpr": rate["fp_per_100_clean_cells"],
                "mean_fp_clean": rate["fp_clean"],
                "clean_cells": rate["clean_cells"],
            }
        )
    assert len(result) == 21
    return result


def e2e_display_rows(roster, types, recompute=False):
    """Redraw published run means unless historical inputs are explicitly requested."""
    if not recompute and (GENERATED / "e2e_table_point.csv").exists():
        rows = read("e2e_table_point.csv")
        variability = {row["method"]: row for row in read("e2e_table_variability.csv")}
        methods = {row["method"] for row in e2e_table_rows(roster, read("false_edits_ba_runs.csv"))}
        if len(rows) != 21 or {row["method"] for row in rows} != methods:
            raise ValueError("Saved point estimates do not cover the Table 3 methods")
        metrics = ("precision", "recall", "f1", "fpr", *(f"recall_{kind}" for kind, _ in TYPES))
        for row in rows:
            other = variability[row["method"]]
            if int(row["repetitions"]) != int(other["repetitions"]) or any(
                not math.isclose(float(row[key]), float(other[key]), abs_tol=1e-10)
                for key in metrics
            ):
                raise ValueError("Saved Table 3 point and variability summaries differ")
        return rows
    rows = e2e_table_rows(roster, read("false_edits_ba_runs.csv"))
    for row in rows:
        for kind, _ in TYPES:
            assert math.isclose(
                row["mean_fp_clean"],
                float(types["e2e", row["method"], kind]["shared_background_fp"]),
            )
    return rows


def draw_types(roster, types, tasks=None, recompute_e2e=False):
    for task in TASKS if tasks is None else tasks:
        # Main task tables use the optimized prompts and display model names.
        # Keep the complete frozen roster for source and supporting analyses.
        rows = [
            r
            for r in roster
            if r["task"] == task
            and reported_method(r["method"])
            and not (r["category"] == "Direct LLMs (API)" and r["method"].endswith(" (Base)"))
        ]
        if task == "e2e":
            rows = e2e_display_rows(roster, types, recompute_e2e)
            if not recompute_e2e and (GENERATED / "e2e_table_point.csv").exists():
                # Use the same renderer as --refresh-point to preserve its layout.
                from build_e2e_variance_table import draw as draw_published

                draw_published(rows, show_variance=False)
                continue
            if recompute_e2e or not (GENERATED / "e2e_table_point.csv").exists():
                with (GENERATED / "e2e_table_metrics.csv").open("w", newline="") as handle:
                    writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
                    writer.writeheader()
                    writer.writerows(rows)
        category_height = 0.88 if task == "e2e" else 0.80
        extent = positions(rows, category_height=category_height)[2]
        grid_height = extent * (0.12 if task == "e2e" else ROW_INCHES)
        height = grid_height + (0.41 if task == "e2e" else 0.76)
        fig = plt.figure(figsize=(FIGURE_WIDTH, height))

        def values(row):
            if task == "e2e":
                return [float(row[m]) for m in ("precision", "recall", "f1", "fpr")] + [
                    float(row[f"recall_{kind}"]) for kind, _ in TYPES
                ]
            return [float(row[m]) for m in ("precision", "recall")] + [
                float(types[task, row["method"], t][m])
                for t, _ in TYPES
                for m in ("precision", "recall")
            ]

        panel(
            fig,
            rows,
            ["Overall (%)"] + [name for _, name in TYPES],
            values,
            left=0.29,
            width=0.70,
            top=1 - (0.39 if task == "e2e" else 0.43) / height,
            height=grid_height / height,
            highlight_group="Overall (%)",
            header_legend=task == "e2e",
            category_height=category_height,
            method_labels=(
                {
                    "Excel": "Microsoft Excel Clean Data",
                    "Google Sheets": "Google Sheets Smart Cleanup",
                }
                if task == "e2e"
                else None
            ),
            metrics_by_group=(
                [("P ↑", "R ↑", r"$F_1$ ↑", "FPR ↓"), ("R ↑",), ("R ↑",), ("R ↑",)]
                if task == "e2e"
                else None
            ),
        )
        colorbar(
            fig,
            72 / (72 * FIGURE_WIDTH) if task == "e2e" else 0.75,
            1 - 10 / (72 * height) if task == "e2e" else 0.22 / height,
            70 / (72 * FIGURE_WIDTH) if task == "e2e" else 0.22,
            label=r"P/R/$F_1$ (%)" if task == "e2e" else "P/R (%)",
        )
        save(fig, PAPER / "figures/paper" / f"{task}_type_heatmap.pdf", check_layout=task == "e2e")
        plt.close(fig)


def draw_sources(roster, strata):
    """Compare the two source scores directly, using all applicable methods.

    Each point is a method, not a mean across methods. The equality line
    reveals the direction of each source difference. Labels are fixed reference
    workflows discussed in the text, not a performance-based selection.
    """
    configure(font_size=8)
    styles = {
        "Direct LLMs (API)": ("o", WORKFLOW_COLORS["Direct LLMs (API)"]),
        "Coding agents": ("s", WORKFLOW_COLORS["Coding agents"]),
        "Other workflows": ("D", WORKFLOW_COLORS["Other workflows"]),
    }
    labels = {
        "GPT-6-astra (Prompt-tuned)": "Astra API",
        "GPT-6-astra (Copilot)": "Astra/Copilot",
        "Excel": "Excel",
        "NeuSpell": "NeuSpell",
    }
    # Text offsets separate nearby reference points without changing coordinates.
    offsets = {
        ("detection", "precision"): [(-4, -12), (-8, 8), (5, 5), (5, 14)],
        ("detection", "recall"): [(-7, -9), (-2, 9), (4, -3), (5, 11)],
        ("e2e", "precision"): [(-5, -13), (5, 7), (4, -5), (5, 13)],
        ("e2e", "recall"): [(-3, 8), (4, 12), (5, -4), (5, 7)],
    }
    fig, axes = plt.subplots(2, 2, figsize=(COLUMN_WIDTH, 3.05), sharex=True, sharey=True)
    fig.subplots_adjust(left=0.17, right=0.98, bottom=0.23, top=0.82, wspace=0.30, hspace=0.56)
    evidence = []
    for i, task in enumerate(("detection", "e2e")):
        rows = [r for r in roster if r["task"] == task and reported_method(r["method"])]
        for j, metric in enumerate(("precision", "recall")):
            ax = axes[i, j]
            ax.plot([0, 100], [0, 100], color="#aab6c0", lw=0.7, ls="--", zorder=0)
            for row in rows:
                x, y = [
                    float(strata[task, row["method"], "source", b][metric])
                    for b in BUCKETS["source"]
                ]
                assert 0 <= x <= 100 and 0 <= y <= 100
                group = row["category"] if row["category"] in styles else "Other workflows"
                marker, color = styles[group]
                (artist,) = ax.plot(
                    x,
                    y,
                    marker=marker,
                    linestyle="none",
                    color=color,
                    markersize=4 if row["method"] in labels else 2.8,
                    markeredgewidth=0.6,
                    markerfacecolor="white" if group == "Coding agents" else color,
                    zorder=4 if row["method"] in labels else 2,
                )
                artist.set_gid(f"{task}|{metric}|{row['method']}")
                evidence.append(
                    {
                        "task": task,
                        "metric": metric,
                        "method": row["method"],
                        "relational": x,
                        "spreadsheet": y,
                    }
                )
            for number, (method, offset) in enumerate(
                zip(labels, offsets[task, metric], strict=True), 1
            ):
                x, y = [float(strata[task, method, "source", b][metric]) for b in BUCKETS["source"]]
                ax.annotate(
                    str(number),
                    (x, y),
                    xytext=offset,
                    textcoords="offset points",
                    ha="right" if offset[0] < 0 else "left",
                    va="center",
                    color=WORKFLOW_COLORS.get(
                        next(r["category"] for r in rows if r["method"] == method), "#626f7c"
                    ),
                    arrowprops={
                        "arrowstyle": "-",
                        "color": "#8796a3",
                        "lw": 0.5,
                        "shrinkA": 2,
                        "shrinkB": 4,
                    },
                    bbox={"facecolor": "white", "edgecolor": "none", "pad": 0.2},
                )
            ax.set_xlim(-3, 103)
            ax.set_ylim(-3, 103)
            ax.set_xticks([0, 50, 100])
            ax.set_yticks([0, 50, 100])
            task_label = "Detection" if task == "detection" else "End-to-end"
            ax.set_title(
                f"({'abcd'[2 * i + j]}) {task_label} {metric}",
                loc="left",
                pad=5,
            )
            ax.tick_params(length=2.5, pad=3)
            ax.grid(linewidth=0.35, alpha=0.6)
            ax.set_axisbelow(True)
    fig.supxlabel("Relational (%)", y=0.13)
    fig.supylabel("Spreadsheet (%)", x=0.015)
    for number, (method, label) in enumerate(labels.items()):
        category = next(r["category"] for r in roster if r["method"] == method)
        fig.text(
            0.12 + 0.43 * (number % 2),
            0.065 if number < 2 else 0.02,
            f"{number + 1}  {label}",
            va="center",
            color=WORKFLOW_COLORS.get(category, "#626f7c"),
        )
    handles = [
        Line2D(
            [],
            [],
            color=color,
            marker=marker,
            linestyle="none",
            markersize=4,
            markerfacecolor="white" if group == "Coding agents" else color,
        )
        for group, (marker, color) in styles.items()
    ]
    fig.legend(
        handles,
        [group.removesuffix(" (API)") for group in styles],
        loc="upper center",
        bbox_to_anchor=(0.53, 1.0),
        frameon=False,
        ncol=2,
        handletextpad=0.5,
        columnspacing=0.7,
    )
    save(
        fig,
        PAPER / "figures/paper/source_accuracy_heatmap.pdf",
        width=COLUMN_WIDTH,
        font_size=8,
        check_layout=True,
    )
    plt.close(fig)
    configure()
    return evidence


def smooth_size_trend(sizes, values, bandwidth):
    """Gaussian mean of defined exact-size scores, within observed support.

    Each defined size receives equal prior weight. The bandwidth is fixed by
    dimension across all methods and tasks; raw aggregate scores are untouched.
    """
    x, y = np.asarray(sizes, dtype=float), np.asarray(values, dtype=float)
    valid = np.isfinite(y)
    x, y = x[valid], y[valid]
    if not len(x):
        return np.array([]), np.array([])
    grid = np.linspace(x.min(), x.max(), 250)
    weights = np.exp(-0.5 * ((grid[:, None] - x[None, :]) / bandwidth) ** 2)
    return grid, weights @ y / weights.sum(axis=1)


def draw_sizes(roster, exact):
    points = {(r["task"], r["method"], r["dimension"], int(r["size"])): r for r in exact}
    api = {}
    for task in TASKS:
        candidates = [
            r for r in roster if r["task"] == task and r["category"] == "Direct LLMs (API)"
        ]
        api[task] = max(candidates, key=lambda r: float(r["f1"]))["method"]
    assert api["e2e"] == api["detection"] == "GPT-6-astra (Prompt-tuned)"
    agents = [
        r["method"]
        for r in roster
        if r["task"] == "detection"
        and r["category"] == "Coding agents"
        and reported_method(r["method"])
    ]
    assert len(agents) == 2
    methods = [api["detection"], *agents]
    labels = ["GPT-6-astra (API, tuned)", *agents]
    colors = ["#1767c6", "#62a5cf", "#b65378"]
    styles = ["-", "--", "-."]
    fig, axes = plt.subplots(2, 2, figsize=(FIGURE_WIDTH, 4.35), sharey=True)
    for i, task in enumerate(("detection", "e2e")):
        for j, dim in enumerate(("columns", "rows")):
            ax = axes[i, j]
            for method, label, color, style in zip(methods, labels, colors, styles, strict=True):
                observed = [int(r["size"]) for r in exact if r["dimension"] == dim]
                sizes = list(range(min(observed), max(observed) + 1))
                values = []
                for size in sizes:
                    point = points.get((task, method, dim, size))
                    values.append(
                        float(point["f1"])
                        if point and point["f1_defined"] == "True"
                        else float("nan")
                    )
                trend_x, trend_y = smooth_size_trend(sizes, values, SIZE_BANDWIDTH[dim])
                ax.plot(
                    trend_x,
                    trend_y,
                    label=label,
                    color=color,
                    linestyle=style,
                    linewidth=1.5,
                )
            ax.set_title(f"({'abcd'[2*i+j]}) {TASKS[task]} — {dim}")
            ax.set_xticks([2, 5, 10, 15, 20] if dim == "columns" else [10, 25, 50, 75, 100])
            ax.set_xlim((1.5, 20.5) if dim == "columns" else (8, 102))
            ax.set_xlabel(f"{dim.capitalize()} per table")
            ax.set_ylim(-3, 103)
            ax.set_yticks([0, 25, 50, 75, 100])
            if j == 0:
                ax.set_ylabel("Smoothed F1 (%)")
            ax.grid(axis="y", color="#dddddd", linewidth=0.5)
            ax.set_axisbelow(True)
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        loc="upper center",
        ncol=3,
        frameon=False,
        bbox_to_anchor=(0.5, 1),
        columnspacing=1.2,
        handlelength=2.3,
    )
    fig.subplots_adjust(left=0.08, right=0.985, bottom=0.11, top=0.80, hspace=0.65, wspace=0.16)
    save(fig, PAPER / "figures/paper/table_size_accuracy.pdf")
    plt.close(fig)
    return methods


def appendix_tables(roster, strata):
    lines = ["% Generated from table_strata_metrics.csv; all applicable methods retained."]
    for task in TASKS:
        rows = [r for r in roster if r["task"] == task and reported_method(r["method"])]
        for dimension, buckets in BUCKETS.items():
            title = {"columns": "column count", "rows": "row count", "source": "source"}[dimension]
            n = 3 * len(buckets)
            lines += [
                r"\begin{table*}[p]",
                rf"\caption{{The table reports within-bucket precision, recall, and $F_1$ (\%) for {TASKS[task].lower()} by {title}, averaged across runs. Values are rounded to two decimals.}}",
                rf"\label{{tab:appendix-{task}-{dimension}}}",
                r"\centering\cbtablefont",
                r"\setlength{\tabcolsep}{2pt}",
                rf"\begin{{tabular*}}{{\textwidth}}{{@{{\extracolsep{{\fill}}}}l*{{{n}}}{{r}}@{{}}}}",
                r"\toprule",
                " & "
                + " & ".join(rf"\multicolumn{{3}}{{c}}{{{b.replace('-', '--')}}}" for b in buckets)
                + r" \\",
                "".join(rf"\cmidrule(lr){{{i}-{i+2}}}" for i in range(2, n + 1, 3)),
                "Method & " + " & ".join(["P", "R", "$F_1$"] * len(buckets)) + r" \\",
            ]
            category = None
            for row in rows:
                if row["category"] != category:
                    category = row["category"]
                    lines += [
                        r"\midrule",
                        rf"\multicolumn{{{n+1}}}{{@{{}}l}}{{\textit{{{category.removesuffix(' (API)')}}}}} \\",
                    ]
                values = [
                    f"{float(strata[task, row['method'], dimension, b][m]):.2f}"
                    for b in buckets
                    for m in ("precision", "recall", "f1")
                ]
                lines.append(row["method"] + " & " + " & ".join(values) + r" \\")
            lines += [r"\bottomrule", r"\end{tabular*}", r"\end{table*}", ""]
    (generated_asset("accuracy_strata_appendix.tex", directory=GENERATED)).write_text(
        "\n".join(lines)
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--e2e-table-only",
        action="store_true",
        help="Update only the main end-to-end results table.",
    )
    parser.add_argument(
        "--recompute",
        action="store_true",
        help="Rebuild the historical point estimates from original per-run inputs.",
    )
    args = parser.parse_args()
    configure()
    files = (
        "task_type_metrics.csv",
        "task_type_precision.csv",
        "table_strata_metrics.csv",
        "table_exact_size_metrics.csv",
        "false_edits_ba_runs.csv",
    )
    if not args.recompute and (GENERATED / "e2e_table_point.csv").exists():
        files += ("e2e_table_point.csv", "e2e_table_variability.csv")
    hashes = {
        name: hashlib.sha256((generated_asset(name, directory=GENERATED)).read_bytes()).hexdigest()
        for name in files
    }
    roster = read(files[0])
    types = {(r["task"], r["method"], r["error_type"]): r for r in read(files[1])}
    if args.e2e_table_only:
        draw_types(roster, types, tasks=["e2e"], recompute_e2e=args.recompute)
        sources = (
            ("e2e_table_point.csv", "e2e_table_variability.csv")
            if not args.recompute and (GENERATED / "e2e_table_point.csv").exists()
            else (files[0], files[1], "false_edits_ba_runs.csv")
        )
        proof = {
            "source_sha256": {
                name: hashlib.sha256(
                    (generated_asset(name, directory=GENERATED)).read_bytes()
                ).hexdigest()
                for name in sources
            },
            "policy": "Point estimates use the same run means as the published variability table. --recompute explicitly selects the original historical inputs. FPR is 100 times clean-cell edits divided by all clean cells, averaged across runs. Wrong replacements at errors are not clean-cell FP. FPR is unshaded; P/R/F1 share the existing 0--100 scale.",
            "model_calls": 0,
        }
        folder = PAPER / "build/e2e_table_fpr"
        folder.mkdir(exist_ok=True)
        (folder / "evidence.json").write_text(json.dumps(proof, indent=2) + "\n")
        print("Rendered 21 methods: overall P/R/F1/FPR and recall by error type.")
        return
    strata = {
        (r["task"], r["method"], r["dimension"], r["bucket"]): r
        for r in read(files[2])
        if r["source_filter"] == "All"
    }
    assert len(roster) == 58 and len(types) == 174 and len(strata) == 464
    for row in roster:
        task, method = row["task"], row["method"]
        for kind, _ in TYPES:
            score = types[task, method, kind]
            assert score["repetitions"] == row["repetitions"]
            assert math.isclose(float(score["recall"]), float(row[f"recall_{kind}"]))
        for dimension, buckets in BUCKETS.items():
            for bucket in buckets:
                score = strata[task, method, dimension, bucket]
                assert score["repetitions"] == row["repetitions"]
                assert score["category"] == row["category"]
    draw_types(roster, types, recompute_e2e=args.recompute)
    draw_sources(roster, strata)
    methods = draw_sizes(roster, read(files[3]))
    appendix_tables(roster, strata)
    assert hashes == {
        name: hashlib.sha256((generated_asset(name, directory=GENERATED)).read_bytes()).hexdigest()
        for name in files
    }
    evidence = {
        "source_sha256": hashes,
        "size_figure_methods": methods,
        "selection": "Highest overall-F1 API configuration in both tasks, plus the two Astra coding agents; fixed across exact row/column counts. Archived Opus configurations are omitted from displays.",
        "size_smoothing": {
            "method": "Gaussian kernel mean of defined exact-size mean micro F1; equal prior weight per size, no robust outlier rejection. Undefined scores excluded, defined zero scores retained. Evaluate only within each curve's observed support; curves between sizes are descriptive estimates.",
            "bandwidth": SIZE_BANDWIDTH,
            "grid_points": 250,
        },
        "policy": "Unchanged mean within-run metrics. The end-to-end table reports overall P/R/F1, clean-cell FPR, and recall by error type. Detection type slices share clean-cell negatives. Sources show all applicable methods. No new inference.",
    }
    path = PAPER / "build/generated/accuracy_presentation_evidence.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(evidence, indent=2) + "\n")
    print("Rendered 4 figures and 6 appendix tables from unchanged frozen scores.")


if __name__ == "__main__":
    main()
