"""Independently classify frozen Astra FP/FN patterns through Azure OpenAI.

Prepare requests without prior category labels; checkpoint each API response;
report a separate review table without changing the paper's current pie chart.
"""

from __future__ import annotations

import argparse
import csv
import difflib
import hashlib
import json
import logging
import re
import sys
import time
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from decimal import Decimal
from pathlib import Path

import jsonschema
import yaml
from build_failure_requirement_pies import CONFIG, audited_groups

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parent
CATEGORIES = ("Knowledge", "Formatting convention", "Reasoning")
ISSUE_CATEGORIES = {
    "lexical_or_entity": "Knowledge",
    "surface_only": "Formatting convention",
    "contextual_convention": "Reasoning",
    "arithmetic_or_relationship": "Reasoning",
    "semantic_content_or_alignment": "Reasoning",
    "mixed_no_primary": "Uncertain",
    "insufficient_reference": "Uncertain",
}


def seal(value):
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, ensure_ascii=False).encode()
    ).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    temporary.replace(path)


def write_csv(path, rows, fields):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def schema():
    item = {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "group_id": {"type": "string"},
            "issue_kind": {"type": "string", "enum": list(ISSUE_CATEGORIES)},
            "primary_category": {"type": "string", "enum": [*CATEGORIES, "Uncertain"]},
            "secondary_categories": {
                "type": "array",
                "items": {"type": "string", "enum": list(CATEGORIES)},
            },
            "confidence": {"type": "string", "enum": ["high", "medium", "low"]},
            "needs_review": {"type": "boolean"},
            "reference_status": {
                "type": "string",
                "enum": ["usable", "questionable", "insufficient"],
            },
            "rationale": {"type": "string"},
        },
    }
    item["required"] = list(item["properties"])
    return {
        "type": "object",
        "additionalProperties": False,
        "properties": {"items": {"type": "array", "items": item}},
        "required": ["items"],
    }


def validate(result, ids, expected_schema=None):
    jsonschema.validate(result, expected_schema or schema())
    rows = result["items"]
    assert len(rows) == len(ids) and {row["group_id"] for row in rows} == set(ids)
    for row in rows:
        if "issue_kind" in row:
            assert ISSUE_CATEGORIES[row["issue_kind"]] == row["primary_category"]
        secondary = row["secondary_categories"]
        assert len(secondary) == len(set(secondary))
        assert row["primary_category"] not in secondary
        assert row["rationale"].strip()
        if (
            row["confidence"] == "low"
            or row["primary_category"] == "Uncertain"
            or row["reference_status"] != "usable"
        ):
            assert row["needs_review"]
    return rows


def failure_payload(group, table_rows):
    """Expose observation/reference evidence while hiding all prior classifications."""
    indices = sorted({event[2] for event in group["occurrences"]})
    assert all(table_rows[row][group["col"]] == group["original"] for row in indices)
    references = [group["original"]] if group["outcome"] == "clean_edit" else group["accepted"]
    observed = group["original"] if group["proposed"] is None else group["proposed"]
    return {
        "group_id": group["group_id"],
        "outcome": group["outcome"],
        "column_index": group["col"],
        "column_name": group["column"],
        "row_indices": indices,
        "original": group["original"],
        "proposed": group["proposed"],
        "accepted": group["accepted"],
        "reference_values": references,
        "comparison_value": observed,
        "residual_differences": [difference(observed, value) for value in references],
    }


def difference(observed, reference):
    edits = [
        {"operation": op, "observed_fragment": observed[a:b], "reference_fragment": reference[c:d]}
        for op, a, b, c, d in difflib.SequenceMatcher(None, observed, reference).get_opcodes()
        if op != "equal"
    ]
    numeric = r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?"
    changed = None
    if re.fullmatch(numeric, observed) and re.fullmatch(numeric, reference):
        changed = Decimal(observed) != Decimal(reference)
    return {
        "reference": reference,
        "edits": edits,
        "numeric_value_changed": changed,
        "digit_sequence_changed": re.findall(r"\d", observed) != re.findall(r"\d", reference),
    }


def prepare(folder, prompt_path):
    cfg = yaml.safe_load(prompt_path.read_text())
    config = json.loads(CONFIG.read_text())
    groups, _ = audited_groups(config)
    assert config["method"] == "GPT-6-astra (Prompt-tuned)" and config["repetitions"] == [1, 2, 3]
    by_table = defaultdict(list)
    for group in groups:
        by_table[group["dataset"]].append(group)
    batches = []
    for dataset, selected in by_table.items():
        path = PAPER / config["snapshot"] / dataset / "dirty.csv"
        with path.open(newline="") as stream:
            headers, *table_rows = list(csv.reader(stream))
        for start in range(0, len(selected), cfg["batch_size"]):
            items = []
            for group in selected[start : start + cfg["batch_size"]]:
                items.append(failure_payload(group, table_rows))
            payload = {
                "dataset": dataset,
                "headers": headers,
                "table_rows": [{"row_index": i, "values": row} for i, row in enumerate(table_rows)],
                "failures": items,
            }
            request = {
                "model": cfg["model"],
                "reasoning": {"effort": cfg["reasoning_effort"]},
                "max_output_tokens": cfg["max_output_tokens"],
                "text": {
                    "format": {
                        "type": "json_schema",
                        "name": "failure_categories",
                        "strict": True,
                        "schema": schema(),
                    }
                },
                "input": [
                    {"role": "system", "content": cfg["system"]},
                    {"role": "user", "content": json.dumps(payload, ensure_ascii=False)},
                ],
            }
            batch = {
                "batch_id": f"B{len(batches) + 1:03d}",
                "group_ids": [row["group_id"] for row in items],
                "request_sha256": seal(request),
                "request": request,
            }
            batches.append(batch)
    plan = {
        "method": config["method"],
        "prompt_sha256": hashlib.sha256(prompt_path.read_bytes()).hexdigest(),
        "prompt_file": str(prompt_path.relative_to(PAPER)),
        "model": cfg["model"],
        "reasoning_effort": cfg["reasoning_effort"],
        "groups": len(groups),
        "source_sha256": config["source_sha256"],
        "batches": batches,
    }
    target = folder / "plan.json"
    if target.exists():
        assert (
            json.loads(target.read_text()) == plan
        ), "Existing run has a different prompt or corpus; use a new output directory."
    else:
        write_json(target, plan)
    print(
        json.dumps(
            {
                "groups": len(groups),
                "batches": len(batches),
                "model": cfg["model"],
                "reasoning_effort": cfg["reasoning_effort"],
            }
        ),
        flush=True,
    )
    return plan, cfg, groups


def run(folder, plan, cfg, env_file, workers, selected_groups):
    sys.path.insert(0, str(ROOT))
    from src.evaluation.constraint_bank.transport import Transport

    transport = Transport(
        {
            "environment_file": str(env_file),
            "api_version": cfg["api_version"],
            "request_timeout_seconds": cfg["request_timeout_seconds"],
        }
    )
    batches = [
        b for b in plan["batches"] if not selected_groups or set(b["group_ids"]) & selected_groups
    ]
    if selected_groups:
        assert selected_groups <= {gid for b in batches for gid in b["group_ids"]}

    def request(batch):
        destination = folder / "responses" / f"{batch['batch_id']}.json"
        if destination.exists():
            record = json.loads(destination.read_text())
            assert record["request_sha256"] == batch["request_sha256"]
            validate(
                record["result"], batch["group_ids"], batch["request"]["text"]["format"]["schema"]
            )
            return "cached"
        attempts = folder / "attempts" / batch["batch_id"]
        attempts.mkdir(parents=True, exist_ok=True)
        for attempt in range(1, cfg["max_attempts"] + 1):
            started = time.time()
            receipt = {
                "request_sha256": batch["request_sha256"],
                "started_at": started,
                "attempt": attempt,
            }
            filename = attempts / f"{time.time_ns()}.json"
            try:
                response = transport.client().responses.create(**batch["request"])
                receipt.update(raw=response.model_dump(), seconds=time.time() - started)
                write_json(filename, receipt)
                assert response.status == "completed", response.status
                result = json.loads(response.output_text)
                validate(result, batch["group_ids"], batch["request"]["text"]["format"]["schema"])
                assert response.model == cfg["model"], response.model
                write_json(destination, {**receipt, "result": result})
                return "completed"
            except Exception as exc:
                status = getattr(exc, "status_code", None)
                receipt.update(
                    error_type=type(exc).__name__, http_status=status, seconds=time.time() - started
                )
                write_json(filename, receipt)
                if status in {400, 401, 403, 404}:
                    raise RuntimeError(
                        f"Non-retryable request: {type(exc).__name__}, status={status}"
                    ) from None
                if attempt == cfg["max_attempts"]:
                    raise RuntimeError(
                        f"Batch {batch['batch_id']} failed: {type(exc).__name__}, status={status}"
                    ) from None
                time.sleep(min(2**attempt, 15))

    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(request, batch): batch for batch in batches}
        for i, future in enumerate(as_completed(futures), 1):
            batch = futures[future]
            try:
                status = future.result()
            except Exception:
                for pending in futures:
                    pending.cancel()
                raise
            print(f"{i}/{len(batches)} {batch['batch_id']} {status}", flush=True)


def report(folder, plan, groups):
    judgments = {}
    for batch in plan["batches"]:
        path = folder / "responses" / f"{batch['batch_id']}.json"
        if path.exists():
            record = json.loads(path.read_text())
            assert record["request_sha256"] == batch["request_sha256"]
            for row in validate(
                record["result"], batch["group_ids"], batch["request"]["text"]["format"]["schema"]
            ):
                assert row["group_id"] not in judgments
                judgments[row["group_id"]] = row
    rows, counts = [], defaultdict(Counter)
    for group in groups:
        if group["group_id"] not in judgments:
            continue
        judgment = judgments[group["group_id"]]
        rows.append(
            {
                "group_id": group["group_id"],
                "old_category": group["analysis_category"],
                **judgment,
                "secondary_categories": json.dumps(judgment["secondary_categories"]),
                "changed_category": judgment["primary_category"] != group["analysis_category"],
                "outcome": group["outcome"],
                "occurrences": len(group["occurrences"]),
                "dataset": group["dataset"],
                "column": group["column"],
                "original": group["original"],
                "proposed": group["proposed"],
                "accepted": json.dumps(group["accepted"], ensure_ascii=False),
                "existing_review_note": group["review_note"],
            }
        )
        for outcome, applies in [
            ("FP", group["outcome"] in {"clean_edit", "wrong_value"}),
            ("FN", group["outcome"] in {"unchanged_error", "wrong_value"}),
        ]:
            if applies:
                counts[outcome][judgment["primary_category"]] += len(group["occurrences"])
    if rows:
        fields = list(rows[0])
        write_csv(folder / "classification_review.csv", rows, fields)
        write_csv(
            folder / "changed_categories.csv", [r for r in rows if r["changed_category"]], fields
        )
        review_rows = [
            r
            for r in rows
            if r["needs_review"]
            or r["existing_review_note"].startswith(("Reference ", "Accepted references"))
        ]
        write_csv(folder / "needs_review.csv", review_rows, fields)
    else:
        review_rows = []
    summary = {
        "model": plan["model"],
        "reasoning_effort": plan["reasoning_effort"],
        "completed_groups": len(rows),
        "total_groups": len(groups),
        "needs_review": sum(row["needs_review"] for row in rows),
        "changed_categories": sum(row["changed_category"] for row in rows),
        "author_review_queue": len(review_rows),
        "counts": dict(counts),
        "status": "LLM-assisted draft; author review pending.",
    }
    if len(rows) == len(groups):
        assert sum(counts["FP"].values()) == 924 and sum(counts["FN"].values()) == 880
    usage = Counter()
    for path in (folder / "attempts").glob("*/*.json"):
        raw = json.loads(path.read_text()).get("raw", {})
        for key in ("input_tokens", "output_tokens", "total_tokens"):
            usage[key] += (raw.get("usage") or {}).get(key, 0)
    summary["usage"] = dict(usage)
    summary["request_attempts"] = len(list((folder / "attempts").glob("*/*.json")))
    summary["prompt_sha256"] = plan["prompt_sha256"]
    totals = []
    for outcome in ("FP", "FN"):
        total = sum(counts[outcome].values())
        for category in (*CATEGORIES, "Uncertain"):
            count = counts[outcome][category]
            totals.append(
                {
                    "outcome": outcome,
                    "category": category,
                    "count": count,
                    "total": total,
                    "percentage": 100 * count / total if total else 0,
                }
            )
    write_csv(
        folder / "classification_counts.csv",
        totals,
        ["outcome", "category", "count", "total", "percentage"],
    )
    lines = [
        "# Astra failure classification with Azure GPT",
        "",
        f"Judge: {plan['model']}; reasoning effort: {plan['reasoning_effort']}.",
        f"Scope: {plan['method']}, three recorded end-to-end runs.",
        f"Completed: {len(rows)}/{len(groups)} failure patterns. "
        f"Changed from the earlier draft: {summary['changed_categories']}. "
        f"Model review flags: {summary['needs_review']}; author review queue: {len(review_rows)}.",
        "",
        "Each request includes original table context, reference values and exact residual "
        "character differences. Previous category assignments are hidden from the judge. "
        "A fixed issue-kind-to-category map is validated for every response. "
        "Confidence is model-reported, not a calibrated probability or human agreement score.",
        "",
        "Counts use cell-by-run occurrences; an incorrect replacement contributes to both FP and FN. "
        "Uncertain cases remain in the denominator. Original benchmark labels, performance scores, "
        "and the manuscript pie chart are unchanged.",
        "",
        "| Category | FP count (%) | FN count (%) |",
        "|---|---:|---:|",
    ]
    for category in (*CATEGORIES, "Uncertain"):
        cells = [r for r in totals if r["category"] == category]
        lines.append(
            "| "
            + category
            + " | "
            + " | ".join(f"{r['count']} ({r['percentage']:.1f}%)" for r in cells)
            + " |"
        )
    lines.extend(
        [
            "",
            "Full judgments: `classification_review.csv`. Review queue: `needs_review.csv`. "
            "Changes: `changed_categories.csv`. Raw requests and receipts: `plan.json`, "
            "`responses/`, and `attempts/`.",
            "",
        ]
    )
    (folder / "report.md").write_text("\n".join(lines))
    write_json(folder / "summary.json", summary)
    print(json.dumps(summary), flush=True)
    return rows, summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["prepare", "run", "report"])
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--prompt", type=Path, default=PAPER / "prompts/failure_requirements.yaml")
    parser.add_argument("--environment-file", type=Path)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument(
        "--groups", default="", help="Smoke-check batches containing these comma-separated IDs."
    )
    args = parser.parse_args()
    logging.disable(logging.CRITICAL)
    folder = args.output_dir.resolve()
    folder.mkdir(parents=True, exist_ok=True)
    if args.action == "report" and (folder / "plan.json").exists():
        plan = json.loads((folder / "plan.json").read_text())
        config = json.loads(CONFIG.read_text())
        assert plan["source_sha256"] == config["source_sha256"]
        groups, _ = audited_groups(config)
        report(folder, plan, groups)
        return
    plan, cfg, groups = prepare(folder, args.prompt.resolve())
    if args.action == "run":
        if args.environment_file is None:
            parser.error(
                "run requires --environment-file; credentials are never copied into the run directory"
            )
        run(
            folder,
            plan,
            cfg,
            args.environment_file.resolve(),
            args.workers,
            {g for g in args.groups.split(",") if g},
        )
    report(folder, plan, groups)


if __name__ == "__main__":
    main()
