"""Report table-level balanced accuracy by error type from frozen run counts."""

from __future__ import annotations

import hashlib
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path

from build_macro_heatmap import read_csv
from build_no_empty_recall_table import draw
from build_stratified_metrics import POPULATIONS, write_csv
from figure_style import configure

PAPER = Path(__file__).resolve().parents[1]
GENERATED = PAPER / "assets/generated"
SCORES = ("table_tpr", "table_tnr", "table_balanced_accuracy")
COUNTS = ("table_tp", "table_fn", "table_fp", "table_tn")


def rates(row):
    """Use the same any-scored-edit and failed-output convention as Table 11."""
    positive, negative = int(row["target_tables"]), int(row["no_target_tables"])
    tp, fp = int(row["predicted_target_tables"]), int(row["false_alarm_tables"])
    assert positive > 0 and negative > 0
    assert 0 <= tp <= positive and 0 <= fp <= negative
    assert int(row["preserved_tables"]) + int(row["failed_no_target_tables"]) + fp == negative
    tpr, tnr = 100 * tp / positive, 100 * (negative - fp) / negative
    return dict(
        table_tp=tp,
        table_fn=positive - tp,
        table_fp=fp,
        table_tn=negative - fp,
        table_tpr=tpr,
        table_tnr=tnr,
        table_balanced_accuracy=(tpr + tnr) / 2,
    )


def inputs():
    roster = [
        r
        for r in read_csv(GENERATED / "task_type_metrics.csv")
        if r["task"] == "e2e"
        and not (r["category"] == "Direct LLMs (API)" and r["method"].endswith(" (Base)"))
    ]
    assert len(roster) == 23
    source = read_csv(GENERATED / "stratified_metrics_runs.csv")
    existing = {
        (r["method"], r["error_type"]): r for r in read_csv(GENERATED / "stratified_metrics.csv")
    }
    overall = {r["method"]: r for r in read_csv(GENERATED / "false_edits_ba_full_metrics.csv")}
    groups, runs = defaultdict(list), []
    for row in source:
        kind = row["error_type"]
        assert int(row["tables"]) == 1000 and int(row["target_tables"]) == POPULATIONS[kind]
        assert int(row["no_target_tables"]) == 1000 - POPULATIONS[kind]
        result = {
            k: row[k]
            for k in (
                "method",
                "category",
                "group",
                "error_type",
                "run",
                "configuration",
                "tables",
                "target_tables",
                "no_target_tables",
            )
        }
        result.update(rates(row))
        groups[row["method"], kind].append(result)
        runs.append(result)
    assert len(runs) == 148 and len(groups) == 92
    assert len({(r["method"], r["error_type"], r["run"]) for r in runs}) == 148
    assert groups.keys() == {(r["method"], kind) for r in roster for kind in POPULATIONS}
    summaries = []
    for (method, kind), group in groups.items():
        old = existing[method, kind]
        row = {
            k: old[k]
            for k in (
                "method",
                "category",
                "group",
                "error_type",
                "runs",
                "tables",
                "target_tables",
                "no_target_tables",
            )
        }
        row.update({key: statistics.mean(r[key] for r in group) for key in (*COUNTS, *SCORES)})
        assert len(group) == int(old["runs"])
        assert math.isclose(row["table_tpr"], float(old["coverage"]), abs_tol=1e-10)
        assert math.isclose(row["table_tnr"], 100 - float(old["false_alarm_rate"]), abs_tol=1e-10)
        if kind == "overall":
            for key in (*COUNTS, *SCORES):
                assert math.isclose(row[key], float(overall[method][key]), abs_tol=1e-10)
        summaries.append(row)
    control = dict(
        method="Keep original", category="Reference", group="Reference", runs=1, tables=1000
    )
    for kind, n in POPULATIONS.items():
        summaries.append(
            dict(
                **control,
                error_type=kind,
                target_tables=n,
                no_target_tables=1000 - n,
                table_tp=0,
                table_fn=n,
                table_fp=0,
                table_tn=1000 - n,
                table_tpr=0.0,
                table_tnr=100.0,
                table_balanced_accuracy=50.0,
            )
        )
    return [control, *roster], runs, summaries


def main():
    sources = [
        GENERATED / name
        for name in (
            "task_type_metrics.csv",
            "stratified_metrics_runs.csv",
            "stratified_metrics.csv",
            "false_edits_ba_full_metrics.csv",
        )
    ]
    hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
    roster, runs, summary = inputs()
    write_csv(GENERATED / "type_balanced_accuracy_runs.csv", runs)
    write_csv(GENERATED / "type_balanced_accuracy_metrics.csv", summary)
    configure()
    shown, height = draw(
        roster,
        read_csv(GENERATED / "type_balanced_accuracy_metrics.csv"),
        target=GENERATED / "type_balanced_accuracy_heatmap.pdf",
        balanced_accuracy=True,
    )
    assert len(shown) == 288
    assert all(hashlib.sha256(p.read_bytes()).hexdigest() == hashes[p.name] for p in sources)
    path = PAPER / "build/generated/type_balanced_accuracy_evidence.json"
    path.write_text(
        json.dumps(
            dict(
                source_sha256=hashes,
                run_type_rows=len(runs),
                method_type_rows=len(summary),
                displayed=shown,
                height_inches=height,
                overall_matches_table_11=True,
            ),
            indent=2,
        )
        + "\n"
    )
    print("Validated 148 run/type rows; all Overall values match Table 11. Rendered 288 values.")


if __name__ == "__main__":
    main()
