"""Checks for repeated values, propagated labels, and reset review histories."""

from tools.build_reviewed_clusters import manual_lines, value_key


def record(status="fp", note="", annotator="reviewer"):
    return dict(status=status, note=note, annotator=annotator)


def test_same_value_deduplicates_across_rows_but_not_columns_or_sources():
    key = value_key("table", "city", "Boston", 1)
    assert key == value_key("table", "city", "Boston", 12)
    assert key != value_key("table", "state", "Boston", 1)
    assert key != value_key("other", "city", "Boston", 1)
    assert value_key("table", "city", "", 1) != value_key("table", "city", "", 12)


def test_propagation_or_bulk_labels_alone_are_not_manual_reviews():
    for note in ["(auto: same-value as another cluster)", "[bulk-numeric-fp]", "[transferred]"]:
        assert manual_lines([(1, record(note=note))]) == []


def test_later_automatic_reclassification_preserves_manual_review_provenance():
    assert manual_lines(
        [
            (1, record(status="tp")),
            (2, record(status="partial", note="reclassified low-value FP as partial")),
        ]
    ) == [1]


def test_tombstones_invalidate_previous_manual_review():
    history = [(1, record()), (2, record(status="unlabeled"))]
    assert manual_lines(history) == []
    assert manual_lines(history + [(3, record(note="(auto: same-value)"))]) == []
    assert manual_lines(history + [(3, record(note="[manual]"))]) == [3]


def test_operator_accepted_llm_suggestion_is_reviewed_but_import_is_not():
    assert manual_lines([(1, record(status="tp", note="[llm-edited]"))]) == [1]
    assert manual_lines([(1, record(annotator="fn-import-reconcile"))]) == []
    assert manual_lines([(1, record()), (2, record(status="skip"))]) == []
