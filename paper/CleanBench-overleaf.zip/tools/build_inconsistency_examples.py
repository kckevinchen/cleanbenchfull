"""Render verified inconsistency examples with the Figures 3/4 worksheet UI.

The recovered evidence supplies all values, coordinates, links and repair status.
No replacement is inferred from a violated relationship or cross-sheet mismatch.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from build_context_screenshots import (
    FONT_SIZE_BP,
    WIDTH,
    SourceViews,
    checkmark,
    document,
    esc,
    highlight_edits,
)
from figure_style import COLUMN_WIDTH
from playwright.sync_api import sync_playwright
from worksheet_style import TABLE_FONT_BP, check_worksheet_style

PAPER = Path(__file__).resolve().parents[1]


class RecoveredSourceViews(SourceViews):
    """Adapt the audited excerpts to the existing source-table renderer."""

    def __init__(self, examples):
        self.excerpts = {x["dataset_id"]: x for e in examples for x in e["excerpt"]}
        self.sources = {}
        self.cells = {}
        self.repairs = {}

    def load(self, dataset):
        excerpt = self.excerpts[dataset]
        self.sources[dataset] = dict(source=excerpt["source"], sha256=excerpt["frozen_csv_sha256"])
        rows = {r["original_row"]: r["full_original_record"] for r in excerpt["records"]}
        return excerpt["original_columns"], rows


def select_examples(data):
    selected = {e["scope"]: e for e in data["examples"] if e["priority"] == "primary"}
    assert set(selected) == {"multi_column", "multi_table"}
    left, right = selected["multi_column"], selected["multi_table"]
    assert left["correction"]["status"] == "human_supported_literal"
    assert left["correction"]["accepted_values"]
    assert right["correction"]["status"] == "conflict_confirmed_no_directional_human_repair"
    assert not right["correction"]["human_accepted_replacement_values"]
    assert right["relation"]["key_occurrences_per_sheet"] == [1, 1]
    assert right["relation"]["key_values"][0] == right["relation"]["key_values"][1]
    return left, right


def comparison(original, correction, *, resolved):
    status = "comparison-accepted" if resolved else "comparison-unresolved"
    return (
        '<div class="repair-strip"><div class="repair-comparison">'
        '<div class="comparison-original"><span class="comparison-label">Original</span>'
        f'<span class="comparison-value">{original}</span></div>'
        f'<div class="{status}"><span class="comparison-label">Correction</span>'
        f'<span class="comparison-value">{correction}</span></div></div></div>'
    )


def content(data, views):
    left, right = select_examples(data)
    correction = left["correction"]
    excerpt = left["excerpt"][0]
    dataset = excerpt["dataset_id"]
    target = correction["target"]["row"]
    headers, _ = views.load(dataset)
    fields = left["relation"]["fields"]
    columns = [headers.index(fields[i]) for i in (0, 2, 1)]
    target_column = correction["target"]["column"]
    accepted = correction["accepted_values"][0]
    repairs = {(target, target_column): accepted}
    left_table = views.table(
        dataset,
        [target],
        columns,
        [120, 120, 204],
        marks=dict.fromkeys(repairs, "error"),
        repairs=repairs,
    )
    original = correction["original_value"]
    repair_key = f"{dataset}:{target}:{target_column}"
    views.repairs[repair_key] = accepted
    left_strip = comparison(
        f'<span data-before="{esc(repair_key)}">{highlight_edits(original, accepted)}</span>',
        checkmark()
        + f'<span class="repaired" data-repair="{esc(repair_key)}">'
        + highlight_edits(original, accepted, show_repair=True)
        + "</span>",
        resolved=True,
    )
    sheets = []
    compared = right["relation"]["compared_attribute"]
    for index, (excerpt, key) in enumerate(
        zip(
            right["excerpt"],
            right["relation"]["keys_by_table"],
            strict=True,
        )
    ):
        dataset = excerpt["dataset_id"]
        headers, _ = views.load(dataset)
        cell = next(c for c in right["jointly_implicated_cells"] if c["dataset"] == dataset)
        columns = [headers.index(name) for name in (compared, key[0])]
        table = views.table(
            dataset,
            [cell["row"]],
            columns,
            [84, 124],
            marks={(cell["row"], columns[0]): "error"},
            wrap_columns=(columns[1],),
            coordinate_width=24,
        )
        table = table.replace(
            'class="sheet-tab">Source</span>', f'class="sheet-tab">Source {"AB"[index]}</span>'
        )
        sheets.append(f'<div class="tableview">{table}</div>')
    first, second = [c["value"] for c in right["jointly_implicated_cells"]]
    right_strip = comparison(f"{esc(first)} ≠ {esc(second)}", "Not determined", resolved=False)
    return f"""<div class="families inconsistency">
      <section class="panel"><h2>(a) Multi-column inconsistency</h2>
        <div class="source-area source-panel"><div class="tableview">{left_table}</div></div>
        {left_strip}
      </section>
      <section class="panel"><h2>(b) Multi-table inconsistency</h2>
        <div class="source-area linked-sheets">{''.join(sheets)}</div>
        {right_strip}
      </section></div>"""


# Color, cell styling, selection frames, Source tabs, and repair rows come from
# the same document() stylesheet as Figures 3/4. Only this figure's layout differs.
CSS = """
.families.inconsistency {grid-template-columns:480px;gap:12px;justify-content:initial}
.inconsistency .source-area {display:flex;flex-direction:column}
.inconsistency .linked-sheets {display:grid;grid-template-columns:235px 235px;gap:10px}
.inconsistency .linked-sheets .tableview {flex-shrink:0}
.inconsistency .comparison-original,.inconsistency .comparison-accepted,
.inconsistency .comparison-unresolved {grid-template-columns:98px minmax(0,1fr);
  padding:3px 6px;line-height:20px}
.inconsistency .comparison-unresolved {display:grid;gap:6px;align-items:center;
  background:#f0f3f5}
"""


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--font-dir", type=Path, required=True)
    parser.add_argument("--browser", type=Path, required=True)
    parser.add_argument("--examples", type=Path, default=PAPER / "figures/figure5_examples.json")
    args = parser.parse_args()
    raw = args.examples.read_bytes()
    data = json.loads(raw)
    left, right = select_examples(data)
    views = RecoveredSourceViews([left, right])
    folder = PAPER / "build/inconsistency_examples"
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / "inconsistency_context.html"
    markup = document(content(data, views), args.font_dir.resolve())
    path.write_text(markup.replace("</style>", CSS + "</style>"), encoding="utf-8")
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=str(args.browser), headless=True)
        page = browser.new_page(viewport={"width": WIDTH, "height": 1000}, device_scale_factor=4)
        page.goto(path.as_uri())
        page.evaluate("document.fonts.ready")
        page.evaluate("document.fonts.load('16px Libertine')")
        page.wait_for_function("document.documentElement.dataset.ready === 'true'")
        assert page.evaluate("document.fonts.check('16px Libertine')")
        cells = page.locator("[data-cell]").evaluate_all(
            "els => els.map(e => [e.dataset.cell,e.textContent])"
        )
        assert len(cells) == len(views.cells) == 7
        for key, displayed in cells:
            assert displayed == views.cells[key]
            source, row, column = key.rsplit(":", 2)
            _, records = views.load(source)
            assert displayed == records[int(row)][int(column)]
        for key, value in page.locator("[data-repair]").evaluate_all(
            "els => els.map(e => [e.dataset.repair,e.textContent])"
        ):
            assert value == views.repairs[key]
        assert page.locator("[data-repair]").count() == page.locator(".checkmark").count() == 1
        assert page.locator(".linked-sheets .sheet-tab").all_text_contents() == [
            "Source A",
            "Source B",
        ]
        selectors = "td,th,h2,.comparison-label,.comparison-value,.sheet-tab"
        overflow = page.locator(selectors).evaluate_all(
            "els => els.filter(e => e.scrollWidth > e.clientWidth+1).map(e => e.textContent)"
        )
        assert not overflow, overflow
        sizes = page.locator("h2").evaluate_all(
            "els => [...new Set(els.map(e => getComputedStyle(e).fontSize))]"
        )
        assert len(sizes) == 1, sizes
        assert (
            abs(float(sizes[0].removesuffix("px")) - FONT_SIZE_BP * WIDTH / (COLUMN_WIDTH * 72))
            < 0.001
        )
        worksheet_style = check_worksheet_style(page)
        canvas = page.locator("#figure").bounding_box()
        clipped = page.locator(selectors).evaluate_all(
            "els => {let f=document.querySelector('#figure').getBoundingClientRect();"
            "return els.filter(e=>{let r=e.getBoundingClientRect();return r.right>f.right+1"
            "||r.bottom>f.bottom+1||r.left<f.left-1;}).map(e=>e.textContent)}"
        )
        assert not clipped, clipped
        assert page.locator(".source-area").evaluate_all(
            'els => els.every(e => [...e.querySelectorAll(".tableview")].every(s => '
            "s.getBoundingClientRect().bottom <= e.getBoundingClientRect().bottom + 1))"
        ), "A source table overlaps its repair strip"
        edges = page.locator(".repair-strip").evaluate_all(
            "es => es.map(e => e.getBoundingClientRect().top)"
        )
        linked = page.locator(".linked-sheets .tableview").evaluate_all(
            "es => es.map(e => {const r=e.getBoundingClientRect();"
            "return {top:r.top,bottom:r.bottom};})"
        )
        assert abs(linked[0]["top"] - linked[1]["top"]) < 1, linked
        assert abs(linked[0]["bottom"] - linked[1]["bottom"]) < 1, linked
        target = PAPER / "assets/generated/inconsistency_context.pdf"
        page.locator("#figure").screenshot(path=str(target.with_suffix(".png")))
        page.pdf(
            path=str(target),
            width=f"{WIDTH}px",
            height=f"{canvas['height']}px",
            margin={"top": "0", "bottom": "0", "left": "0", "right": "0"},
            print_background=True,
        )
        (folder / "evidence.json").write_text(
            json.dumps(
                dict(
                    examples_sha256=hashlib.sha256(raw).hexdigest(),
                    shared_renderer_sha256=hashlib.sha256(
                        (PAPER / "tools/build_context_screenshots.py").read_bytes()
                    ).hexdigest(),
                    example_ids=[left["example_id"], right["example_id"]],
                    snapshot=data["snapshot"],
                    displayed_cells=cells,
                    displayed_repairs=views.repairs,
                    canvas=canvas,
                    font_size_bp=FONT_SIZE_BP,
                    css_font_sizes=sizes,
                    table_font_size_bp=TABLE_FONT_BP,
                    worksheet_style=worksheet_style,
                    overflow=overflow,
                    clipped=clipped,
                    repair_strip_top_edges=edges,
                    policy="Verified benchmark excerpts rendered with the Figures 3/4 worksheet component and repair-strip styles. Only the human-supported payroll replacement gets a checkmark; cross-table correction remains undetermined.",
                ),
                indent=2,
            )
            + "\n"
        )
        browser.close()
    print(
        "Rendered Figure 6 with the shared Figures 3/4 worksheet UI; verified source strings, coordinates, repair provenance, typography and bounds."
    )


if __name__ == "__main__":
    main()
