"""Render the two single-column example figures in one and three panel rows."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from build_context_screenshots import esc
from build_example_options import audit, digest
from figure_style import COLUMN_WIDTH, FONT_SIZE
from playwright.sync_api import sync_playwright
from worksheet_style import check_worksheet_style, worksheet_css

PAPER = Path(__file__).resolve().parents[1]
WIDTH, GAP, PADDING = 720, 18, 3
RATIOS = {
    "I3": [0.18, 0.27, 0.24, 0.31],
    "I4": [0.6, 0.4],
    "I5": [0.36, 0.32, 0.32],
    "I14": [0.34, 0.4, 0.26],
    "I7": [0.17, 0.23, 0.6],
}


def source_table(case, spec, width, coordinate, views, panel):
    headers, _ = views.load(spec["dataset"])
    columns = [headers.index(c) for c in spec["columns"]]
    ratios = RATIOS.get(case["id"], [1 / len(columns)] * len(columns))
    return views.table(
        spec["dataset"],
        panel.get("display_rows", spec["rows"]),
        columns,
        [(width - coordinate) * r for r in ratios],
        marks={(r, headers.index(c)): "error" for r, c in spec["marks"]},
        coordinate_width=coordinate,
    )


def correction_note(case, width, coordinate):
    if not case["corrections"]:
        return f'<div class="conflict">{esc(case["note"])}</div>'
    assert len(case["tables"]) == 1
    fields = case["tables"][0]["columns"]
    ratios = RATIOS.get(case["id"], [1 / len(fields)] * len(fields))
    columns = f'<col style="width:{coordinate}px">' + "".join(
        f'<col style="width:{(width - coordinate) * r}px">' for r in ratios
    )
    values = dict.fromkeys(fields, "")
    for index, correction in enumerate(case["corrections"]):
        record = correction["record"]
        values[record["column"]] = (
            f'<span class="correction" data-correction="{case["id"]}-{index}">'
            f'{esc(record["corrected_value"])}</span>'
        )
    cells = "".join(f"<td>{value}</td>" for value in values.values())
    return (
        f'<table class="corrected-row"><colgroup>{columns}</colgroup>'
        f"<tbody><tr><th></th>{cells}</tr></tbody></table>"
    )


def document(figure, options, views):
    overview = figure["layout"] == "overview_row"
    assert figure["layout"] in {"overview_row", "three_rows"}
    columns = figure["columns"]
    coordinate = 36 if overview else 32
    unit = (WIDTH - 2 * PADDING - GAP * (columns - 1)) / columns
    cases = {case["id"]: case for case in options["examples"]}
    panels = []
    for panel in figure["panels"]:
        case = cases[panel["id"]]
        span = panel.get("span", 1)
        width = unit * span + GAP * (span - 1)
        tables = []
        for index, spec in enumerate(case["tables"]):
            title = (
                f'<div class="table-name">Table {"AB"[index]}</div>'
                if len(case["tables"]) > 1
                else ""
            )
            tables.append(
                '<div class="excerpt">'
                + title
                + source_table(case, spec, width, coordinate, views, panel)
                + "</div>"
            )
        panels.append(
            f'<section data-case="{case["id"]}" style="grid-column:span {span}">'
            f'<h2><span class="panel-letter">({panel["letter"]})</span> {esc(panel["title"])}</h2>'
            f'<div class="example"><div class="tables">{"".join(tables)}</div>'
            f'<div class="note {"resolved" if case["corrections"] else "unresolved"}">'
            f'{correction_note(case, width, coordinate)}</div>'
            '</div></section>'
        )
    font = PAPER / "build/fonts/LinLibertine_Rah.ttf"
    bold = PAPER / "build/fonts/LinLibertine_RBah.ttf"
    scale = WIDTH / (COLUMN_WIDTH * 72)
    table_bp = 6.5 if overview else 6
    css = (
        f"""
    @font-face {{font-family:Libertine;src:url('{font.as_uri()}')}}
    @font-face {{font-family:Libertine;src:url('{bold.as_uri()}');font-weight:700}}
    * {{box-sizing:border-box}}
    body {{margin:0;background:white;color:black;font:{FONT_SIZE * scale}px/1.2 Libertine}}
    #figure {{width:{WIDTH}px;padding:{PADDING}px;display:grid;
      grid-template-columns:repeat({columns},minmax(0,1fr));gap:22px {GAP}px;align-items:stretch}}
    section {{min-width:0;display:flex;flex-direction:column}}
    h2 {{font:inherit;font-weight:700;margin:0 0 6px}}
    .panel-letter {{font-weight:400;color:#52616b}}
    .example {{flex:1;display:flex;flex-direction:column}}
    .tables {{display:flex;flex-direction:column;gap:8px}}
    [data-case='I7'] .tables {{gap:4px}}
    .excerpt {{min-width:0}}
    .sheet-bar {{display:none}}
    .note {{font:700 {6.5 * scale}px/1.2 "Liberation Sans",Arial,sans-serif;
      margin-top:7px;text-align:center}}
    .resolved {{color:#086c40}}
    .unresolved {{color:#a3342d}}
    .correction,.conflict {{display:inline-block;padding:4px 10px;
      border-bottom:2px solid;white-space:pre}}
    .correction {{background:#e2f1e7;border-color:#8ebb9f}}
    .conflict {{background:#fff0ec;border-color:#d6a59e}}
    .table-name {{font:700 {5.5 * scale}px/1.1 "Liberation Sans",Arial,sans-serif;
      color:#52616b;margin-bottom:3px}}
    .corrected-row {{width:100%;table-layout:fixed;border-collapse:collapse;
      font:inherit;color:inherit}}
    .corrected-row td {{padding:0 1px;text-align:center;white-space:nowrap}}
    .corrected-row .correction {{padding:4px}}
    .corrected-row th {{font-weight:400}}
    """
        + worksheet_css(WIDTH, COLUMN_WIDTH)
        + f"""
    #figure table.source {{font-size:{table_bp * scale}px;line-height:1.15}}
    #figure table.source th,#figure table.source td {{padding:2px 3px;border-color:#a5b6bf}}
    #figure table.source .column-letters th {{height:18px;padding:0}}
    #figure table.source .column-letters th,#figure table.source .coord {{
      font-size:{5.5 * scale}px;color:#52616b;border-color:#d1d8dc;background:#f2f4f5}}
    #figure table.source .coord {{padding:0}}
    #figure table.source tbody tr.selected {{outline:2px solid #1a8b4f;outline-offset:0}}
    #figure table.source .omitted td,#figure table.source .omitted th {{color:#82909a}}
    #figure .field-names th {{height:26px}}
    #figure .field-names th:not(.coord) {{padding-right:.9em;overflow-wrap:normal}}
    #figure .field-names th[data-source-header] {{white-space:nowrap}}
    #figure .field-names th:not(.coord)::after {{width:.55em;height:.65em;right:1px}}
    #figure .field-names th:not(.coord)::before {{right:.15em;border-left-width:.14em;
      border-right-width:.14em;border-top-width:.16em}}
    #figure table.source tbody td,#figure table.source tbody th {{height:26px}}
    #figure [data-case='I3'] table.source td,#figure [data-case='I4'] table.source td,
    #figure [data-case='I5'] table.source td,
    #figure [data-case='I7'] table.source td {{white-space:nowrap}}
    #figure .clipped-value {{display:block;overflow:hidden;text-overflow:ellipsis;
      white-space:nowrap}}
    """
    )
    return (
        '<!doctype html><html lang="en"><meta charset="utf-8">'
        f'<style>{css}</style><body><main id="figure" class="{figure["layout"]}">'
        f'{"".join(panels)}</main></body></html>'
    )


def prepare_display(page, figure, options):
    """Apply explicit display aliases while preserving original evidence strings."""
    cases = {case["id"]: case for case in options["examples"]}
    for panel in figure["panels"]:
        section = page.locator(f'[data-case="{panel["id"]}"]')
        source_columns = {c for t in cases[panel["id"]]["tables"] for c in t["columns"]}
        assert set(panel.get("header_labels", {})) <= source_columns
        assert set(panel.get("clip_columns", [])) <= source_columns
        for index, spec in enumerate(cases[panel["id"]]["tables"]):
            table = section.locator("table.source").nth(index)
            for column, original in enumerate(spec["columns"]):
                header = table.locator(".field-names th:not(.coord)").nth(column)
                assert header.text_content() == original.replace("\\n", "")
                label = panel.get("header_labels", {}).get(original, original)
                if label != original:
                    header.evaluate(
                        """(e,v)=>{
                      e.dataset.sourceHeader=v.original;e.title=v.original;e.textContent=v.label;
                    }""",
                        dict(original=original, label=label),
                    )
                if original in panel.get("clip_columns", []):
                    table.locator(f"tbody td:nth-of-type({column + 1}) [data-cell]").evaluate_all(
                        "es=>es.forEach(e=>{e.classList.add('clipped-value');e.title=e.textContent;})"
                    )
    page.locator(".field-names th").evaluate_all("""es=>es.forEach(e=>{
      if(e.textContent==='Date_ini'){
        e.replaceChildren(document.createTextNode('Date_'),document.createElement('wbr'),
          document.createTextNode('ini'));
      }
    })""")
    # Equalize header heights within each panel row; body rows retain identical heights.
    page.locator("section").evaluate_all("""es=>{
      const groups=new Map();es.forEach(e=>{
        const y=Math.round(e.getBoundingClientRect().top);
        if(!groups.has(y))groups.set(y,[]);groups.get(y).push(e);
      });
      groups.forEach(group=>{
        const headers=group.flatMap(e=>[...e.querySelectorAll('.field-names')]);
        const height=Math.max(...headers.map(e=>e.getBoundingClientRect().height));
        headers.forEach(e=>e.style.height=height+'px');
      });
    }""")


def verify_render(page, figure, options, views):
    ids = [panel["id"] for panel in figure["panels"]]
    shown = page.locator("[data-cell]").evaluate_all(
        "es=>es.map(e=>[e.dataset.cell,e.textContent])"
    )
    for key, value in shown:
        assert views.cells[key] == value
    cases = {case["id"]: case for case in options["examples"]}
    for panel in figure["panels"]:
        section = page.locator(f'[data-case="{panel["id"]}"]')
        for index, spec in enumerate(cases[panel["id"]]["tables"]):
            table = section.locator("table.source").nth(index)
            rows = panel.get("display_rows", spec["rows"])
            assert table.locator("tbody tr").count() == len(rows)
            assert table.locator("[data-source-row]").evaluate_all(
                "es=>es.map(e=>Number(e.dataset.sourceRow))"
            ) == [row for row in rows if row is not None]
            assert {r for r, _ in spec["marks"]} <= set(rows)
        aliases = section.locator("[data-source-header]").evaluate_all(
            "es=>Object.fromEntries(es.map(e=>[e.dataset.sourceHeader,e.textContent]))"
        )
        assert aliases == panel.get("header_labels", {})
    # Truncated payee names must still expose the complete five-digit identifier.
    assert page.locator(".clipped-value").evaluate_all("""es=>es.every(e=>{
      const range=document.createRange();range.setStart(e.firstChild,0);range.setEnd(e.firstChild,5);
      return range.getBoundingClientRect().width+24<e.clientWidth;
    })""")
    for case in options["examples"]:
        if case["id"] not in ids:
            continue
        for i, correction in enumerate(case["corrections"]):
            assert (
                page.locator(f'[data-correction="{case["id"]}-{i}"]').text_content()
                == correction["record"]["corrected_value"]
            )
            column = case["tables"][0]["columns"].index(correction["record"]["column"])
            section = page.locator(f'[data-case="{case["id"]}"]')
            source = section.locator("table.source .field-names th:not(.coord)").nth(column)
            label = section.locator(f'[data-correction="{case["id"]}-{i}"]')
            source_box, label_box = source.bounding_box(), label.bounding_box()
            assert (
                abs(
                    source_box["x"]
                    + source_box["width"] / 2
                    - label_box["x"]
                    - label_box["width"] / 2
                )
                < 1
            ), (case["id"], column)
    for key in {"I4", "I7"} & set(ids):
        assert page.locator(f'[data-case="{key}"] [data-correction]').count() == 0
    overflow = page.locator("td,th,h2,.note,.original,.correction").evaluate_all(
        "es=>es.filter(e=>e.scrollWidth>e.clientWidth+1).map(e=>e.textContent)"
    )
    assert not overflow, overflow
    assert page.locator("[data-source-header]").evaluate_all("""es=>es.every(e=>{
      const r=document.createRange();r.selectNodeContents(e);
      const button=getComputedStyle(e,'::after');
      const buttonLeft=e.getBoundingClientRect().right-parseFloat(button.right)
        -parseFloat(button.width)-2;
      return r.getBoundingClientRect().right<buttonLeft;
    })""")
    bounds = page.locator("section,table.source,.note").evaluate_all("""es=>{
      const f=document.querySelector('#figure').getBoundingClientRect();
      return es.filter(e=>{const r=e.getBoundingClientRect();
        return r.left<f.left-1||r.right>f.right+1||r.bottom>f.bottom+1;}).map(e=>e.textContent);
    }""")
    assert not bounds, bounds
    panel_rows = page.locator("section").evaluate_all("""es=>{
      const rows=[];
      es.forEach(e=>{const top=e.getBoundingClientRect().top;
        let row=rows.find(r=>Math.abs(r.top-top)<1);
        if(!row){row={top,ids:[]};rows.push(row);}row.ids.push(e.dataset.case);});
      return rows;
    }""")
    assert len(panel_rows) == figure["rows"], panel_rows
    expected_rows = (
        [["S2", "F1", "I1"]]
        if figure["layout"] == "overview_row"
        else [["I3", "I4"], ["I14", "I5"], ["I7"]]
    )
    assert [r["ids"] for r in panel_rows] == expected_rows
    alignment = []
    for row in panel_rows:
        measures = [
            page.locator(f'[data-case="{key}"]').evaluate("""e=>{
              const t=e.querySelector('table.source').getBoundingClientRect();
              const n=e.querySelector('.note').getBoundingClientRect();
              return {tableTop:t.top,tableBottom:t.bottom,noteTop:n.top};
            }""")
            for key in row["ids"]
        ]
        for dimension in ("tableTop", "tableBottom", "noteTop"):
            values = [m[dimension] for m in measures]
            assert max(values) - min(values) < 1, (row, dimension, measures)
        alignment.append(dict(ids=row["ids"], measures=measures))
    correction_lines = page.locator(".note").evaluate_all("""es=>es.map(e=>{
      const s=getComputedStyle(e),v=getComputedStyle(e.querySelector('.correction,.conflict'));
      return {height:e.getBoundingClientRect().height,
        lineHeight:parseFloat(s.lineHeight),padding:parseFloat(v.paddingTop)+parseFloat(v.paddingBottom),
        border:parseFloat(v.borderTopWidth)+parseFloat(v.borderBottomWidth),
        font:s.fontFamily,weight:s.fontWeight,background:v.backgroundColor};
    })""")
    assert all(
        n["height"] <= n["lineHeight"] + n["padding"] + n["border"] + 2 for n in correction_lines
    )
    assert all("Liberation Sans" in n["font"] for n in correction_lines)
    assert all(n["weight"] == "700" for n in correction_lines)
    font_bp = 6.5 if figure["layout"] == "overview_row" else 6
    sizes = page.locator("table.source td").evaluate_all(
        "es=>es.map(e=>parseFloat(getComputedStyle(e).fontSize))"
    )
    assert all(abs(size * COLUMN_WIDTH * 72 / WIDTH - font_bp) < 0.001 for size in sizes)
    return dict(
        selected_ids=ids,
        displayed_cells=shown,
        worksheet_style=check_worksheet_style(page),
        canvas=page.locator("#figure").bounding_box(),
        printed_width_inches=COLUMN_WIDTH,
        table_font_bp=font_bp,
        panel_rows=panel_rows,
        alignment=alignment,
        display_headers=page.locator("[data-source-header]").evaluate_all(
            "es=>es.map(e=>({original:e.dataset.sourceHeader,display:e.textContent}))"
        ),
        clipped_values=page.locator(".clipped-value").evaluate_all(
            "es=>es.map(e=>({key:e.dataset.cell,value:e.textContent,clipped:e.scrollWidth>e.clientWidth}))"
        ),
        correction_lines=correction_lines,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--browser", required=True, type=Path)
    args = parser.parse_args()
    config_path = PAPER / "figures/error_type_examples.json"
    layout = json.loads(config_path.read_text())
    options_path = PAPER / layout["options"]
    options = json.loads(options_path.read_text())
    ids = [p["id"] for f in layout["figures"] for p in f["panels"]]
    assert len(ids) == len(set(ids)) == 8
    assert set(ids) == set(options["selected_ids"])
    views = audit(options)
    folder = PAPER / "build/error_type_examples"
    folder.mkdir(parents=True, exist_ok=True)
    results = []
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=str(args.browser), headless=True)
        for figure in layout["figures"]:
            assert [p["letter"] for p in figure["panels"]] == list("abcde"[: len(figure["panels"])])
            markup = folder / f'{figure["asset"]}.html'
            markup.write_text(document(figure, options, views))
            pdf = PAPER / "assets/generated" / f'{figure["asset"]}.pdf'
            page = browser.new_page(
                viewport={"width": WIDTH, "height": 1800}, device_scale_factor=3
            )
            page.goto(markup.as_uri())
            page.evaluate("document.fonts.ready")
            prepare_display(page, figure, options)
            result = verify_render(page, figure, options, views)
            # Keep the browser preview identical to the PDF, including display aliases.
            markup.write_text(page.content())
            page.locator("#figure").screenshot(path=str(folder / f'{figure["asset"]}.png'))
            page.pdf(
                path=str(pdf),
                width=f"{WIDTH}px",
                height=f"{result['canvas']['height']}px",
                print_background=True,
                margin=dict(top="0", bottom="0", left="0", right="0"),
            )
            results.append(dict(asset=figure["asset"], pdf_sha256=digest(pdf), **result))
            page.close()
        browser.close()
    (folder / "audit.json").write_text(
        json.dumps(
            dict(
                config_sha256=digest(config_path),
                options_sha256=digest(options_path),
                figures=results,
                annotation_font_bp=FONT_SIZE,
                additional_model_calls=0,
            ),
            indent=2,
        )
        + "\n"
    )
    cells = sum(len(result["displayed_cells"]) for result in results)
    print(f"Verified eight examples and {cells} source cells in one-row and three-row figures.")


if __name__ == "__main__":
    main()
