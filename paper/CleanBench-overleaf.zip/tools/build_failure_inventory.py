"""Inventory every selected LLM/constraint failure for an offline taxonomy audit.

Writes private cell-level evidence under ignored build/, never changes labels or
scores. Transformation tags are mechanical descriptions, not causal judgments.
"""

from __future__ import annotations

import csv
import gzip
import json
import re
import sys
import unicodedata
from collections import Counter, defaultdict
from datetime import datetime
from decimal import Decimal, InvalidOperation
from itertools import chain
from pathlib import Path

from build_failure_taxonomy import CATEGORIES, FIELDS, counts
from build_macro_metrics import PAPER, ROOT, Inputs, agent_runs, api_runs, historical_runs
from paper_taxonomy import project_sets

OUT = PAPER / "build/failure_inventory"


def numeric(value):
    """Conservative decimal syntax; no locale inference or currency conversion."""
    value = value.strip()
    if not re.fullmatch(r"[+-]?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?(?:[eE][+-]?\d+)?%?", value):
        return None
    try:
        percent = value.endswith("%")
        number = Decimal(value.rstrip("%").replace(",", ""))
        if percent:
            sign, digits, exponent = number.as_tuple()
            return Decimal((sign, digits, exponent - 2))
        return number
    except InvalidOperation:
        return None


def transform(original, proposed):
    if original == proposed:
        return "identical_output"
    if not proposed.strip():
        return "blanked_value"
    if not original.strip():
        return "filled_blank"
    if all(
        re.fullmatch(r"\d{4}-\d\d-\d\d(?:[ T]\d\d:\d\d:\d\d(?:\.\d+)?)?", s)
        for s in (original, proposed)
    ):
        try:
            if datetime.fromisoformat(original) == datetime.fromisoformat(proposed):
                return "iso_date_time_representation"
        except ValueError:
            pass
    a, b = numeric(original), numeric(proposed)
    if a is not None and b is not None:
        return "numeric_representation" if a == b else "numeric_value_change"
    if original.split() == proposed.split():
        return "whitespace"
    if original.casefold() == proposed.casefold():
        return "case"
    if " ".join(original.split()).casefold() == " ".join(proposed.split()).casefold():
        return "case_and_whitespace"
    skeleton = lambda s: "".join(c for c in s.casefold() if c.isalnum())
    if skeleton(original) == skeleton(proposed):
        return "punctuation_case_spacing"
    ascii_form = lambda s: "".join(
        c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c)
    )
    if ascii_form(original) == ascii_form(proposed):
        return "unicode_or_accent"
    return "content_change"


def reference_surface_match(proposed, accepted):
    """Same case-folded alphanumeric sequence, not a semantic-equivalence test."""
    if proposed is None:
        return False
    skeleton = lambda s: "".join(c for c in s.casefold() if c.isalnum())
    for value in accepted:
        a, b = numeric(proposed), numeric(value)
        if a is not None and b is not None and a != b:
            continue  # A minus sign or decimal point can change a numeric value.
        if skeleton(proposed) == skeleton(value):
            return True
    return False


def summarize_inventory(runs):
    """Exact descriptive counts; no semantic relabeling or score adjustment."""
    methods = defaultdict(Counter)
    columns = defaultdict(list)
    for run in runs:
        methods[run["method"]]["runs"] += 1
    with gzip.open(OUT / "failures.jsonl.gz", "rt") as stream:
        for line in stream:
            r = json.loads(line)
            count = methods[r["method"]]
            count[r["outcome"]] += 1
            if r["outcome"] == "unchanged_error":
                count["unchanged_" + r["execution"]] += 1
                continue
            count["false_positive"] += 1
            count["transform_" + r["transform"]] += 1
            if r["outcome"] == "wrong_value" and r["reference_surface_match"]:
                count["wrong_with_same_alphanumeric_sequence"] += 1
            if r["proposed"] in {"0", "0.0"}:
                count["replacement_zero"] += 1
            if r["proposed"] == "?":
                count["replacement_question_mark"] += 1
            if r["existing_column_value"] and r["transform"] in {
                "content_change",
                "numeric_value_change",
            }:
                count["existing_other_column_value"] += 1
            if (
                re.fullmatch(r"\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.000", r["original"])
                and r["proposed"] == r["original"][:-4]
            ):
                count["drop_zero_milliseconds"] += 1
            if r["category"] == "Constraint-based":
                columns[r["method"], r["run"], r["dataset"], r["col"]].append(r)
    collapse = []
    for (method, run, ds, col), rows in columns.items():
        originals = {r["original"] for r in rows}
        predictions = {r["proposed"] for r in rows}
        if len(rows) >= 20 and len(originals) >= 5 and len(predictions) == 1:
            collapse.append(
                dict(
                    method=method,
                    run=run,
                    dataset=ds,
                    col=col,
                    column=rows[0]["column"],
                    changed_cells=len(rows),
                    distinct_originals=len(originals),
                    proposed=next(iter(predictions)),
                )
            )
    result = dict(
        methods=methods,
        repeated_substitutions=collapse,
        policy="Counts sum retained runs; divide by runs for means. Repeated-substitution examples require at least 20 false-positive cells, at least five original strings, and one proposed string within a method/run/table/column. Alphanumeric agreement is a text comparison, not proof of semantic correctness.",
    )
    (OUT / "diagnostics.json").write_text(json.dumps(result, indent=2) + "\n")


def main():
    sys.path.insert(0, str(ROOT))
    from external.rein.score_repair import _extract_value
    from src.evaluation.paper_evaluation.analysis import GroundTruth

    class CapturingTruth(GroundTruth):
        def analyze(self, records, task, statuses):
            self.last_records = list(records)
            return super().analyze(self.last_records, task, statuses)

    OUT.mkdir(parents=True, exist_ok=True)
    inputs = Inputs()
    snapshot = ROOT / "outputs/baseline_campaign/20260910/snapshot"
    frozen = inputs.read(PAPER / "figures/error_analysis.json")["input_sha256"]
    for name in ("_manifest.json", "benchmark_cell.json", "neutral_cells.jsonl", "ignored.jsonl"):
        path = snapshot / name
        inputs.bind(path, frozen[str(path.relative_to(ROOT))])
    inputs.bind(Path(__file__).resolve())
    manifest = inputs.read(snapshot / "_manifest.json")
    truth = CapturingTruth(snapshot, manifest)
    types = project_sets(truth.fine)
    source = {}
    column_values = {}
    for ds, info in manifest["datasets"].items():
        path = inputs.bind(snapshot / ds / "dirty.csv", info["dirty_sha256"])
        with path.open(newline="") as stream:
            header, *rows = csv.reader(stream)
        source[ds] = header, rows
        for col in range(len(header)):
            column_values[ds, col] = {r[col] for r in rows}

    groups = {}
    summaries = []
    unchanged_groups = defaultdict(Counter)
    unique_cells = defaultdict(set)
    total = 0
    with gzip.open(OUT / "failures.jsonl.gz", "wt") as stream:
        for run in chain(
            historical_runs(inputs, truth), api_runs(inputs, truth), agent_runs(inputs, truth)
        ):
            if run["category"] not in CATEGORIES:
                continue
            predictions = {}
            for r in truth.last_records:
                c = r["dataset"], int(r["row"]), int(r["col"])
                assert c not in predictions
                value = _extract_value(r)
                if isinstance(value, str):
                    predictions[c] = value
            observed, tagged = Counter(), Counter()
            for c in sorted(truth.eligible | predictions.keys()):
                if truth.immune(c) or c in truth.ambiguous or c in truth.errors - truth.eligible:
                    continue
                ds, row, col = c
                original = source[ds][1][row][col]
                proposed = predictions.get(c)
                accepted = sorted(truth.accepted.get(c, []))
                status = run["tables"][ds]["execution"]
                if c in truth.eligible:
                    if proposed in accepted:
                        observed["correct"] += 1
                        continue
                    if proposed is None:
                        key = "unchanged_" + ("completed" if status == "complete" else status)
                        outcome = "unchanged_error"
                    else:
                        key, outcome = "wrong_value", "wrong_value"
                else:
                    assert proposed is not None
                    key, outcome = "clean_edits", "clean_edit"
                observed[key] += 1
                total += 1
                unique_cells[outcome].add(c)
                tag = transform(original, proposed) if proposed is not None else "no_proposed_value"
                tagged[outcome, tag] += 1
                row_types = sorted(t for t, cells in types.items() if c in cells)
                record = dict(
                    method=run["method"],
                    category=run["category"],
                    run=run["run"],
                    dataset=ds,
                    row=row,
                    col=col,
                    column=source[ds][0][col],
                    source_row=manifest["datasets"][ds]["exported_to_source"][row],
                    original=original,
                    proposed=proposed,
                    accepted=accepted,
                    outcome=outcome,
                    transform=tag,
                    error_types=row_types,
                    execution=status,
                    existing_column_value=proposed in column_values[ds, col],
                    reference_surface_match=reference_surface_match(proposed, accepted),
                )
                stream.write(json.dumps(record, ensure_ascii=False) + "\n")
                if proposed is None:
                    unchanged_groups[run["method"], status].update(row_types)
                gkey = (ds, col, original, proposed, tuple(accepted), outcome, status)
                if gkey not in groups:
                    groups[gkey] = {
                        k: v
                        for k, v in record.items()
                        if k not in {"method", "category", "run", "row", "source_row"}
                    }
                    groups[gkey].update(rows=set(), method_runs=Counter(), events=0)
                g = groups[gkey]
                g["rows"].add(row)
                g["method_runs"][run["method"]] += 1
                g["events"] += 1
            expected = counts(run["tables"])
            assert {k: observed[k] for k in FIELDS} == expected, run["method"]
            summaries.append(
                dict(
                    method=run["method"],
                    category=run["category"],
                    run=run["run"],
                    counts=expected,
                    tags=[
                        dict(outcome=o, transform=t, count=n)
                        for (o, t), n in sorted(tagged.items())
                    ],
                )
            )
    result = []
    for g in groups.values():
        g["rows"] = sorted(g["rows"])
        g["method_runs"] = dict(g["method_runs"])
        result.append(g)
    result.sort(key=lambda g: (-g["events"], g["dataset"], g["column"]))
    with (OUT / "groups.jsonl").open("w") as f:
        for g in result:
            f.write(json.dumps(g, ensure_ascii=False) + "\n")
    wrong_groups = [g for g in result if g["outcome"] == "wrong_value"]
    reference_review = []
    for cell, accepted in sorted(truth.accepted.items()):
        instructions = [
            value
            for value in sorted(accepted)
            if len(value) > 50
            and re.match(r"(?i)(verify|check|confirm|replace|correct|use)\b", value)
        ]
        if instructions:
            reference_review.append(
                dict(
                    dataset=cell[0],
                    row=cell[1],
                    col=cell[2],
                    accepted=sorted(accepted),
                    instruction_like=instructions,
                    only_instructions=len(instructions) == len(accepted),
                )
            )
    (OUT / "reference_review.json").write_text(json.dumps(reference_review, indent=2) + "\n")
    evidence = dict(
        runs=summaries,
        methods=len({r["method"] for r in summaries}),
        failure_events=total,
        groups=len(groups),
        wrong_replacement_source_groups=len(wrong_groups),
        wrong_replacement_combinations=len(
            {(g["original"], g["proposed"], tuple(g["accepted"])) for g in wrong_groups}
        ),
        unique_cells={k: len(v) for k, v in unique_cells.items()},
        source_sha256=inputs.hashes,
        additional_model_calls=0,
        policy="Every failure counted once per selected run; wrong replacements are one event contributing both FP and FN. Tags describe string transformations, not verified semantic causes.",
    )
    (OUT / "summary.json").write_text(json.dumps(evidence, indent=2) + "\n")
    summarize_inventory(summaries)
    print(json.dumps({k: v for k, v in evidence.items() if k not in {"runs", "source_sha256"}}))


if __name__ == "__main__":
    main()
