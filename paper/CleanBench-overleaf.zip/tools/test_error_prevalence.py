"""Check type assignment under corrupt values and the prevalence denominator."""

import json
import unittest
from pathlib import Path

import numpy as np
from tools.build_error_prevalence import estimate, infer_type


class ErrorPrevalenceTests(unittest.TestCase):
    def setUp(self):
        path = Path(__file__).resolve().parents[1] / "figures/error_prevalence_config.json"
        self.config = json.loads(path.read_text())

    def kind(self, name, values):
        return infer_type(name, values, self.config)[0]

    def test_corrupt_string_does_not_move_a_numeric_column_into_text(self):
        values = [str(i) for i in range(9)] + ["oops"]
        self.assertEqual(self.kind("Amount", values), "Numeric")
        self.assertEqual(self.kind("Unit Cost", values), "Numeric")

    def test_numeric_identifiers_and_categories_are_not_measurements(self):
        self.assertEqual(self.kind("ProductKey", ["1", "2", "3"]), "ID/Other")
        self.assertEqual(self.kind("DateKey", ["20200101", "20200102"]), "ID/Other")
        self.assertEqual(self.kind("Status", ["0", "1"] * 5), "Categorical")
        self.assertEqual(self.kind("field", ["001234", "005678"]), "ID/Other")
        self.assertEqual(self.kind("Lender ABA Number", ["123456789", "987654321"]), "ID/Other")
        self.assertEqual(self.kind("Phone calls entering call centers", ["10", "20"]), "Numeric")
        self.assertEqual(self.kind("Key#1 Title", ["Manager", "Chair"]), "Text")

    def test_dates_and_excel_serial_dates_keep_temporal_meaning(self):
        self.assertEqual(self.kind("Start Date", ["43466", "43497"]), "Date/time")
        self.assertEqual(self.kind("field", ["2019-01-01", "2019-02-01"]), "Date/time")
        self.assertEqual(self.kind("month", ["Jan", "Mar", "July", "Mar"]), "Date/time")
        self.assertEqual(self.kind("Year", ["2014", "2015", "12/1/2016"]), "Date/time")
        self.assertEqual(self.kind("Date_end", ["1/31/2019"] * 8 + ["Q"] * 2), "Date/time")
        self.assertEqual(self.kind("IndexCol", ["1-Dec-16", "2-Dec-16"]), "Date/time")
        self.assertEqual(self.kind("Dayname", ["Wednusday", "Sunday", "Thursday"]), "Date/time")

    def test_long_repeated_prose_is_not_a_short_category(self):
        values = ["This is a full sentence describing an unusual event."] * 10
        self.assertEqual(self.kind("Description", values), "Text")
        self.assertEqual(self.kind("field", ["red", "green"] * 10), "Categorical")
        self.assertEqual(self.kind("field", ["", "N/A"]), "ID/Other")

    def test_rates_use_summed_exposure_and_resample_whole_tables(self):
        weights = np.array([[1, 1], [2, 0], [0, 2]])
        point, lower, upper = estimate([1, 3], [100, 1000], weights, 1000)
        self.assertAlmostEqual(point, 1000 * 4 / 1100)
        self.assertNotAlmostEqual(point, (10 + 3) / 2)
        expected = np.quantile([1000 * 4 / 1100, 10, 3], [0.025, 0.975])
        np.testing.assert_allclose([lower, upper], expected)


if __name__ == "__main__":
    unittest.main()
