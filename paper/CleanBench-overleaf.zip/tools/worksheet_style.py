"""Shared worksheet appearance sampled from the unchanged Figure 1 reference."""

import json
from pathlib import Path

from figure_style import COLUMN_WIDTH

PAPER = Path(__file__).resolve().parents[1]
REFERENCE = PAPER / "figures/cross_table_detection.json"
TABLE_FONT_BP = 7


def worksheet_css(canvas_width, printed_width=COLUMN_WIDTH):
    """Keep source cells regular black; put judgments outside the source grid."""
    colors = json.loads(REFERENCE.read_text())["display"]["reference_style"]["colors"]
    size = TABLE_FONT_BP * canvas_width / (printed_width * 72)
    return f"""
    :root {{ --sheet-header:{colors['header']}; --sheet-stripe:{colors['stripe']};
      --sheet-grid:{colors['grid']}; --sheet-coordinate:{colors['coordinate']};
      --sheet-selection:{colors['selection']}; --sheet-error:{colors['annotation']}; }}
    #figure .tableview {{border:0;overflow:visible}}
    #figure table.source, #figure table.outputs {{width:100%;border-collapse:collapse;
      table-layout:fixed;font:{size}px/1.3 "Liberation Sans",Arial,sans-serif;color:black}}
    #figure table.source th, #figure table.source td,
    #figure table.outputs th, #figure table.outputs td {{border:1px solid var(--sheet-grid);
      padding:4px 6px;vertical-align:middle;text-align:left;font-weight:400}}
    #figure table.source thead .field-names th:not(.coord),
    #figure table.outputs thead th {{background:var(--sheet-header);color:white;font-weight:700}}
    #figure .field-names th:not(.coord) {{position:relative;padding-right:1.15em}}
    #figure .field-names th:not(.coord)::after {{content:"";position:absolute;right:2px;
      top:50%;transform:translateY(-50%);width:.8em;height:.85em;
      border:1px solid #a2b4bf;background:linear-gradient(white,#edf0f2);
      clip-path:polygon(0 0,100% 0,100% 100%,0 100%)}}
    #figure .field-names th:not(.coord)::before {{content:"";position:absolute;right:.28em;
      top:50%;z-index:1;border-left:.18em solid transparent;
      border-right:.18em solid transparent;border-top:.2em solid #707070}}
    #figure table.source .column-letters th, #figure table.source .coord {{
      background:var(--sheet-coordinate);color:black;border:1px solid #d3d3d3;
      text-align:center;padding:2px;font-weight:400}}
    #figure table.source .column-letters th {{height:1.3em}}
    #figure table.source .corner {{position:relative}}
    #figure table.source .corner::after {{content:"";position:absolute;right:3px;bottom:3px;
      border:.36em solid transparent;border-right-color:#d9d9d9;border-bottom-color:#d9d9d9}}
    #figure table.source tbody td, #figure table.outputs tbody td {{background:white;
      white-space:pre-wrap;position:relative}}
    #figure table.source tbody tr:nth-child(odd) td,
    #figure table.outputs tbody tr:nth-child(odd) td {{background:var(--sheet-stripe)}}
    #figure table.source tbody td.numeric {{text-align:right}}
    #figure table.source tbody .edit {{color:black;font-weight:400;background:none}}
    #figure table.source .marked, #figure table.source .active-cell {{outline:none}}
    #figure table.source .active-cell::after {{display:none}}
    #figure table.source tbody tr.selected {{outline:2px solid var(--sheet-selection);
      outline-offset:-1px;position:relative;z-index:1}}
    #figure .sheet-bar {{background:var(--sheet-coordinate);border-color:#d3d3d3;
      font:{size}px/1.3 "Liberation Sans",Arial,sans-serif}}
    #figure .sheet-tab {{color:#00883d;border-color:var(--sheet-selection);font-weight:400}}
    #figure .cell-callout {{color:white;background:var(--sheet-header)}}
    #figure table.source .has-callout {{padding-bottom:26px}}
    #figure table.outputs {{margin-top:8px}}
    #figure table.outputs .label {{color:black}}
    #figure table.outputs b.bad {{color:#c60000;background:none;font-weight:700}}
    #figure table.outputs b.good {{color:#00883d;background:none;font-weight:700}}
    #figure .repair-comparison {{border:1px solid var(--sheet-grid);border-radius:0;
      font:{size}px/1.3 "Liberation Sans",Arial,sans-serif;color:black}}
    #figure .comparison-original {{background:var(--sheet-stripe);
      border-bottom:1px solid var(--sheet-grid)}}
    #figure .comparison-accepted, #figure .comparison-unresolved {{background:white}}
    #figure .comparison-label {{color:#555}}
    #figure .comparison-original .edit {{color:#c60000;background:none;border-radius:0}}
    #figure .comparison-accepted .edit, #figure .comparison-accepted .repaired {{
      color:#00883d;background:none;border-radius:0}}
    #figure .construction .review-note {{border:1px solid var(--sheet-grid);border-radius:0}}
    #figure .construction .review-header {{background:var(--sheet-header);color:white}}
    #figure .construction .cell-address {{color:white}}
    #figure .construction .review-verdict {{border-color:white;background:white;color:#c60000}}
    #figure .construction .note-callout {{background:white;color:var(--sheet-header)}}
    """


def check_worksheet_style(page):
    """Audit the rendered grid, rather than only inspecting stylesheet strings."""
    measured = page.locator("table.source, table.outputs").evaluate_all("""tables => tables.map(t => {
      const header=t.querySelector('thead .field-names th:not(.coord)') || t.querySelector('thead th');
      const cell=t.querySelector('tbody td');
      const h=getComputedStyle(header), c=getComputedStyle(cell);
      return {header:h.backgroundColor, headerText:h.color, stripe:c.backgroundColor,
        font:c.fontFamily, weight:c.fontWeight, color:c.color};
    })""")
    assert measured
    for item in measured:
        assert item["header"] == "rgb(21, 96, 130)", item
        assert item["headerText"] == "rgb(255, 255, 255)", item
        assert item["stripe"] == "rgb(192, 230, 245)", item
        assert item["weight"] == "400" and item["color"] == "rgb(0, 0, 0)", item
        assert "Liberation Sans" in item["font"], item
    return measured
