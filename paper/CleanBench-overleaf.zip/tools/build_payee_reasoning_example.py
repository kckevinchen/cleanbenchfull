"""Preview a recorded Payee edit against an explicitly assumed reference."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from build_failure_examples import digest
from build_failure_type_examples import WIDTH, audited_examples, document
from failure_evidence import saved_issue
from playwright.sync_api import sync_playwright
from worksheet_style import check_worksheet_style

PAPER = Path(__file__).resolve().parents[1]
CONFIG = PAPER / "figures/astra_payee_reasoning_example.json"


def audit_payee(config, requirements, views):
    dataset, row = config["dataset"], config["row"]
    headers, rows = views.load(dataset)
    coords = views.manifest[dataset]["exported_to_source"]
    col = headers.index(config["column"])
    identifier_col = headers.index(config["identifier_column"])
    original = rows[coords[row]][col]
    identifier = rows[coords[row]][identifier_col]
    assert original == config["original"]
    prefix, separator, suffix = original.partition(" ")
    assert prefix != identifier and separator == " "
    assert config["display_reference"] == identifier + separator + suffix
    assert config["display_status"] == "error" and config["display_assumption"]

    benchmark = PAPER / requirements["snapshot"] / "benchmark_cell.json"
    records = [json.loads(line) for line in benchmark.read_text().splitlines() if line.strip()]
    matches = [
        record
        for record in records
        if record["source"] == views.manifest[dataset]["source"]
        and record["row"] == coords[row]
        and record["column"] == config["column"]
    ]
    assert len(matches) == 1 and matches[0]["status"] == config["benchmark_status"] == "ambiguous"
    assert matches[0]["corrected_value"] is None

    predictions = {}
    with (PAPER / requirements["predictions"]).open() as stream:
        for line in stream:
            prediction = json.loads(line)
            if (
                prediction["dataset"] == dataset
                and prediction["row"] == row
                and prediction["col"] in {col, identifier_col}
                and prediction["detector"].endswith("/gpt-6-astra/selected")
            ):
                run = int(prediction["detector"].split("/")[0].removeprefix("rep_"))
                key = run, prediction["col"]
                assert key not in predictions
                predictions[key] = prediction["corrected_value"]
    evidence = []
    for run in requirements["repetitions"]:
        for field in [col, identifier_col]:
            value = predictions.get((run, field))
            receipt = saved_issue(
                PAPER,
                requirements["recorded_response_archive"],
                run=run,
                dataset=dataset,
                row=row,
                column=headers[field],
                original=rows[coords[row]][field],
                proposed=value,
            )
            evidence.append(dict(column=headers[field], proposed=value, **receipt))
    proposed = predictions[config["selected_run"], col]
    assert proposed == config["recorded_output"] == "95416 City of Dinuba"
    assert all(predictions.get((run, identifier_col)) is None for run in [1, 2, 3])
    assert all(predictions.get((run, col)) is None for run in [2, 3])
    assert proposed.partition(" ")[0] == prefix
    assert proposed.casefold() == original.casefold()

    case = dict(
        id=config["id"],
        analysis_group=config["analysis_group"],
        dataset=dataset,
        row=row,
        col=col,
        source_row=coords[row],
        selected_rows=[coords[index] for index in config["rows"]],
        field_indices=[headers.index(field) for field in config["columns"]],
        column_weights=config["column_weights"],
        original=original,
        proposed=proposed,
        highlight_astra_edits=config.get("highlight_astra_edits", False),
        reference=config["display_reference"],
        context=config["display_assumption"] if config.get("show_assumption", False) else "",
        note="The recorded casing edit leaves the conflicting embedded identifier unchanged.",
    )
    return case, dict(benchmark_record=matches[0], recorded_outputs=evidence)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--browser", type=Path, required=True)
    args = parser.parse_args()
    config = json.loads(CONFIG.read_text())
    paper_config = json.loads((PAPER / config["paper_examples_config"]).read_text())
    cases, views = audited_examples(paper_config)
    requirements = json.loads((PAPER / paper_config["source_config"]).read_text())
    hashes_before = {name: digest(PAPER / name) for name in requirements["source_sha256"]}
    assert hashes_before == requirements["source_sha256"]
    example, provenance = audit_payee(config, requirements, views)
    assert [case["analysis_group"] for case in cases[:2]] == ["Knowledge", "Formatting convention"]
    assert example["analysis_group"] == "Reasoning"
    cases = cases[:2] + [example]
    markup, expected = document(cases, views, show_notes=False)
    folder = PAPER / "build/payee_reasoning_example"
    artifacts = {}
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(executable_path=str(args.browser), headless=True)
        for variant, output in [
            ("comparison", config["comparison_pdf"]),
            ("reasoning", config["standalone_pdf"]),
        ]:
            destination = folder / variant
            destination.mkdir(parents=True, exist_ok=True)
            html = markup
            if variant == "reasoning":
                html = html.replace(
                    "</style>",
                    f'#figure section:not([data-case="{example["id"]}"]) {{display:none}}</style>',
                )
            source = destination / "index.html"
            source.write_text(html)
            page = browser.new_page(
                viewport={"width": WIDTH, "height": 1800}, device_scale_factor=2
            )
            page.goto(source.as_uri())
            page.evaluate("document.fonts.ready")
            context = page.locator(f'[data-case="{example["id"]}"] .context')
            if config.get("show_assumption", False):
                assert context.inner_text() == config["display_assumption"]
            else:
                assert context.count() == 0
                assert config["display_assumption"] not in page.locator("body").inner_text()
            for cell in page.locator("[data-cell]").evaluate_all(
                "es=>es.map(e=>({key:e.dataset.cell,value:e.textContent}))"
            ):
                assert views.cells[cell["key"]] == cell["value"]
            for (case_id, role), value in expected.items():
                assert (
                    page.locator(f'[data-case="{case_id}"] [data-role="{role}"]').text_content()
                    == value
                )
            highlighted = page.locator(
                f'[data-case="{example["id"]}"] [data-role="astra"] .bad'
            ).all_text_contents()
            assert highlighted == ["of"], highlighted
            overflow = page.locator("td,th,.heading,.context,.value").evaluate_all(
                "es=>es.filter(e=>e.scrollWidth>e.clientWidth+1).map(e=>e.textContent)"
            )
            assert not overflow, overflow
            style = check_worksheet_style(page)
            canvas = page.locator("#figure").bounding_box()
            page.locator("#figure").screenshot(path=str(destination / "preview.png"))
            pdf = PAPER / output
            page.pdf(
                path=str(pdf),
                width=f"{WIDTH}px",
                height=f"{canvas['height']}px",
                print_background=True,
                margin=dict(top="0", bottom="0", left="0", right="0"),
            )
            artifacts[variant] = dict(
                path=output, sha256=digest(pdf), canvas=canvas, worksheet_style=style
            )
            page.close()
        browser.close()
    assert {name: digest(PAPER / name) for name in hashes_before} == hashes_before
    (folder / "evidence.json").write_text(
        json.dumps(
            dict(
                config_sha256=digest(CONFIG),
                scope=config["scope"],
                case=example,
                provenance=provenance,
                source_cells=views.cells,
                source_sha256=hashes_before,
                artifacts=artifacts,
                additional_model_calls=0,
            ),
            indent=2,
        )
        + "\n"
    )
    print("Verified the literal source, three completed runs, and unchanged benchmark hashes.")
    print("Rendered the Reasoning illustration and three-panel preview.")


if __name__ == "__main__":
    main()
