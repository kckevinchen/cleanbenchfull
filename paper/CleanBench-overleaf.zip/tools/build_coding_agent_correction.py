"""Audit native-agent correction outputs.

Then run build_coding_agent_repair.py to refresh the combined three-task tables.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import statistics
import sys
from pathlib import Path

import numpy as np
import yaml
from build_coding_agents import f1
from experiment_presentation import astra_interval

if __package__:
    from .tex_sources import generated_asset
else:
    from tex_sources import generated_asset

ARMS = ["codex_astra", "copilot_astra", "claude_opus", "copilot_opus"]


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", required=True, type=Path)
    args = parser.parse_args()
    repo = args.repo_root.resolve()
    sys.path.insert(0, str(repo))
    from src.evaluation import llm_correction as C

    paper = Path(__file__).resolve().parents[1]
    detection = read(paper / "build/generated/coding_agent_evidence.json")
    mapping_file = repo / "outputs/coding_agents/correction_full_once_20261002/arm_sources.json"
    mapping = read(mapping_file)["arms"]
    sources = {str(mapping_file.relative_to(repo)): digest(mapping_file)}
    evidence, matrices, signature = [], [], None
    for arm, det in zip(ARMS, detection["rows"]):
        directory = repo / mapping[arm]
        config = read(directory.parent / "config.json")
        common = [config[k] for k in ["scope", "locations", "benchmark_sha256", "task_sha256"]]
        signature = common if signature is None else signature
        assert common == signature
        settings = config["settings"]
        assert settings["effort"] == "low" and settings["time_limit_seconds"] == 300
        assert settings["scope"] == "full"
        scope, locations = config["scope"], config["locations"]
        assert len(scope) == len(set(scope)) == 164
        assert sum(map(len, locations.values())) == 1093
        assert locations == C.read(repo / settings["reference"])["locations"]
        datasets = Path(config["datasets"])
        assert C.tuning.benchmark_fingerprint(datasets) == config["benchmark_sha256"]
        task_path = repo / settings["task_prompt"]
        assert digest(task_path) == config["task_sha256"]
        task = yaml.safe_load(task_path.read_text())["task"]
        manifest = read(datasets / "_manifest.json")["datasets"]
        accepted, _ = C.score_repair.load_accepted_sets(
            datasets / "benchmark_cell.json",
            datasets,
            {v["source"]: k for k, v in manifest.items()},
        )
        receipts = sorted(directory.glob("table_*/receipt.json"))
        assert len(receipts) == 164
        seen, predictions, counts, successful, failed = set(), [], {}, [], []
        for path in receipts:
            r = read(path)
            name = r["dataset"]
            assert name in scope and name not in seen
            seen.add(name)
            assert r["model"] == settings["arms"][arm]["model"]
            assert r["agent"] == settings["arms"][arm]["agent"] == det["agent"]
            work = path.parent / "work"
            assert digest(work / "input.csv") == digest(datasets / name / "dirty.csv")
            headers, rows = C.S.load_table(work / "input.csv")
            assert read(work / "known_locations.json") == {
                "known_locations": [
                    {"row": row, "column": headers[col]} for row, col in locations[name]
                ]
            }
            assert (work / "TASK.txt").read_text() == task
            assert digest(work / "TASK.txt") == r["task_sha256"]
            edits = []
            if r["output_valid"] and r["exit_code"] == 0 and not r["timeout"]:
                parsed = C.validate_response(
                    (work / "corrections.json").read_text(), headers, locations[name]
                )
                assert parsed == r["corrections"]
                edits = C.changed_predictions(name, headers, rows, parsed)
                successful.append(r)
            else:
                failed.append(name)
            predictions.extend({**e, "detector": arm} for e in edits)
            targets = {(name, row, col) for row, col in locations[name]}
            values = {(name, e["row"], e["col"]): e["corrected_value"] for e in edits}
            tp, fp, fn, _, _ = C.score_repair._grade_correction(
                targets, values, lambda cell, value: value in accepted[cell], {}
            )
            counts[name] = [tp, fp, fn]
            sources[str(path.relative_to(repo))] = digest(path)
        assert seen == set(scope)
        stored = [
            json.loads(line)
            for line in (directory.parent / "predictions.jsonl").read_text().splitlines()
            if json.loads(line)["detector"] == arm
        ]
        key = lambda r: (r["dataset"], r["row"], r["col"])
        assert sorted(stored, key=key) == sorted(predictions, key=key)
        matrix = np.array([counts[name] for name in sorted(scope)])
        metric = read(directory.parent / "score.json")["results"][arm]
        tp, fp, fn = matrix.sum(axis=0).tolist()
        assert [tp, fp, fn] == [metric[k] for k in ["tp", "fp", "fn"]]
        assert metric["scope_datasets"] == 164 and metric["n_errors"] == tp + fn == 1093
        assert math.isclose(metric["precision"], tp / (tp + fp))
        assert math.isclose(metric["recall"], tp / (tp + fn))
        assert math.isclose(100 * metric["f1"], float(f1([tp, fp, fn])))
        evidence.append(
            {
                "arm": arm,
                "model": det["model"],
                "harness": det["harness"],
                "metrics": metric,
                "successful_tables": len(successful),
                "failed_tables": failed,
                "mean_successful_seconds": statistics.mean(
                    r["elapsed_seconds"] for r in successful
                ),
                "per_table_counts": counts,
            }
        )
        matrices.append(matrix)
        for name in ["config.json", "score.json", "predictions.jsonl"]:
            p = directory.parent / name
            sources[str(p.relative_to(repo))] = digest(p)
    rng = np.random.default_rng(20261002)
    differences = [[], []]
    for _ in range(10000):
        draw = rng.integers(0, 164, 164)
        values = [float(f1(m[draw].sum(axis=0))) for m in matrices]
        differences[0].append(values[1] - values[0])
        differences[1].append(values[2] - values[3])
    intervals = [np.percentile(d, [2.5, 97.5]).tolist() for d in differences]
    generated = paper / "assets/generated"
    (generated / "coding_agent_correction_task.txt").write_text(task)
    (generated_asset("coding_agents_correction_intervals.tex", directory=generated)).write_text(
        astra_interval(intervals[0], repair=True)
    )
    report = {
        "rows": evidence,
        "source_sha256": sources,
        "bootstrap": {"draws": 10000, "seed": 20261002, "intervals": intervals},
    }
    (paper / "build/generated/coding_agent_correction_evidence.json").write_text(
        json.dumps(report, indent=2) + "\n"
    )
    print(
        json.dumps(
            {
                "results": [
                    {"arm": r["arm"], "f1": r["metrics"]["f1"], "failed": len(r["failed_tables"])}
                    for r in evidence
                ],
                "intervals": intervals,
            }
        )
    )


if __name__ == "__main__":
    main()
