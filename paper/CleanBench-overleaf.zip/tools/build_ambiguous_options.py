"""Audit ambiguous labels and capture source-backed options for author review."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from collections import Counter
from pathlib import Path

from build_context_screenshots import SourceViews, esc
from figure_style import FIGURE_WIDTH
from playwright.sync_api import sync_playwright
from worksheet_style import check_worksheet_style, worksheet_css

PAPER = Path(__file__).resolve().parents[1]
WIDTH, HEIGHT = 960, 1358


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit(config):
    snapshot = PAPER.parent / config["snapshot"]
    benchmark = snapshot / "benchmark_cell.json"
    assert digest(benchmark) == config["benchmark_sha256"]
    assert digest(snapshot / "_manifest.json") == config["manifest_sha256"]
    labels = [json.loads(line) for line in benchmark.read_text().splitlines() if line.strip()]
    ambiguous = [r for r in labels if r["status"] == "ambiguous"]
    assert len(ambiguous) == len({(r["source"], r["row"], r["column"]) for r in ambiguous})
    counts = Counter(r["dataset"] for r in ambiguous)
    assert counts == {"pbi_500": 384, "bing21_500": 458}
    assert len(ambiguous) == 842
    views = SourceViews(snapshot)
    assert len({c["id"] for c in config["examples"]}) == len(config["examples"])
    ids = {c["id"] for c in config["examples"]}
    assert len(config["review_order"]) == len(ids)
    assert set(config["review_order"]) == ids
    assert set(config["shortlist_ids"]) <= ids
    assert config["review_order"][: len(config["shortlist_ids"])] == config["shortlist_ids"]
    assert len(config["shortlist_ids"]) % 2 == 0
    for case in config["examples"]:
        headers, rows = views.load(case["dataset"])
        assert views.manifest[case["dataset"]]["source"] == case["source"]
        assert views.sources[case["dataset"]]["sha256"] == case["source_sha256"]
        assert set(case["values"]) == {str(r) for r in case["rows"] if r is not None}
        for row, fields in case["values"].items():
            assert list(fields) == case["columns"]
            for field, value in fields.items():
                assert rows[int(row)][headers.index(field)] == value
        verified = set()
        for proof in case["labels"]:
            record = proof["record"]
            assert labels[proof["line"] - 1] == record
            assert record["status"] == "ambiguous" and record["corrected_value"] is None
            assert record["source"] == case["source"]
            assert case["values"][str(record["row"])][record["column"]] == record["original_value"]
            verified.add((record["row"], record["column"]))
        assert verified == {tuple(mark) for mark in case["marks"]}
    return views, counts


def card(case, views):
    headers, _ = views.load(case["dataset"])
    columns = [headers.index(f) for f in case["columns"]]
    ratios = case.get("column_widths") or {
        "A1": [0.5, 0.5],
        "A2": [0.35, 0.65],
        "A3": [0.22, 0.78],
        "A4": [0.28, 0.72],
        "A5": [0.3, 0.7],
        "A6": [0.2, 0.8],
        "A7": [0.6, 0.4],
        "A8": [0.27, 0.27, 0.46],
        "A9": [0.15, 0.29, 0.28, 0.28],
        "A10": [0.5, 0.5],
        "A11": [0.6, 0.4],
        "A12": [0.65, 0.35],
    }.get(case["id"])
    assert ratios and len(ratios) == len(columns)
    assert abs(sum(ratios) - 1) < 1e-9
    table = views.table(
        case["dataset"],
        case["rows"],
        columns,
        [(WIDTH - 120) * ratio for ratio in ratios],
        marks={(r, headers.index(c)): "?" for r, c in case["marks"]},
        coordinate_width=48,
    )
    interpretations = ""
    if "interpretations" in case:
        first, second = case["interpretations"]
        interpretations = (
            f'<div class="alternatives"><span>{esc(first)}</span>'
            f"<i>or</i><span>{esc(second)}</span></div>"
        )
    return f"""<section class="case" data-case="{case['id']}">
      <h2><span class="case-id">{case['id']}</span> {esc(case['title'])}
      <span class="verdict">Ambiguous</span></h2>
      <div class="capture">{table}</div>
      {interpretations}
      <p class="question">{esc(case['question'])}</p>
      <p class="explanation">{esc(case['explanation'])}</p>
      <p class="source">{esc(case['source'])}</p></section>"""


def document(config, views):
    sections = []
    lookup = {c["id"]: c for c in config["examples"]}
    examples = [lookup[key] for key in config["review_order"]]
    for i in range(0, len(examples), 2):
        sections.append(f"""<article class="review-page">
          <header><h1>Ambiguous annotation options</h1>
          <p>842 labeled cells: 384 relational + 458 spreadsheet</p></header>
          {''.join(card(c, views) for c in examples[i:i+2])}
          <footer>Source-table viewer screenshots; original strings and frozen labels.
          <span>{i // 2 + 1} / {(len(examples) + 1) // 2}</span></footer></article>""")
    css = (
        worksheet_css(WIDTH, printed_width=FIGURE_WIDTH)
        + f"""
    @page {{size:{WIDTH}px {HEIGHT}px;margin:0}}
    * {{box-sizing:border-box}} body {{margin:0;color:#263442;background:white;
      font:20px/1.4 'Liberation Sans',Arial,sans-serif}}
    #figure {{width:{WIDTH}px}} .review-page {{height:{HEIGHT}px;padding:36px;
      position:relative;break-after:page}} .review-page:last-child {{break-after:auto}}
    header {{border-bottom:2px solid #526779;margin-bottom:24px;padding-bottom:12px}}
    h1 {{font-size:29px;margin:0 0 6px}} header p {{font-size:18px;margin:0;color:#536372}}
    .case {{margin-bottom:24px;padding-bottom:22px;border-bottom:1px solid #cad2d9}}
    h2 {{font-size:23px;margin:0 0 16px;display:flex;align-items:center;gap:10px}}
    .case-id {{color:#486a89}} .verdict {{margin-left:auto;font-size:17px;
      color:#825719;background:#faf0db;border:1px solid #d3bc8c;padding:3px 10px}}
    #figure table.source {{font-size:20px}}
    #figure .field-names th {{height:68px;white-space:pre-wrap;overflow-wrap:anywhere}}
    #figure table.source td {{height:38px;overflow-wrap:anywhere}}
    #figure .omitted td,#figure .omitted th {{height:22px;line-height:1;padding:0 6px}}
    .sheet-bar {{display:none}} .question {{font-weight:700;margin:12px 0 5px}}
    .alternatives {{display:flex;align-items:center;gap:12px;margin-top:12px;
      font-size:18px;text-align:center}}
    .alternatives span {{flex:1;padding:6px;border:1px solid #cad2d9;background:#f5f7f8}}
    .alternatives i {{font-style:normal;color:#697783}}
    .explanation {{margin:0;font-size:19px;color:#46535f}}
    .source {{font-size:12px;color:#697783;margin:10px 0 0;overflow-wrap:anywhere}}
    footer {{position:absolute;bottom:24px;left:36px;right:36px;font-size:14px;color:#697783}}
    footer span {{float:right}}
    """
    )
    return f'<!doctype html><html lang="en"><meta charset="utf-8"><style>{css}</style><body><main id="figure">{"".join(sections)}</main></body></html>'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--browser", required=True, type=Path)
    args = parser.parse_args()
    config_path = PAPER / "figures/ambiguous_example_options.json"
    config = json.loads(config_path.read_text())
    views, counts = audit(config)
    folder = PAPER / "build/ambiguous_options"
    folder.mkdir(parents=True, exist_ok=True)
    markup = folder / "index.html"
    markup.write_text(document(config, views))
    pdf = PAPER / "assets/generated/ambiguous_example_options.pdf"
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=str(args.browser), headless=True)
        page = browser.new_page(viewport={"width": WIDTH, "height": HEIGHT}, device_scale_factor=3)
        page.goto(markup.as_uri())
        page.evaluate("document.fonts.ready")
        shown = page.locator("[data-cell]").evaluate_all(
            "es=>es.map(e=>[e.dataset.cell,e.textContent])"
        )
        for key, value in shown:
            assert views.cells[key] == value
        overflow = page.locator("td,th,h2,.question,.explanation,.alternatives span").evaluate_all(
            "es=>es.filter(e=>e.scrollWidth>e.clientWidth+1).map(e=>e.textContent)"
        )
        assert not overflow, overflow
        bounds = page.locator(".review-page").evaluate_all("""es=>es.map(p=>{
          const cases=[...p.querySelectorAll('.case')];
          return cases.at(-1).getBoundingClientRect().bottom <=
            p.querySelector('footer').getBoundingClientRect().top-12;})""")
        assert all(bounds), bounds
        styles = check_worksheet_style(page)
        captures = []
        for case in config["examples"]:
            path = folder / f'{case["id"]}.png'
            page.locator(f'[data-case="{case["id"]}"] .capture').screenshot(path=str(path))
            captures.append(dict(id=case["id"], screenshot_sha256=digest(path)))
        for i, article in enumerate(page.locator(".review-page").all(), 1):
            article.screenshot(path=str(folder / f"page-{i}.png"))
        page.pdf(path=str(pdf), width=f"{WIDTH}px", height=f"{HEIGHT}px", print_background=True)
        shortlist = PAPER / "assets/generated/ambiguous_example_shortlist.pdf"
        shortlist_pages = len(config["shortlist_ids"]) // 2
        page.locator(".review-page").evaluate_all(
            """(pages, count)=>pages.slice(0,count).forEach((p,i)=>{
              p.querySelector('h1').textContent='New ambiguous example options';
              p.querySelector('footer span').textContent=`${i+1} / ${count}`;
            })""",
            shortlist_pages,
        )
        page.pdf(
            path=str(shortlist),
            width=f"{WIDTH}px",
            height=f"{HEIGHT}px",
            print_background=True,
            page_ranges=f"1-{shortlist_pages}",
        )
        browser.close()
    shutil.copy2(pdf, folder / "ambiguous-options.pdf")
    shutil.copy2(shortlist, folder / "shortlist.pdf")
    (folder / "evidence.json").write_text(
        json.dumps(
            dict(
                config_sha256=digest(config_path),
                pdf_sha256=digest(pdf),
                shortlist_sha256=digest(shortlist),
                shortlist_ids=config["shortlist_ids"],
                ambiguous_cells=sum(counts.values()),
                counts_by_source=counts,
                options=len(config["examples"]),
                literal_cells_checked=len(shown),
                captures=captures,
                worksheet_style=styles,
                additional_model_calls=0,
            ),
            indent=2,
        )
        + "\n"
    )
    print(
        f"Verified {sum(counts.values())} ambiguous cells; rendered {len(captures)} options: {pdf}"
    )


if __name__ == "__main__":
    main()
