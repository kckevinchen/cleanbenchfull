"""Build a standalone source-verified gallery of Astra FP/FN examples."""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime
from decimal import Decimal
from pathlib import Path

from build_context_screenshots import SourceViews
from build_failure_examples import marked
from build_failure_requirement_pies import audited_groups
from failure_evidence import saved_issue
from playwright.sync_api import sync_playwright
from worksheet_style import check_worksheet_style, worksheet_css

PAPER = Path(__file__).resolve().parents[1]
CONFIG = PAPER / "figures/astra_error_analysis_options.json"
OUT = PAPER / "build/astra_error_analysis_options"
PDF = PAPER / "assets/generated/astra_error_analysis_options.pdf"
WIDTH, HEIGHT = 960, 1358
CONTENT_WIDTH = WIDTH - 80


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def escape(value):
    return html.escape(str(value), quote=True)


def verify_phone_sources(original, proposed, verification):
    """Compare recorded published numbers without asserting current reachability."""
    digits = re.sub(r"\D", "", original)
    assert re.sub(r"\D", "", proposed) == digits[:-1], "Expected final-digit loss"
    assert verification["scope"] == "published_number"
    assert verification["sources"]
    for source in verification["sources"]:
        published = re.sub(r"\D", "", source["published_number"])
        if not source["published_number"].startswith("+"):
            assert published.startswith("0") and digits.startswith("64")
            published = "64" + published[1:]
        assert published == digits, "Published number differs from the source cell"
        assert source["url"].startswith("https://")
        assert re.fullmatch(r"[0-9a-f]{64}", source["snapshot_sha256"])


def verify_relation(check, group, table, *, predictions=None, headers=None):
    """Verify a displayed relationship against literal source rows and references."""
    row = table[group["row"]]
    if check["kind"] == "phone_terminal_groups":
        value = row[group["column"]].strip()
        assert value == group["original"] and value.split()[-1].isdigit()
        assert len(value.split()[-1]) == 1
        peers = [
            record[group["column"]].strip()
            for index, record in enumerate(table)
            if index != group["row"] and re.search(r"\d", record[group["column"]])
        ]
        assert peers and all(v.split()[-1].isdigit() for v in peers)
        lengths = [len(v.split()[-1]) for v in peers]
        assert min(lengths) > 1, "Another phone also has a one-digit final group"
        return (
            f"The target alone ends in an isolated {value.split()[-1]}. The {len(peers)} "
            f"other numeric entries have {min(lengths)}–{max(lengths)} digits in the final group."
        )
    if check["kind"] == "composite_key":
        assert check["target"] == group["column"]
        for record in table:
            expected = check["separator"].join(record[field] for field in check["components"])
            assert record[check["target"]] == expected, "Source key violates the stated composition"
        expected = check["separator"].join(row[field] for field in check["components"])
        assert group["original"] == expected and group["proposed"] != expected
        source_fact = (
            f"Verified in all {len(table)} benchmark rows: {check['target']} = "
            + f" + {check['separator']!r} + ".join(check["components"])
            + "."
        )
        if predictions is None:
            return (
                source_fact + " Source values alone do not establish a violation in the edited row."
            )
        assert headers is not None
        runs = sorted(
            {
                event[0]
                for event in group["occurrences"]
                if tuple(event[1:]) == (group["dataset"], group["row"], group["col"])
            }
        )
        checks = []
        for run in runs:
            values = dict(row)
            changes = []
            for field in [*check["components"], check["target"]]:
                value = predictions.get((run, group["dataset"], group["row"], headers.index(field)))
                if value is not None:
                    values[field] = value
                    if field in check["components"]:
                        changes.append(f"{field} becomes {value!r}")
            expected = check["separator"].join(values[field] for field in check["components"])
            status = "preserves" if values[check["target"]] == expected else "breaks"
            context = "; ".join(changes) if changes else "the component fields are unchanged"
            checks.append(f"Run {run}: {context}; the recorded output {status} the composition.")
        return source_fact + " " + " ".join(checks)
    if check["kind"] == "date_within_period":
        assert len(group["accepted"]) == 1
        parse = lambda value: datetime.strptime(value, check["date_format"])
        start, end, pay = (parse(row[check[field]]) for field in ("start", "end", "pay"))
        original, reference = parse(group["original"]), parse(group["accepted"][0])
        assert original < start <= reference <= end < pay, "Date relationship is not supported"
        return (
            f"Verified chronology: the recorded approval {group['original']} predates the "
            f"pay period {row[check['start']]} to {row[check['end']]}. The reference "
            f"{group['accepted'][0]} lies inside that period, before pay date {row[check['pay']]}."
        )
    if check["kind"] == "matching_peer":
        peer = table[check["peer_row"]]
        assert check["peer_row"] != group["row"]
        assert all(row[field] == peer[field] for field in check["match_fields"])
        assert group["accepted"] == [peer[group["column"]]], "Peer does not contain the reference"
        return (
            f"Verified comparison: rows {group['row']} and {check['peer_row']} share "
            + ", ".join(f"{field}={row[field]}" for field in check["match_fields"])
            + f". The accepted string occurs verbatim in row {check['peer_row']}."
        )
    raise AssertionError(f"Unknown relationship check: {check['kind']}")


def classified_groups(config):
    """Load the frozen active judgments shared by the gallery and paper figure."""
    requirement_path = PAPER / config["requirements_config"]
    requirements = json.loads(requirement_path.read_text())
    groups, _ = audited_groups(requirements)
    lookup = {group["group_id"]: group for group in groups}
    classification = config["classification_source"]
    review_path = PAPER / classification["review"]
    assert digest(review_path) == classification["sha256"]
    metadata = json.loads((PAPER / classification["metadata"]).read_text())
    assert metadata["source_sha256"] == requirements["source_sha256"]
    assert metadata["model"] == classification["model"]
    with review_path.open() as stream:
        judgments = list(csv.DictReader(stream))
    assert len(judgments) == len(lookup) == metadata["completed_groups"] == 492
    judgments = {row["group_id"]: row for row in judgments}
    assert set(judgments) == set(lookup)
    for group_id, group in lookup.items():
        judgment = judgments[group_id]
        for field in ("outcome", "dataset", "column", "original"):
            assert judgment[field] == str(group[field]), (group_id, field)
        assert judgment["proposed"] == (group["proposed"] or "")
        assert json.loads(judgment["accepted"]) == group["accepted"]
        assert int(judgment["occurrences"]) == len(group["occurrences"])
        group["analysis_category"] = judgment["primary_category"]
    return requirements, groups, judgments


def prepare(config):
    requirements, groups, judgments = classified_groups(config)
    classification = config["classification_source"]
    lookup = {group["group_id"]: group for group in groups}
    events = {tuple(event): group["outcome"] for group in groups for event in group["occurrences"]}
    predictions = {}
    with (PAPER / requirements["predictions"]).open() as stream:
        for line in stream:
            row = json.loads(line)
            if row["detector"].endswith("/gpt-6-astra/selected"):
                run = int(row["detector"].split("/")[0].removeprefix("rep_"))
                predictions[run, row["dataset"], row["row"], row["col"]] = row["corrected_value"]
    stages = {}
    for run in requirements["repetitions"]:
        path = PAPER.parent / (
            "outputs/prompt_tuning/dev200_none_20260930_continuation/"
            f"rep_{run:02d}/recovered/compare_gpt-6-astra_selected/receipt.json"
        )
        stage = json.loads(path.read_text())
        assert not stage["failed_tables"], (run, stage["failed_tables"])
        stages[str(path.relative_to(PAPER.parent))] = digest(path)

    sys.path.insert(0, str(PAPER.parent))
    from src.evaluation.paper_evaluation.analysis import GroundTruth

    snapshot = PAPER / requirements["snapshot"]
    manifest = json.loads((snapshot / "_manifest.json").read_text())
    truth = GroundTruth(snapshot, manifest)
    views = SourceViews(snapshot)
    results = []
    assert len({s["id"] for s in config["cases"]}) == len(config["cases"])
    assert len({s["group_id"] for s in config["cases"]}) == len(config["cases"])
    for spec in config["cases"]:
        assert spec["group_id"] not in config["excluded_reference_groups"]
        group = lookup[spec["group_id"]]
        assert group["analysis_category"] == spec["category"]
        judgment = judgments[spec["group_id"]]
        ds, row, col = group["dataset"], group["row"], group["col"]
        key = ds, row, col
        headers, source_rows = views.load(ds)
        coords = manifest["datasets"][ds]["exported_to_source"]
        source_row = coords[row]
        assert source_rows[source_row][col] == group["original"]
        fields = spec["columns"]
        assert group["column"] in fields and all(field in headers for field in fields)
        assert set(spec.get("header_labels", {})) <= set(fields)
        selected = spec.get("rows")
        if selected is None:
            start = min(max(0, row - 1), max(0, len(coords) - 3))
            selected = list(range(start, min(len(coords), start + 3)))
        assert row in selected and len(selected) == len(set(selected))
        assert all(0 <= index < len(coords) for index in selected), (spec["id"], selected)
        outputs = []
        flags = {"FP": [], "FN": []}
        for run in requirements["repetitions"]:
            value = predictions.get((run, *key))
            outcome = events.get((run, *key))
            if outcome in {"clean_edit", "wrong_value"}:
                flags["FP"].append(run)
            if outcome in {"unchanged_error", "wrong_value"}:
                flags["FN"].append(run)
            if outcome is None:
                assert (key in truth.eligible and value in truth.accepted[key]) or (
                    key not in truth.errors and value is None
                ), (spec["id"], run, value)
            outputs.append(dict(run=run, value=value, outcome=outcome or "correct"))
        assert flags[spec["focus"]], spec["id"]
        pattern_runs = sorted(
            {event[0] for event in group["occurrences"] if tuple(event[1:]) == key}
        )
        assert pattern_runs
        selected_output = next(o for o in outputs if o["run"] == pattern_runs[0])
        response = saved_issue(
            PAPER,
            requirements["recorded_response_archive"],
            run=pattern_runs[0],
            dataset=ds,
            row=row,
            column=group["column"],
            original=group["original"],
            proposed=selected_output["value"],
        )
        for output in outputs:
            if output["run"] in pattern_runs:
                assert output["value"] == group["proposed"]
                assert output["outcome"] == group["outcome"]
        accepted = sorted(truth.accepted.get(key, []))
        clean = key not in truth.errors
        assert clean == (group["outcome"] == "clean_edit")
        facts = []
        for fact in spec.get("verified_facts", []):
            if fact == "numeric_equivalence":
                assert Decimal(group["original"]) == Decimal(group["proposed"])
                facts.append(f"Both numeric strings equal {Decimal(group['original'])}.")
            elif fact == "monthly_sum":
                values = source_rows[source_row]
                months = "July August September October November December January February March April May June".split()
                total = sum(int(values[headers.index(month)]) for month in months)
                assert total == int(values[headers.index("Total")])
                edited = total - int(group["original"]) + int(group["proposed"])
                assert total != edited
                facts.append(
                    f"Verified sum: original months = {total:,}; recorded Total = {total:,}; "
                    f"months after Astra's edit = {edited:,}."
                )
            elif fact == "shifted_row":
                reference = []
                reference_values = []
                for field in fields:
                    related = ds, row, headers.index(field)
                    assert related in truth.eligible and len(truth.accepted[related]) == 1
                    value = next(iter(truth.accepted[related]))
                    reference_values.append(value)
                    reference.append(field + "=" + value)
                assert Counter(
                    source_rows[source_row][headers.index(field)] for field in fields
                ) == Counter(reference_values)
                facts.append(
                    "Verified reordering of the original field values. Reference row: "
                    + "; ".join(reference)
                    + "."
                )
            elif fact == "digit_loss":
                original_digits = re.sub(r"\D", "", group["original"])
                proposed_digits = re.sub(r"\D", "", group["proposed"])
                assert len(original_digits) == len(proposed_digits) + 1
                assert any(
                    original_digits[:i] + original_digits[i + 1 :] == proposed_digits
                    for i in range(len(original_digits))
                )
                facts.append(
                    f"The source contains {len(original_digits)} digits; "
                    f"Astra's selected output contains {len(proposed_digits)}."
                )
            else:
                raise AssertionError(fact)
        if spec.get("web_verification"):
            verify_phone_sources(group["original"], group["proposed"], spec["web_verification"])
        if spec.get("verified_relations"):
            table = [dict(zip(headers, source_rows[index], strict=True)) for index in coords]
            facts.extend(
                verify_relation(check, group, table, predictions=predictions, headers=headers)
                for check in spec["verified_relations"]
            )
        results.append(
            dict(
                spec,
                dataset=ds,
                row=row,
                col=col,
                source_row=source_row,
                source=manifest["datasets"][ds]["source"],
                original=group["original"],
                accepted=accepted,
                clean=clean,
                outputs=outputs,
                flags=flags,
                pattern_runs=pattern_runs,
                selected_rows=[coords[index] for index in selected],
                fields=fields,
                field_indices=[headers.index(field) for field in fields],
                verified_fact_text=facts,
                classifier=classification["model"],
                classification_rationale=judgment["rationale"],
                classification_confidence=judgment["confidence"],
                classification_needs_review=judgment["needs_review"] == "True",
                recorded_explanation=response["explanation"],
                show_recorded_explanation=spec.get(
                    "show_recorded_explanation", config.get("show_recorded_explanation", False)
                ),
                show_classifier_rationale=config.get("show_classifier_rationale", True),
                response_evidence=response,
                source_sha256=views.sources[ds]["sha256"],
            )
        )
    return results, views, requirements, stages


def card(case, views):
    ds = case["dataset"]
    headers, rows = views.load(ds)
    columns = case["field_indices"]
    sizes = [
        max(10, min(48, max(len(str(rows[row][col])) for row in case["selected_rows"])))
        for col in columns
    ]
    weights = [size / sum(sizes) for size in sizes]
    marks = {(case["source_row"], case["col"]): "focus"}
    if "shifted_row" in case.get("verified_facts", []):
        marks = {(case["source_row"], col): "focus" for col in columns}
    table = views.table(
        ds,
        case["selected_rows"],
        columns,
        [(CONTENT_WIDTH - 36) * weight for weight in weights],
        marks=marks,
        coordinate_width=36,
        wrap_columns=columns,
    )
    outputs = defaultdict(list)
    for output in case["outputs"]:
        outputs[output["value"]].append(output["run"])
    output_rows = []
    reference = case["original"] if case["clean"] else case["accepted"][0]
    for index, (value, runs) in enumerate(outputs.items()):
        label = "Astra (run" + ("s " if len(runs) > 1 else " ") + ", ".join(map(str, runs)) + ")"
        if value is None:
            missed = " missed" if not case["clean"] else ""
            displayed = f'<i class="no-edit{missed}">No edit</i>'
        else:
            displayed = marked(value, reference, "good" if value in case["accepted"] else "bad")
        output_rows.append(
            f'<tr><th>{escape(label)}</th><td><span data-output="{index}">{displayed}</span></td></tr>'
        )
    refs = [case["original"]] if case["clean"] else case["accepted"]
    ref_html = "<br>".join(
        f'<span data-reference="{index}">{escape(value)}</span>' for index, value in enumerate(refs)
    )
    ref_label = "Reference: keep original" if case["clean"] else "Accepted reference"
    flag_text = " · ".join(
        f"{kind} in run" + ("s " if len(runs) > 1 else " ") + ", ".join(map(str, runs))
        for kind, runs in case["flags"].items()
        if runs
    )
    selected_pattern = (
        "Selected pattern: run"
        + ("s " if len(case["pattern_runs"]) > 1 else " ")
        + ", ".join(map(str, case["pattern_runs"]))
    )
    flag_text = selected_pattern + " · " + flag_text
    emphasis = (
        '<span class="choice">Selected for paper</span>'
        if case.get("selected_for_paper")
        else '<span class="choice">Shortlist</span>'
        if case["shortlist"]
        else ""
    )
    changes = []
    if case.get("new"):
        changes.append("New option")
    if case.get("previous_category"):
        changes.append("Previously: " + case["previous_category"])
    change_note = " · ".join(changes)
    review = (
        '<p class="review"><b>Check before selection:</b> ' + escape(case["review_note"]) + "</p>"
        if case.get("review_note")
        else ""
    )
    facts = "".join(f'<p class="fact">{escape(text)}</p>' for text in case["verified_fact_text"])
    verification = case.get("web_verification")
    web = ""
    if verification:
        links = ", ".join(
            f'<a href="{escape(source["url"])}">{escape(source["title"])}</a>'
            for source in verification["sources"]
        )
        web = (
            '<p class="fact"><b>Web evidence:</b> '
            + escape(verification["summary"])
            + f" Sources: {links}. Checked {escape(verification['checked_on'])}.</p>"
        )
    recorded = ""
    if case.get("show_recorded_explanation") and case["recorded_explanation"]:
        recorded = (
            '<p class="judgment"><b>Saved Astra explanation:</b> '
            + escape(case["recorded_explanation"])
            + "</p>"
        )
    references = []
    for source in case.get("reference_sources", []):
        assert source["url"].startswith("https://")
        references.append(
            f'<a href="{escape(source["url"])}">{escape(source["title"])}</a>: '
            + escape(source["claim"])
            + f' Checked {escape(source["checked_on"])}.'
        )
    reference_html = (
        '<p class="fact"><b>Primary source:</b> ' + " ".join(references) + "</p>"
        if references
        else ""
    )
    classification_html = (
        '<p class="judgment"><b>GPT-5.4 classification:</b> '
        + escape(case["classification_rationale"])
        + "</p>"
        if case.get("show_classifier_rationale", True)
        else ""
    )
    return f"""<section class="case" id="{case['id']}" data-case="{case['id']}"
      data-category="{escape(case['category'])}" data-focus="{case['focus']}">
      <h2><span class="case-id">{case['id']}</span> {escape(case['title'])}{emphasis}</h2>
      <div class="classification">{escape(case['category'])}{' · ' + escape(change_note) if change_note else ''}</div>
      <div class="run-flags">{escape(flag_text)}</div>
      <div class="context">{table}</div>
      <table class="outputs"><colgroup><col style="width:180px"><col></colgroup>
        <thead><tr><th>Method / reference</th><th>Value at the outlined cell</th></tr></thead>
        <tbody>{''.join(output_rows)}<tr class="reference"><th>{ref_label}</th><td>{ref_html}</td></tr></tbody>
      </table>
      <p class="observation">{escape(case['observation'])}</p>{facts}{web}{recorded}
      {reference_html}{classification_html}{review}
      <p class="source">{escape(case['source'])} · original row {case['source_row']}
        (worksheet row {case['source_row'] + 2}) · {escape(headers[case['col']])} · {case['group_id']}</p>
    </section>"""


def document(cases, views, config):
    fonts = PAPER / "build/fonts"
    css = f"""
    @page {{size:{WIDTH}px {HEIGHT}px;margin:0}}
    @font-face {{font-family:Libertine;src:url('{(fonts/'LinLibertine_Rah.ttf').as_uri()}')}}
    @font-face {{font-family:Libertine;src:url('{(fonts/'LinLibertine_RBah.ttf').as_uri()}');font-weight:700}}
    * {{box-sizing:border-box}}
    body {{margin:0;color:#253342;background:white;font:19px/1.3 Libertine}}
    #figure {{width:{WIDTH}px}}
    .review-page {{width:{WIDTH}px;height:{HEIGHT}px;padding:32px 40px 52px;
      position:relative;break-after:page}}
    .review-page:last-child {{break-after:auto}}
    .page-head {{border-bottom:1px solid #9faeb9;padding-bottom:10px;margin-bottom:20px}}
    h1 {{font-size:25px;margin:0 0 6px}}
    .page-head p {{font-size:17px;margin:0;color:#52616b}}
    .case {{width:{CONTENT_WIDTH}px;margin:0 0 22px;padding-bottom:15px;
      border-bottom:1px solid #cbd4dc;break-inside:avoid}}
    .case h2 {{font-size:21px;margin:0 0 7px;font-weight:700}}
    .case-id {{color:#355c77;margin-right:8px}}
    .choice {{float:right;font-size:15px;font-weight:400;
      padding:2px 6px;border:1px solid #8db19d;color:#166440}}
    .run-flags {{font-size:16px;color:#52616b;margin-bottom:8px}}
    .classification {{font-size:16px;color:#355c77;margin-bottom:6px}}
    .outputs {{margin-top:10px}}
    .observation,.fact,.review {{margin:9px 0 0}}
    .fact {{font-size:18px;color:#245c4b}}
    .review {{font-size:17px;color:#7b5523}}
    .judgment {{font-size:17px;color:#52616b;margin:9px 0 0}}
    .source {{font-size:13px;color:#65717c;overflow-wrap:anywhere;margin:8px 0 0}}
    footer {{position:absolute;bottom:22px;left:40px;right:40px;color:#65717c;
      font-size:14px;display:flex;justify-content:space-between}}
    .guide p,.guide li {{font-size:20px}}
    .guide table {{border-collapse:collapse;width:100%;margin:24px 0}}
    .guide th,.guide td {{border-bottom:1px solid #cbd4dc;padding:10px 8px;text-align:left}}
    .guide .ids {{font-size:17px;line-height:1.5}}
    .index-table {{width:100%;border-collapse:collapse;font-size:15px;line-height:1.15}}
    .index-table th,.index-table td {{padding:5px 6px;border-bottom:1px solid #dbe2e6;
      text-align:left;vertical-align:top}}
    .index-table th {{background:#f1f5f7}}
    .index-table .case-link,.index-table .page-number {{white-space:nowrap}}
    .index-table .status {{font-size:13px;white-space:nowrap;color:#166440}}
    a.case-link {{color:#355c77;text-decoration:none}}
    .no-edit.missed {{color:#c60000}}
    .no-edit {{color:#6b737d}}
    #staging {{width:{CONTENT_WIDTH}px;margin:32px 40px}}
    """ + worksheet_css(WIDTH, printed_width=10)
    css += """
    #figure .sheet-bar {display:none}
    #figure table.source,#figure table.outputs {font-size:17px;line-height:1.2}
    #figure table.source th,#figure table.source td,
    #figure table.outputs th,#figure table.outputs td {padding:4px 6px;overflow-wrap:anywhere}
    #figure table.source .field-names th {white-space:pre-wrap}
    #figure table.source .column-letters th {height:22px;padding:0}
    #figure table.source tr.selected {outline:none}
    #figure table.source td.marked {outline:2px solid #1a8b4f;outline-offset:-1px;z-index:1}
    #figure table.outputs tbody th {font-weight:400;background:#f3f6f8}
    #figure table.outputs tr.reference th {color:#08733c}
    #figure table.outputs tr.reference {outline:1px solid #8ebb9f;outline-offset:-1px}
    #figure table.outputs td {white-space:pre-wrap}
    """
    counts = Counter((case["category"], case["focus"]) for case in cases)
    overview = "".join(
        f'<tr><td>{escape(cat)}</td><td>{counts[cat,"FP"]}</td><td>{counts[cat,"FN"]}</td></tr>'
        for cat in config["categories"]
    )
    sections = []
    for category in config["categories"]:
        for focus in config["focuses"]:
            selected = [
                case for case in cases if case["category"] == category and case["focus"] == focus
            ]
            if not selected:
                continue
            ids = ", ".join(case["id"] for case in selected if case["shortlist"])
            sections.append(
                f'<p><b>{escape(category)} / {focus}</b><br><span class="ids">{ids or "See the full section."}</span></p>'
            )
    guide = f"""<article class="review-page guide">
      <header class="page-head"><h1>Astra error-analysis example options</h1>
      <p>{len(cases)} source-backed candidates · Knowledge / Formatting convention / Reasoning</p></header>
      <p>This document is for selecting examples. It uses the three recorded Astra
      evaluations from the paper. Source strings, source coordinates, predictions,
      and reference replacements are retained.</p>
      <table><thead><tr><th>Analysis category</th><th>FP section</th><th>FN section</th></tr></thead>
      <tbody>{overview}</tbody></table>
      <p><b>How to read the cases.</b> FP includes changes to clean values and incorrect
      replacements at labeled errors. An incorrect replacement is both FP and FN.
      The run labels identify exactly where a failure occurred; other runs may succeed.</p>
      <p>Selected pattern identifies the runs discussed by the case's category and
      observation. All three outputs are shown, including other edits or successes.</p>
      <p>The outline marks the cell being discussed. Reference means the frozen
      evaluation reference. Categories and classification explanations use the
      same GPT-5.4 judgments as the paper's failure-analysis pie charts.
      IDs stay unchanged when a case moves to a different category.</p>
      <h2>Start with these cases</h2>{''.join(sections)}
      <footer><span>Selection gallery; manuscript and evaluation scores unchanged.</span><span>1</span></footer>
      </article>"""
    if config.get("compact_guide"):
        review_focus = (
            f'<p>{escape(config["review_focus"])}</p>' if config.get("review_focus") else ""
        )
        if config.get("selection_groups"):
            ids = [case_id for group in config["selection_groups"] for case_id in group["ids"]]
            assert len(ids) == len(set(ids)) and set(ids) == {case["id"] for case in cases}
            sections = [
                f'<p><b>{escape(group["title"])}</b><br>'
                f'<span class="ids">{escape(", ".join(group["ids"]))}</span><br>'
                f'{escape(group["note"])}</p>'
                for group in config["selection_groups"]
            ]
        if config.get("full_index"):
            paper = [case for case in cases if case.get("selected_for_paper")]
            reasoning = [
                case for case in cases if case["id"] in config.get("priority_reasoning_ids", [])
            ]
            formatting = [
                case for case in cases if case["id"] in config.get("priority_formatting_ids", [])
            ]
            knowledge = [
                case for case in cases if case["id"] in config.get("priority_knowledge_ids", [])
            ]
            sections = []
            for title, group in (
                ("Selected for the paper", paper),
                ("Additional Knowledge options", knowledge),
                ("Additional Formatting convention options", formatting),
                ("Additional Reasoning options", reasoning),
            ):
                if not group:
                    continue
                links = ", ".join(
                    f'<a class="case-link" href="#{case["id"]}">{case["id"]}</a>'
                    f' (p. <span data-page-for="{case["id"]}"></span>)'
                    for case in group
                )
                sections.append(f"<p><b>{escape(title)}</b><br>{links}</p>")
            sections.append(
                "<p>The following three index pages list every candidate by category, "
                "with its title, FP/FN focus, selection status, and page. "
                "Click an ID or page number to open its source-backed comparison.</p>"
            )
        guide = f"""<article class="review-page guide">
          <header class="page-head"><h1>{escape(config['document_title'])}</h1>
          <p>{len(cases)} source-backed candidates · Astra end-to-end correction</p></header>
          <p>Each case shows the source table, Astra's saved outputs, and the reference.
          The outlined cell is the focus. Red marks the output difference; green marks
          the reference. Category labels use the updated evidence-based classification.</p>
          {review_focus}
          <table><thead><tr><th>Analysis category</th><th>FP focus</th><th>FN focus</th></tr></thead>
          <tbody>{overview}</tbody></table>
          <h2>Review guide</h2>{''.join(sections)}
          <p>{escape(config.get("selection_note", "These are example options. The complete gallery retains all earlier cases. No benchmark labels, model outputs, or scores have been changed."))}</p>
          <footer><span>Original context and source-checked comparisons.</span><span>1</span></footer>
          </article>"""
    index = ""
    if config.get("full_index"):
        for position, category in enumerate(config["categories"], 2):
            selected = [case for case in cases if case["category"] == category]
            rows = []
            for case in selected:
                status = (
                    "Paper"
                    if case.get("selected_for_paper")
                    else "Shortlist"
                    if case.get("in_shortlist")
                    else "Candidate"
                )
                rows.append(
                    f'<tr data-index-case="{case["id"]}">'
                    f'<td><a class="case-link" href="#{case["id"]}">{case["id"]}</a></td>'
                    f'<td>{case["focus"]}</td><td>{escape(case["title"])}</td>'
                    f'<td class="status">{status}</td>'
                    f'<td class="page-number"><a class="case-link" href="#{case["id"]}">'
                    f'<span data-page-for="{case["id"]}"></span></a></td></tr>'
                )
            index += f"""<article class="review-page index-page">
              <header class="page-head"><h1>{escape(category)}: complete case index</h1>
              <p>{len(selected)} candidates · IDs and page numbers link to the cases</p></header>
              <table class="index-table"><thead><tr><th>ID</th><th>Focus</th>
              <th>Case</th><th>Selection</th><th>Page</th></tr></thead>
              <tbody>{"".join(rows)}</tbody></table>
              <footer><span>Paper = currently selected; Shortlist = prioritized candidates.</span>
              <span>{position}</span></footer></article>"""
    return (
        '<!doctype html><html lang="en"><meta charset="utf-8">'
        f'<style>{css}</style><body><main id="figure">{guide}{index}'
        f'<div id="staging">{"".join(card(case, views) for case in cases)}</div></main></body></html>'
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--browser", type=Path, required=True)
    parser.add_argument("--config", type=Path, default=CONFIG)
    parser.add_argument("--output-dir", type=Path, default=OUT)
    parser.add_argument("--pdf", type=Path, default=PDF)
    args = parser.parse_args()
    out, pdf, config_path = args.output_dir.resolve(), args.pdf.resolve(), args.config.resolve()
    out.mkdir(parents=True, exist_ok=True)
    pdf.parent.mkdir(parents=True, exist_ok=True)
    config = json.loads(config_path.read_text())
    cases, views, requirements, stages = prepare(config)
    markup = out / "index.html"
    markup.write_text(document(cases, views, config))
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(executable_path=str(args.browser), headless=True)
        page = browser.new_page(viewport={"width": WIDTH, "height": HEIGHT}, device_scale_factor=2)
        page.goto(markup.as_uri())
        page.evaluate("document.fonts.ready")
        for case in cases:
            section = page.locator(f'[data-case="{case["id"]}"]')
            for field, label in case.get("header_labels", {}).items():
                section.locator(".field-names th:not(.coord)").nth(
                    case["fields"].index(field)
                ).evaluate("(e,v)=>{e.title=e.textContent;e.textContent=v}", label)
        pages = page.evaluate(
            """({height})=>{
          const root=document.querySelector('#figure');
          const cards=[...document.querySelectorAll('#staging .case')];
          const frontPages=root.querySelectorAll('.review-page').length;
          const result=[];let active=null;
          for (const card of cards) {
            const key=card.dataset.category+' / '+card.dataset.focus;
            const needed=card.getBoundingClientRect().height+22;
            if (!active || active.key!==key || active.used+needed>height-170) {
              const article=document.createElement('article');article.className='review-page';
              const header=document.createElement('header');header.className='page-head';
              const h=document.createElement('h1');h.textContent=key;
              const p=document.createElement('p');p.textContent='Astra · frozen three-run end-to-end correction outputs';
              header.append(h,p);article.append(header);
              const footer=document.createElement('footer');
              footer.innerHTML='<span>Original context above; predictions and reference below.</span><span>'+(result.length+frontPages+1)+'</span>';
              article.append(footer);root.append(article);
              active={key,article,footer,used:0,ids:[]};result.push(active);
            }
            if (needed>height-170) throw new Error('Case too tall: '+card.id);
            active.article.insertBefore(card,active.footer);active.used+=needed;active.ids.push(card.id);
          }
          document.querySelector('#staging').remove();
          const pageById=Object.fromEntries(result.flatMap((p,i)=>p.ids.map(id=>[id,i+frontPages+1])));
          for(const entry of root.querySelectorAll('[data-page-for]')) {
            if(!(entry.dataset.pageFor in pageById)) throw new Error('Unknown case in index');
            entry.textContent=pageById[entry.dataset.pageFor];
          }
          return result.map((p,i)=>({page:i+frontPages+1,section:p.key,ids:p.ids,height:p.used}));
        }""",
            {"height": HEIGHT},
        )
        assert [key for group in pages for key in group["ids"]] == [case["id"] for case in cases]
        for cell in page.locator("[data-cell]").evaluate_all(
            "es=>es.map(e=>({key:e.dataset.cell,value:e.textContent}))"
        ):
            assert views.cells[cell["key"]] == cell["value"], cell
        for case in cases:
            section = page.locator(f'[data-case="{case["id"]}"]')
            unique = list(dict.fromkeys(row["value"] for row in case["outputs"]))
            for index, value in enumerate(unique):
                assert section.locator(f'[data-output="{index}"]').text_content() == (
                    "No edit" if value is None else value
                )
            refs = [case["original"]] if case["clean"] else case["accepted"]
            for index, value in enumerate(refs):
                assert section.locator(f'[data-reference="{index}"]').text_content() == value
        overflow = page.locator("td,th,h1,h2,.observation,.fact,.review,.source").evaluate_all(
            "es=>es.filter(e=>e.scrollWidth>e.clientWidth+1).map(e=>e.textContent)"
        )
        assert not overflow, overflow
        too_tall = page.locator(".review-page").evaluate_all("""pages=>pages.filter(p=>{
          const footer=p.querySelector('footer').getBoundingClientRect();
          return [...p.querySelectorAll('.case')].some(c=>c.getBoundingClientRect().bottom>footer.top-5);
        }).map(p=>p.textContent.slice(0,80))""")
        assert not too_tall, too_tall
        if config.get("full_index"):
            indexed = page.locator("[data-index-case]").evaluate_all(
                "es=>es.map(e=>e.dataset.indexCase)"
            )
            assert len(indexed) == len(cases) and set(indexed) == {c["id"] for c in cases}
            clipped = page.locator(".index-page").evaluate_all("""es=>es.filter(e=>
                e.querySelector('.index-table').getBoundingClientRect().bottom >
                e.querySelector('footer').getBoundingClientRect().top-5
            ).map(e=>e.querySelector('h1').textContent)""")
            assert not clipped, clipped
        page_count = page.locator(".review-page").count()
        style = check_worksheet_style(page)
        markup.write_text(page.content())
        page.locator(".review-page").first.screenshot(path=str(out / "overview.png"))
        for group in pages:
            if group["ids"][0] in {"KFP01", "KFN01", "FFP01", "FFN01", "RFP01", "RFN01"}:
                page.locator(".review-page").nth(group["page"] - 1).screenshot(
                    path=str(out / (group["ids"][0] + ".png"))
                )
        page.pdf(
            path=str(pdf),
            width=f"{WIDTH}px",
            height=f"{HEIGHT}px",
            print_background=True,
            margin=dict(top="0", bottom="0", left="0", right="0"),
        )
        browser.close()
    with (out / "case_index.csv").open("w", newline="") as stream:
        fields = [
            "id",
            "category",
            "previous_category",
            "focus",
            "title",
            "shortlist",
            "review_note",
            "page",
            "group_id",
            "new",
            "classification_confidence",
            "classification_needs_review",
            "classification_rationale",
        ]
        writer = csv.DictWriter(stream, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        for case in cases:
            position = next(group["page"] for group in pages if case["id"] in group["ids"])
            writer.writerow(
                {key: case.get(key, "") if key != "page" else position for key in fields}
            )
    with (out / "explanation_audit.csv").open("w", newline="") as stream:
        fields = [
            "id",
            "category",
            "focus",
            "group_id",
            "observation",
            "original",
            "recorded_explanation",
            "proposed",
            "reference",
            "receipt_sha256",
        ]
        writer = csv.DictWriter(stream, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        for case in cases:
            response = case["response_evidence"]
            writer.writerow(
                {
                    **{k: case[k] for k in fields[:7]},
                    "proposed": response["issue"].get("corrected_value")
                    if response["issue"]
                    else None,
                    "reference": json.dumps(
                        case["accepted"] if not case["clean"] else [case["original"]]
                    ),
                    "receipt_sha256": response["receipt_sha256"],
                }
            )
    (out / "evidence.json").write_text(
        json.dumps(
            dict(
                config_sha256=digest(config_path),
                requirements_config_sha256=digest(PAPER / config["requirements_config"]),
                source_sha256=requirements["source_sha256"],
                classification_source=config["classification_source"],
                execution_receipts=stages,
                cases=cases,
                sources=views.sources,
                pages=pages,
                worksheet_style=style,
                pdf_sha256=digest(pdf),
                additional_model_calls=0,
            ),
            indent=2,
        )
        + "\n"
    )
    print(
        f"Verified {len(cases)} distinct example candidates, {len(views.cells)} source cells, "
        f"and three-run outputs; rendered {page_count} review pages."
    )


if __name__ == "__main__":
    main()
