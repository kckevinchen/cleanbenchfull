"""Add sample SD to Table 3 using independent per-run aggregates.

One-run methods keep an undefined SD. Never manufacture repetitions or infer
run-to-run variability from bootstrap samples or individual table scores.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
import sys
from pathlib import Path

import matplotlib.pyplot as plt
from build_accuracy_presentation import (
    TYPES,
    colorbar,
    e2e_table_rows,
    panel,
    positions,
    read,
)
from figure_style import FIGURE_WIDTH, configure, save
from repetition_inputs import load_baseline_runs, replacement_groups

PAPER = Path(__file__).resolve().parents[1]
GENERATED = PAPER / "assets/generated"
METRICS = ("precision", "recall", "f1", "fpr", *(f"recall_{kind}" for kind, _ in TYPES))
VARIANCE_CATEGORIES = {"Direct LLMs (API)", "Coding agents"}


def sample_summary(values):
    if not values or any(not math.isfinite(value) for value in values):
        raise ValueError("A run series must contain finite observations")
    return statistics.mean(values), statistics.stdev(values) if len(values) > 1 else None


def saved_rows():
    rows = read("e2e_table_variability.csv")
    for row in rows:
        row["repetitions"] = int(row["repetitions"])
        row["variance_requested"] = str(row["variance_requested"]).lower() == "true"
        for metric in METRICS:
            row[metric] = float(row[metric])
            row["sd_" + metric] = float(row["sd_" + metric]) if row["sd_" + metric] else None
    return rows


def aggregate(roster, type_runs, false_positive_runs, additional_runs=(), replacement_runs=()):
    rows = e2e_table_rows(roster, false_positive_runs)
    seen = set()
    indexed = {}
    for record in type_runs:
        key = record["method"], int(record["run"]), record["error_type"]
        if key in seen:
            raise ValueError("Duplicate method/run/error-type observation")
        seen.add(key)
        indexed[key] = record
    result = []
    identities = set()
    agents = {r["method"] for r in rows if r["category"] == "Coding agents"}
    replacements = replacement_groups(
        replacement_runs,
        {r["method"] for r in rows if r["category"] not in VARIANCE_CATEGORIES},
    )
    for run in additional_runs:
        if run["method"] not in agents:
            raise ValueError("Unexpected coding-agent method")
        if run["identity"] in identities:
            raise ValueError("A repeated run identity cannot be counted twice")
        identities.add(run["identity"])
    for row in rows:
        method = row["method"]
        runs = [r for r in false_positive_runs if r["method"] == method]
        requested = row["category"] in VARIANCE_CATEGORIES or len(runs) > 1
        ids = [int(r["run"]) for r in runs]
        assert len(ids) == len(set(ids)) == int(row["repetitions"])
        series = {metric: [] for metric in METRICS}
        for record in runs:
            run = int(record["run"])
            overall = indexed[method, run, "overall"]
            assert (int(overall["tables"]), int(overall["targets"])) == (1000, 1093)
            for metric in ("precision", "recall", "f1"):
                series[metric].append(float(overall[f"micro_{metric}"]))
            series["fpr"].append(100 * int(record["fp_clean"]) / int(record["clean_cells"]))
            for kind, _ in TYPES:
                series[f"recall_{kind}"].append(float(indexed[method, run, kind]["micro_recall"]))
        for metric, values in series.items():
            assert math.isclose(statistics.mean(values), float(row[metric]), abs_tol=1e-10), (
                method,
                metric,
            )
        extra = [run for run in additional_runs if run["method"] == method]
        if extra and row["category"] != "Coding agents":
            raise ValueError("Only the admitted coding-agent repetitions may extend frozen runs")
        for run in extra:
            if (run["tables"], run["targets"]) != (1000, 1093):
                raise ValueError("Partial runs cannot contribute to variance")
            for metric in METRICS:
                value = float(run["metrics"][metric])
                if not math.isfinite(value) or not 0 <= value <= 100:
                    raise ValueError("Invalid per-run percentage")
                series[metric].append(value)
        if method in replacements:
            if extra:
                raise ValueError("A method cannot mix replacement and additional trials")
            series = {
                metric: [float(run["metrics"][metric]) for run in replacements[method]]
                for metric in METRICS
            }
            if any(
                not math.isfinite(value) or not 0 <= value <= 100
                for values in series.values()
                for value in values
            ):
                raise ValueError("Invalid replacement per-run percentage")
            requested = True
        spreads, means = {}, {}
        for metric, values in series.items():
            mean, sd = sample_summary(values)
            means[metric] = mean
            spreads[f"sd_{metric}"] = sd if requested else None
        result.append(
            {
                **row,
                **means,
                "mean_fp_clean": means["fpr"] * float(row["clean_cells"]) / 100,
                "repetitions": len(series["f1"]),
                "variance_requested": requested,
                **spreads,
            }
        )
    return result


def load_agent_runs(root):
    """Accept only complete, receipt-backed repetitions of the E2E task."""
    repo = PAPER.parent
    sys.path.insert(0, str(repo))
    from build_empty_match_metrics import empty_match_table_scores
    from build_macro_type_metrics import scored_cells, slice_tables
    from external.rein.score_repair import _extract_value
    from paper_taxonomy import project_sets
    from src.evaluation.coding_agent_e2e_report import collect
    from src.evaluation.paper_evaluation.analysis import GroundTruth

    reference = json.loads(
        (repo / "outputs/coding_agents/astra_e2e_low_access_20261027/config.json").read_text()
    )
    snapshot = Path(reference["datasets"])
    truth = GroundTruth(snapshot, json.loads((snapshot / "_manifest.json").read_text()))
    targets = {kind: cells & truth.eligible for kind, cells in project_sets(truth.fine).items()}
    result = []
    for agent, name in (("codex", "Codex"), ("copilot", "Copilot")):
        for repetition in (2, 3):
            folder = root / f"{agent}_rep{repetition}"
            report_path = folder / "evaluation/REPORT.json"
            if not report_path.exists():
                continue
            config, _, predictions, scopes, _, _ = collect(folder)
            assert config["scope"] == reference["scope"]
            assert config["task_sha256"] == reference["task_sha256"]
            assert config["benchmark_sha256"] == reference["benchmark_sha256"]
            for field in ("effort", "cli_versions", "time_limit_seconds", "workers_per_agent"):
                assert config["config"][field] == reference["config"][field]
            assert config["config"]["models"][agent] == reference["config"]["models"][agent]
            assert len(scopes[agent]) == 1000
            report = json.loads(report_path.read_text())
            assert report["partial"] is False
            for relative, digest in report["source_sha256"].items():
                assert hashlib.sha256((folder / relative).read_bytes()).hexdigest() == digest
            rows = [r for r in predictions if r["detector"] == agent]
            states = {}
            for path in (folder / agent).glob("table_*/receipt.json"):
                receipt = json.loads(path.read_text())
                states[receipt["dataset"]] = (
                    "complete"
                    if receipt["output_valid"]
                    and receipt["exit_code"] == 0
                    and not receipt["timeout"]
                    else "failed"
                )
            tables, _ = truth.analyze(rows, "e2e", states)
            correct_edits, attempted = scored_cells(rows, truth)
            slices = slice_tables(correct_edits, attempted, targets, states, truth.eligible)
            macro = {
                key: 100
                * statistics.mean(empty_match_table_scores(table)[key] for table in tables.values())
                for key in ("precision", "recall", "f1")
            }
            macro.update(
                {
                    f"recall_{kind}": 100
                    * statistics.mean(
                        empty_match_table_scores(table)["recall"] for table in local.values()
                    )
                    for kind, local in slices.items()
                }
            )
            correct = set()
            for row in rows:
                cell = (row["dataset"], int(row["row"]), int(row["col"]))
                if cell in truth.eligible and _extract_value(row) in truth.accepted[cell]:
                    correct.add(cell)
            tp, fp, fn = (sum(t[k] for t in tables.values()) for k in ("tp", "fp", "fn"))
            score = report["metrics"]["end_to_end"][agent]
            assert [tp, fp, fn] == [score[k] for k in ("tp", "fp", "fn")]
            assert tp + fn == 1093
            assert len(correct) == tp
            metrics = {
                "precision": 100 * tp / (tp + fp) if tp + fp else 0,
                "recall": 100 * tp / (tp + fn),
                "f1": 200 * tp / (2 * tp + fp + fn),
                "fpr": 100 * sum(t["outside_target"] for t in tables.values()) / 362393,
                **{
                    f"recall_{kind}": 100 * len(correct & targets[kind]) / len(targets[kind])
                    for kind, _ in TYPES
                },
            }
            result.append(
                {
                    "identity": str(folder.resolve()),
                    "method": f"GPT-6-astra ({name})",
                    "tables": 1000,
                    "targets": 1093,
                    "metrics": metrics,
                    "macro_metrics": macro,
                }
            )
    return result


def draw(rows, show_variance=True, *, output=None, review_methods=None):
    configure()
    plt.rcParams.update(
        {
            "mathtext.fontset": "custom",
            "mathtext.rm": "Linux Libertine",
            "mathtext.it": "Linux Libertine:italic",
            "mathtext.bf": "Linux Libertine:bold",
            "mathtext.default": "regular",
        }
    )
    category_height = 0.88
    grid_height = positions(rows, category_height=category_height)[2] * (
        0.17 if show_variance else 0.125
    )
    height = grid_height + 0.56
    fig = plt.figure(figsize=(FIGURE_WIDTH, height))
    method_labels = {}
    commercial = {
        "Excel": "Microsoft Excel Clean Data",
        "Google Sheets": "Google Sheets Smart Cleanup",
    }
    for row in rows:
        method = row["method"].removesuffix(" (Prompt-tuned)")
        label = commercial.get(method, method)
        if row.get("constraint_selection"):
            label += r"$^{\dagger}$"
        method_labels[method] = label + (
            f" (n={row['repetitions']})" if show_variance and row["variance_requested"] else ""
        )
    panel(
        fig,
        rows,
        ["Overall (%)", *(name for _, name in TYPES)],
        lambda row: [float(row[k]) for k in METRICS],
        left=0.29,
        width=0.70,
        top=1 - 0.50 / height,
        height=grid_height / height,
        highlight_group="Overall (%)",
        header_legend=True,
        category_height=category_height,
        metrics_by_group=[("P ↑", "R ↑", r"$F_1$ ↑", "FPR ↓"), ("R ↑",), ("R ↑",), ("R ↑",)],
        method_labels=method_labels,
        review_methods=review_methods,
        deviations=lambda row: [row[f"sd_{k}"] for k in METRICS]
        if show_variance and row["variance_requested"]
        else None,
    )
    colorbar(
        fig,
        1 / FIGURE_WIDTH,
        1 - 10 / (72 * height),
        70 / (72 * FIGURE_WIDTH),
        label=r"P/R/$F_1$ (%)",
    )
    target = output or PAPER / (
        "figures/paper/e2e_type_variability.pdf"
        if show_variance
        else "figures/paper/e2e_type_heatmap.pdf"
    )
    save(fig, target, check_layout=True)
    plt.close(fig)
    return target


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--agent-repeat-root",
        type=Path,
        help="Include only complete, verified new coding-agent repetitions",
    )
    parser.add_argument(
        "--baseline-repeat-root",
        type=Path,
        help="Use independently verified fresh three-run baseline series",
    )
    parser.add_argument(
        "--refresh-point",
        action="store_true",
        help="Update the point-estimate table with the same run means",
    )
    parser.add_argument(
        "--recompute",
        action="store_true",
        help="Recompute from original per-run inputs rather than redraw saved summaries",
    )
    args = parser.parse_args()
    sources = ("task_type_metrics.csv", "macro_type_metrics_runs.csv", "false_edits_ba_runs.csv")
    additional = load_agent_runs(args.agent_repeat_root.resolve()) if args.agent_repeat_root else []
    replacements = (
        load_baseline_runs(args.baseline_repeat_root) if args.baseline_repeat_root else []
    )
    redraw = not (args.recompute or args.agent_repeat_root or args.baseline_repeat_root)
    if redraw and (GENERATED / "e2e_table_variability.csv").exists():
        rows = saved_rows()
        sources = ("e2e_table_variability.csv",)
    else:
        rows = aggregate(
            *(read(name) for name in sources),
            additional_runs=additional,
            replacement_runs=replacements,
        )
    with (GENERATED / "e2e_table_variability.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    output = draw(rows)
    if args.refresh_point:
        point_rows = [
            {
                key: value
                for key, value in row.items()
                if not key.startswith("sd_") and key != "variance_requested"
            }
            for row in rows
        ]
        with (GENERATED / "e2e_table_point.csv").open("w", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(point_rows[0]), lineterminator="\n")
            writer.writeheader()
            writer.writerows(point_rows)
        draw(rows, show_variance=False)
    evidence = {
        "source_sha256": {
            name: hashlib.sha256((GENERATED / name).read_bytes()).hexdigest() for name in sources
        },
        "statistic": "sample standard deviation across independent runs (ddof=1)",
        "input_mode": "saved_summaries" if redraw else "verified_per_run_inputs",
        "units": "percentages; SD in percentage points and variance in squared percentage points",
        "single_run_sd": None,
        "methods_with_three_runs": [
            r["method"] for r in rows if r["variance_requested"] and int(r["repetitions"]) == 3
        ],
        "methods_needing_more_runs": [
            r["method"] for r in rows if r["variance_requested"] and int(r["repetitions"]) < 3
        ],
        "model_calls": 0,
        "additional_completed_runs": additional,
        "replacement_baseline_runs": replacements,
        "summaries": [
            {
                "method": row["method"],
                "repetitions": row["repetitions"],
                "metrics": {
                    metric: {
                        "mean": row[metric],
                        "sample_sd": row[f"sd_{metric}"],
                        "sample_variance": row[f"sd_{metric}"] ** 2
                        if row[f"sd_{metric}"] is not None
                        else None,
                    }
                    for metric in METRICS
                },
            }
            for row in rows
        ],
    }
    folder = PAPER / "build/e2e_variability"
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "evidence.json").write_text(json.dumps(evidence, indent=2) + "\n")
    lines = [
        "End-to-end correction: independent runs, 1,000 tables per run.",
        "",
        "P/R/F1 are mean ± sample SD (%) across per-run micro scores (ddof=1). "
        "Variance is in squared percentage points. A dash means undefined for one run. "
        "Failed tables remain in the full scoring denominator. No new inference is performed by this report.",
        "",
        "| Method | n | P | R | F1 | F1 variance |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        cells = []
        for metric in ("precision", "recall", "f1"):
            sd = row[f"sd_{metric}"]
            spread = (
                f"{sd:.4g}"
                if sd is not None and 0 < sd < 0.005
                else f"{sd:.2f}"
                if sd is not None
                else "—"
            )
            cells.append(
                f"{row[metric]:.2f} ± {spread}" if sd is not None else f"{row[metric]:.2f} (—)"
            )
        sd = row["sd_f1"]
        variance = f"{sd ** 2:.6g}" if sd is not None else "—"
        lines.append(
            f"| {row['method']} | {row['repetitions']} | " + " | ".join(cells) + f" | {variance} |"
        )
    (folder / "REPORT.md").write_text("\n".join(lines) + "\n")
    print(output)


if __name__ == "__main__":
    main()
