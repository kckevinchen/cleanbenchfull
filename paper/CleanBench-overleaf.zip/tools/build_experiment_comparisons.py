"""Present prompt and end-to-end correction comparisons from frozen scores."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from build_accuracy_presentation import SIZE_BANDWIDTH, smooth_size_trend
from figure_style import COLUMN_WIDTH, configure, save

if __package__:
    from .tex_sources import generated_asset
else:
    from tex_sources import generated_asset

PAPER = Path(__file__).resolve().parents[1]
GENERATED = PAPER / "assets/generated"
MODELS = ("GPT-4.1", "GPT-5.2", "GPT-5.5", "GPT-6-astra")
METHODS = (
    ("GPT-4.1 (Prompt-tuned)", "GPT-4.1", "#7b8794", "o", "-"),
    ("GPT-5.2 (Prompt-tuned)", "GPT-5.2", "#b65378", "s", "--"),
    ("GPT-5.5 (Prompt-tuned)", "GPT-5.5", "#008579", "^", "-."),
    ("GPT-6-astra (Prompt-tuned)", "GPT-6-astra", "#1767c6", "D", "-"),
    ("GPT-6-astra (Codex)", "GPT-6-astra (Codex)", "#d48623", "P", "--"),
    ("GPT-6-astra (Copilot)", "GPT-6-astra (Copilot)", "#8555a0", "X", ":"),
)
PANELS = (
    ("source", "Table source", ("Relational", "Spreadsheet")),
    ("columns", "Columns per table", ("2-4", "5-8", "9-20")),
    ("rows", "Rows per table", ("10-24", "25-49", "50-100")),
)


def read(name):
    with (generated_asset(name, directory=GENERATED)).open() as handle:
        return list(csv.DictReader(handle))


def prompt_table(rows):
    scores = {
        row["method"]: row
        for row in rows
        if row["task"] == "e2e" and row["category"] == "Direct LLMs (API)"
    }
    lines = [
        r"\begingroup",
        r"\small",
        r"\setlength{\tabcolsep}{2.4pt}",
        r"\begin{tabular*}{\columnwidth}{@{\extracolsep{\fill}}lrrrrrr@{}}",
        r"\toprule",
        r" & \multicolumn{3}{c}{Initial prompt} & \multicolumn{3}{c}{Optimized prompt} \\",
        r"\cmidrule(lr){2-4}\cmidrule(l){5-7}",
        r"Model & P & R & $F_1$ & P & R & $F_1$ \\",
        r"\midrule",
    ]
    evidence = []
    for model in MODELS:
        initial, optimized = [
            scores[f"{model} ({variant})"] for variant in ("Base", "Prompt-tuned")
        ]
        values = [
            float(row[metric])
            for row in (initial, optimized)
            for metric in ("precision", "recall", "f1")
        ]
        assert all(0 <= value <= 100 for value in values)
        lines.append(model + " & " + " & ".join(f"{value:.2f}" for value in values) + r" \\")
        evidence.append({"model": model, "initial": initial, "optimized": optimized})
    lines.extend([r"\bottomrule", r"\end{tabular*}", r"\endgroup", ""])
    (generated_asset("prompt_optimization_table.tex", directory=GENERATED)).write_text(
        "\n".join(lines)
    )
    return evidence


def variation_figure(rows, exact_rows, *, targets=1093, output=None):
    scores = {}
    for row in rows:
        if row["task"] == "e2e" and row["source_filter"] == "All":
            key = row["method"], row["dimension"], row["bucket"]
            assert key not in scores, key
            scores[key] = row
    configure(font_size=7.5)
    fig = plt.figure(figsize=(COLUMN_WIDTH, 2.65))
    axes = [
        fig.add_axes([0.16, 0.56, 0.82, 0.16]),
        fig.add_axes([0.16, 0.10, 0.33, 0.295]),
        fig.add_axes([0.66, 0.10, 0.32, 0.295]),
    ]
    evidence = {"source_scores": [], "exact_size_scores": [], "display_curves": []}
    for index, (dimension, title, buckets) in enumerate(PANELS):
        ax = axes[index]
        for method_index, (method, label, color, marker, style) in enumerate(METHODS):
            if dimension == "source":
                points = [scores[method, dimension, bucket] for bucket in buckets]
                values = [float(point["f1"]) for point in points]
                assert all(0 <= value <= 100 for value in values)
                width = 0.105
                offset = (method_index - (len(METHODS) - 1) / 2) * width
                ax.bar(
                    [i + offset for i in range(len(buckets))],
                    values,
                    width=width,
                    label=label,
                    color=color,
                    edgecolor="white",
                    linewidth=0.45,
                    zorder=3,
                )
                evidence["source_scores"].extend(points)
            else:
                points = sorted(
                    (
                        row
                        for row in exact_rows
                        if row["task"] == "e2e"
                        and row["method"] == method
                        and row["dimension"] == dimension
                    ),
                    key=lambda row: int(row["size"]),
                )
                sizes = [int(point["size"]) for point in points]
                assert len(sizes) == len(set(sizes))
                values = [
                    float(point["f1"]) if point["f1_defined"] == "True" else float("nan")
                    for point in points
                ]
                x, y = smooth_size_trend(sizes, values, SIZE_BANDWIDTH[dimension])
                assert len(x) == len(y) == 250
                assert all(0 <= value <= 100 for value in y)
                ax.plot(
                    x,
                    y,
                    label=label,
                    color=color,
                    linewidth=1.35,
                    linestyle=style,
                    marker=marker,
                    markevery=(method_index * 5, 42),
                    markersize=3,
                    markeredgecolor="white",
                    markeredgewidth=0.35,
                )
                evidence["exact_size_scores"].extend(points)
                evidence["display_curves"].append(
                    {
                        "method": method,
                        "dimension": dimension,
                        "bandwidth": SIZE_BANDWIDTH[dimension],
                        "x": x.tolist(),
                        "f1": y.tolist(),
                    }
                )
            assert sum(int(point["tables"]) for point in points) == 1000
            assert sum(int(point["targets"]) for point in points) == targets
        if dimension == "source":
            ax.set_xticks(range(len(buckets)), buckets)
            ax.set_xlim(-0.5, len(buckets) - 0.5)
        elif dimension == "columns":
            ax.set_xticks([2, 5, 10, 15, 20])
            ax.set_xlim(2, 20)
        else:
            ax.set_xticks([10, 25, 50, 75, 100])
            ax.set_xlim(10, 100)
            ax.get_xticklabels()[-1].set_ha("right")
        ax.set_ylim(0, 100)
        ax.set_yticks([0, 50, 100])
        ax.set_title(f"({'abc'[index]}) {title}", loc="left", pad=5)
        ax.grid(axis="y")
        ax.set_axisbelow(True)
        ax.tick_params(axis="both", length=2, pad=2)
        ax.set_ylabel(r"End-to-end $F_1$ (%)", labelpad=3)
    handles, labels = axes[1].get_legend_handles_labels()
    legend_order = (0, 3, 1, 4, 2, 5)
    fig.legend(
        [handles[index] for index in legend_order],
        [labels[index] for index in legend_order],
        loc="upper center",
        bbox_to_anchor=(0.5, 1 - 9 / (72 * fig.get_figheight())),
        ncol=3,
        frameon=False,
        columnspacing=0.6,
        handlelength=1.0,
        handletextpad=0.3,
        labelspacing=0.35,
    )
    save(
        fig,
        output or PAPER / "figures/paper/e2e_source_size_comparison.pdf",
        width=COLUMN_WIDTH,
        font_size=7.5,
        check_layout=True,
    )
    plt.close(fig)
    return evidence


def main():
    inputs = ("task_type_metrics.csv", "table_strata_metrics.csv", "table_exact_size_metrics.csv")
    hashes = {
        name: hashlib.sha256((generated_asset(name, directory=GENERATED)).read_bytes()).hexdigest()
        for name in inputs
    }
    evidence = {
        "input_sha256": hashes,
        "prompts": prompt_table(read(inputs[0])),
        "variation": variation_figure(read(inputs[1]), read(inputs[2])),
        "aggregation": (
            "Source bars use frozen count-based scores averaged across runs. "
            "Numeric size curves smooth the frozen scores at exact observed sizes "
            "with shared Gaussian bandwidths of 2 columns or 10 rows."
        ),
    }
    destination = PAPER / "build/generated/experiment_comparison_evidence.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(evidence, indent=2) + "\n")
    assert hashes == {
        name: hashlib.sha256((generated_asset(name, directory=GENERATED)).read_bytes()).hexdigest()
        for name in inputs
    }
    print("Wrote prompt table and end-to-end source/size figure from unchanged frozen scores.")


if __name__ == "__main__":
    main()
