import itertools

from consistency_scoring import components, distance, score_tables


def test_80_20_direction_swap_and_valid_completions():
    original = {i: "A" if i < 80 else "B" for i in range(100)}
    legal = [{i: {v} for i in original} for v in ["A", "B"]]
    assert distance(original, legal) == 20
    swapped = {i: "B" if i < 60 or i >= 80 else "A" for i in original}
    assert distance(swapped, legal) == 20
    assert distance(dict.fromkeys(original, "B"), legal) == 0
    assert distance(dict.fromkeys(original, "C"), legal) == 100
    assert distance({i: "A" if i < 90 else "B" for i in original}, legal) == 10


def test_shared_cell_is_counted_once():
    original = ["A", "B", "A"]

    def member(i):
        return dict(table="t", local_row=i, col=0, original_value=original[i], accepted=["A", "B"])

    groups = [
        dict(
            id="one",
            scoring_rule="literal_unification",
            canonical_options=["A", "B"],
            members=[member(0), member(1)],
        ),
        dict(
            id="two",
            scoring_rule="literal_unification",
            canonical_options=["A", "B"],
            members=[member(1), member(2)],
        ),
    ]
    joint = components(groups, {})
    assert len(joint) == 1 and joint[0]["d0"] == 1
    keys = list(joint[0]["original"])
    for values in itertools.product(["A", "B", "invalid"], repeat=3):
        brute = min(
            sum(a != b for a, b in zip(values, completion))
            for completion in [("A",) * 3, ("B",) * 3]
        )
        assert distance(dict(zip(keys, values)), joint[0]["legal"]) == brute


def test_formatting_preserves_different_underlying_values():
    g = dict(
        id="phone",
        scoring_rule="phone_format",
        format_options=["parentheses", "hyphens"],
        members=[
            dict(
                table="t",
                local_row=0,
                col=0,
                original_value="(123) 456-7890",
                accepted=["(123) 456-7890", "123-456-7890"],
            ),
            dict(
                table="t",
                local_row=1,
                col=0,
                original_value="123-456-7891",
                accepted=["(123) 456-7891", "123-456-7891"],
            ),
        ],
    )
    c = components([g], {})[0]
    assert c["d0"] == 1
    assert distance({("t", 0, 0): "123-456-7890", ("t", 1, 0): "123-456-7891"}, c["legal"]) == 0
    assert distance({("t", 0, 0): "123-456-7890", ("t", 1, 0): "123-456-7890"}, c["legal"]) == 1


def test_precision_counts_gain_and_invalid_values_not_legal_edit_volume():
    keys = [("t", i, 0) for i in range(100)]
    original = {c: "A" if c[1] < 80 else "B" for c in keys}
    joint = [dict(original=original, legal=[dict.fromkeys(keys, {v}) for v in ("A", "B")], d0=20)]
    counts = {
        "t": dict(
            tp=0, fp=0, fn=0, execution="complete", types={"inconsistency": dict(hit=0, gt=0)}
        )
    }

    def score(edits, complete=True):
        counts["t"]["execution"] = "complete" if complete else "failed"
        predictions = [dict(dataset="t", row=i, col=0, corrected_value=v) for i, v in edits.items()]
        return score_tables(counts, predictions, {}, {"inconsistency": set()}, joint)["t"]

    for edits, expected in [
        ({}, (0, 0, 20)),
        (dict.fromkeys(range(60), "B"), (0, 0, 20)),
        (dict.fromkeys(range(80), "B"), (20, 0, 0)),
        (dict.fromkeys(range(80, 100), "A"), (20, 0, 0)),
        (dict.fromkeys(range(100), "C"), (0, 100, 20)),
    ]:
        r = score(edits)
        assert tuple(r[k] for k in ("tp", "fp", "fn")) == expected
    assert score(dict.fromkeys(range(80), "B"), complete=False)["tp"] == 0
    assert counts["t"]["tp"] == counts["t"]["fn"] == 0


def test_group_replaces_overlapping_ordinary_target_without_double_credit():
    a = ("t", 0, 0)
    g = dict(
        id="g",
        scoring_rule="literal_unification",
        canonical_options=["A", "B"],
        members=[
            dict(table="t", local_row=i, col=0, original_value=v, accepted=["A", "B"])
            for i, v in enumerate(["A", "B"])
        ],
    )
    joint = components([g], {a: {"B"}})
    assert len(joint[0]["legal"]) == 1 and joint[0]["d0"] == 1
    counts = {
        "t": dict(
            tp=1,
            fp=0,
            fn=0,
            execution="complete",
            types={"inconsistency": dict(hit=1, gt=1), "typo-formatting": dict(hit=1, gt=1)},
        )
    }
    prediction = [dict(dataset="t", row=0, col=0, corrected_value="B")]
    result = score_tables(counts, prediction, {a: {"B"}}, {"inconsistency": {a}}, joint)["t"]
    assert (result["tp"], result["fp"], result["fn"]) == (1, 0, 0)
    assert result["types"] == counts["t"]["types"]
