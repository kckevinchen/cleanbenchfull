"""Capture a complete live labeling UI and its saved web result, without writes.

The full-page capture remains available separately from the paper crop, which
ends at the corrected-value field. Neither changes labels or launches verification.
The paper capture widens the detail pane to reduce wrapping and figure height.
It displays at most two evidence entries while retaining the saved result intact.
The focused paper capture keeps the original left/right arrangement with fewer
source columns, so the screenshot can be larger within a paper column.
"""

from __future__ import annotations

import argparse
import base64
import csv
import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import urlopen

from PIL import Image
from playwright.sync_api import expect, sync_playwright

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parent
RUN = "20260604T223438Z_model_ce334f25"
SOURCE = "252479847_DimDate.csv"
CLUSTER = SOURCE + "__r00000-c000"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def focus_columns(page, columns):
    """Hide unrelated source columns in the capture browser only."""
    available = page.locator("#csv-viewer th[data-col]").all_text_contents()
    assert len(set(columns)) == len(columns) and set(columns) <= set(available)
    assert "Dayname" in columns
    cells = page.locator("#csv-viewer td[data-raw]")
    values = cells.evaluate_all("es => es.map(e => e.dataset.raw)")
    page.locator("#csv-viewer [data-col]").evaluate_all(
        "(es, columns) => es.forEach(e => {"
        "if (!columns.includes(e.dataset.col)) e.style.display = 'none';})",
        columns,
    )
    page.add_style_tag(
        content="""
        #csv-pos, #add-cluster-btn, #exclude-bar .exclude-input,
        #exclude-active {display: none;}
        #csv-head, #exclude-bar {padding: 6px 8px;}
        #csv-viewer table {font-size: 14px; width: 100%;}
        #csv-viewer td, #csv-viewer th {padding: 4px 6px;}
        """
    )
    assert cells.evaluate_all("es => es.map(e => e.dataset.raw)") == values
    assert page.locator("#csv-viewer th[data-col]:visible").all_text_contents() == columns
    return dict(
        displayed_columns=columns,
        total_columns=len(available),
        source_cell_values_unchanged=True,
        arrangement="source table on the left; full review pane on the right",
        hidden_controls=["add cluster", "row/column exclusions", "row range status"],
        table_font_size_css_px=14,
    )


def save_pdf_companion(browser, screenshot):
    """Embed the complete PNG without changing its aspect ratio."""
    target = PAPER / "assets/generated/labeling_workbench.pdf"
    with Image.open(screenshot) as image:
        width, height = image.size
    encoded = base64.b64encode(screenshot.read_bytes()).decode("ascii")
    page = browser.new_page()
    page.set_content(
        "<style>html,body{margin:0;padding:0;width:100%;height:100%;overflow:hidden;}"
        "img{position:absolute;inset:0;display:block;width:100%;height:100%;"
        "object-fit:contain;}</style>" + f'<img src="data:image/png;base64,{encoded}">',
        wait_until="load",
    )
    page.pdf(
        path=str(target),
        width=f"{width / 144}in",
        height=f"{height / 144}in",
        margin={"top": "0", "right": "0", "bottom": "0", "left": "0"},
        print_background=True,
    )
    page.close()
    return dict(
        file=str(target.relative_to(PAPER)),
        sha256=digest(target),
        source_png_sha256=digest(screenshot),
        lossless_embedding=True,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--browser", type=Path, required=True)
    parser.add_argument("--base-url", default="http://127.0.0.1:8000")
    parser.add_argument(
        "--paper-columns",
        nargs="+",
        help="Source columns to show while keeping the original left/right UI",
    )
    parser.add_argument(
        "--paper-table-width",
        type=int,
        default=250,
        help="Source-pane width when --paper-columns is supplied",
    )
    parser.add_argument(
        "--paper-crop",
        action="store_true",
        help="Capture the verified review through Corrected value for the labeling-interface figure",
    )
    parser.add_argument(
        "--paper-detail-width",
        type=int,
        default=560,
        help="Detail-pane width in CSS pixels for the paper crop (original UI: 380)",
    )
    parser.add_argument(
        "--paper-evidence-limit",
        type=int,
        default=2,
        help="Maximum evidence entries displayed in the paper crop",
    )
    args = parser.parse_args()
    assert args.paper_evidence_limit > 0
    if args.paper_columns and not args.paper_crop:
        parser.error("--paper-columns requires --paper-crop")
    base = args.base_url.rstrip("/")
    run_dir = ROOT / "outputs" / RUN
    protected = [run_dir / name for name in ("labels.jsonl", "web_verifications.json")]
    before = {str(path.relative_to(ROOT)): digest(path) for path in protected}
    with urlopen(f"{base}/api/runs/{RUN}") as response:
        metadata = json.load(response)
    source = next(s for s in metadata["sources"] if s["name"] == SOURCE)
    source_path = Path(source["path"])
    assert source["available"] and source_path.is_file()
    web = next(
        v
        for v in json.loads((run_dir / "web_verifications.json").read_text())
        if v["cluster_id"] == CLUSTER
    )
    assert web["suspect_value"] == "Wednusday"
    assert web["canonical_value"] == "Wednesday"
    assert web["evidence"] and not web["error"]
    folder = PAPER / "build/workbench_full_review"
    folder.mkdir(parents=True, exist_ok=True)
    target = (
        PAPER
        / "figures/workbench"
        / ("verified_review.png" if args.paper_crop else "full_review.png")
    )
    blocked = []
    layout_adjustment = None
    evidence_display = None
    column_display = None
    viewport_width = 1220 + args.paper_detail_width if args.paper_crop else 1600
    if args.paper_columns:
        assert 200 <= args.paper_table_width <= 600
        viewport_width = 320 + args.paper_table_width + args.paper_detail_width
    url = f"{base}/ui/label.html?run={RUN}"
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=str(args.browser), headless=True)
        page = browser.new_page(
            viewport={"width": viewport_width, "height": 1100}, device_scale_factor=2
        )
        # Use the UI's existing browser zoom setting; preserve all DOM content.
        page.add_init_script("localStorage.setItem('workbench:zoom-override', 'off')")

        def read_only(route):
            request = route.request
            if request.method not in ("GET", "HEAD", "OPTIONS"):
                blocked.append({"method": request.method, "url": request.url})
                route.abort()
            else:
                route.continue_()

        page.route("**/*", read_only)
        page.goto(url, wait_until="networkidle", timeout=60000)
        if args.paper_crop:
            assert 380 <= args.paper_detail_width <= 800
            if args.paper_detail_width != 380 or args.paper_columns:
                center_width = (
                    f"{args.paper_table_width}px" if args.paper_columns else "minmax(0, 1fr)"
                )
                grid = f"320px {center_width} {args.paper_detail_width}px"
                page.add_style_tag(content=f"body {{grid-template-columns: {grid};}}")
                layout_adjustment = dict(
                    property="grid-template-columns",
                    value=grid,
                    purpose="Set source and review pane widths while retaining the left/right UI.",
                    content_changes=False,
                )
        page.wait_for_selector("#queue .row", timeout=30000)
        page.locator("#queue-search").fill(SOURCE.removesuffix(".csv"))
        expect(page.locator("#queue .row")).to_have_count(1)
        page.locator("#queue .row").first.click()
        page.wait_for_selector(".web-verify:not(.web-verify-cta)", timeout=15000)
        page.evaluate("document.fonts.ready")
        assert CLUSTER.casefold() in page.locator("#detail").inner_text().casefold()
        assert page.locator("#note").count() == 1
        assert "Wednesday" in page.locator(".web-verify").inner_text()
        web_panel = page.locator(".web-verify:not(.web-verify-cta)")
        if args.paper_crop:
            displayed = web["evidence"][: args.paper_evidence_limit]
            page.add_style_tag(
                content=".web-verify ul.evidence li:nth-child(n+"
                + str(args.paper_evidence_limit + 1)
                + ") {display: none;}"
            )
            if len(displayed) < len(web["evidence"]):
                web_panel.locator(".web-meta").evaluate(
                    "(el, count) => el.prepend(`Showing ${count} of `)", len(displayed)
                )
            evidence_display = dict(
                limit=args.paper_evidence_limit,
                saved_count=len(web["evidence"]),
                displayed_count=len(displayed),
                displayed_urls=[item["url"] for item in displayed],
                saved_result_unchanged=True,
            )
            expect(web_panel.locator("li a:visible")).to_have_count(len(displayed))
        if args.paper_columns:
            column_display = focus_columns(page, args.paper_columns)
            with source_path.open(newline="", encoding="utf-8-sig") as stream:
                rows = list(csv.DictReader(stream))
            for row, values in enumerate(rows):
                for column in args.paper_columns:
                    cell = page.locator(f'td[data-row="{row}"][data-col="{column}"]')
                    assert cell.get_attribute("data-raw") == values[column]
        page.screenshot(path=str(folder / "viewport.png"), full_page=True)
        for _ in range(4):
            overflow = page.locator("#detail, #center, #sidebar").evaluate_all(
                "es => Math.max(...es.map(e => e.scrollHeight - e.clientHeight))"
            )
            if overflow <= 2:
                break
            page.set_viewport_size(
                {
                    "width": viewport_width,
                    "height": math.ceil(page.viewport_size["height"] + overflow + 24),
                }
            )
        panes = page.locator("#detail, #center, #sidebar").evaluate_all(
            "es => es.map(e => ({id:e.id, client:e.clientHeight, scroll:e.scrollHeight}))"
        )
        assert all(v["scroll"] <= v["client"] + 2 for v in panes), panes
        assert page.locator("#note").is_visible()
        assert page.locator("footer.shortcuts").is_visible()
        assert page.locator(".web-verify-cta").count() == 0
        assert "CONFIRMED_ERROR" in web_panel.inner_text()
        assert web_panel.locator("li a").count() == len(web["evidence"])
        clip = None
        form_preview = None
        if args.paper_crop:
            corrected = page.locator("#corrected-value")
            form_preview = dict(
                field="corrected-value",
                previous_value=corrected.input_value(),
                displayed_value=web["canonical_value"],
                value_source="saved web verification canonical_value",
                persisted=False,
            )
            corrected.fill(web["canonical_value"])
            corrected.blur()
            expect(corrected).to_have_value("Wednesday")
            center = page.locator("#center").bounding_box()
            correction_box = corrected.bounding_box()
            propagation = page.locator("#propagate-same-value").locator("..").bounding_box()
            bottom = min(correction_box["y"] + correction_box["height"] + 8, propagation["y"] - 2)
            result = web_panel.bounding_box()
            clip = dict(
                x=center["x"],
                y=center["y"],
                width=page.viewport_size["width"] - center["x"],
                height=bottom - center["y"],
            )
            assert correction_box["y"] + correction_box["height"] <= bottom < propagation["y"]
            assert result["y"] >= clip["y"]
            assert result["y"] + result["height"] <= clip["y"] + clip["height"]
            if args.paper_columns:
                detail = page.locator("#detail").bounding_box()
                assert center["x"] + center["width"] <= detail["x"] + 1
                assert abs(center["y"] - detail["y"]) <= 1
                assert clip["width"] == args.paper_table_width + args.paper_detail_width
                assert page.locator("#csv-viewer").evaluate(
                    "e => e.scrollWidth <= e.clientWidth + 1"
                )
            page.screenshot(path=str(target), clip=clip)
        else:
            page.screenshot(path=str(target), full_page=True)
        companion = save_pdf_companion(browser, target) if args.paper_crop else None
        (folder / "full_ui.txt").write_text(page.locator("body").inner_text())
        viewport = page.viewport_size
        browser.close()
    after = {str(path.relative_to(ROOT)): digest(path) for path in protected}
    assert before == after
    assert not blocked, blocked
    evidence = dict(
        capture="Continuous screenshot of the actual labeling web UI with a saved web result.",
        run=RUN,
        source=SOURCE,
        row=0,
        column="Dayname",
        original_value="Wednusday",
        saved_web_verdict=web["verdict"],
        saved_web_canonical_value=web["canonical_value"],
        saved_web_evidence_urls=[item["url"] for item in web["evidence"]],
        screenshot=dict(file=str(target.relative_to(PAPER)), sha256=digest(target)),
        source_csv_sha256=digest(source_path),
        source_artifact_sha256=before,
        viewport_css_px=viewport,
        device_scale_factor=2,
        full_page=not args.paper_crop,
        crop=clip,
        form_preview=form_preview,
        pane_dimensions=panes,
        includes=[
            "header",
            "selection sidebar",
            "source table",
            "saved web verification",
            "verdict",
            "correction",
            "bulk propagation",
            "Note",
            "per-cell notes",
            "affected rows",
            "detections",
            "shortcut footer",
        ],
        dom_or_style_replacements=layout_adjustment is not None or evidence_display is not None,
        layout_adjustment=layout_adjustment,
        evidence_display=evidence_display,
        column_display=column_display,
        blocked_mutating_requests=blocked,
        label_history_unchanged=True,
        additional_model_calls=0,
        figure1a_mapping="No exact match found among 180 local detection runs; not this case.",
        captured_at=datetime.now(timezone.utc).isoformat(),
    )
    if args.paper_crop:
        evidence["pdf_companion"] = companion
        evidence["includes"] = [
            "source table",
            "saved web verification",
            "evidence links",
            "verdict",
            "correction",
        ]
    metadata_name = "labeling_workbench.json" if args.paper_crop else "labeling_workbench_full.json"
    (PAPER / "figures" / metadata_name).write_text(json.dumps(evidence, indent=2) + "\n")
    mode = "verified review crop" if args.paper_crop else "full UI"
    print(f"Captured {mode} at {viewport['width']} x {viewport['height']} CSS pixels; no writes.")


if __name__ == "__main__":
    main()
