"""Check failure classification against the canonical correction scorer."""

import sys

import pytest
from build_failure_taxonomy import ROOT, counts, summarize

sys.path.insert(0, str(ROOT))
from src.evaluation.paper_evaluation.analysis import classify_table


def test_exact_deletion_wrong_value_and_immunity():
    cells = [("t", 0, i) for i in range(8)]
    # Three targets: valid deletion, wrong replacement, and unmodified error.
    # Also an accepted-original error, ambiguous cell, ignored cell, and clean edit.
    eligible = set(cells[:3])
    result, _ = classify_table(
        {
            cells[0]: "",
            cells[1]: "wrong",
            cells[3]: "edit",
            cells[4]: "edit",
            cells[5]: "edit",
            cells[6]: "edit",
        },
        set(cells[:4]),
        {cells[4]},
        eligible,
        {cells[0]: {""}, cells[1]: {"right"}, cells[2]: {"right"}},
        "e2e",
        "complete",
        lambda c: c == cells[5],
    )
    actual = counts({"t": result})
    assert actual == dict(
        correct=1,
        unchanged_completed=1,
        unchanged_failed=0,
        unchanged_unknown=0,
        wrong_value=1,
        clean_edits=1,
    )
    assert (result["tp"], result["fp"], result["fn"]) == (1, 2, 2)


@pytest.mark.parametrize("status", ["complete", "failed", "unknown"])
def test_empty_result_preserves_failure_provenance(status):
    c = ("t", 0, 0)
    result, _ = classify_table({}, {c}, set(), {c}, {c: {"right"}}, "e2e", status, lambda _: False)
    actual = counts({"t": result})
    key = "unchanged_completed" if status == "complete" else "unchanged_" + status
    assert actual[key] == 1
    assert sum(actual.values()) == 1


def test_run_means_preserve_partition_and_failure_status():
    rows = [
        dict(
            method="model",
            category="Direct LLMs",
            correct=800,
            unchanged_completed=200,
            unchanged_failed=50,
            unchanged_unknown=0,
            wrong_value=43,
            clean_edits=100,
        ),
        dict(
            method="model",
            category="Direct LLMs",
            correct=700,
            unchanged_completed=350,
            unchanged_failed=0,
            unchanged_unknown=0,
            wrong_value=43,
            clean_edits=200,
        ),
    ]
    (row,) = summarize(rows)
    assert row["unchanged_failed"] == 25 and row["unchanged"] == 300
    assert row["correct"] + row["unchanged"] + row["wrong_value"] == 1093
    assert row["clean_edits"] == 150 and row["runs"] == 2
