"""Report GPT-5.2 retest resources for valid, nonempty responses only.

Optional watch mode updates the report until the existing inference run ends.
This tool never submits requests or changes the running experiment.
"""

from __future__ import annotations

import argparse
import csv
import json
import statistics
import time
from collections import Counter, defaultdict
from pathlib import Path

from build_llm_scaling import included_response, read, resource_statistics


def collect(folder):
    values = defaultdict(list)
    exclusions = Counter()
    for path in (folder / "receipts/gpt-5.2").glob("r*/*.json"):
        receipt = read(path)
        attempt = receipt["attempts"][-1] if receipt["attempts"] else {}
        if included_response(receipt["status"], attempt):
            values[receipt["rows"]].append(attempt)
        else:
            label = (
                "empty"
                if receipt["status"] == "success" and attempt.get("issues_count") == 0
                else receipt["status"]
            )
            exclusions[label] += 1
    return values, dict(exclusions)


def summarize(values):
    return {
        "requests": len(values),
        "tables": len({a["table_id"] for a in values}),
        **resource_statistics(values),
        "median_output_tokens": statistics.median(a["usage"]["output_tokens"] for a in values)
        if values
        else None,
    }


def report(run_dir):
    old = defaultdict(list)
    for name in ("row_scaling_20261006", "row_scaling_3k4k_20261006"):
        groups, _ = collect(run_dir.parent / name)
        for size, values in groups.items():
            old[size].extend(values)
    new, exclusions = collect(run_dir)
    rows = []
    for size in read(run_dir / "design.json")["row_levels"]:
        common = {a["table_id"] for a in old[size]} & {a["table_id"] for a in new[size]}
        old_matched = [a for a in old[size] if a["table_id"] in common]
        new_matched = [a for a in new[size] if a["table_id"] in common]
        history = defaultdict(list)
        for a in old_matched:
            history[a["table_id"]].append(a)
        deltas = []
        for a in new_matched:
            previous = history[a["table_id"]]
            assert all(p["payload_sha256"] == a["payload_sha256"] for p in previous)
            deltas.append(
                a["elapsed_seconds"] - statistics.median(p["elapsed_seconds"] for p in previous)
            )
        row = {"rows": size}
        for prefix, values in (
            ("old", old[size]),
            ("new", new[size]),
            ("old_matched", old_matched),
            ("new_matched", new_matched),
        ):
            row.update({f"{prefix}_{k}": v for k, v in summarize(values).items()})
        row["median_paired_seconds_change"] = statistics.median(deltas) if deltas else None
        rows.append(row)
    state = read(run_dir / "process.json")
    result = {
        "status": state["status"],
        "updated_at_unix": time.time(),
        "selection": "Successful, complete, schema-valid responses with issues_count > 0 only; no accuracy claim. Identical selection for runtime and cost. Empty and invalid responses and API errors excluded. Conditional response costs are not total campaign expenditure. Matched fields use table IDs eligible in both batches; eligible repetitions may vary.",
        "new_excluded_statuses": exclusions,
        "rows": rows,
    }
    target = run_dir / "retest_comparison_nonempty.json"
    tmp = target.with_suffix(".tmp")
    tmp.write_text(json.dumps(result, indent=2) + "\n")
    tmp.replace(target)
    target = run_dir / "retest_comparison_nonempty.csv"
    tmp = target.with_suffix(".tmp")
    with tmp.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    tmp.replace(target)
    return state["status"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--watch", action="store_true")
    args = parser.parse_args()
    while True:
        status = report(args.run_dir.resolve())
        print(f"Updated nonempty-response report: {status}", flush=True)
        if not args.watch or status != "running":
            break
        time.sleep(20)


if __name__ == "__main__":
    main()
