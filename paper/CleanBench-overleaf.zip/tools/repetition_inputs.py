"""Validate fresh three-run baseline series before replacing old summaries."""

from __future__ import annotations

import hashlib
import json
from collections import defaultdict


def replacement_groups(runs, methods):
    groups = defaultdict(list)
    identities = set()
    for run in runs:
        if run["method"] not in methods:
            raise ValueError("Unexpected replacement baseline method")
        if run["identity"] in identities:
            raise ValueError("Duplicate replacement trial identity")
        identities.add(run["identity"])
        if (run["tables"], run["targets"]) != (1000, 1093):
            raise ValueError("Partial replacement trials cannot supply variability")
        groups[run["method"]].append(run)
    for local in groups.values():
        if len(local) != 3 or {run["run"] for run in local} != {1, 2, 3}:
            raise ValueError("A replacement baseline requires three independent trials")
        if len({json.dumps(run["settings"], sort_keys=True) for run in local}) != 1:
            raise ValueError("Replacement baseline settings differ across trials")
    return groups


def load_baseline_runs(root):
    root = root.resolve()
    payload = json.loads((root / "verified_repetitions.json").read_text())
    for run in payload["runs"]:
        from pathlib import Path

        receipt = Path(run["receipt"]).resolve()
        if not receipt.is_relative_to(root):
            raise ValueError("Baseline receipt is outside its experiment root")
        if hashlib.sha256(receipt.read_bytes()).hexdigest() != run["receipt_sha256"]:
            raise ValueError("Verified baseline receipt changed")
    return payload["runs"]
