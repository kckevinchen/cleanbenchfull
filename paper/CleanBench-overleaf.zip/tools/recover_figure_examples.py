"""Extract literal, provenance-bearing Figure 5 candidates from frozen inputs."""

from __future__ import annotations

import csv
import io
from collections import Counter

from recover_figure_data import json_write


def latest_annotations(records):
    """Append-only store semantics: an unlabeled tombstone replaces earlier labels."""
    latest = {}
    for line, record in enumerate(records, 1):
        key = (
            record.get("target"),
            record.get("target_id"),
            record.get("source"),
            record.get("row"),
            record.get("column"),
        )
        latest[key] = line, record
    return list(latest.values())


def recover_examples(evidence, out, snapshot_name):
    root = evidence.root
    snapshot = root / snapshot_name
    manifest = evidence.read(snapshot / "_manifest.json")
    broader = root / "outputs/broader_scope/20260921"
    audit = evidence.read(broader / "audit.json")
    input_manifest = evidence.read(broader / "input_manifest.json")
    row_path = root / "benchmark/CleanBench/benchmark_row.json"
    row_records = evidence.lines(row_path, audit["source_proofs"][evidence.name(row_path)])
    cell_path = snapshot / "benchmark_cell.json"
    cell_records = evidence.lines(cell_path, manifest["input_sha256"]["benchmark_cell.json"])
    tables = {}

    def table(ds):
        if ds not in tables:
            entry = manifest["datasets"][ds]
            path = snapshot / ds / "dirty.csv"
            raw = evidence.bytes(path, entry["dirty_sha256"])
            grid = list(csv.reader(io.StringIO(raw.decode("utf-8-sig"), newline="")))
            assert grid[0] == entry["columns"] and len(grid) - 1 == entry["n_rows"]
            tables[ds] = grid
        return tables[ds]

    def excerpt(ds, rows, columns, workbook=None):
        entry = manifest["datasets"][ds]
        grid = table(ds)
        column_ids = [grid[0].index(c) for c in columns]
        original_root = (
            "data/curated_bing21_mt100_dedup/" + workbook + "/" + entry["source"]
            if workbook
            else "data/curated_bing21_500_dedup/" + entry["source"]
        )
        return dict(
            dataset_id=ds,
            source=entry["source"],
            source_path_in_snapshot_manifest=entry["source_path"],
            frozen_csv_path=evidence.name(snapshot / ds / "dirty.csv"),
            frozen_csv_sha256=entry["dirty_sha256"],
            original_csv_path=original_root,
            original_csv_available=(root / original_root).exists(),
            workbook=workbook,
            sheet_csv=entry["source"] if workbook else None,
            original_excel_sheet_name=None,
            sheet_name_limitation="Only exported sheet CSV IDs are recoverable; original Excel tab names and cell formatting are unavailable.",
            original_columns=grid[0],
            displayed_columns=columns,
            column_mapping=[
                dict(display_column=i, csv_column=j, original_column=j, name=grid[0][j])
                for i, j in enumerate(column_ids)
            ],
            records=[
                dict(
                    display_row=i,
                    snapshot_row=r,
                    original_row=entry["exported_to_source"][r],
                    values=[grid[r + 1][j] for j in column_ids],
                    full_original_record=grid[r + 1],
                )
                for i, r in enumerate(rows)
            ],
        )

    def annotation(path, line, record, unit):
        return dict(
            annotation_id=record.get("violation_id", record.get("target_id")),
            source=evidence.name(path),
            source_sha256=evidence.hashes[evidence.name(path)],
            source_line=line,
            unit=unit,
            status=record["status"],
            benchmark_status="error"
            if record["status"] in ("tp", "partial", "fn", "confirmed_inconsistency")
            else record["status"],
            annotator=record.get("annotator"),
            timestamp=record.get("ts"),
            human_note=record.get("note", ""),
            record=record,
        )

    relation_path = (
        root / "outputs/20260616T220338Z_gpt-5.2,gpt-5.4,gpt-5.5_relations_adaptive/labels.jsonl"
    )
    relation_labels = latest_annotations(
        evidence.lines(relation_path, audit["source_proofs"][evidence.name(relation_path)])
    )
    correction_path = root / "outputs/20260510T211448Z_gpt5-family/labels.jsonl"
    correction_labels = latest_annotations(evidence.lines(correction_path))
    examples = []
    for row, priority, expected in ((4, "primary", "1/11/2019"), (5, "alternate", "1/25/2019")):
        ds = "25039521"
        field = "Time Card Approval Deadline"
        grid = table(ds)
        col = grid[0].index(field)
        cell = next(
            r
            for r in cell_records
            if r["source"] == ds + ".csv" and r["row"] == row and r["column"] == field
        )
        assert cell["corrected_value"] == expected and cell["original_value"] == grid[row + 1][col]
        support = [
            (line, r)
            for line, r in correction_labels
            if r.get("source") == ds + ".csv"
            and r.get("row") == row
            and r.get("column") == field
            and r.get("status") in ("tp", "partial", "fn")
            and r.get("corrected_value") == expected
        ]
        assert len(support) == 1
        relations = [
            r
            for r in audit["records"]
            if r["dataset"] == ds
            and r["record"]["status"] == "error"
            and row in r["record"]["rows"]
        ]
        assert relations
        human_relation = [
            (line, r)
            for line, r in relation_labels
            if r.get("source") == ds + ".csv" and r.get("row") == 4 and r.get("status") == "tp"
        ]
        assert human_relation
        examples.append(
            dict(
                example_id=f"payroll_deadline_row_{row}",
                family="Inconsistency",
                scope="multi_column",
                priority=priority,
                selection_reason="A deadline in 1919 conflicts with a 2018–2019 pay period; a literal replacement has independent human support.",
                excerpt=[
                    excerpt(
                        ds,
                        [3, 4, 5, 6],
                        [
                            "Payroll Description",
                            "Pay Period \nBegin Date",
                            "Pay Period \nEnd Date",
                            field,
                            "Pay Date",
                        ],
                    )
                ],
                relation=dict(
                    kind="date_order",
                    description="Approval deadline falls within the associated pay period and near the pay date.",
                    fields=["Pay Period \nBegin Date", field, "Pay Period \nEnd Date", "Pay Date"],
                    source=evidence.name(row_path),
                    benchmark_records=[r["record"] for r in relations],
                    annotation_ids=[r["id"] for r in relations],
                    model_rationale_is_human_note=False,
                ),
                annotations=[
                    annotation(relation_path, line, r, "Joint multi-column relation cluster")
                    for line, r in human_relation
                ]
                + [
                    annotation(
                        correction_path,
                        line,
                        r,
                        "Cell correction, reviewed independently of the relation",
                    )
                    for line, r in support
                ],
                jointly_implicated_cells=[
                    dict(
                        dataset=ds,
                        row=r,
                        column=grid[0].index(c),
                        name=c,
                        value=grid[r + 1][grid[0].index(c)],
                    )
                    for r in [4, 5]
                    for c in ["Pay Period \nBegin Date", "Pay Period \nEnd Date", field, "Pay Date"]
                ],
                correction=dict(
                    status="human_supported_literal",
                    target=dict(dataset=ds, row=row, column=col, name=field),
                    accepted_values=[expected],
                    original_value=cell["original_value"],
                    basis="Frozen cell benchmark plus the latest explicit literal correction in the cited historical human store; not inferred from the violated date relation.",
                    frozen_cell_record=cell,
                    historical_relation_audit="The relation-only audit classified this repair as provisional_literal because it searched relation histories only. The independently recovered earlier cell-correction history supplies additional provenance; historical scores and labels are unchanged.",
                ),
            )
        )
    mt_root = root / "outputs/20260622T184510Z_gpt5-family"
    label_path, violation_path = (
        mt_root / n for n in ("multi_table_labels.jsonl", "multi_table_violations.jsonl")
    )
    mt_labels, violations = evidence.lines(label_path), evidence.lines(violation_path)
    groups = evidence.lines(mt_root / "multi_table_groups.jsonl")
    cross = [
        (
            "primary",
            "e29eb79cdd9db30981c1df84b746e46b30e58191.xlsx",
            "571d4522",
            58,
            "d93dccab",
            18,
            "Last Name",
            ["6fdc1987bdff36c4", "ec28fdc4e74b62f7"],
        ),
        (
            "alternate",
            "40b95b84a393e0dc7be7376c8a3e11bd3079143b.xlsx",
            "32c26f90",
            32,
            "b4f82530",
            41,
            "2021-2025",
            ["281b0bee73a7a528"],
        ),
    ]
    for priority, wb, ds1, row1, ds2, row2, field, ids in cross:
        assert {ds1, ds2} <= set(input_manifest["workbooks"][wb])
        selected_labels = []
        for vid in ids:
            history = [
                (line, r) for line, r in enumerate(mt_labels, 1) if r.get("violation_id") == vid
            ]
            assert history and history[-1][1]["status"] == "confirmed_inconsistency"
            selected_labels.append(
                annotation(label_path, *history[-1], "Joint linked-cell conflict")
            )
        witnesses = [
            (line, r) for line, r in enumerate(violations, 1) if r.get("violation_id") in ids
        ]
        assert {(r["sheet"], r["row"]) for _, r in witnesses} == {
            (ds1 + ".csv", row1),
            (ds2 + ".csv", row2),
        }
        group = next(g for g in groups if g.get("workbook") == wb)["groups"][0]
        grids = [table(ds1), table(ds2)]
        if priority == "primary":
            display = [
                ["First Name", "Last Name", "Email", "Job Title", "Company/Organization"],
                ["First Name", "Last Name", "Email Address", "Job Title", "Company/Organization"],
            ]
            keys = [["Email"], ["Email Address"]]
            extra = [["First Name", "Job Title", "Company/Organization"]] * 2
            description = "Exact email equality links these records; first name, job title, and organization also match. No surname similarity is used to establish identity."
        else:
            display = [list(grids[0][0]), list(grids[1][0])]
            keys = [["Agency", "Initiative Title", "2021", "2022", "2023", "2024", "2025"]] * 2
            extra = [[], []]
            description = "The complete seven-field context (agency, initiative, and five annual values) matches exactly and uniquely in each sheet. Agency and initiative alone are not unique. The totals differ only in float serialization."
        key_values, uniqueness = [], []
        for grid, r, fields in zip(grids, (row1, row2), keys, strict=True):
            columns = [grid[0].index(c) for c in fields]
            values = [grid[r + 1][j] for j in columns]
            count = sum([line[j] for j in columns] == values for line in grid[1:])
            assert count == 1, "Ambiguous record linkage"
            key_values.append(values)
            uniqueness.append(count)
        assert key_values[0] == key_values[1]
        for a, b in zip(extra[0], extra[1], strict=True):
            assert (
                grids[0][row1 + 1][grids[0][0].index(a)] == grids[1][row2 + 1][grids[1][0].index(b)]
            )
        extracts = []
        for ds, r, fields in zip((ds1, ds2), (row1, row2), display, strict=True):
            count = len(table(ds)) - 1
            rows = list(range(max(0, min(r - 1, count - 3)), min(count, max(3, r + 2))))
            extracts.append(excerpt(ds, rows, fields, wb))
        gold = [
            r
            for r in row_records
            if r.get("workbook") == wb
            and r.get("source") in (ds1 + ".csv", ds2 + ".csv")
            and r.get("target_row") in (row1, row2)
            and r.get("target_column") == field
        ]
        assert len(gold) == 2
        conflicting = [
            dict(
                dataset=ds,
                row=r,
                column=grid[0].index(field),
                name=field,
                value=grid[r + 1][grid[0].index(field)],
            )
            for ds, r, grid in zip((ds1, ds2), (row1, row2), grids, strict=True)
        ]
        assert conflicting[0]["value"] != conflicting[1]["value"]
        examples.append(
            dict(
                example_id=f"linked_{ds1}_{row1}_{ds2}_{row2}",
                family="Inconsistency",
                scope="multi_table",
                priority=priority,
                workbook=wb,
                excerpt=extracts,
                annotations=selected_labels,
                relation=dict(
                    kind="linked_attribute_conflict",
                    description=description,
                    keys_by_table=keys,
                    key_values=key_values,
                    key_occurrences_per_sheet=uniqueness,
                    corroborating_fields=extra,
                    compared_attribute=field,
                    group_source=evidence.name(mt_root / "multi_table_groups.jsonl"),
                    recovered_group={
                        k: group[k]
                        for k in (
                            "workbook",
                            "group_id",
                            "kind",
                            "confirmed",
                            "rationale",
                            "sheets",
                            "column_mapping",
                            "primary_key",
                        )
                    },
                    witnesses=[
                        dict(source=evidence.name(violation_path), source_line=line, record=r)
                        for line, r in witnesses
                    ],
                    coordinate_warning="The email witness prose mentions stale rows 27/8. Structured row fields 58/18, frozen strings, linked fields, and exported benchmark coordinates agree; those structured coordinates are used."
                    if priority == "primary"
                    else None,
                ),
                jointly_implicated_cells=conflicting,
                correction=dict(
                    status="conflict_confirmed_no_directional_human_repair",
                    target=None,
                    accepted_values=None,
                    human_accepted_replacement_values=[],
                    exported_benchmark_acceptable_sets=[r["corrected_value"] for r in gold],
                    frozen_row_records=gold,
                    basis="The exporter mechanically constructs bidirectional surface-form sets from both cells after a human confirms the conflict. The human labels contain no replacement value and do not establish which spelling/value is correct. These generated sets are not a human-approved directional repair.",
                    figure_action="Show both conflicting values with an Undetermined correction or Conflict confirmed label; do not select a correct side.",
                ),
            )
        )
    sources = {name: digest for name, digest in evidence.hashes.items()}
    result = dict(
        schema_version=1,
        requested_paper_revision="d329674",
        snapshot=dict(
            path=snapshot_name,
            manifest_sha256=evidence.hashes[evidence.name(snapshot / "_manifest.json")],
            snapshot_sha256=manifest["snapshot_sha256"],
            row_benchmark_sha256=evidence.hashes[evidence.name(row_path)],
        ),
        coordinate_convention="Rows are zero-based data-record indices, excluding the CSV header. Column indices are zero-based in the exported CSV. snapshot_row maps to original_row through exported_to_source; display_row is zero-based within the excerpt. CSV row/column coordinates are not original Excel cell addresses.",
        string_policy="CSV-reader strings are retained exactly, including case, whitespace, punctuation, leading zeros and embedded header newlines. CSV byte hashes bind quoting/encoding; no claim about Excel formatting is made.",
        examples=examples,
        counts=dict(Counter((e["scope"] + "/" + e["priority"]) for e in examples)),
        limitations=[
            "The multi-column alternate comes from the same payroll table; it is not an independent dataset example.",
            "Original workbooks, original Excel tab names, and the historical curation manifest are not available at their recorded paths. Frozen CSVs, workbook membership, group mappings, violations and human labels were recovered.",
            "No directional human correction was found for the selected cross-table findings. Exported bidirectional acceptable sets are generated by code and include unchanged surface forms.",
            "Human notes are empty on the selected confirmations. Rule rationales and model witness prose are preserved as separate evidence, not relabeled as human explanations.",
        ],
        searched_evidence=[
            "All 46 frozen row-benchmark records and their broader-scope audit (six positive multi-column witnesses, five unique positive linked conflicts).",
            "Frozen cell benchmark, the relation annotation store, earlier explicit cell-correction history, multi-table labels, violations, groups and frozen table membership.",
            "Historical data/curated_bing21_mt100_dedup/manifest.json path: unavailable; recovered workbook-to-CSV membership from the hashed broader-scope input manifest.",
        ],
        unavailable_sources=[
            dict(
                path="data/curated_bing21_mt100_dedup/manifest.json",
                expected_historical_sha256=input_manifest["source_proofs"].get(
                    "data/curated_bing21_mt100_dedup/manifest.json"
                ),
                status="Not present at the recorded path",
            )
        ],
        source_sha256=sources,
    )
    json_write(out / "figure5_examples.json", result)
    return result
