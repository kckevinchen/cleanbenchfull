"""Verify and render Figure 1's recorded cross-table false positive.

Source tables are browser captures of literal frozen CSV excerpts. Publisher
evidence is clipped from pinned, unmodified webpage screenshots. No inference,
label changes, or experiment rescoring is performed.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
import subprocess
from pathlib import Path

from PIL import Image

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parent
CASE = PAPER / "figures/bloom_false_positive.json"
PIXEL_BP = 504.403 / 3684


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def records(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]


def audit(case):
    for name, expected in case["input_sha256"].items():
        assert digest(ROOT / name) == expected, f"Changed evidence: {name}"
    legacy = case["legacy_panel"]
    assert digest(PAPER / legacy["image"]) == legacy["sha256"]
    assert Image.open(PAPER / legacy["image"]).size == (3684, 1543)
    snapshot = ROOT / case["snapshot"]
    manifest = json.loads((snapshot / "_manifest.json").read_text())
    for table in case["tables"]:
        metadata = manifest["datasets"][table["dataset_id"]]
        with (snapshot / table["dataset_id"] / "dirty.csv").open(
            newline="", encoding="utf-8-sig"
        ) as stream:
            reader = csv.DictReader(stream)
            assert reader.fieldnames == table["headers"] == metadata["columns"]
            rows = list(reader)
        assert rows[table["snapshot_row"]] == table["target_values"]
        assert metadata["source_path"] == table["source_path"]
        for item in table["context"]:
            assert metadata["exported_to_source"][item["snapshot_row"]] == item["source_row"]
            assert item["worksheet_row"] == item["source_row"] + 2
            for column, value in item["values"].items():
                assert rows[item["snapshot_row"]][column] == value
        assert table["target_values"]["Title"] == "Bloom"
    review = case["review"]
    history = records(ROOT / review["path"])
    saved = [r for r in history if r["violation_id"] == review["violation_id"]][-1]
    assert history[review["line"] - 1] == saved == review["record"]
    assert saved["status"] == review["status"] == "not_a_violation"
    candidate = case["candidate"]
    saved_candidates = [
        r
        for r in records(ROOT / candidate["path"])
        if r["violation_id"] == candidate["violation_id"]
    ]
    assert saved_candidates == candidate["records"]
    assert candidate["violation_id"] == review["violation_id"]
    assert {r["values"]["Author"] for r in saved_candidates} == {"Oppel, Kenneth", "Kevin Panetta"}
    assert {tuple(r["values"]["primary_key"]) for r in saved_candidates} == {("bloom",)}
    for publisher in case["publishers"]:
        image = PAPER / publisher["screenshot_file"]
        assert digest(image) == publisher["sha256"], image
        width, height = Image.open(image).size
        assert [width, height] == publisher["pixels"]
        x, y, w, h = publisher["crop_pixels"]
        assert min(x, y) >= 0 and min(w, h) > 0
        assert x + w <= width and y + h <= height
    for table in case["tables"]:
        if capture := table.get("capture"):
            assert digest(PAPER / capture["file"]) == capture["sha256"]


def capture_tables(case, browser_path):
    from playwright.sync_api import sync_playwright

    with sync_playwright() as playwright:
        options = {"headless": True}
        if browser_path:
            options["executable_path"] = str(browser_path)
        browser = playwright.chromium.launch(**options)
        for table, author in zip(case["tables"], ("oppel", "panetta"), strict=True):
            columns = table["display_columns"]
            document = [
                "<!doctype html><meta charset='utf-8'><style>",
                "*{box-sizing:border-box}body{margin:0;background:white}",
                "table{border-collapse:collapse;table-layout:fixed;width:448px;",
                "font:22px 'Liberation Sans',Arial,sans-serif;color:black}",
                "th,td{height:34px;padding:0 4px;border:1px solid #44b3e1;",
                "white-space:nowrap;overflow:hidden;vertical-align:middle;text-align:left;",
                "font-weight:400}.letters th{height:30px;background:#f0f0f0;text-align:center}",
                ".coord{background:#f0f0f0;color:#596b77;text-align:center;padding:0}",
                ".fields th{height:40px}.fields th:not(.coord){background:#156082;",
                "color:white;font-weight:700}.stripe td{background:#c0e6f5}</style>",
                "<table><colgroup><col style='width:42px'><col style='width:128px'>",
                "<col style='width:278px'></colgroup><thead><tr class='letters'>",
                "<th></th><th>A</th><th>B</th></tr><tr class='fields'>",
                "<th class='coord'>1</th>",
                *[f"<th>{html.escape(column)}</th>" for column in columns],
                "</tr></thead><tbody>",
            ]
            for item in table["context"]:
                target = item["snapshot_row"] == table["snapshot_row"]
                stripe = "stripe" if item["worksheet_row"] % 2 == 0 else ""
                document.append(
                    f"<tr class='{stripe}' data-target='{str(target).lower()}'>"
                    f"<th class='coord'>{item['worksheet_row']}</th>"
                    + "".join(f"<td>{html.escape(item['values'][c])}</td>" for c in columns)
                    + "</tr>"
                )
            document.append("</tbody></table>")
            page = browser.new_page(viewport={"width": 448, "height": 250}, device_scale_factor=4)
            page.set_content("".join(document))
            page.evaluate("document.fonts.ready")
            target = page.locator("tr[data-target='true']")
            assert target.locator("td").all_text_contents() == [
                table["target_values"][c] for c in columns
            ]
            box = target.bounding_box()
            path = PAPER / f"figures/evidence/bloom_{author}_table.png"
            page.locator("table").screenshot(path=str(path))
            table["capture"] = {
                "file": str(path.relative_to(PAPER)),
                "sha256": digest(path),
                "device_scale_factor": 4,
                "css_width": 448,
                "target_css_rect": [box[k] for k in ("x", "y", "width", "height")],
                "format": "Browser screenshot of literal frozen CSV values in a spreadsheet viewer",
            }
            page.close()
        browser.close()


def panel_source(case):
    lines = [
        "% !TEX root = ../main.tex",
        "% Generated by tools/build_bloom_example.py; raw screenshots remain unchanged.",
        r"\begingroup",
        r"\definecolor{cbBloomCheck}{HTML}{00B050}",
        r"\definecolor{cbBloomReject}{HTML}{EE0000}",
        r"\begin{tikzpicture}[x=0.13691721bp,y=-0.13691721bp,",
        r"font=\sffamily\fontsize{9.5bp}{11.4bp}\selectfont,text=black,",
        r"every node/.style={inner sep=0,outer sep=0}]",
        r"\path[use as bounding box] (0,0) rectangle (3684,1543);",
    ]
    for table, publisher, top in zip(case["tables"], case["publishers"], (120, 850), strict=True):
        capture = table["capture"]
        left, source_width = 8, 1366
        factor = source_width / capture["css_width"]
        x, y, w, h = capture["target_css_rect"]
        target_top, target_bottom = top + y * factor, top + (y + h) * factor
        center = (target_top + target_bottom) / 2
        lines.extend(
            [
                rf"\node[anchor=north west] at ({left},{top}) {{\includegraphics[width={source_width * PIXEL_BP:.6f}bp]{{{capture['file']}}}}};",
                rf"\draw[cbBloomCheck,line width=1.8bp] (4,{target_top:.3f}) rectangle (1374,{target_bottom:.3f});",
            ]
        )
        raw_width = publisher["pixels"][0]
        crop_x, crop_y, crop_width, crop_height = publisher["crop_pixels"]
        evidence_left, evidence_width = 1665, 1995
        scale = evidence_width / crop_width
        evidence_height = crop_height * scale
        evidence_top = top - 10
        image_x = evidence_left - crop_x * scale
        image_y = evidence_top - crop_y * scale
        lines.extend(
            [
                r"\begin{scope}",
                rf"\clip ({evidence_left},{evidence_top}) rectangle (3660,{evidence_top + evidence_height:.3f});",
                rf"\node[anchor=north west] at ({image_x:.3f},{image_y:.3f}) {{\includegraphics[width={raw_width * scale * PIXEL_BP:.6f}bp]{{{publisher['screenshot_file']}}}}};",
                r"\end{scope}",
                rf"\draw[cbBloomCheck,line width=1.8bp] (1657,{evidence_top - 8}) rectangle (3668,{evidence_top + evidence_height + 8:.3f});",
                rf"\draw[-stealth,cbBloomCheck,line width=2bp,line cap=round] (1374,{center:.3f})--(1657,{evidence_top + evidence_height / 2:.3f});",
            ]
        )
    lines.extend(
        [
            r"\node[anchor=west,text=cbBloomReject] (bloomflag) at (1510,780) {LLM flags: \textbf{author conflict}};",
            r"\node[anchor=west] at ([xshift=7bp]bloomflag.east) {\includegraphics[trim=613.969590bp 172.801676bp 172.365308bp 146.401420bp,clip,width=10.95338bp]{figures/FP-examples.png}};",
            r"\node[anchor=west,text=cbBloomCheck,font=\sffamily\fontsize{8bp}{9.6bp}\selectfont\bfseries] at (1665,1490) {Different books; keep both authors.};",
            r"\end{tikzpicture}",
            r"\endgroup",
            "",
        ]
    )
    # Suppress TeX whitespace outside the picture so both subplots have the
    # exact same canvas, rather than adding an interword space to its width.
    return "\n".join(line if line.startswith("%") else line + "%" for line in lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--capture-tables", action="store_true")
    parser.add_argument("--browser", type=Path)
    parser.add_argument("--render", action="store_true")
    parser.add_argument("--tectonic", type=Path, default=Path("tectonic"))
    args = parser.parse_args()
    case = json.loads(CASE.read_text())
    audit(case)
    if args.capture_tables:
        capture_tables(case, args.browser)
        CASE.write_text(json.dumps(case, indent=2) + "\n")
    if args.render:
        build = PAPER / "build/figure1_bloom"
        build.mkdir(parents=True, exist_ok=True)
        root = build / "bloom_false_positive.tex"
        root.write_text(
            r"\documentclass[border=0pt]{standalone}"
            + "\n"
            + r"\usepackage{fontspec,tikz,xcolor,graphicx}"
            + "\n"
            + r"\setsansfont{Liberation Sans}"
            + "\n"
            + r"\begin{document}"
            + panel_source(case)
            + r"\end{document}"
            + "\n"
        )
        subprocess.run(
            [
                str(args.tectonic),
                "-X",
                "compile",
                str(root),
                "-Z",
                f"search-path={PAPER}",
                "--outdir",
                str(PAPER / "assets/generated"),
            ],
            cwd=PAPER,
            check=True,
        )
    audit(json.loads(CASE.read_text()))
    print("Verified Bloom source coordinates, saved rejection, screenshots and upper-panel hash.")


if __name__ == "__main__":
    main()
