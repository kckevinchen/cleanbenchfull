"""Build a descriptive figure from the frozen construction/evaluation snapshot.

No inference, score recomputation, or annotation changes. Raw coordinates stay
outside the paper repository. The checked aggregate evidence goes under build/.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

if __package__:
    from .tex_sources import generated_asset
else:
    from tex_sources import generated_asset

if __package__:
    from .figure_style import (
        COLUMN_WIDTH,
        SOURCE_COLORS,
        TWO_PANEL_HEIGHT,
        TWO_PANEL_MARGINS,
        configure,
        save,
    )
    from .paper_taxonomy import INCONSISTENCY_TYPES
else:
    from figure_style import (
        COLUMN_WIDTH,
        SOURCE_COLORS,
        TWO_PANEL_HEIGHT,
        TWO_PANEL_MARGINS,
        configure,
        save,
    )
    from paper_taxonomy import INCONSISTENCY_TYPES


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def describe(manifest: dict, records: list[dict]) -> dict:
    tables = list(manifest["datasets"].values())
    by_source = {t["source"]: t for t in tables}
    assert len(by_source) == len(tables), "Duplicate source identity"
    coordinates = {(r["source"], r["row"], r["column"]) for r in records}
    assert len(coordinates) == len(records), "Duplicate labeled cell"
    assert {r["source"] for r in records} <= set(by_source)
    errors = [r for r in records if r["status"] == "error"]
    counts = Counter(r["source"] for r in errors)
    for table in tables:
        assert counts[table["source"]] == table["n_error_cells"]
    groups = {}
    for label, source_prefix in [("BI", "pbi_500/"), ("Web", "bing21_500/")]:
        population = [t for t in tables if t["source_path"].startswith(source_prefix)]
        values = sorted((counts[t["source"]] for t in population), reverse=True)
        positive = [v for v in values if v]
        hist = [
            sum(v == 0 for v in values),
            sum(v == 1 for v in values),
            sum(2 <= v <= 5 for v in values),
            sum(6 <= v <= 10 for v in values),
            sum(v > 10 for v in values),
        ]
        assert sum(hist) == len(values)
        cumulative, total = [], 0
        for value in positive:
            total += value
            cumulative.append(total)
        groups[label] = {
            "tables": len(values),
            "errors": sum(values),
            "histogram": hist,
            "positive_tables": len(positive),
            "sorted_positive_counts": positive,
            "cumulative_errors": cumulative,
            "top_ten_errors": sum(positive[:10]),
            "top_ten_share": 100 * sum(positive[:10]) / total,
            "largest_table_error_count": max(values),
        }
    assert sum(g["tables"] for g in groups.values()) == len(tables)
    assert sum(g["errors"] for g in groups.values()) == len(errors)
    type_sets = Counter(
        tuple(
            sorted({"inconsistency" if t in INCONSISTENCY_TYPES else t for t in r["error_types"]})
        )
        for r in errors
    )
    type_cardinality = Counter(len(k) for k in type_sets for _ in range(type_sets[k]))
    memberships = sum(len(k) * n for k, n in type_sets.items())
    return {
        "source_groups": groups,
        "histogram_bins": ["0", "1", "2–5", "6–10", ">10"],
        "distinct_errors": len(errors),
        "type_memberships": memberships,
        "type_cardinality": dict(type_cardinality),
        "multiple_type_cells": sum(n for k, n in type_sets.items() if len(k) > 1),
        "inconsistency_formatting_overlap": sum(
            n for k, n in type_sets.items() if {"inconsistency", "typo-formatting"} <= set(k)
        ),
        "inconsistency_spelling_overlap": sum(
            n for k, n in type_sets.items() if {"inconsistency", "typo-spelling"} <= set(k)
        ),
    }


def draw(profile: dict, target: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.ticker import FixedLocator, FuncFormatter

    configure()
    fig, axes = plt.subplots(2, 1, figsize=(COLUMN_WIDTH, TWO_PANEL_HEIGHT))
    display_names = {"BI": "Relational", "Web": "Spreadsheet"}
    colors = {key: SOURCE_COLORS[value] for key, value in display_names.items()}
    for index, (name, group) in enumerate(profile["source_groups"].items()):
        xs = [x + (index - 0.5) * 0.34 for x in range(5)]
        bars = axes[0].bar(
            xs, group["histogram"], width=0.32, color=colors[name], label=display_names[name]
        )
        for bar, count in zip(bars, group["histogram"]):
            axes[0].annotate(
                str(count),
                (bar.get_x() + bar.get_width() / 2, count * 1.15),
                xytext=(-4 if index == 0 else 4, 0),
                textcoords="offset points",
                ha="center",
                va="bottom",
            )
        cumulative = [100 * v / group["errors"] for v in group["cumulative_errors"]]
        axes[1].plot(
            [0] + list(range(1, len(cumulative) + 1)),
            [0] + cumulative,
            color=colors[name],
            lw=1.6,
            linestyle="-" if index == 0 else "--",
            label=display_names[name],
        )
        axes[1].scatter([10], [group["top_ten_share"]], s=15, color=colors[name], zorder=3)
        axes[1].annotate(
            f"{group['top_ten_share']:.1f}%",
            (10, group["top_ten_share"]),
            xytext=(7, 12 if index == 0 else -10),
            textcoords="offset points",
            color=colors[name],
            bbox={"facecolor": "white", "edgecolor": "none", "pad": 0.25},
        )
    axes[0].set_yscale("log")
    axes[0].set_ylim(1, 1000)
    axes[0].yaxis.set_major_locator(FixedLocator([1, 10, 100, 1000]))
    axes[0].yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{int(v):,}"))
    axes[0].set_xticks(range(5), profile["histogram_bins"])
    axes[0].set_xlabel("Labeled errors per table")
    axes[0].set_ylabel("Tables (log scale)")
    axes[0].set_title("(a) Errors per table", loc="left", pad=8)
    axes[1].set_ylim(0, 105)
    axes[1].set_xlim(0, 125)
    axes[1].set_xticks([0, 25, 50, 75, 100, 125])
    axes[1].set_yticks([0, 25, 50, 75, 100])
    axes[1].set_xlabel("Tables ranked by decreasing error count")
    axes[1].set_ylabel("Cumulative errors (%)")
    axes[1].set_title("(b) Error concentration", loc="left", pad=8)
    axes[1].axvspan(0, 10, color="#edf4ff", zorder=0)
    axes[1].axvline(10, color="#a6b4c0", linestyle=":", linewidth=0.6, zorder=0)
    for ax in axes:
        ax.minorticks_off()
        ax.grid(axis="y", linewidth=0.45)
        ax.set_axisbelow(True)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        loc="upper center",
        bbox_to_anchor=(0.52, 1.0),
        ncol=2,
        frameon=False,
        columnspacing=2,
    )
    fig.subplots_adjust(**TWO_PANEL_MARGINS)
    save(fig, target, width=COLUMN_WIDTH, check_layout=True)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--paper", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    snapshot, paper = args.snapshot.resolve(), args.paper.resolve()
    manifest_path, labels = snapshot / "_manifest.json", snapshot / "benchmark_cell.json"
    manifest = json.loads(manifest_path.read_text())
    assert sha(labels) == manifest["input_sha256"]["benchmark_cell.json"]
    records = [json.loads(line) for line in labels.read_text().splitlines() if line.strip()]
    profile = describe(manifest, records)
    assert profile["distinct_errors"] == 1409
    assert profile["type_memberships"] == 1503
    assert all(g["tables"] == 500 for g in profile["source_groups"].values())
    target = paper / "assets/generated"
    target.mkdir(parents=True, exist_ok=True)
    draw(profile, target / "corpus_profile.pdf")
    macros = {
        "BIErrorTopTen": str(profile["source_groups"]["BI"]["top_ten_errors"]),
        "WebErrorTopTen": str(profile["source_groups"]["Web"]["top_ten_errors"]),
        "BIErrorTopTenPercent": f"{profile['source_groups']['BI']['top_ten_share']:.1f}\\%",
        "WebErrorTopTenPercent": f"{profile['source_groups']['Web']['top_ten_share']:.1f}\\%",
        "MultiTypeCells": str(profile["multiple_type_cells"]),
        "DoubleTypeCells": str(profile["type_cardinality"][2]),
        "TripleTypeCells": str(profile["type_cardinality"].get(3, 0)),
        "FormatInconsistencyOverlap": str(profile["inconsistency_formatting_overlap"]),
        "SpellingInconsistencyOverlap": str(profile["inconsistency_spelling_overlap"]),
    }
    (generated_asset("corpus_profile_numbers.tex", directory=target)).write_text(
        "\n".join("\\newcommand{\\CB" + key + "}{" + value + "}" for key, value in macros.items())
        + "\n"
    )
    profile["provenance"] = {
        "labels_sha256": sha(labels),
        "manifest_sha256": sha(manifest_path),
        "script_sha256": sha(Path(__file__)),
        "figure_sha256": sha(target / "corpus_profile.pdf"),
    }
    evidence = paper / "build/generated/corpus_profile.json"
    evidence.parent.mkdir(parents=True, exist_ok=True)
    evidence.write_text(json.dumps(profile, indent=2) + "\n")
    print(json.dumps({k: v for k, v in profile.items() if k != "source_groups"}, indent=2))


if __name__ == "__main__":
    main()
