"""Guard against inflated stopping rates and unjustified false-positive counts."""

import pytest
from tools.audit_discovery_stopping import replay, review_outcome


def observation(k, status, streak, mass=0.0, observed=0, upper=0.0):
    return dict(
        k_arm=k,
        status=status,
        saturated_streak=streak,
        n_observed=observed,
        n1=int(mass > 0),
        n2=0,
        total_hits=observed,
        good_turing_missing_mass=mass,
        chao1_ci_95_high=upper,
    )


def test_empty_search_requires_real_consecutive_probes():
    first = observation(1, "active", 1)
    last = observation(2, "saturated", 2)
    assert replay([first, first, last, last], 1, 3) == "saturated"
    with pytest.raises(AssertionError):
        replay([first, observation(1, "saturated", 2)], 1, 3)


def test_first_qualifying_pass_at_budget_is_exhausted():
    history = [
        observation(1, "active", 0, mass=1, observed=1, upper=1),
        observation(2, "exhausted", 1, observed=1, upper=1),
    ]
    assert replay(history, 1, 2) == "exhausted"


def test_chao_upper_bound_can_fail_when_gt_passes():
    row = observation(1, "exhausted", 0, observed=10, upper=11)
    assert replay([row], 1, 1) == "exhausted"


def test_reference_absence_is_not_a_false_positive():
    key = ("table.csv", 0, "name")
    assert review_outcome(key, {}, {}) == "unreviewed"
    reviews = {key: {"provenance": [{"status": "fp"}, {"status": "tp"}]}}
    assert review_outcome(key, {}, reviews) == "mixed_review"
    assert review_outcome(key, {key: {"status": "error"}}, reviews) == "error"
    reviews[key]["provenance"] = [{"status": "fp"}]
    assert review_outcome(key, {}, reviews) == "rejected"
