"""Audit frozen end-to-end predictions and plot method-specific correction outcomes.

Run with ../venv/bin/python tools/build_error_analysis.py. No inference is run.
The companion JSON pins the selected runs, reference snapshot, and examples.
"""

from __future__ import annotations

import csv
import hashlib
import json
import statistics
import sys
from collections import defaultdict
from pathlib import Path

from figure_style import COLUMN_WIDTH, TWO_PANEL_HEIGHT, configure, save

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parent
OUTCOMES = ("correct", "wrong", "flagged_no_edit", "not_flagged", "outside")


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def records(path, detector=None):
    with path.open() as stream:
        for line in stream:
            if line.strip():
                row = json.loads(line)
                if detector is None or row["detector"] == detector:
                    yield row


def cell(row):
    return row["dataset"], int(row["row"]), int(row["col"])


def changed_values(rows, original):
    """Keep empty-string edits; null and exact unchanged values abstain."""
    from external.rein.score_repair import _extract_value

    seen, result = set(), {}
    for row in rows:
        c = cell(row)
        assert c not in seen, ("Duplicate prediction", c)
        seen.add(c)
        value = _extract_value(row)
        if value is not None and value != original(c):
            result[c] = value
    return result


def partition(truth, flags, changes):
    """Split every eligible target once; count other scored edits separately."""
    assert set(changes) <= flags, "Repair coordinates absent from native detection"
    correct = {c for c, v in changes.items() if c in truth.eligible and v in truth.accepted[c]}
    wrong = (set(changes) & truth.eligible) - correct
    untouched = truth.eligible - changes.keys()
    groups = {
        "correct": correct,
        "wrong": wrong,
        "flagged_no_edit": untouched & flags,
        "not_flagged": untouched - flags,
        "outside": {
            c for c in changes if c not in truth.errors | truth.ambiguous and not truth.immune(c)
        },
    }
    target_groups = [groups[k] for k in OUTCOMES[:4]]
    assert set().union(*target_groups) == truth.eligible
    assert sum(map(len, target_groups)) == len(truth.eligible)
    return groups


def audit_inputs(config):
    for name, digest in config["input_sha256"].items():
        assert sha(ROOT / name) == digest, ("Frozen input changed", name)


def api_runs(config, tables, original, bind):
    from external.gpt5_detect import secure_tuning as secure

    campaign = ROOT / config["api_campaign"]
    settings = read(campaign / "config.json")
    assert settings["benchmark_sha256"] == config["benchmark_sha256"]
    report = read(campaign / "final_report/RESULTS.json")
    scored = ROOT / config["api_scored"]
    derivation = read(scored / "derivation.json")
    expected = read(scored / "e2e_scores.json")["results"]
    assert report["status"] == "completed_and_audited" and report["tables"] == 1000
    valued = defaultdict(list)
    for row in records(scored / "valued_predictions.jsonl"):
        valued[row["detector"]].append(row)
    runs = []
    for model in config["api_models"]:
        for rep in range(1, 4):
            name = f"compare_{model}_selected"
            record = next(
                r for r in report["repetitions"][rep - 1]["comparison"] if r["name"] == name
            )
            stage = campaign / f"rep_{rep:02d}/recovered" / name
            receipt = read(stage / "receipt.json")
            assert receipt["model"] == model and receipt["failed_tables"] == []
            assert record["prompt_sha256"] == sha(stage / "prompt.txt") == receipt["prompt_sha256"]
            assert sha(stage / "predictions.jsonl") == receipt["predictions_sha256"]
            bind(stage / "receipt.json")
            bind(stage / "prompt.txt")
            bind(stage / "predictions.jsonl")
            system = (stage / "prompt.txt").read_text()
            flags, changes, issues_by_cell = set(), {}, {}
            effort = settings.get("effort_by_model", {}).get(model, settings["effort"])
            for ds, (headers, data) in tables.items():
                path = stage.parent / "requests" / model / secure.digest(system) / f"{ds}.json"
                response = read(path)
                assert bind(path) == derivation["receipt_hashes"][str(path.relative_to(ROOT))]
                assert response["status"] == "success"
                user = json.dumps(
                    {
                        "headers": headers,
                        "rows": [{"row": i, "values": r} for i, r in enumerate(data)],
                    },
                    ensure_ascii=False,
                )
                assert response["request_sha256"] == secure.digest([model, effort, system, user])
                assert response["response_model"] == receipt["response_model"]
                issues = secure.validate_issues(response["raw"], headers, data)
                assert issues == response["issues"]
                for issue in issues:
                    c = ds, issue["row"], headers.index(issue["column"])
                    flags.add(c)
                    issues_by_cell[c] = dict(issue, receipt=str(path.relative_to(ROOT)))
                    value = issue["corrected_value"]
                    if value is not None and value != original(c):
                        changes[c] = value
            assert flags == {cell(r) for r in records(stage / "predictions.jsonl")}
            detector = f"rep_{rep:02d}/{model}/selected"
            assert changes == changed_values(valued[detector], original)
            runs.append(
                dict(
                    method=model,
                    repetition=rep,
                    flags=flags,
                    changes=changes,
                    expected=expected[detector],
                    issues=issues_by_cell,
                    completed_tables=1000,
                )
            )
    return runs


def agent_run(config, tables, original, bind, agent=None):
    agent = config["agent"] if agent is None else agent
    native = ROOT / agent["native"]
    scored = ROOT / agent["scored"]
    evidence = read(scored / "RESULTS.json")
    settings = read(native / "config.json")
    assert settings["benchmark_sha256"] == config["benchmark_sha256"]
    assert set(settings["scope"]) == set(tables)
    flags, changes, issues_by_cell, seen = set(), {}, {}, set()
    for path in sorted((native / agent["detector"]).glob("table_*/receipt.json")):
        response = read(path)
        assert bind(path) == evidence["source_sha256"][str(path.relative_to(ROOT))]
        ds = response["dataset"]
        assert ds in tables and ds not in seen
        seen.add(ds)
        assert response["output_valid"] and response["exit_code"] == 0 and not response["timeout"]
        assert response["model"] == settings["config"]["models"][agent["detector"]]
        for issue in response["issues"]:
            c = ds, issue["row"], tables[ds][0].index(issue["column"])
            assert c not in flags and issue["observed"] == original(c)
            flags.add(c)
            issues_by_cell[c] = dict(issue, receipt=str(path.relative_to(ROOT)))
            value = issue.get("corrected_value")
            if value is not None and value != original(c):
                changes[c] = value
    assert seen == set(tables)
    assert flags == {cell(r) for r in records(native / "predictions.jsonl", agent["detector"])}
    assert changes == changed_values(records(scored / "predictions.jsonl", agent["arm"]), original)
    expected = next(r["metrics"] for r in evidence["rows"] if r["arm"] == agent["arm"])
    return dict(
        method=agent["arm"],
        repetition=1,
        flags=flags,
        changes=changes,
        expected=expected,
        issues=issues_by_cell,
        completed_tables=1000,
    )


def constraint_run(config, original, bind):
    constraint = config["constraint"]
    selection = read(ROOT / config["presentation"])
    chosen = next(r for r in selection["main"]["e2e"] if r["method"] == constraint["method"])
    assert chosen["configuration"] == constraint["configuration"]
    rows = read(ROOT / config["selected_results"])["rows"]
    streams = {}
    for task in ("detection", "e2e"):
        row = next(
            r
            for r in rows
            if r["configuration"] == constraint["configuration"] and r["task"] == task
        )
        path = ROOT / Path(row["prediction_path"]).relative_to(ROOT)
        assert bind(path) == row["prediction_sha256"]
        assert set(row["execution_status"].values()) == {"complete"}
        assert len(row["execution_status"]) == 1000
        streams[task] = list(records(path, constraint["configuration"]))
        if task == "e2e":
            expected = row["analysis"]["full"]
            assert expected == chosen["metrics"]
    return dict(
        method=constraint["method"],
        repetition=1,
        flags={cell(r) for r in streams["detection"]},
        changes=changed_values(streams["e2e"], original),
        expected=expected,
        issues={},
        completed_tables=1000,
    )


def examples(config, runs, truth, manifest, tables, original, bind):
    results = []
    for spec in config["examples"]:
        c = spec["dataset"], spec["row"], spec["col"]
        assert original(c) == spec["original"]
        matched = [r for r in runs if r["method"] in spec["methods"]]
        observations = []
        for run in matched:
            assert c in run["groups"][spec["outcome"]]
            assert run["changes"][c] == spec["proposed"]
            issue = run["issues"].get(c)
            observations.append(
                dict(method=run["method"], repetition=run["repetition"], issue=issue)
            )
        assert matched
        assert sorted(truth.accepted.get(c, [])) == spec["accepted"]
        if spec.get("native_receipt"):
            receipt = read(ROOT / spec["native_receipt"])
            assert receipt["status"] == "complete"
            assert any(
                cell(p) == c and p["corrected_value"] == spec["proposed"]
                for p in receipt["predictions"]["e2e"]
            )
            for name, digest in receipt["output_sha256"].items():
                assert bind(Path(name)) == digest
            with (ROOT / spec["native_repaired"]).open(newline="") as stream:
                native = list(csv.reader(stream))
            assert native[c[1] + 1][c[2]] == spec["proposed"]
        results.append(
            dict(
                spec,
                column=tables[c[0]][0][c[2]],
                source_row=manifest["datasets"][c[0]]["exported_to_source"][c[1]],
                observations=observations,
            )
        )
    return results


def render(summary, generated):
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch
    from matplotlib.ticker import FixedFormatter, FixedLocator, NullLocator

    configure(font_size=8)
    fig = plt.figure(figsize=(COLUMN_WIDTH, TWO_PANEL_HEIGHT))
    left = fig.add_axes((0.39, 0.66, 0.58, 0.24))
    right = fig.add_axes((0.39, 0.285, 0.58, 0.17))
    colors = ["#287c70", "#ba6446", "#546d85", "#dde2e6"]
    labels = ["Correct value", "Wrong value", "Flagged, no edit", "Not flagged"]
    for i, row in enumerate(summary):
        offset = 0
        for key, color in zip(OUTCOMES[:4], colors, strict=True):
            width = 100 * row[key] / row["targets"]
            left.barh(i, width, left=offset, height=0.57, color=color, linewidth=0)
            if key in ("correct", "not_flagged") and width > 12:
                left.text(
                    offset + width / 2,
                    i,
                    f"{width:.1f}%",
                    ha="center",
                    va="center",
                    color="white" if key == "correct" else "#3f4b55",
                )
            offset += width
        values = row["outside_runs"]
        right.plot([min(values), max(values)], [i, i], color="#8996a2", lw=1)
        # Three open circles are repetitions; the filled diamond is their mean.
        jitter = [-0.12, 0, 0.12] if len(values) == 3 else [0]
        right.scatter(
            values,
            [i + d for d in jitter],
            s=23,
            facecolors="white",
            edgecolors="#546d85",
            linewidths=0.8,
            zorder=3,
        )
        right.scatter([row["outside"]], [i], marker="D", s=22, color="#263442", zorder=4)
        right.annotate(
            f"{row['outside']:,.0f}",
            (max(values), i),
            xytext=(7, 0),
            textcoords="offset points",
            va="center",
            color="#263442",
        )
    left.set_yticks(range(len(summary)), [r["label"] for r in summary])
    left.set_ylim(len(summary) - 0.5, -0.5)
    left.set_xlim(0, 100)
    left.set_xticks([0, 25, 50, 75, 100])
    left.set_xlabel("Replacement targets (%)")
    left.set_title("(a) Replacement outcomes", loc="left", pad=8)
    left.tick_params(axis="y", length=0, pad=8)
    left.spines["left"].set_visible(False)
    left.set_axisbelow(True)
    left.grid(axis="x", color="#e6eaf0")
    right.set_xscale("log")
    right.set_xlim(100, 9000)
    right.xaxis.set_major_locator(FixedLocator([100, 1000]))
    right.xaxis.set_major_formatter(FixedFormatter(["100", "1,000"]))
    right.xaxis.set_minor_locator(NullLocator())
    right.set_yticks(range(len(summary)), [r["label"] for r in summary])
    right.set_ylim(len(summary) - 0.5, -0.5)
    right.tick_params(axis="y", length=0, pad=8)
    right.spines["left"].set_visible(False)
    right.set_xlabel("Count (log scale)")
    right.set_title("(b) Edits outside targets", loc="left", pad=8)
    right.grid(axis="x")
    fig.legend(
        handles=[Patch(facecolor=c, label=l) for c, l in zip(colors, labels, strict=True)],
        loc="lower center",
        bbox_to_anchor=(0.53, 0.005),
        ncol=2,
        frameon=False,
        handlelength=1.25,
        columnspacing=1.0,
    )
    save(fig, generated / "error_analysis.pdf", width=COLUMN_WIDTH, font_size=8, check_layout=True)
    plt.close(fig)


def main():
    sys.path.insert(0, str(ROOT))
    from external.gpt5_detect.tuning import benchmark_fingerprint
    from src.evaluation.paper_evaluation.analysis import GroundTruth, aggregate

    config_path = PAPER / "figures/error_analysis.json"
    config = read(config_path)
    audit_inputs(config)
    bound = {}

    def bind(path):
        digest = sha(path)
        bound[str(path.relative_to(ROOT))] = digest
        return digest

    snapshot = ROOT / config["snapshot"]
    assert benchmark_fingerprint(snapshot) == config["benchmark_sha256"]
    manifest = read(snapshot / "_manifest.json")
    truth = GroundTruth(snapshot, manifest)
    assert len(truth.eligible) == 1093 and len(manifest["datasets"]) == 1000
    tables = {}
    for ds, entry in sorted(manifest["datasets"].items()):
        path = snapshot / ds / "dirty.csv"
        assert bind(path) == entry["dirty_sha256"]
        with path.open(newline="") as stream:
            header, *data = csv.reader(stream)
        assert len(data) == entry["n_rows"] and len(header) == entry["n_cols"]
        tables[ds] = header, data

    def original(c):
        return tables[c[0]][1][c[1]][c[2]]

    runs = api_runs(config, tables, original, bind)
    runs.append(agent_run(config, tables, original, bind))
    if config.get("example_agent"):
        runs.append(agent_run(config, tables, original, bind, config["example_agent"]))
    runs.append(constraint_run(config, original, bind))
    per_run = []
    for run in runs:
        groups = partition(truth, run["flags"], run["changes"])
        counts = {k: len(v) for k, v in groups.items()}
        predicted = [
            dict(dataset=c[0], row=c[1], col=c[2], corrected_value=v)
            for c, v in run["changes"].items()
        ]
        scored, _ = truth.analyze(predicted, "e2e", {ds: "complete" for ds in tables})
        scored = aggregate(scored)
        checks = dict(
            tp=counts["correct"],
            fp=counts["wrong"] + counts["outside"],
            fn=1093 - counts["correct"],
        )
        for key, value in checks.items():
            assert value == scored[key] == run["expected"][key], (run["method"], key)
        run["groups"] = groups
        per_run.append(
            dict(
                method=run["method"],
                repetition=run["repetition"],
                targets=1093,
                completed_tables=run["completed_tables"],
                **counts,
                **checks,
            )
        )
    summary = []
    for method, label in config["labels"].items():
        selected = [r for r in per_run if r["method"] == method]
        summary.append(
            dict(
                method=method,
                label=label,
                runs=len(selected),
                targets=1093,
                **{k: statistics.mean(r[k] for r in selected) for k in OUTCOMES},
                outside_runs=[r["outside"] for r in selected],
            )
        )
    cases = examples(config, runs, truth, manifest, tables, original, bind)
    generated = PAPER / "assets/generated"
    with (generated / "error_analysis_runs.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(per_run[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(per_run)
    with (generated / "error_analysis_summary.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(
            stream,
            fieldnames=[k for k in summary[0] if k != "outside_runs"],
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows({k: v for k, v in row.items() if k != "outside_runs"} for row in summary)
    render(summary, generated)
    evidence = dict(
        config_sha256=sha(config_path),
        source_sha256=bound,
        per_run=per_run,
        summary=summary,
        examples=cases,
        additional_model_calls=0,
    )
    target = PAPER / "build/generated/error_analysis_evidence.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(evidence, indent=2, ensure_ascii=False) + "\n")
    print(
        json.dumps(
            dict(
                runs=len(runs),
                targets=1093,
                tables=1000,
                examples=len(cases),
                additional_model_calls=0,
            )
        )
    )


if __name__ == "__main__":
    main()
