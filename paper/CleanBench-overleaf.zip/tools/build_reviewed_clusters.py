"""Recover deduplicated reviewed clusters; default renders the frozen count only."""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

if __package__:
    from .tex_sources import generated_asset
else:
    from tex_sources import generated_asset

if __package__:
    from .build_annotation_funnel import Coordinates, digest, records
else:
    from build_annotation_funnel import Coordinates, digest, records

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parent
VALID = {"tp", "fp", "partial", "unsure"}
AUTOMATIC_NOTES = ("auto:", "reclassified", "[bulk", "[transferred]", "[llm-fix]")


def manual_verdict(record):
    note = str(record.get("note") or "").lower()
    return (
        record.get("status") in VALID
        and not any(marker in note for marker in AUTOMATIC_NOTES)
        and record.get("annotator") not in {"repro", "fn-import-reconcile"}
    )


def manual_lines(history):
    """A current verdict must have manual provenance after its last reset."""
    if not history or history[-1][1].get("status") not in VALID:
        return []
    reset = max((line for line, r in history if r.get("status") == "unlabeled"), default=0)
    return [line for line, r in history if line > reset and manual_verdict(r)]


def value_key(source, column, value, row):
    # Match the workbench queue: nonempty repeated values form one review item;
    # empty values retain their cell identity.
    return ("value", source, column, value) if value else ("empty", source, column, row)


def recover(config):
    path = PAPER / "figures/annotation_funnel.json"
    assert digest(path) == config["annotation_config_sha256"]
    for name, expected in config["source_sha256"].items():
        assert digest(ROOT / name) == expected, name
    inputs = json.loads(path.read_text())
    snapshot = ROOT / inputs["snapshot"]
    coords = Coordinates(snapshot, json.loads((snapshot / "_manifest.json").read_text()))
    sys.path.insert(0, str(ROOT))
    from src.labeling.correction_suggester import build_cluster_index

    reviewed = defaultdict(list)
    all_labeled = set()
    per_run = []
    for run in inputs["runs"]:
        directory = ROOT / run["directory"]
        history = defaultdict(list)
        for line, record in records(directory / "labels.jsonl"):
            history[record["target_id"]].append((line, record))
        latest = {tid: rows[-1][1] for tid, rows in history.items()}
        groups = []
        draft_path = directory / "column_cluster_drafts.jsonl"
        if draft_path.exists():
            drafts = {(r["source"], r["column"]): r for _, r in records(draft_path)}
            saved_path = directory / "column_clusters.jsonl"
            saved = (
                {(r["source"], r["column"]): r for _, r in records(saved_path)}
                if saved_path.exists()
                else {}
            )
            for (source, raw_col), clusters in build_cluster_index(
                drafts, latest, records=saved
            ).items():
                column = coords.column(source, raw_col)
                if column is None:
                    continue
                ci = coords.meta[source][1]["columns"].index(column)
                values = {row[ci].strip() for row in coords.grid(source)}
                for group in clusters:
                    if values & group.value_set:
                        key = ("column_group", source, column, tuple(sorted(group.value_set)))
                        groups.append((key, group.target_id))
        else:
            for cluster in json.loads((directory / "clusters.json").read_text()):
                columns = cluster.get("columns") or []
                # The eight source runs contain cell-level findings only.
                if not columns:
                    continue
                assert len(columns) == 1, "A broader finding needs a separate counting unit"
                cell = coords.original(
                    dict(source=cluster["source"], column=columns[0], row=cluster.get("row"))
                )
                if cell is None:
                    continue
                source, row, column = cell
                ci = coords.meta[source][1]["columns"].index(column)
                value = coords.grid(source)[row][ci]
                groups.append((value_key(source, column, value, row), cluster["cluster_id"]))
        active, manual = set(), set()
        for key, target in groups:
            if latest.get(target, {}).get("status") not in VALID:
                continue
            active.add(key)
            all_labeled.add(key)
            lines = manual_lines(history[target])
            if lines:
                manual.add(key)
                reviewed[key].append(dict(run=run["directory"], target=target, lines=lines))
        per_run.append(dict(run=run["directory"], labeled=len(active), reviewed=len(manual)))
    by_source = Counter(coords.pool((key[1], 0, key[2])) for key in reviewed)
    counts = {**by_source, "total": len(reviewed)}
    assert counts == config["expected"], counts
    # Detailed identities stay private; publication artifacts contain aggregates.
    evidence = PAPER / "build/generated/reviewed_clusters.json"
    evidence.parent.mkdir(parents=True, exist_ok=True)
    evidence.write_text(
        json.dumps(
            dict(
                groups=[dict(key=key, provenance=rows) for key, rows in sorted(reviewed.items())],
                verified_csv_sha256=coords.csv_hashes,
            ),
            indent=2,
        )
        + "\n"
    )
    return dict(
        counts=counts,
        by_run=per_run,
        labeled_groups=len(all_labeled),
        groups_without_manual_verdict=len(all_labeled - reviewed.keys()),
        group_kinds=dict(Counter(key[0] for key in reviewed)),
        config_sha256=digest(PAPER / "figures/reviewed_clusters.json"),
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--refresh", action="store_true")
    args = parser.parse_args()
    config_path = PAPER / "figures/reviewed_clusters.json"
    config = json.loads(config_path.read_text())
    aggregate = PAPER / "assets/generated/reviewed_cluster_counts.json"
    if args.refresh:
        aggregate.write_text(json.dumps(recover(config), indent=2) + "\n")
    data = json.loads(aggregate.read_text())
    assert data["config_sha256"] == digest(config_path)
    assert data["counts"] == config["expected"]
    total = data["counts"]["total"]
    (generated_asset("reviewed_cluster_numbers.tex")).write_text(
        "% Generated by tools/build_reviewed_clusters.py.\n"
        + rf"\newcommand{{\CBReviewedClustersRounded}}{{{total / 1000:.1f}k}}"
        + "\n"
    )
    print(f"{total:,} deduplicated clusters with recorded manual verdicts; no model calls.")


if __name__ == "__main__":
    main()
