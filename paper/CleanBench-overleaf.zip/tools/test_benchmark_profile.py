"""Check coordinate unions, denominators, and complete dimension populations."""

import copy
import unittest

from tools.build_benchmark_profile import SOURCES, TYPES, dimensions, joint_types


class BenchmarkProfileTests(unittest.TestCase):
    def setUp(self):
        self.columns = [
            dict(dataset=source, source=source, column=i, column_type=kind, scorable=10)
            for source in SOURCES
            for i, kind in enumerate(TYPES)
        ]

    def test_overlapping_historical_inconsistency_labels_count_once(self):
        cell = ("BI", 0, 0)
        rows = joint_types(self.columns, {"inconsistency": {cell}, "semantic_incompatible": {cell}})
        selected = [
            r for r in rows if r["source"] == "Relational" and r["column_type"] == "Numeric"
        ]
        self.assertEqual(sum(r["errors"] for r in selected), 1)
        row = next(r for r in selected if r["error_type"] == "Inconsistency")
        self.assertEqual(row["scorable_cells"], 10)
        self.assertEqual(row["errors_per_1000"], 100)

    def test_distinct_paper_types_retain_overlap_without_dropping_exposure(self):
        cell = ("BI", 0, 0)
        rows = joint_types(self.columns, {"typo-spelling": {cell}, "inconsistency": {cell}})
        self.assertEqual(sum(r["errors"] for r in rows), 2)
        self.assertTrue(all(r["scorable_cells"] == 10 for r in rows))

    def test_unmatched_error_coordinate_is_rejected(self):
        with self.assertRaises(AssertionError):
            joint_types(self.columns, {"typo-spelling": {("missing-table", 0, 0)}})

    def test_column_counts_include_clean_and_unscorable_columns(self):
        self.columns.extend(
            [
                dict(dataset="BI", source="BI", column=5, column_type="Numeric", scorable=20),
                dict(dataset="BI", source="BI", column=6, column_type="Numeric", scorable=0),
            ]
        )
        rows = joint_types(self.columns, {"typo-spelling": {("BI", 0, 0)}})
        selected = [
            r for r in rows if r["source"] == "Relational" and r["column_type"] == "Numeric"
        ]
        self.assertTrue(all(r["columns"] == 3 for r in selected))
        self.assertTrue(all(r["scorable_cells"] == 30 for r in selected))
        self.assertEqual(sum(r["errors"] for r in selected), 1)

    def test_dimension_bins_include_boundaries_and_expose_missing_tables(self):
        tables = [dict(source="BI", rows=10, columns=2), dict(source="BI", rows=100, columns=20)]
        config = {"row_bins": [[10, 24], [25, 100]], "column_bins": [[2, 4], [5, 20]]}
        rows = dimensions(tables, config)
        self.assertEqual([r["tables"] for r in rows if r["source"] == "Relational"], [1, 1, 1, 1])
        bad = copy.deepcopy(tables)
        bad[0]["rows"] = 9
        with self.assertRaises(AssertionError):
            dimensions(bad, config)


if __name__ == "__main__":
    unittest.main()
