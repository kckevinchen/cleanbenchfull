"""Check type-slice exclusions, shared negatives and table-macro boundaries."""

import sys
from pathlib import Path
from types import SimpleNamespace

import pytest
from build_macro_metrics import run_scores, table_scores
from build_macro_type_metrics import scored_cells, slice_tables

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))


def test_background_false_positives_are_shared_and_other_type_errors_excluded():
    spelling, formatting, shared, clean = [("t", 0, col) for col in range(4)]
    targets = {"spelling": {spelling, shared}, "formatting": {formatting, shared}}
    slices = slice_tables(
        {formatting, shared},
        {spelling, formatting, shared, clean},
        targets,
        {"t": "complete"},
        {spelling, formatting, shared},
    )
    assert slices["spelling"]["t"] == {"tp": 1, "fp": 2, "fn": 1, "execution": "complete"}
    assert slices["formatting"]["t"] == {"tp": 2, "fp": 1, "fn": 0, "execution": "complete"}


def test_other_only_type_wrong_edit_is_excluded_from_target_cohort_and_preservation():
    cell = ("other", 0, 0)
    slices = slice_tables(
        set(),
        {cell},
        {"spelling": set(), "formatting": {cell}},
        {"other": "complete", "failed": "failed"},
        {cell},
    )
    assert table_scores(slices["spelling"]["other"])["f1"] is None
    assert table_scores(slices["spelling"]["other"])["precision"] is None
    assert table_scores(slices["spelling"]["other"])["preservation"] == 1
    assert table_scores(slices["formatting"]["other"])["f1"] == 0
    assert table_scores(slices["spelling"]["failed"])["f1"] is None
    assert table_scores(slices["spelling"]["failed"])["preservation"] == 0
    scores = run_scores(slices["spelling"])
    assert scores["macro_f1"] is None
    assert scores["macro_precision"] is None
    assert scores["macro_precision_tables"] == scores["target_tables"] == 0
    assert scores["preservation"] == scores["all_table_macro_f1"] == 50
    assert scores["preservation_tables"] == 2
    formatting = run_scores(slices["formatting"])
    assert formatting["target_tables"] == formatting["preservation_tables"] == 1
    assert (
        formatting["macro_precision"] == formatting["macro_recall"] == formatting["macro_f1"] == 0
    )
    assert formatting["preservation"] == 0


def test_wrong_replacement_on_overlapping_target_contributes_to_both_types():
    cell = ("t", 0, 0)
    slices = slice_tables(set(), {cell}, {"a": {cell}, "b": {cell}}, {"t": "complete"}, {cell})
    for kind in ("a", "b"):
        assert slices[kind]["t"]["tp"] == 0
        assert slices[kind]["t"]["fp"] == slices[kind]["t"]["fn"] == 1
        scores = run_scores(slices[kind])
        assert scores["macro_precision"] == scores["macro_recall"] == scores["macro_f1"] == 0
        assert scores["target_tables"] == 1
        assert scores["preservation_tables"] == 0


def test_type_macro_metrics_share_fixed_cohort_and_keep_clean_false_alarms_in_micro():
    target = ("error", 0, 0)
    clean = ("false_alarm", 0, 0)
    slices = slice_tables(
        {target},
        {target, clean},
        {"type": {target}},
        {"error": "complete", "false_alarm": "complete", "empty": "complete"},
        {target},
    )
    scores = run_scores(slices["type"])
    assert scores["macro_precision"] == scores["macro_recall"] == scores["macro_f1"] == 100
    assert scores["micro_precision"] == 50
    assert scores["micro_recall"] == 100
    assert scores["micro_f1"] == pytest.approx(200 / 3)
    assert scores["macro_precision_tables"] == scores["macro_recall_tables"] == 1
    assert scores["target_tables"] == scores["macro_f1_tables"] == 1
    assert scores["preservation_tables"] == 2
    assert scores["preservation"] == 50
    assert scores["all_table_macro_f1"] == pytest.approx(200 / 3)


def test_type_records_keep_scoring_immunity_and_empty_string_replacement():
    target, noop, ambiguous, ignored, clean = [("t", 0, col) for col in range(5)]
    truth = SimpleNamespace(
        tables={"t": {"rows": 1, "columns": 5}},
        eligible={target},
        errors={target, noop},
        ambiguous={ambiguous},
        accepted={target: {""}},
        immune=lambda cell: cell == ignored,
    )
    records = [
        {"dataset": "t", "row": 0, "col": col, "corrected_value": "" if col == 0 else "edit"}
        for col in range(5)
    ]
    correct, attempted = scored_cells(records, truth)
    assert correct == {target}
    assert attempted == {target, clean}
    # A nonempty raw issue list can leave an empty scored slice after immunity.
    correct, attempted = scored_cells(records[1:4], truth)
    assert correct == attempted == set()
    empty = slice_tables(correct, attempted, {"type": set()}, {"t": "complete"}, truth.eligible)
    assert table_scores(empty["type"]["t"]) == {
        "precision": None,
        "recall": None,
        "f1": None,
        "preservation": 1,
        "all_table_f1": 1,
    }


def test_type_target_cohort_includes_noops_and_failed_or_unknown_outputs():
    targets = {(ds, 0, 0) for ds in ("correct", "missed", "failed", "unknown")}
    slices = slice_tables(
        {("correct", 0, 0)},
        {("correct", 0, 0)},
        {"type": targets},
        {"correct": "complete", "missed": "complete", "failed": "failed", "unknown": "unknown"},
        targets,
    )
    scores = run_scores(slices["type"])
    assert scores["target_tables"] == scores["macro_precision_tables"] == 4
    assert scores["macro_recall_tables"] == scores["macro_f1_tables"] == 4
    assert scores["macro_precision"] == scores["macro_recall"] == scores["macro_f1"] == 25
    assert scores["preservation"] is None


def test_duplicate_prediction_coordinates_are_not_silently_collapsed():
    truth = SimpleNamespace(
        tables={"t": {"rows": 1, "columns": 1}},
        eligible=set(),
        errors=set(),
        ambiguous=set(),
        accepted={},
        immune=lambda _: False,
    )
    record = {"dataset": "t", "row": 0, "col": 0, "corrected_value": "edit"}
    with pytest.raises(AssertionError, match="Duplicate prediction"):
        scored_cells([record, record], truth)
