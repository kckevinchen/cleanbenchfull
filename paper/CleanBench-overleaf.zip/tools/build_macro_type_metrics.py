"""Derive per-error-type table-macro correction scores from frozen main runs.

Each type shares clean-background false positives, includes wrong replacements
at its own targets, and excludes errors belonging only to other types. No model
calls, label changes, or updates to existing micro score files are performed.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import sys
from collections import defaultdict
from itertools import chain
from pathlib import Path

from build_coding_agents import END_TO_END_PREDICTIONS
from build_error_types import select_rows
from build_macro_metrics import (
    Inputs,
    agent_runs,
    api_runs,
    average_runs,
    check_micro,
    historical_runs,
    run_scores,
    table_scores,
    write_csv,
)
from build_type_precision import focused_metrics
from paper_taxonomy import DISPLAY_TYPES, project_sets

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parent
TYPES = [("overall", "Overall"), *DISPLAY_TYPES]


def scored_cells(records, truth):
    """Recover accepted edits and attempted scored coordinates with old immunity."""
    from external.rein.score_repair import _extract_value

    seen, scored = set(), {}
    for record in records:
        cell = record["dataset"], int(record["row"]), int(record["col"])
        assert cell not in seen, "Duplicate prediction coordinate"
        seen.add(cell)
        table = truth.tables[cell[0]]
        assert 0 <= cell[1] < table["rows"] and 0 <= cell[2] < table["columns"]
        if truth.immune(cell) or cell in truth.ambiguous or cell in truth.errors - truth.eligible:
            continue
        value = _extract_value(record)
        if isinstance(value, str):
            scored[cell] = value
    correct = {
        c for c, value in scored.items() if c in truth.eligible and value in truth.accepted[c]
    }
    return correct, set(scored)


def slice_tables(correct, attempted, targets_by_type, executions, eligible):
    """Assign each table's shared background FPs and type-specific TP/FP/FN."""
    assert correct <= attempted
    attempts, hits = defaultdict(set), defaultdict(set)
    targets = {kind: defaultdict(set) for kind in targets_by_type}
    for cell in attempted:
        assert cell[0] in executions
        attempts[cell[0]].add(cell)
    for cell in correct:
        hits[cell[0]].add(cell)
    for kind, cells in targets_by_type.items():
        for cell in cells:
            assert cell in eligible and cell[0] in executions
            targets[kind][cell[0]].add(cell)
    result = {kind: {} for kind in targets_by_type}
    for ds, execution in executions.items():
        local = {kind: values[ds] for kind, values in targets.items()}
        metrics = focused_metrics(hits[ds], attempts[ds], local, len(attempts[ds] - eligible))
        for kind, metric in metrics.items():
            result[kind][ds] = {
                **{key: metric[key] for key in ("tp", "fp", "fn")},
                "execution": execution,
            }
    return result


class Predictions:
    """Select the same recorded streams as the existing overall macro builder."""

    def __init__(self, inputs):
        self.inputs = inputs
        folder = ROOT / "outputs/paper_evaluation/20260920"
        selection = inputs.read(folder / "presentation_selection.json")
        selected = inputs.read(
            folder / "selected_results.json", selection["source_manifest_sha256"]
        )
        self.historical = {r["configuration"]: r for r in select_rows(folder, selected, selection)}
        self.api = None
        self.agents = None

    def records(self, run):
        if run["group"] in {"Academic", "Industrial"}:
            row = self.historical[run["configuration"]]
            return list(
                self.inputs.records(
                    row["prediction_path"], row["configuration"], row["prediction_sha256"]
                )
            )
        if run["group"] == "Direct LLMs":
            if self.api is None:
                evidence = self.inputs.read(PAPER / "build/generated/llm_baseline_evidence.json")
                path = next(p for p in evidence["source_sha256"] if p.endswith("e2e_scores.json"))
                path = self.inputs.path(path).with_name("valued_predictions.jsonl")
                proof = self.inputs.read(PAPER / "figures/error_analysis.json")["input_sha256"]
                self.api = defaultdict(list)
                for record in self.inputs.records(
                    path, expected=proof[str(path.relative_to(ROOT))]
                ):
                    if record["detector"].endswith("/selected"):
                        self.api[record["detector"]].append(record)
            return self.api[run["configuration"]]
        assert run["group"] == "Coding agents"
        if self.agents is None:
            evidence = self.inputs.read(PAPER / "build/generated/coding_agent_repair_evidence.json")
            path = END_TO_END_PREDICTIONS
            self.agents = defaultdict(list)
            for record in self.inputs.records(path, expected=evidence["source_sha256"][path]):
                self.agents[record["detector"]].append(record)
        return self.agents[run["configuration"]]


def numeric_equal(value, expected):
    if expected in (None, ""):
        assert value is None
    else:
        assert value is not None and math.isclose(float(value), float(expected), abs_tol=1e-12)


def csv_rows(inputs, name):
    with inputs.bind(PAPER / name).open(newline="") as stream:
        return list(csv.DictReader(stream))


def main():
    sys.path.insert(0, str(ROOT))
    from src.evaluation.paper_evaluation.analysis import GroundTruth

    inputs = Inputs()
    snapshot = ROOT / "outputs/baseline_campaign/20260910/snapshot"
    manifest = inputs.read(snapshot / "_manifest.json")
    for name in ("benchmark_cell.json", "neutral_cells.jsonl", "ignored.jsonl"):
        inputs.bind(snapshot / name, manifest["input_sha256"][name])
    truth = GroundTruth(snapshot, manifest)
    for ds in truth.ids:
        path = snapshot / ds / "gt_cells.jsonl"
        if path.exists():
            inputs.bind(path)
    types = project_sets(truth.fine)
    targets = {kind: cells & truth.eligible for kind, cells in types.items()}
    assert [len(targets[k]) for k, _ in DISPLAY_TYPES] == [512, 270, 405]
    target_tables = {kind: len({cell[0] for cell in cells}) for kind, cells in targets.items()}
    assert [target_tables[k] for k, _ in DISPLAY_TYPES] == [106, 79, 61]
    published_types = inputs.read(PAPER / "build/generated/type_precision_evidence.json")
    frozen_type_runs = defaultdict(list)
    for run in published_types["runs"]:
        if run["task"] == "e2e":
            frozen_type_runs[run["method"]].append(run["metrics"])
    old_runs = {
        (r["method"], int(r["run"])): r
        for r in csv_rows(inputs, "assets/generated/macro_metrics_runs.csv")
    }
    old_summary = {r["method"]: r for r in csv_rows(inputs, "assets/generated/macro_metrics.csv")}
    streams = Predictions(inputs)
    results = []
    detailed = PAPER / "build/generated/macro_type_metrics_per_table.jsonl"
    detailed.parent.mkdir(parents=True, exist_ok=True)
    with detailed.open("w") as output:
        for run in chain(
            historical_runs(inputs, truth), api_runs(inputs, truth), agent_runs(inputs, truth)
        ):
            tables = run.pop("tables")
            expected = run.pop("expected")
            overall = check_micro(tables, expected)
            frozen_overall = old_runs[run["method"], run["run"]]
            for key, value in overall.items():
                numeric_equal(value, frozen_overall[key])
            correct, attempted = scored_cells(streams.records(run), truth)
            assert [len(correct), len(attempted - correct), len(truth.eligible - correct)] == [
                overall[k] for k in ("tp", "fp", "fn")
            ]
            executions = {ds: table["execution"] for ds, table in tables.items()}
            sliced = slice_tables(correct, attempted, targets, executions, truth.eligible)
            results.append(
                {**run, "error_type": "overall", "error_type_label": "Overall", **overall}
            )
            frozen = frozen_type_runs[run["method"]][run["run"] - 1]
            for kind, label in DISPLAY_TYPES:
                score = run_scores(sliced[kind])
                old = frozen[kind]
                for key in ("tp", "fp", "fn"):
                    assert score[key] == old[key], (run["method"], run["run"], kind, key)
                for key in ("precision", "recall"):
                    numeric_equal(score["micro_" + key], 100 * old[key])
                assert score["targets"] == len(targets[kind])
                assert score["target_tables"] == score["macro_f1_tables"] == target_tables[kind]
                assert score["preservation_tables"] == len(truth.ids) - target_tables[kind]
                results.append({**run, "error_type": kind, "error_type_label": label, **score})
                for ds, table in sliced[kind].items():
                    per_table = table_scores(table)
                    output.write(
                        json.dumps(
                            {
                                **run,
                                "error_type": kind,
                                "dataset": ds,
                                **table,
                                **{
                                    f"table_{key}_percent": value * 100
                                    if value is not None
                                    else None
                                    for key, value in per_table.items()
                                },
                            }
                        )
                        + "\n"
                    )
            print("Audited", run["method"], "run", run["run"], flush=True)
    grouped = defaultdict(list)
    for run in results:
        grouped[run["method"], run["error_type"]].append(run)
    summary = []
    for (method, kind), runs in grouped.items():
        row = {
            "method": method,
            "category": runs[0]["category"],
            "group": runs[0]["group"],
            "error_type": kind,
            "error_type_label": runs[0]["error_type_label"],
            **average_runs(runs),
        }
        if kind == "overall":
            for key in old_summary[method]:
                if key in {"method", "category", "group"}:
                    assert row[key] == old_summary[method][key]
                else:
                    numeric_equal(row[key], old_summary[method][key])
        summary.append(row)
    assert len(results) == 37 * 4 and len(summary) == 23 * 4
    old_types = {
        (r["method"], r["error_type"]): r
        for r in csv_rows(inputs, "assets/generated/task_type_precision.csv")
        if r["task"] == "e2e" and not r["method"].endswith(" (Base)")
    }
    for row in summary:
        if row["error_type"] == "overall":
            continue
        old = old_types[row["method"], row["error_type"]]
        for key in ("precision", "recall"):
            numeric_equal(row["micro_" + key], old[key])
    generated = PAPER / "assets/generated"
    write_csv(generated / "macro_type_metrics.csv", summary)
    write_csv(generated / "macro_type_metrics_runs.csv", results)
    for code in (
        Path(__file__).resolve(),
        PAPER / "tools/build_macro_metrics.py",
        PAPER / "tools/build_type_precision.py",
        PAPER / "tools/paper_taxonomy.py",
        ROOT / "src/evaluation/paper_evaluation/analysis.py",
        ROOT / "external/rein/score_repair.py",
    ):
        inputs.bind(code)
    evidence = {
        "task": "e2e",
        "score_units": "Percent (0-100)",
        "methods": 23,
        "runs": 37,
        "policy": __doc__,
        "source_sha256": inputs.hashes,
        "type_supports": {kind: len(cells) for kind, cells in targets.items()},
        "target_table_supports": target_tables,
        "macro_policy": "Apply the existing table scores independently to each type slice. Macro precision, recall and F1 average the fixed tables with targets of that type. Empty outputs and failed/unknown execution on these target tables score zero. Preservation averages completed no-scored-change indicators over tables with no targets of that type. all_table_macro_f1 retains the previous all-table score for decomposition. Average tables within each run, then defined runs. All overall values match macro_metrics.csv exactly.",
        "summary": summary,
        "run_scores": results,
        "per_table_file": str(detailed.relative_to(PAPER)),
        "per_table_sha256": hashlib.sha256(detailed.read_bytes()).hexdigest(),
    }
    (PAPER / "build/generated/macro_type_metrics_evidence.json").write_text(
        json.dumps(evidence, indent=2) + "\n"
    )
    print(
        "Verified92 summary rows/148 run rows; overall macro and published type micro scores unchanged."
    )


if __name__ == "__main__":
    main()
