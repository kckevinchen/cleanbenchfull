"""Derive table-macro correction scores from the frozen main-comparison runs.

No inference, label changes, or updates to existing micro score assets are performed.
Every run is checked against its published micro scores before aggregation.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import statistics
import sys
from collections import Counter, defaultdict
from itertools import chain
from pathlib import Path

from build_coding_agents import END_TO_END_PREDICTIONS, RUNS
from build_error_types import select_rows
from build_unified_task_tables import MODELS

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parent
SCORE_FIELDS = tuple(
    prefix + metric for prefix in ("micro_", "macro_") for metric in ("precision", "recall", "f1")
) + ("preservation", "all_table_macro_f1")
POPULATION_FIELDS = (
    "tables",
    "targets",
    "zero_target_tables",
    "target_tables",
    "macro_precision_tables",
    "macro_recall_tables",
    "macro_f1_tables",
    "preservation_tables",
)
COUNT_FIELDS = (
    "tp",
    "fp",
    "fn",
    "complete_tables",
    "failed_tables",
    "unknown_tables",
    "successful_zero_target",
    "zero_target_wrong_edit",
    "zero_target_failed",
)
SHORT_NAMES = {
    "Excel Clean Data": "Excel",
    "Google Sheets Cleanup": "Google Sheets",
    "KATARA (KB component)": "KATARA (KB)",
}


def table_scores(table):
    """Separate correction on target tables from zero-target preservation."""
    tp, fp, fn = (table[k] for k in ("tp", "fp", "fn"))
    assert all(isinstance(n, int) and n >= 0 for n in (tp, fp, fn))
    status = table["execution"]
    assert status in {"complete", "failed", "unknown"}
    complete = status == "complete"
    p_den, r_den, f_den = tp + fp, tp + fn, 2 * tp + fp + fn
    all_table_f1 = (2 * tp / f_den if f_den else 1.0) if complete else 0.0
    if not r_den:
        return {
            "precision": None,
            "recall": None,
            "f1": None,
            "preservation": float(complete and not p_den),
            "all_table_f1": all_table_f1,
        }
    return {
        "precision": (tp / p_den if p_den else 0.0) if complete else 0.0,
        "recall": tp / r_den if complete else 0.0,
        "f1": all_table_f1,
        "preservation": None,
        "all_table_f1": all_table_f1,
    }


def run_scores(tables):
    """Compute full-population micro and fixed-target-table macro scores."""
    values = list(tables.values())
    assert values
    scored = [table_scores(t) for t in values]
    tp, fp, fn = (sum(t[k] for t in values) for k in ("tp", "fp", "fn"))
    statuses = Counter(t["execution"] for t in values)
    target_scores = [r for t, r in zip(values, scored, strict=True) if t["tp"] + t["fn"]]
    preserved = [r["preservation"] for r in scored if r["preservation"] is not None]
    zero = [t for t in values if t["tp"] + t["fn"] == 0]
    mean = (
        lambda key: 100 * statistics.mean(t[key] for t in target_scores) if target_scores else None
    )
    result = {
        "tables": len(values),
        "targets": tp + fn,
        "zero_target_tables": len(zero),
        "target_tables": len(target_scores),
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "micro_precision": 100 * tp / (tp + fp) if tp + fp else 0.0,
        "micro_recall": 100 * tp / (tp + fn) if tp + fn else 0.0,
        "micro_f1": 200 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0.0,
        "macro_precision": mean("precision"),
        "macro_recall": mean("recall"),
        "macro_f1": mean("f1"),
        "macro_precision_tables": len(target_scores),
        "macro_recall_tables": len(target_scores),
        "macro_f1_tables": len(target_scores),
        "preservation": 100 * statistics.mean(preserved) if preserved else None,
        "preservation_tables": len(preserved),
        "all_table_macro_f1": 100 * statistics.mean(t["all_table_f1"] for t in scored),
        "complete_tables": statuses["complete"],
        "failed_tables": statuses["failed"],
        "unknown_tables": statuses["unknown"],
        "successful_zero_target": sum(t["execution"] == "complete" and t["fp"] == 0 for t in zero),
        "zero_target_wrong_edit": sum(t["fp"] > 0 for t in zero),
        "zero_target_failed": sum(t["execution"] != "complete" for t in zero),
    }
    components = (
        len(target_scores) * (result["macro_f1"] or 0)
        + len(preserved) * (result["preservation"] or 0)
    ) / len(values)
    assert math.isclose(result["all_table_macro_f1"], components, abs_tol=1e-12)
    return result


def average_runs(runs):
    """Average each run's scores, rather than pooling runs or averaging P and R."""
    assert runs
    result = {"runs": len(runs)}
    for key in POPULATION_FIELDS:
        assert len({r[key] for r in runs}) == 1
        result[key] = runs[0][key]
    for key in (*SCORE_FIELDS, *COUNT_FIELDS):
        values = [r[key] for r in runs if r[key] is not None]
        result[key] = statistics.mean(values) if values else None
    return result


class Inputs:
    def __init__(self):
        self.hashes = {}

    def path(self, name):
        path = Path(name)
        return path if path.is_absolute() else ROOT / path

    def bind(self, name, expected=None):
        path = self.path(name)
        key = str(path.relative_to(ROOT))
        if key not in self.hashes:
            self.hashes[key] = hashlib.sha256(path.read_bytes()).hexdigest()
        if expected is not None:
            assert self.hashes[key] == expected, f"Changed input: {key}"
        return path

    def read(self, name, expected=None):
        return json.loads(self.bind(name, expected).read_bytes())

    def records(self, name, detector=None, expected=None):
        path = self.bind(name, expected)
        with path.open() as stream:
            for line in stream:
                if line.strip():
                    row = json.loads(line)
                    if detector is None or row["detector"] == detector:
                        yield row


def check_micro(tables, expected):
    scores = run_scores(tables)
    assert scores["tables"] == 1000 and scores["targets"] == 1093
    assert scores["zero_target_tables"] == 836
    assert scores["target_tables"] == scores["macro_f1_tables"] == 164
    for key in ("tp", "fp", "fn"):
        assert scores[key] == expected[key], (key, scores[key], expected[key])
    for key in ("precision", "recall", "f1"):
        assert math.isclose(scores["micro_" + key], 100 * expected[key], abs_tol=1e-12)
    return scores


def historical_runs(inputs, truth):
    folder = ROOT / "outputs/paper_evaluation/20260920"
    presentation = inputs.read(folder / "presentation_selection.json")
    selected = inputs.read(folder / "selected_results.json", presentation["source_manifest_sha256"])
    for name in ("excel_public", "cleanagent_repaired"):
        inputs.bind(folder / name / "selected_results.json")
    chosen = select_rows(folder, selected, presentation)
    categories = {
        m: category for category, methods in presentation["categories"].items() for m in methods
    }
    repetitions = Counter()
    for entry in chosen:
        records = list(
            inputs.records(
                entry["prediction_path"], entry["configuration"], entry["prediction_sha256"]
            )
        )
        statuses = entry["execution_status"]
        assert set(statuses) == set(truth.ids)
        tables, _ = truth.analyze(records, "e2e", statuses)
        stored = inputs.read(entry["per_table_path"])
        for ds, table in tables.items():
            for key in ("tp", "fp", "fn", "execution"):
                assert table[key] == stored[ds][key], (entry["method"], ds, key)
        method = SHORT_NAMES.get(entry["method"], entry["method"])
        repetitions[method] += 1
        category = categories[entry["method"]]
        yield {
            "method": method,
            "category": category,
            "group": "Industrial" if category == "Industrial workflows" else "Academic",
            "run": repetitions[method],
            "configuration": entry["configuration"],
            "tables": tables,
            "expected": entry["analysis"]["full"],
        }


def api_runs(inputs, truth):
    from external.gpt5_detect.secure_tuning import digest

    evidence = inputs.read(PAPER / "build/generated/llm_baseline_evidence.json")
    proofs = evidence["source_sha256"]
    report_path = next(p for p in proofs if p.endswith("final_report/RESULTS.json"))
    scored_path = next(p for p in proofs if p.endswith("e2e_scores.json"))
    derivation_path = next(p for p in proofs if p.endswith("derivation.json"))
    campaign = inputs.path(report_path).parents[1]
    report = inputs.read(report_path, proofs[report_path])
    expected = inputs.read(scored_path, proofs[scored_path])["results"]
    derivation = inputs.read(derivation_path, proofs[derivation_path])
    assert report["status"] == "completed_and_audited" and report["tables"] == 1000
    frozen = inputs.read(PAPER / "figures/error_analysis.json")["input_sha256"]
    pred_path = inputs.path(scored_path).with_name("valued_predictions.jsonl")
    grouped = defaultdict(list)
    for record in inputs.records(pred_path, expected=frozen[str(pred_path.relative_to(ROOT))]):
        grouped[record["detector"]].append(record)
    for model in MODELS:
        for repetition in (1, 2, 3):
            name = f"compare_{model}_selected"
            stage = campaign / f"rep_{repetition:02d}/recovered" / name
            record = inputs.read(stage / "receipt.json")
            prompt_path = inputs.bind(stage / "prompt.txt", record["prompt_sha256"])
            prompt = prompt_path.read_text()
            inputs.bind(stage / "predictions.jsonl", record["predictions_sha256"])
            statuses = {}
            for ds in truth.ids:
                path = stage.parent / "requests" / model / digest(prompt) / f"{ds}.json"
                response = inputs.read(
                    path, derivation["receipt_hashes"][str(path.relative_to(ROOT))]
                )
                statuses[ds] = "complete" if response["status"] == "success" else "failed"
            assert {ds for ds, status in statuses.items() if status == "failed"} == set(
                record["failed_tables"]
            )
            key = f"rep_{repetition:02d}/{model}/selected"
            tables, _ = truth.analyze(grouped[key], "e2e", statuses)
            yield {
                "method": model.replace("gpt", "GPT") + " (Prompt-tuned)",
                "category": "Direct LLMs",
                "group": "Direct LLMs",
                "run": repetition,
                "configuration": key,
                "tables": tables,
                "expected": expected[key],
            }


def agent_runs(inputs, truth):
    evidence = inputs.read(PAPER / "build/generated/coding_agent_repair_evidence.json")
    proofs = evidence["source_sha256"]
    prediction = END_TO_END_PREDICTIONS
    grouped = defaultdict(list)
    for record in inputs.records(prediction, expected=proofs[prediction]):
        grouped[record["detector"]].append(record)
    assert len(evidence["rows"]) == len(RUNS) == 4
    for entry, (run, agent, model, harness) in zip(evidence["rows"], RUNS, strict=True):
        assert (entry["run"], entry["model"], entry["harness"]) == (run, model, harness)
        directory = ROOT / "outputs/coding_agents" / run
        statuses = {}
        for path in sorted((directory / agent).glob("table_*/receipt.json")):
            receipt = inputs.read(path, proofs[str(path.relative_to(ROOT))])
            assert receipt["dataset"] not in statuses
            statuses[receipt["dataset"]] = (
                "complete"
                if receipt["output_valid"] and receipt["exit_code"] == 0 and not receipt["timeout"]
                else "failed"
            )
        assert set(statuses) == set(truth.ids)
        assert sum(v == "complete" for v in statuses.values()) == entry["successful_tables"]
        tables, _ = truth.analyze(grouped[entry["arm"]], "e2e", statuses)
        for ds, table in tables.items():
            assert [table[k] for k in ("tp", "fp", "fn")] == entry["per_table_counts"][ds]
        yield {
            "method": f"{model} ({harness})",
            "category": "Coding agents",
            "group": "Coding agents",
            "run": 1,
            "configuration": entry["arm"],
            "tables": tables,
            "expected": entry["metrics"],
        }


def write_csv(path, rows):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main():
    sys.path.insert(0, str(ROOT))
    from src.evaluation.paper_evaluation.analysis import GroundTruth

    inputs = Inputs()
    snapshot = ROOT / "outputs/baseline_campaign/20260910/snapshot"
    manifest = inputs.read(snapshot / "_manifest.json")
    for name in ("benchmark_cell.json", "neutral_cells.jsonl", "ignored.jsonl"):
        inputs.bind(snapshot / name, manifest["input_sha256"][name])
    truth = GroundTruth(snapshot, manifest)
    assert len(truth.ids) == 1000 and len(truth.eligible) == 1093
    assert sum(t["repair_targets"] == 0 for t in truth.tables.values()) == 836
    detailed = PAPER / "build/generated/macro_metrics_per_table.jsonl"
    detailed.parent.mkdir(parents=True, exist_ok=True)
    runs = []
    with detailed.open("w") as stream:
        for run in chain(
            historical_runs(inputs, truth), api_runs(inputs, truth), agent_runs(inputs, truth)
        ):
            tables = run.pop("tables")
            expected = run.pop("expected")
            scores = check_micro(tables, expected)
            row = {**run, **scores}
            runs.append(row)
            for ds, table in tables.items():
                per_table = table_scores(table)
                stream.write(
                    json.dumps(
                        {
                            "method": run["method"],
                            "run": run["run"],
                            "configuration": run["configuration"],
                            "dataset": ds,
                            "execution": table["execution"],
                            **{key: table[key] for key in ("tp", "fp", "fn")},
                            **{
                                f"table_{key}_percent": 100 * value if value is not None else None
                                for key, value in per_table.items()
                            },
                        }
                    )
                    + "\n"
                )
            print(
                f"{row['method']} run{row['run']}: micro={row['micro_f1']:.4f} macro={row['macro_f1']:.4f}",
                flush=True,
            )
    grouped = defaultdict(list)
    for run in runs:
        grouped[run["method"]].append(run)
    summary = []
    for method, group in grouped.items():
        summary.append(
            {
                "method": method,
                "category": group[0]["category"],
                "group": group[0]["group"],
                **average_runs(group),
            }
        )
    assert len(summary) == 23 and len(runs) == 37
    published_path = inputs.bind(PAPER / "assets/generated/task_type_metrics.csv")
    with published_path.open(newline="") as stream:
        published = {
            r["method"]: r
            for r in csv.DictReader(stream)
            if r["task"] == "e2e" and not r["method"].endswith(" (Base)")
        }
    assert set(grouped) == set(published)
    for row in summary:
        for metric in ("precision", "recall", "f1"):
            assert math.isclose(
                row["micro_" + metric], float(published[row["method"]][metric]), abs_tol=1e-12
            ), row["method"]
    empty, _ = truth.analyze([], "e2e", dict.fromkeys(truth.ids, "complete"))
    reference = {"method": "Keep original", **run_scores(empty)}
    assert reference["micro_f1"] == reference["macro_f1"] == 0
    assert reference["macro_precision"] == reference["macro_recall"] == 0
    assert reference["preservation"] == 100
    assert math.isclose(reference["all_table_macro_f1"], 83.6)
    output = PAPER / "assets/generated"
    write_csv(output / "macro_metrics.csv", summary)
    write_csv(output / "macro_metrics_runs.csv", runs)
    for code in (
        Path(__file__).resolve(),
        PAPER / "tools/build_error_types.py",
        PAPER / "tools/build_coding_agents.py",
        PAPER / "tools/build_unified_task_tables.py",
        ROOT / "src/evaluation/paper_evaluation/analysis.py",
        ROOT / "external/rein/score_repair.py",
        ROOT / "external/rein/score.py",
        ROOT / "external/rein/common.py",
    ):
        inputs.bind(code)
    evidence = {
        "task": "e2e",
        "score_units": "Percent (0-100) in summary, run and per-table files",
        "policy": "Compute macro precision, recall and F1 over the fixed tables with replacement targets. No scored changes or failed/unknown execution on a target table scores zero. Preservation is the fraction of zero-target tables completed with no scored changes. Average each score within each run, then across defined runs. Existing micro scores, macro recall and scoring immunity remain unchanged. all_table_macro_f1 retains the legacy all-table F1 for decomposition and validation.",
        "source_sha256": inputs.hashes,
        "methods": len(summary),
        "runs": len(runs),
        "reference": reference,
        "summary": summary,
        "run_scores": runs,
        "per_table_file": str(detailed.relative_to(PAPER)),
        "per_table_sha256": hashlib.sha256(detailed.read_bytes()).hexdigest(),
    }
    (PAPER / "build/generated/macro_metrics_evidence.json").write_text(
        json.dumps(evidence, indent=2) + "\n"
    )
    print("Verified all23 main methods/37 runs against existing published micro scores.")


if __name__ == "__main__":
    main()
