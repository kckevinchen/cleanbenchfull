"""Compare target-table macro scores with the alternate empty-match convention.

All values come from the separate frozen empty-match summaries. Existing macro
tables, scores, and illustrations are neither read for scoring nor modified.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from figure_style import COLUMN_WIDTH, MODEL_COLORS, configure, save
from matplotlib.lines import Line2D

PAPER = Path(__file__).resolve().parents[1]
GENERATED = PAPER / "assets/generated"
SOURCE = GENERATED / "empty_match_metrics.csv"
RUNS = GENERATED / "empty_match_metrics_runs.csv"
TARGET = GENERATED / "empty_match_comparison.pdf"
SELECTED = (
    "DaisyP",
    "SymSpell",
    "Excel",
    "GPT-5.5 (Prompt-tuned)",
    "GPT-6-astra (Prompt-tuned)",
    "GPT-6-astra (Codex)",
)
METRICS = (
    ("precision", "P", "o", MODEL_COLORS[1], -0.20),
    ("recall", "R", "^", MODEL_COLORS[2], 0.0),
    ("f1", "F1", "s", MODEL_COLORS[3], 0.20),
)


def read(path):
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def inputs():
    rows, runs = read(SOURCE), read(RUNS)
    indexed = {row["method"]: row for row in rows}
    if len(rows) != 23 or len(indexed) != 23 or len(runs) != 37:
        raise ValueError("Expected the 23 published workflows and 37 retained runs")
    by_method = defaultdict(list)
    for run in runs:
        by_method[run["method"]].append(run)
    if indexed.keys() != by_method.keys():
        raise ValueError("Summary and retained-run rosters differ")
    fields = [
        f"{prefix}{metric}" for prefix in ("macro_", "target_macro_") for metric, *_ in METRICS
    ]
    fields.append("preservation")
    for row in rows:
        method = row["method"]
        if (int(row["tables"]), int(row["target_tables"]), int(row["preservation_tables"])) != (
            1000,
            164,
            836,
        ):
            raise ValueError(f"Unexpected table populations: {method}")
        if len(by_method[method]) != int(row["runs"]):
            raise ValueError(f"Retained-run count differs: {method}")
        for field in fields:
            value = float(row[field])
            if not math.isfinite(value) or not 0 <= value <= 100:
                raise ValueError(f"Invalid {field} for {method}")
            mean = math.fsum(float(run[field]) for run in by_method[method]) / len(
                by_method[method]
            )
            if not math.isclose(value, mean, abs_tol=1e-10):
                raise ValueError(f"Summary/run mean differs: {method}, {field}")
        for metric, *_ in METRICS:
            expected = 0.164 * float(row[f"target_macro_{metric}"]) + 0.836 * float(
                row["preservation"]
            )
            if not math.isclose(float(row[f"macro_{metric}"]), expected, abs_tol=1e-10):
                raise ValueError(f"Empty-match decomposition differs: {method}, {metric}")
    return [indexed[method] for method in SELECTED]


def main():
    rows = inputs()
    configure()
    fig, ax = plt.subplots(figsize=(COLUMN_WIDTH, 2.9))
    fig.subplots_adjust(left=0.37, right=0.97, bottom=0.17, top=0.80)
    ax.set_xlim(-3, 103)
    ax.set_ylim(len(rows) - 0.4, -0.6)
    ax.set_xticks([0, 50, 100])
    ax.set_yticks(range(len(rows)), [row["method"].removesuffix(" (Prompt-tuned)") for row in rows])
    ax.set_xlabel("Macro score (%)", labelpad=3)
    ax.tick_params(axis="y", length=0, pad=4)
    ax.spines["left"].set_visible(False)
    ax.set_axisbelow(True)
    ax.grid(axis="x", color="#e6eaf0", linewidth=0.4)
    for index in range(len(rows)):
        if index % 2 == 0:
            ax.axhspan(index - 0.43, index + 0.43, color="#f4f6f9", linewidth=0, zorder=0)
    reference = 100 * int(rows[0]["preservation_tables"]) / int(rows[0]["tables"])
    ax.axvline(reference, color="#75818e", linestyle=(0, (3, 2)), linewidth=0.8, zorder=1)
    measured = []
    for index, row in enumerate(rows):
        for metric, label, marker, color, offset in METRICS:
            original = float(row[f"target_macro_{metric}"])
            alternate = float(row[f"macro_{metric}"])
            y = index + offset
            ax.plot([original, alternate], [y, y], color=color, alpha=0.35, linewidth=0.7, zorder=2)
            (first,) = ax.plot(
                original,
                y,
                marker=marker,
                markersize=3.6,
                markerfacecolor="white",
                markeredgecolor=color,
                markeredgewidth=0.8,
                linestyle="none",
                zorder=3,
            )
            (second,) = ax.plot(
                alternate,
                y,
                marker=marker,
                markersize=3.6,
                markerfacecolor=color,
                markeredgecolor=color,
                markeredgewidth=0.8,
                linestyle="none",
                zorder=4,
            )
            if list(first.get_xdata()) != [original] or list(second.get_xdata()) != [alternate]:
                raise ValueError("Rendered x coordinates must equal the frozen scores")
            measured.append(
                {
                    "method": row["method"],
                    "metric": label,
                    "target_macro": original,
                    "all_table_macro": alternate,
                    "categorical_y": y,
                }
            )
    metric_handles = [
        Line2D(
            [],
            [],
            linestyle="none",
            marker=marker,
            markersize=3.6,
            markerfacecolor=color,
            markeredgecolor=color,
            label=label,
        )
        for _, label, marker, color, _ in METRICS
    ]
    target_handle = Line2D(
        [],
        [],
        linestyle="none",
        marker="o",
        markersize=3.6,
        markerfacecolor="white",
        markeredgecolor="#536170",
        label="Target (164)",
    )
    all_handle = Line2D(
        [],
        [],
        linestyle="none",
        marker="o",
        markersize=3.6,
        markerfacecolor="#536170",
        markeredgecolor="#536170",
        label="All (1,000)",
    )
    reference_handle = Line2D(
        [],
        [],
        color="#75818e",
        linestyle=(0, (3, 2)),
        linewidth=0.8,
        label=f"All-table keep original ({reference:.1f})",
    )
    fig.legend(
        handles=[
            metric_handles[0],
            target_handle,
            metric_handles[1],
            all_handle,
            metric_handles[2],
            reference_handle,
        ],
        ncol=3,
        frameon=False,
        loc="upper left",
        bbox_to_anchor=(0.02, 0.98, 0.96, 0),
        mode="expand",
        borderaxespad=0,
        borderpad=0,
        handlelength=1.0,
        handletextpad=0.35,
        columnspacing=0.6,
        labelspacing=0.45,
    )
    save(fig, TARGET, width=COLUMN_WIDTH, check_layout=True)
    plt.close(fig)
    evidence = {
        "sources_sha256": {
            path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in (SOURCE, RUNS)
        },
        "available_methods": 23,
        "selected_methods": list(SELECTED),
        "target_tables": 164,
        "all_tables": 1000,
        "preservation_tables": 836,
        "keep_original_all_table_score": reference,
        "width_inches": COLUMN_WIDTH,
        "height_inches": 2.9,
        "font_size_bp": 8,
        "coordinate_policy": "Measured x scores are unchanged; metric offsets apply only to categorical y positions.",
        "paired_scores": measured,
    }
    destination = PAPER / "build/generated/empty_match_figure_evidence.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(evidence, indent=2) + "\n", encoding="utf-8")
    print(f"Rendered {len(measured)} paired scores: {TARGET.relative_to(PAPER)}")


if __name__ == "__main__":
    main()
