import pytest
from build_llm_scaling import included_response, resource_statistics


def attempt(**changes):
    return {
        "status": "returned",
        "valid_output": True,
        "complete": True,
        "truncated": False,
        "issues_count": 2,
        **changes,
    }


def test_only_successful_valid_nonempty_outputs_are_included():
    assert included_response("success", attempt())
    for status in ("exception", "invalid_output", "model_mismatch", "infeasible_estimated_context"):
        assert not included_response(status, attempt())
    for changes in (
        {"issues_count": 0},
        {"issues_count": None},
        {"valid_output": False},
        {"complete": False},
        {"truncated": True},
        {"status": "exception"},
    ):
        assert not included_response("success", attempt(**changes))


def test_resource_pair_uses_same_selected_responses_and_empty_is_not_zero():
    common = {"usage": {"input_tokens": 10, "cached_read_tokens": 0}, "price_tier": "short"}
    values = [
        {**common, "elapsed_seconds": s, "public_price_usd": c, "no_cache_scenario_usd": 2 * c}
        for s, c in ((2, 1), (4, 3), (100, 8))
    ]
    result = resource_statistics(values)
    assert result["median_seconds"] == 4
    assert result["mean_public_price_usd"] == pytest.approx(4)
    assert all(v is None for v in resource_statistics([]).values())
