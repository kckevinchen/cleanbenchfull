"""Root-only author sources and reproducible generated-table staging."""

import hashlib
import importlib
import json
from pathlib import Path
from zipfile import ZipFile

import pytest
from tools.export_overleaf import validate_tex_sources
from tools.tex_sources import generated_asset


def snapshot(tmp_path, *, digest=None):
    directory = tmp_path / "assets/generated"
    directory.mkdir(parents=True)
    data = b"Frozen & 42 \\\\\n"
    with ZipFile(directory / "tex_snapshots.zip", "w") as bundle:
        bundle.writestr("table.tex", data)
        bundle.writestr(
            "MANIFEST.json",
            json.dumps({"sha256": {"table.tex": digest or hashlib.sha256(data).hexdigest()}}),
        )
    return directory, data


def test_frozen_table_stages_once_and_preserves_generated_work(tmp_path):
    directory, data = snapshot(tmp_path)
    target = generated_asset("table.tex", directory=directory)
    assert target == tmp_path / "build/generated/tex/table.tex"
    assert target.read_bytes() == data
    target.write_text("Reviewed new output")
    assert generated_asset("table.tex", directory=directory).read_text() == "Reviewed new output"
    assert not list(directory.glob("*.tex"))
    assert generated_asset("scores.csv", directory=directory) == directory / "scores.csv"
    assert not generated_asset("new_table.tex", directory=directory).exists()


def test_corrupt_frozen_table_is_rejected(tmp_path):
    directory, _ = snapshot(tmp_path, digest="bad hash")
    with pytest.raises(ValueError, match="hash mismatch"):
        generated_asset("table.tex", directory=directory)
    assert not (tmp_path / "build/generated/tex/table.tex").exists()


@pytest.mark.parametrize("name", ["../table.tex", "/tmp/table.tex"])
def test_generated_asset_cannot_escape_directory(name):
    with pytest.raises(ValueError, match="relative"):
        generated_asset(name)


def test_archive_contains_only_complete_root_tex_sources(tmp_path):
    main = tmp_path / "main.tex"
    section = tmp_path / "section.tex"
    main.write_text("% \\input{old/unused}\n\\input{section}\n")
    section.write_text("Existing content")
    validate_tex_sources(tmp_path, {main, section})
    main.write_text("\\input{figures/hidden}\n")
    with pytest.raises(ValueError, match="Nested TeX"):
        validate_tex_sources(tmp_path, {main, section})
    main.write_text("\\input{missing}\n")
    with pytest.raises(ValueError, match="Missing root TeX"):
        validate_tex_sources(tmp_path, {main, section})
    with pytest.raises(ValueError, match="project root"):
        validate_tex_sources(tmp_path, {tmp_path / "figures/table.tex"})


def test_all_frozen_generated_tables_retain_their_hashes():
    archive = Path(__file__).resolve().parents[1] / "assets/generated/tex_snapshots.zip"
    with ZipFile(archive) as bundle:
        manifest = json.loads(bundle.read("MANIFEST.json"))
        assert len(manifest["sha256"]) == 51
        assert set(bundle.namelist()) == {*manifest["sha256"], "MANIFEST.json"}
        for name, expected in manifest["sha256"].items():
            assert hashlib.sha256(bundle.read(name)).hexdigest() == expected


def test_existing_plot_readers_use_archived_tables(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).resolve().parent))
    families = importlib.import_module("build_family_distribution").counts()
    quality = importlib.import_module("build_price_quality").collect()
    assert len(families) == 6
    assert sum(row["memberships"] for row in families) == 1503
    assert len(quality) == 4


def test_current_author_sources_have_only_root_inputs():
    paper = Path(__file__).resolve().parents[1]
    validate_tex_sources(paper, set(paper.glob("*.tex")))
    for name in ("figures", "assets", "preamble", "appendices", "legacy"):
        assert not list((paper / name).rglob("*.tex"))
