"""Add alternate all-table macro scores with credit for correct empty outputs.

Derive scores from the existing target-table macro and preservation summaries,
then independently validate against frozen per-table counts. Existing metric
files, predictions, labels, and scoring definitions remain unchanged.
"""

from __future__ import annotations

import csv
import hashlib
import json
import statistics
from collections import defaultdict
from pathlib import Path

PAPER = Path(__file__).resolve().parents[1]
METRICS = ("precision", "recall", "f1")


def combine(target_score, preservation, target_tables, preservation_tables):
    """Weight both disjoint table populations; inputs and output are percentages."""
    assert target_tables >= 0 and preservation_tables >= 0
    total = target_tables + preservation_tables
    assert total > 0
    assert target_score is not None or target_tables == 0
    assert preservation is not None or preservation_tables == 0
    assert target_score is None or 0 <= target_score <= 100
    assert preservation is None or 0 <= preservation <= 100
    return (target_tables * (target_score or 0) + preservation_tables * (preservation or 0)) / total


def empty_match_table_scores(table):
    """Compute the alternate convention directly from one table's frozen counts."""
    tp, fp, fn = (table[key] for key in ("tp", "fp", "fn"))
    assert all(isinstance(value, int) and value >= 0 for value in (tp, fp, fn))
    assert table["execution"] in {"complete", "failed", "unknown"}
    if table["execution"] != "complete":
        return dict.fromkeys(METRICS, 0.0)
    if tp + fn == 0:
        return dict.fromkeys(METRICS, float(tp + fp == 0))
    return {
        "precision": tp / (tp + fp) if tp + fp else 0.0,
        "recall": tp / (tp + fn),
        "f1": 2 * tp / (2 * tp + fp + fn),
    }


def convert(row):
    """Convert one frozen run or method summary without rescoring predictions."""
    identity = ("method", "category", "group")
    repetition = ("runs",) if "runs" in row else ("run", "configuration")
    result = {key: row[key] for key in (*identity, *repetition)}
    for key in ("tables", "target_tables", "preservation_tables"):
        result[key] = int(row[key])
    assert result["tables"] == result["target_tables"] + result["preservation_tables"]
    preservation = float(row["preservation"]) if row["preservation"] != "" else None
    for metric in METRICS:
        source = row["macro_" + metric]
        target_score = float(source) if source != "" else None
        result["macro_" + metric] = combine(
            target_score, preservation, result["target_tables"], result["preservation_tables"]
        )
    for metric in METRICS:
        source = row["macro_" + metric]
        result["target_macro_" + metric] = float(source) if source != "" else None
    result["preservation"] = preservation
    return result


def write_csv(path, rows):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main():
    generated = PAPER / "assets/generated"
    evidence_path = PAPER / "build/generated/macro_metrics_evidence.json"
    evidence = json.loads(evidence_path.read_text())
    per_table = PAPER / evidence["per_table_file"]
    assert hashlib.sha256(per_table.read_bytes()).hexdigest() == evidence["per_table_sha256"]
    sources = [
        generated / name
        for name in (
            "macro_metrics.csv",
            "macro_metrics_runs.csv",
            "macro_type_metrics.csv",
            "macro_type_metrics_runs.csv",
        )
    ]
    before = {path: hashlib.sha256(path.read_bytes()).hexdigest() for path in sources}
    rows = []
    for path in sources[:2]:
        with path.open(newline="") as stream:
            rows.append(list(csv.DictReader(stream)))
    summary, runs = ([convert(row) for row in population] for population in rows)
    assert len(summary) == 23 and len(runs) == 37
    for row in (*summary, *runs):
        assert (row["tables"], row["target_tables"], row["preservation_tables"]) == (1000, 164, 836)

    direct = defaultdict(list)
    seen = set()
    for line in per_table.open():
        table = json.loads(line)
        identity = table["method"], int(table["run"]), table["configuration"]
        coordinate = (*identity, table["dataset"])
        assert coordinate not in seen
        seen.add(coordinate)
        direct[identity].append(empty_match_table_scores(table))
    assert len(seen) == 37000 and len(direct) == 37
    direct_summary = defaultdict(list)
    max_direct_delta = max_legacy_delta = 0.0
    for row, source in zip(runs, rows[1], strict=True):
        identity = row["method"], int(row["run"]), row["configuration"]
        tables = direct[identity]
        assert len(tables) == row["tables"]
        independent = {
            "macro_" + metric: 100 * statistics.mean(table[metric] for table in tables)
            for metric in METRICS
        }
        for key, value in independent.items():
            difference = abs(value - row[key])
            assert difference <= 1e-12, (identity, key, value, row[key])
            max_direct_delta = max(max_direct_delta, difference)
        legacy_delta = abs(row["macro_f1"] - float(source["all_table_macro_f1"]))
        assert legacy_delta <= 1e-12
        max_legacy_delta = max(max_legacy_delta, legacy_delta)
        direct_summary[row["method"]].append(independent)
    for row, source in zip(summary, rows[0], strict=True):
        method_runs = direct_summary[row["method"]]
        assert len(method_runs) == int(row["runs"])
        for metric in METRICS:
            key = "macro_" + metric
            value = statistics.mean(run[key] for run in method_runs)
            difference = abs(value - row[key])
            assert difference <= 1e-12, (row["method"], key, value, row[key])
            max_direct_delta = max(max_direct_delta, difference)
        legacy_delta = abs(row["macro_f1"] - float(source["all_table_macro_f1"]))
        assert legacy_delta <= 1e-12
        max_legacy_delta = max(max_legacy_delta, legacy_delta)

    reference = {
        "method": "Keep original",
        "tables": 1000,
        "target_tables": 164,
        "preservation_tables": 836,
        "preservation": 100.0,
        **{"macro_" + key: combine(0, 100, 164, 836) for key in METRICS},
    }
    assert all(reference["macro_" + key] == 83.6 for key in METRICS)
    write_csv(generated / "empty_match_metrics.csv", summary)
    write_csv(generated / "empty_match_metrics_runs.csv", runs)
    for path, digest in before.items():
        assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
    paths = [*sources, evidence_path, per_table, Path(__file__).resolve()]
    receipt = {
        "task": "e2e",
        "score_units": "Percent (0-100)",
        "policy": "For completed tables requiring no replacements, no scored edits earn precision=recall=F1=1 and scored edits earn zero. Target tables use their ordinary ratios, with empty outputs scoring zero. Failed/unknown execution always scores zero. Average over all 1,000 tables in each run, then average runs.",
        "derivation": "For each metric: (target_tables * target_macro_metric + preservation_tables * preservation) / tables.",
        "methods": len(summary),
        "runs": len(runs),
        "per_table_rows_validated": len(seen),
        "max_direct_count_score_delta": max_direct_delta,
        "max_existing_all_table_f1_delta": max_legacy_delta,
        "source_sha256": {
            str(path.relative_to(PAPER.parent)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in paths
        },
        "unchanged_macro_csv_sha256": {path.name: digest for path, digest in before.items()},
        "reference": reference,
        "summary": summary,
        "run_scores": runs,
    }
    (PAPER / "build/generated/empty_match_metrics_evidence.json").write_text(
        json.dumps(receipt, indent=2) + "\n"
    )
    print(
        "Verified 23 methods / 37 runs against 37,000 frozen table records; "
        "existing macro CSVs unchanged."
    )


if __name__ == "__main__":
    main()
