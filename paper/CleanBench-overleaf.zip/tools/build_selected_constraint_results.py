"""Assemble full-paper Table 3 inputs from cross-fitted constraint predictions."""

from __future__ import annotations

import argparse
import importlib.util
import json
import shutil
from pathlib import Path

from build_constraint_score_analysis import (
    DATA,
    METHODS,
    THRESHOLDS,
    digest,
    read,
    write_csv,
)


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n")


def fold_assignment(curves, folds, metric):
    universe = set(next(iter(curves.values())))
    groups = [{ds for group in fold for ds in group} for fold in folds]
    if set.union(*groups) != universe or sum(map(len, groups)) != len(universe):
        raise ValueError("Folds must partition the complete table population")
    assignment, choices = {}, []
    for test in groups:
        train = universe - test
        scores = {
            t: metric({ds: counts[ds] for ds in train})[0]["f1"] for t, counts in curves.items()
        }
        choice = max(scores, key=lambda t: (scores[t], t))
        assignment.update(dict.fromkeys(test, choice))
        choices.append(choice)
    return assignment, choices


def build(repo, study, output):
    if output.exists():
        raise ValueError("Choose a new output directory")
    module_path = repo / "src/reproducibility/table3.py"
    spec = importlib.util.spec_from_file_location("selected_table3", module_path)
    scoring = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scoring)
    original = repo / "reproducibility/table3"
    manifest = scoring.verify(original)
    reference = read(original / "reference.json")
    experiment = repo / "reproducibility/constraints"
    experiment_manifest = read(experiment / "manifest.json")
    for name, checksum in experiment_manifest["sha256"].items():
        assert digest(experiment / name) == checksum
    assert digest(original / "reference.json") == experiment_manifest["reference_sha256"]
    folds, plans = read(experiment / "folds.json"), read(experiment / "plans.json")["numeric"]
    candidate_path = study / "candidate_bank.json"
    assert digest(candidate_path) == experiment_manifest["source_pool_sha256"]
    bank = read(candidate_path)
    pool = read(repo / "baselines/constraints/config/pool.json")["tables"]
    assert (
        digest(repo / "baselines/constraints/config/pool.json")
        == experiment_manifest["pool_sha256"]
    )
    by_id = {(ds, r["rule"]["rule_id"]): r for ds, rules in bank.items() for r in rules}
    targets = {(r["dataset"], r["row"], r["col"]) for r in reference["targets"]}
    coverage = []
    for threshold in THRESHOLDS:
        candidates = [
            (ds, r) for ds, rules in pool.items() for r in rules if r["score"] >= threshold
        ]
        for method in ["shared", *METHODS]:
            selected = [
                (ds, r) for ds, r in candidates if method == "shared" or method in r["native"]
            ]
            cells = {
                (ds, *cell)
                for ds, r in selected
                for cell in by_id[ds, r["rule"]["rule_id"]]["gt_overlap"]
            }
            assert cells <= targets
            coverage.append(
                dict(
                    method=METHODS.get(method, "Shared bank"),
                    threshold=threshold,
                    constraints=len(selected),
                    tables=len({ds for ds, _ in selected}),
                    error_cells=len(cells),
                    coverage_percent=100 * len(cells) / len(targets),
                )
            )
    write_csv(DATA / "constraint_score_coverage.csv", coverage)
    root = output / "reproducibility/table3"
    shutil.copytree(original, root)
    destination = output / "src/reproducibility/table3.py"
    destination.parent.mkdir(parents=True)
    shutil.copy2(module_path, destination)
    shutil.copy2(original / "expected/table3_point.csv", DATA / "constraint_original_table3.csv")
    manifest["runs"] = [r for r in manifest["runs"] if r["method"] not in METHODS.values()]
    manifest["constraint_selection"] = list(METHODS.values())
    for method in METHODS:
        shutil.rmtree(root / "methods" / method)
    evidence, runtime_rows = {}, []
    for method, label in METHODS.items():
        curves, runs = {}, {}
        for threshold in THRESHOLDS:
            bank_id = plans[str(threshold)]
            entry = experiment_manifest["runs"][bank_id][method]
            predictions = list(scoring.records(experiment / entry["predictions"]))
            execution = read(experiment / entry["execution"])
            curves[threshold] = scoring.score_run(predictions, reference, execution)
            runs[threshold] = predictions, execution, bank_id
        assignment, choices = fold_assignment(curves, folds, scoring.metrics)
        predictions = [r for t in THRESHOLDS for r in runs[t][0] if assignment[r["dataset"]] == t]
        execution = {ds: runs[t][1][ds] for ds, t in assignment.items()}
        tables = scoring.score_run(predictions, reference, execution)
        assert tables == {ds: curves[t][ds] for ds, t in assignment.items()}
        identity = f"{method}/run_01"
        folder = root / "methods" / identity
        folder.mkdir(parents=True)
        with (folder / "predictions.jsonl").open("w") as stream:
            for row in sorted(predictions, key=lambda r: (r["dataset"], r["row"], r["col"])):
                stream.write(json.dumps(row) + "\n")
        with (folder / "table_counts.jsonl").open("w") as stream:
            for ds, row in sorted(tables.items()):
                stream.write(json.dumps(dict(dataset=ds, **row)) + "\n")
        metadata = dict(
            method=label,
            run=1,
            configuration="GT-assisted constraints with five-fold semantic-score selection",
            execution=execution,
            settings=dict(fold_thresholds=choices, table_thresholds=assignment),
            population=reference["population"],
            scoring=reference["scoring"],
        )
        write_json(folder / "run.json", metadata)
        manifest["runs"].append(
            dict(
                identity=identity,
                method=label,
                run=1,
                point_view=True,
                predictions=f"methods/{identity}/predictions.jsonl",
                counts=f"methods/{identity}/table_counts.jsonl",
                metadata=f"methods/{identity}/run.json",
            )
        )
        evidence[method] = dict(
            fold_thresholds=choices,
            table_thresholds=assignment,
            metrics=scoring.metrics(tables)[0],
            source_banks={str(t): runs[t][2] for t in set(choices)},
        )
        # Read native execution time from the exact tables supplying these outputs.
        if method not in {"bigdansing", "nadeef"}:
            continue
        seconds, timed, failures = 0.0, 0, 0
        for threshold in set(choices):
            native = study / "sweep/native" / runs[threshold][2]
            records = read(native / f"results/{method}/run_01/evidence.json")
            for ds, item in records.items():
                if assignment[ds] != threshold:
                    continue
                result_path = Path(item["evidence"]["result"])
                assert digest(result_path) == item["evidence"]["result_sha256"]
                result = read(result_path)
                seconds += result["elapsed_seconds"]
                timed += 1
                failures += item["status"] != "complete"
        runtime_rows.append(
            dict(method=label, seconds=seconds, native_tables=timed, failed_tables=failures)
        )
    observations = {}
    for run in manifest["runs"]:
        counts = {r["dataset"]: r for r in scoring.records(root / run["counts"])}
        observations[run["identity"]] = scoring.metrics(counts)[0]
    for view in ["point", "variability"]:
        scoring.write_csv(
            root / f"expected/table3_{view}.csv", scoring.summarize(manifest, observations, view)
        )
    manifest["sha256"] = {
        p.relative_to(root).as_posix(): digest(p)
        for p in sorted(root.rglob("*"))
        if p.is_file() and p.name != "manifest.json"
    }
    write_json(root / "manifest.json", manifest)
    scoring.verify(root)
    write_json(
        DATA / "constraint_selected_results.json",
        dict(
            reference_sha256=digest(root / "reference.json"),
            source_manifest_sha256=digest(original / "manifest.json"),
            candidate_bank_sha256=digest(candidate_path),
            folds_sha256=digest(experiment / "folds.json"),
            methods=evidence,
            runtime=runtime_rows,
        ),
    )
    print(root)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--study", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    build(args.repo.resolve(), args.study.resolve(), args.output.resolve())


if __name__ == "__main__":
    main()
