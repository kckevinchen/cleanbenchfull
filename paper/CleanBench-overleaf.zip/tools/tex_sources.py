"""Keep generated TeX intermediates out of the manuscript's source tree.

Author-editable TeX lives in the project root. Historical generated tables are
frozen in tex_snapshots.zip for offline builders; working copies and new outputs
live under ignored build/generated/tex and never overwrite the manuscript.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

PAPER = Path(__file__).resolve().parents[1]


def generated_asset(name: str, *, directory: Path | None = None) -> Path:
    """Resolve an asset, staging legacy TeX inputs in the local build directory."""
    directory = PAPER / "assets/generated" if directory is None else Path(directory)
    relative = Path(name)
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError(f"Expected a relative generated asset name: {name}")
    if relative.suffix != ".tex" or directory.parts[-2:] != ("assets", "generated"):
        return directory / relative
    paper = directory.parent.parent
    target = paper / "build/generated/tex" / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    if not target.exists():
        archive = directory / "tex_snapshots.zip"
        if archive.exists():
            with ZipFile(archive) as bundle:
                if relative.as_posix() in bundle.namelist():
                    data = bundle.read(relative.as_posix())
                    manifest = json.loads(bundle.read("MANIFEST.json"))
                    expected = manifest["sha256"][relative.as_posix()]
                    if hashlib.sha256(data).hexdigest() != expected:
                        raise ValueError(f"Generated TeX snapshot hash mismatch: {name}")
                    target.write_bytes(data)
    return target
