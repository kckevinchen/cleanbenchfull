"""Check abstention, false alarms, failures, and stratified aggregation."""

import pytest
from build_stratified_metrics import run_metrics, summarize_runs


def table(tp=0, fp=0, fn=0, execution="complete"):
    return {"tp": tp, "fp": fp, "fn": fn, "execution": execution}


def test_silent_reference_has_undefined_precision_and_balanced_fifty():
    result = run_metrics([table(fn=3), table()])
    assert result["conditional_precision"] is None
    assert result["target_conditional_precision"] is None
    assert result["target_recall"] == result["coverage"] == result["target_f1"] == 0
    assert result["false_alarm_rate"] == 0
    assert result["preservation"] == 100
    assert result["balanced_score"] == 50


def test_perfect_workflow_gets_full_credit_in_both_groups():
    result = run_metrics([table(tp=3), table()])
    for key in (
        "conditional_precision",
        "target_conditional_precision",
        "target_recall",
        "coverage",
        "target_f1",
        "preservation",
        "balanced_score",
    ):
        assert result[key] == 100


def test_conditional_all_table_precision_and_error_precision_have_distinct_roles():
    result = run_metrics([table(tp=1), table(fp=50), table()])
    assert result["conditional_precision"] == 50
    assert result["target_conditional_precision"] == 100
    assert result["false_alarm_rate"] == 50
    assert result["balanced_score"] == 75


def test_false_alarm_is_per_table_and_extra_quiet_tables_do_not_inflate_error_f1():
    a = run_metrics([table(fn=1), table(fp=1), table()])
    b = run_metrics([table(fn=1), table(fp=500), table()])
    assert a["false_alarm_rate"] == b["false_alarm_rate"] == 50
    assert a["target_f1"] == b["target_f1"] == 0
    c = run_metrics([table(tp=1, fn=1), table(), table()])
    d = run_metrics([table(tp=1, fn=1), *[table() for _ in range(100)]])
    for key in ("target_recall", "target_conditional_precision", "target_f1", "balanced_score"):
        assert c[key] == d[key]


@pytest.mark.parametrize("execution", ["failed", "unknown"])
def test_failed_outputs_are_not_successful_preservation(execution):
    result = run_metrics([table(fn=1, execution=execution), table(execution=execution)])
    assert result["coverage"] == result["target_recall"] == 0
    assert result["false_alarm_rate"] == 0
    assert result["failed_no_target_rate"] == 100
    assert result["preservation"] == result["balanced_score"] == 0


def test_coverage_counts_an_attempt_even_when_all_proposed_values_are_wrong():
    result = run_metrics([table(fp=1, fn=1), table(fn=1), table()])
    assert result["coverage"] == 50
    assert result["target_recall"] == result["conditional_precision"] == 0


def test_summary_f1_is_harmonic_after_averaging_its_inputs():
    a = run_metrics([table(tp=1, fn=4), table()])
    b = run_metrics([table(tp=5, fp=20), table()])
    summary = summarize_runs([a, b])
    assert summary["target_conditional_precision"] == summary["target_recall"] == 60
    assert summary["target_f1"] == 60
    assert summary["balanced_score"] == 80
    assert summary["target_f1"] != pytest.approx((a["target_f1"] + b["target_f1"]) / 2)


def test_undefined_precision_does_not_remove_silent_runs_from_recall_or_coverage():
    silent = run_metrics([table(fn=1), table()])
    active = run_metrics([table(tp=1), table()])
    summary = summarize_runs([silent, active])
    assert summary["conditional_precision"] == summary["target_conditional_precision"] == 100
    assert summary["precision_defined_runs"] == summary["target_precision_defined_runs"] == 1
    assert summary["target_recall"] == summary["coverage"] == 50
