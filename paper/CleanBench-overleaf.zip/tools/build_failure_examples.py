"""Verify and render recorded failure cases as compact, vector comparison cards.

The inputs are frozen predictions and reference annotations. No model calls or
new labeling are performed. Only the selected excerpts enter the figure.
"""

from __future__ import annotations

import argparse
import csv
import difflib
import hashlib
import html
import json
import re
import sys
from itertools import chain
from pathlib import Path

from build_context_screenshots import column_letter, worksheet_row
from figure_style import COLUMN_WIDTH, FIGURE_WIDTH, FONT_SIZE, model_label
from worksheet_style import TABLE_FONT_BP, check_worksheet_style, worksheet_css

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parent
WIDTH = 600


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def records(path):
    with path.open() as stream:
        for line in stream:
            if line.strip():
                yield json.loads(line)


def audit(config):
    sys.path.insert(0, str(ROOT))
    from src.evaluation.paper_evaluation.analysis import GroundTruth

    snapshot = ROOT / config["snapshot"]
    for name, expected in config["snapshot_sha256"].items():
        assert digest(snapshot / name) == expected, name
    manifest = json.loads((snapshot / "_manifest.json").read_text())
    truth = GroundTruth(snapshot, manifest)
    predictions = {}
    for name, spec in config["predictions"].items():
        path = ROOT / spec["path"]
        assert digest(path) == spec["sha256"], name
        values = {}
        for row in records(path):
            if row["detector"] != spec["detector"]:
                continue
            key = row["dataset"], int(row["row"]), int(row["col"])
            assert key not in values, (name, key)
            values[key] = row["corrected_value"]
        predictions[name] = values
    execution = {}
    if config.get("paired_outputs"):
        from build_macro_metrics import Inputs, api_runs, historical_runs

        inputs = Inputs()
        requested = {s["detector"] for s in config["predictions"].values()}
        for run in chain(historical_runs(inputs, truth), api_runs(inputs, truth)):
            if run["configuration"] in requested:
                execution[run["configuration"]] = {
                    ds: table["execution"] for ds, table in run["tables"].items()
                }
        assert set(execution) == requested
    results = []
    for spec in config["examples"]:
        ds = spec["dataset"]
        path = snapshot / ds / "dirty.csv"
        source_hash = digest(path)
        assert source_hash == manifest["datasets"][ds]["dirty_sha256"]
        with path.open(newline="") as stream:
            headers, *rows = list(csv.reader(stream))
        col = headers.index(spec["column"])
        row = spec["row"]
        key = ds, row, col
        assert rows[row][col] == spec["original"]
        if "comparisons" in spec:
            assert config.get("paired_outputs")
            assert key in truth.eligible
            assert truth.accepted[key] == {spec["reference"]}
            for comparison in spec["comparisons"]:
                for method in comparison["methods"]:
                    value = predictions[method].get(key)
                    status = execution[config["predictions"][method]["detector"]][ds]
                    verify_comparison(value, comparison["proposed"], status)
            assert any(c["proposed"] != spec["reference"] for c in spec["comparisons"])
        elif spec.get("outcome", "wrong_value") == "clean_edit":
            assert key not in truth.errors | truth.ambiguous and not truth.immune(key)
            assert spec["reference"] == spec["original"] != spec["proposed"]
        else:
            assert key in truth.eligible
            assert truth.accepted[key] == {spec["reference"]}
            assert spec["proposed"] not in truth.accepted[key]
        if spec.get("require_existing_category"):
            assert any(r[col] == spec["proposed"] for r in rows)
        for method in spec.get("methods", []):
            assert predictions[method][key] == spec["proposed"], (method, key)
        context = {c: rows[row][headers.index(c)] for c in spec.get("context_columns", [])}
        peers = spec.get("context_peers", [])
        if peers:
            assert row not in peers and len(set(peers)) == len(peers)
            context[f"Other {spec['column']} values"] = "; ".join(rows[i][col] for i in peers)
        matches = None
        if "matching_targets" in spec:
            method = spec["methods"][0]
            matches = [
                list(k)
                for k, value in predictions[method].items()
                if k[0] == ds
                and k[2] == col
                and k in truth.eligible
                and rows[k[1]][col] == spec["original"]
                and value == spec["proposed"]
                and truth.accepted[k] == {spec["reference"]}
            ]
            assert len(matches) == spec["matching_targets"]
        results.append(
            dict(
                spec,
                context=context,
                col=col,
                source_row=manifest["datasets"][ds]["exported_to_source"][row],
                source_sha256=source_hash,
                original_column_frequency=sum(r[col] == spec["original"] for r in rows),
                matching_coordinates=matches,
            )
        )
    return results


def verify_comparison(actual, expected, execution):
    """No-edit examples require a completed run, not a missing failed output."""
    assert execution == "complete", "An example must not disguise an execution failure as no edit"
    assert actual == expected, (actual, expected)


def marked(value, comparison, css_class):
    """Highlight differing words while preserving literal spaces and punctuation."""
    tokens = re.findall(r"\w+|\W+", value)
    other = re.findall(r"\w+|\W+", comparison)
    pieces = []
    for op, start, end, _, _ in difflib.SequenceMatcher(None, tokens, other).get_opcodes():
        text = html.escape("".join(tokens[start:end]))
        if not text:
            continue
        pieces.append(text if op == "equal" else f'<b class="{css_class}">{text}</b>')
    return "".join(pieces)


def document(cases, wrap_values=False, columns=1):
    assert columns in (1, 2)
    fonts = PAPER / "build/fonts"
    regular = fonts / "LinLibertine_Rah.ttf"
    bold = fonts / "LinLibertine_RBah.ttf"
    if not regular.exists():
        regular, bold = fonts / "LinLibertine_R.otf", fonts / "LinLibertine_RB.otf"
    assert regular.is_file() and bold.is_file(), "Linux Libertine fonts are required"
    width = WIDTH * columns
    printed_width = COLUMN_WIDTH if columns == 1 else FIGURE_WIDTH
    size = FONT_SIZE * width / (printed_width * 72)
    css = f"""
    @font-face {{font-family:Libertine;src:url('{regular.as_uri()}')}}
    @font-face {{font-family:Libertine;src:url('{bold.as_uri()}');font-weight:700}}
    * {{box-sizing:border-box}}
    body {{margin:0;background:white;color:black;font:{size}px/1.25 Libertine}}
    #figure {{width:{width}px;padding:2px;display:grid;
      grid-template-columns:repeat({columns},minmax(0,1fr));gap:20px 24px}}
    section {{min-width:0}}
    .heading {{font-weight:700;margin-bottom:6px}}
    .context-group {{min-height:1.25em;margin-bottom:6px}}
    .context {{color:#444}}
    .context .label {{color:#555}}
    .value {{white-space:pre-wrap;overflow-wrap:anywhere}}
    .no-edit {{color:#555;font-style:italic}}
    .outputs .label {{width:138px;white-space:nowrap}}
    .outputs tr.reference {{outline:2px solid #00b050;outline-offset:-1px}}
    """ + worksheet_css(width, printed_width)
    cards = []
    for letter, case in zip("abcdefghijklmnopqrstuvwxyz"[: len(cases)], cases, strict=True):
        title = html.escape(case["title"])
        if "analysis_group" in case:
            assert case["analysis_group"] in {"Knowledge", "Reasoning", "Formatting"}
            title = f'{html.escape(case["analysis_group"])}: {title}'
        context = "".join(
            f'<div class="context"><span class="label">{html.escape(k)}: </span>'
            f"{html.escape(v)}</div>"
            for k, v in case["context"].items()
        )
        source = f"""<div class="worksheet"><table class="source">
          <colgroup><col style="width:38px"><col></colgroup>
          <thead><tr class="column-letters"><th class="corner"></th>
            <th>{column_letter(case['col'])}</th></tr>
            <tr class="field-names"><th class="coord">1</th>
            <th>{html.escape(case['column'])}</th></tr></thead>
          <tbody><tr class="selected"><th class="coord">{worksheet_row(case['source_row'])}</th>
            <td><span class="value" data-role="original">{html.escape(case['original'])}</span></td>
          </tr></tbody></table></div>"""
        comparisons = case.get(
            "comparisons",
            [dict(label=case.get("display_methods", ""), proposed=case.get("proposed"))],
        )
        outputs = []
        for i, comparison in enumerate(comparisons):
            value = comparison["proposed"]
            if value is None:
                value_html = '<span class="no-edit">No edit</span>'
            elif value == case["reference"]:
                value_html = marked(value, case["original"], "good")
            else:
                value_html = marked(value, case["reference"], "bad")
            role = f"method-{i}" if "comparisons" in case else "proposed"
            outputs.append(
                '<tr><td class="label">'
                f'{html.escape(model_label(comparison["label"]))}</td>'
                f'<td><span class="value" data-role="{role}">{value_html}</span></td></tr>'
            )
        reference = marked(case["reference"], case["original"], "good")
        cards.append(f"""<section data-case="{case['id']}">
          <div class="heading">({letter}) {title}</div>
          <div class="context-group">{context}</div>{source}
          <table class="outputs"><colgroup><col style="width:138px"><col></colgroup>
            <thead><tr><th>Method</th><th>Output</th></tr></thead><tbody>
            {''.join(outputs)}<tr class="reference"><td class="label">Reference</td>
            <td><span class="value" data-role="reference">{reference}</span></td></tr>
          </tbody></table></section>""")
    return (
        '<!doctype html><html lang="en"><meta charset="utf-8">'
        '<title>CleanBench recorded correction errors</title>'
        f'<style>{css}</style><body><main id="figure">{"".join(cards)}</main></body></html>'
    )


def main():
    from playwright.sync_api import sync_playwright

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--browser", type=Path, help="Optional Chromium executable")
    parser.add_argument("--config", type=Path, default=PAPER / "figures/failure_examples.json")
    parser.add_argument("--name", default="failure_examples", help="Output asset stem")
    args = parser.parse_args()
    config_path = args.config
    config = json.loads(config_path.read_text())
    cases = audit(config)
    target = PAPER / "build/generated" / args.name
    target.mkdir(parents=True, exist_ok=True)
    page_path = target / "index.html"
    columns = config.get("columns", 1)
    page_path.write_text(document(cases, config.get("wrap_values", False), columns))
    output_dir = PAPER / (
        "figures/paper" if args.name == "llm_constraint_failures" else "assets/generated"
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    pdf = output_dir / f"{args.name}.pdf"
    with sync_playwright() as playwright:
        options = {"headless": True}
        if args.browser:
            options["executable_path"] = str(args.browser)
        browser = playwright.chromium.launch(**options)
        page = browser.new_page(
            viewport={"width": WIDTH * columns, "height": 1400}, device_scale_factor=4
        )
        page.goto(page_path.as_uri())
        page.evaluate("document.fonts.ready")
        for case in cases:
            expected = {k: case[k] for k in ("original", "reference")}
            if "comparisons" in case:
                expected.update(
                    {
                        f"method-{i}": "No edit" if c["proposed"] is None else c["proposed"]
                        for i, c in enumerate(case["comparisons"])
                    }
                )
            else:
                expected["proposed"] = case["proposed"]
            for role, value in expected.items():
                loc = page.locator(f'[data-case="{case["id"]}"] [data-role="{role}"]')
                assert loc.text_content() == value
        overflow = page.locator(".value, .heading, .context, .outputs .label").evaluate_all(
            "es => es.filter(e => e.scrollWidth > e.clientWidth + 1).length"
        )
        assert overflow == 0, "Clipped comparison text"
        worksheet_style = check_worksheet_style(page)
        canvas = page.locator("#figure").bounding_box()
        page.locator("#figure").screenshot(path=str(target / "preview.png"))
        page.pdf(
            path=str(pdf),
            width=f"{WIDTH * columns}px",
            height=f"{canvas['height']}px",
            margin={"top": "0", "bottom": "0", "left": "0", "right": "0"},
            print_background=True,
        )
        browser.close()
    evidence = dict(
        config_sha256=digest(config_path),
        pdf_sha256=digest(pdf),
        examples=cases,
        canvas=canvas,
        font_size_bp=FONT_SIZE,
        table_font_size_bp=TABLE_FONT_BP,
        worksheet_style=worksheet_style,
        columns=columns,
        additional_model_calls=0,
    )
    (target / "evidence.json").write_text(json.dumps(evidence, indent=2, ensure_ascii=False) + "\n")
    print(
        json.dumps(
            dict(
                examples=len(cases),
                matching_targets=cases[0].get("matching_targets"),
                additional_model_calls=0,
            )
        )
    )


if __name__ == "__main__":
    main()
