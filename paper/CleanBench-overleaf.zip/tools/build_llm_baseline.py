"""Freeze three-task manuscript tables from the completed direct LLM studies."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import statistics
from pathlib import Path

if __package__:
    from .tex_sources import generated_asset
else:
    from tex_sources import generated_asset

from build_resource_usage import main_table_resources, resource_pair

MODELS = ["gpt-4.1", "gpt-5.2", "gpt-5.5", "gpt-6-astra"]
TASKS = [
    ("detection", "Detection only"),
    ("e2e", "End-to-end correction"),
    ("correction", "Repair only"),
]


def read(path):
    return json.loads(path.read_text())


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_counts(row, tables, targets):
    assert row.get("scope_datasets", row.get("tables")) == tables
    assert row["tp"] + row["fn"] == targets
    for key, numerator, denominator in [
        ("precision", row["tp"], row["tp"] + row["fp"]),
        ("recall", row["tp"], targets),
        ("f1", 2 * row["tp"], 2 * row["tp"] + row["fp"] + row["fn"]),
    ]:
        assert math.isclose(row[key], numerator / denominator if denominator else 0)


def load_correction(correction, harness, benchmark_hash, split):
    audit = read(correction / "RESULTS.json")
    assert audit["status"] == "completed_and_independently_audited"
    rows, sources = {}, [correction / "RESULTS.json"]
    for model in MODELS:
        summary = audit["summary"][model]
        root = harness / summary["source"]
        config = read(root / "config.json")
        result = read(root / model / "RESULTS.json")
        lock = read(root / model / "prompt_lock.json")
        assert read(root / "RESULTS.json")["status"] == "completed_and_audited"
        assert config["benchmark_sha256"] == benchmark_hash
        assert read(root / "split.json") == split
        settings = config["settings"]
        assert settings["effort"] == "none" and settings["effort_by_model"] == {
            "gpt-6-astra": "low"
        }
        assert settings["repetitions"] == settings["development_repetitions"] == 3
        assert len(config["locations"]) == 164
        assert sum(map(len, config["locations"].values())) == 1093
        assert len(config["development_scope"]) == 32
        assert sum(len(config["locations"][d]) for d in config["development_scope"]) == 210
        assert lock == result["selection"] and lock["selected"] == summary["selected_strategy"]
        candidates = read(root / "search_lock.json")["strategies"]
        means = {}
        for candidate in candidates:
            trials = [r for r in result["development"] if r["candidate"] == candidate]
            assert len(trials) == 3 and {r["repetition"] for r in trials} == {1, 2, 3}
            assert all(not r["record"]["failed_tables"] for r in trials)
            means[candidate] = statistics.mean(r["record"]["metrics"]["f1"] for r in trials)
        assert means == lock["development_means"]
        assert max(means, key=means.get) == lock["selected"]
        assert [r["repetition"] for r in result["comparisons"]] == [1, 2, 3]
        for arm in ["baseline", "selected"]:
            records = []
            for rep in result["comparisons"]:
                record = rep["arms"][arm]
                assert record["model"] == model and not record["failed_tables"]
                assert record["scope"] == sorted(config["locations"])
                candidate = "baseline" if arm == "baseline" else lock["selected"]
                assert record["strategy"] == candidates[candidate]
                folder = root / f"rep_{rep['repetition'] + 3:02d}" / record["name"]
                assert sha256(folder / "prompt.txt") == record["prompt_sha256"]
                assert sha256(folder / "predictions.jsonl") == record["predictions_sha256"]
                records.append(dict(record["metrics"], failed_tables=0))
            assert [r["f1"] for r in records] == summary[arm]["repetitions"]
            rows[model, arm] = records
        sources.extend(
            [
                root / "config.json",
                root / "search_lock.json",
                root / model / "RESULTS.json",
                root / model / "prompt_lock.json",
            ]
        )
    return rows, sources


def load_runs(run, repair, correction):
    source = run / "final_report/RESULTS.json"
    detection = read(source)
    config = read(run / "config.json")
    assert (
        detection["status"] == read(run / "audit_status.json")["status"] == "completed_and_audited"
    )
    assert detection["tables"] == 1000 and detection["development_tables"] == 200
    assert [r["repetition"] for r in detection["repetitions"]] == [1, 2, 3]
    assert config["optimizer"] == "gpt-5.5" and config["effort"] == "none"
    assert config["effort_by_model"] == {"gpt-6-astra": "low"}
    repair_scores = read(repair / "e2e_scores.json")
    derivation = read(repair / "derivation.json")
    assert Path(derivation["campaign"]).resolve() == run
    assert derivation["repair_targets"] == 1093 and derivation["repair_target_tables"] == 164
    assert repair_scores["task"] == "e2e" and len(repair_scores["results"]) == 24
    # Bind offline repairs to the same original receipts used for detection.
    harness = run.parents[2]
    for name, digest in derivation["receipt_hashes"].items():
        assert sha256(harness / name) == digest
    correction_rows, correction_sources = load_correction(
        correction, harness, config["benchmark_sha256"], read(run / "split.json")
    )
    rows = {}
    for model in MODELS:
        for arm in ["baseline", "selected"]:
            drows = [
                next(r for r in rep["comparison"] if r["name"] == f"compare_{model}_{arm}")
                for rep in detection["repetitions"]
            ]
            erows = [
                dict(
                    repair_scores["results"][f"rep_{i:02d}/{model}/{arm}"],
                    failed_tables=drows[i - 1]["failed_tables"],
                )
                for i in range(1, 4)
            ]
            crows = correction_rows[model, arm]
            for i, row in enumerate(erows, 1):
                assert row["matching"] == "exact"
                assert (
                    derivation["diagnostics"][f"rep_{i:02d}/{model}/{arm}"].get("failed_tables", 0)
                    == row["failed_tables"]
                )
            for task, data, tables, targets in [
                ("detection", drows, 1000, 1409),
                ("e2e", erows, 1000, 1093),
                ("correction", crows, 164, 1093),
            ]:
                for row in data:
                    verify_counts(row, tables, targets)
                rows[task, model, arm] = data
    sources = [
        source,
        run / "config.json",
        repair / "e2e_scores.json",
        repair / "derivation.json",
        *correction_sources,
    ]
    return (
        rows,
        config["benchmark_sha256"],
        {str(p.relative_to(harness)): sha256(p) for p in sources},
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", required=True, type=Path)
    parser.add_argument("--repair-dir", required=True, type=Path)
    parser.add_argument("--correction-dir", required=True, type=Path)
    args = parser.parse_args()
    rows, benchmark_hash, sources = load_runs(
        args.run_dir.resolve(), args.repair_dir.resolve(), args.correction_dir.resolve()
    )
    resources, resource_sha = main_table_resources()
    main_rows, appendix_rows, evidence = [], [], []
    for model in MODELS:
        for arm, label in [("baseline", "Base"), ("selected", "Prompt-tuned")]:
            resource_key = "API Base" if arm == "baseline" else "API Tuned"
            means = [
                100 * statistics.mean(r["f1"] for r in rows[task, model, arm]) for task, _ in TASKS
            ]
            main_rows.append(
                f"{model.replace('gpt', 'GPT')} & {label} & "
                + " & ".join(f"{v:.2f}" for v in means)
                + " & "
                + " & ".join(resource_pair(resources, model.replace("gpt", "GPT"), resource_key))
                + r" \\"
            )
        if model != MODELS[-1]:
            main_rows.append(r"\midrule")
    for task, task_label in TASKS:
        appendix_rows.append(rf"\multicolumn{{9}}{{l}}{{\textit{{{task_label}}}}} \\")
        for model in MODELS:
            for arm, label in [("baseline", "Base"), ("selected", "Prompt-tuned")]:
                data = rows[task, model, arm]
                means = [
                    100 * statistics.mean(r[k] for r in data) for k in ["precision", "recall", "f1"]
                ]
                f1 = [r["f1"] * 100 for r in data]
                sd = statistics.stdev(f1)
                failed = [r["failed_tables"] for r in data]
                appendix_rows.append(
                    f"{model.replace('gpt', 'GPT')} & {label} & {means[0]:.2f} & {means[1]:.2f} & "
                    + " & ".join(f"{v:.2f}" for v in f1)
                    + f" & {means[2]:.2f} $\\pm$ {sd:.2f} & "
                    + "/".join(map(str, failed))
                    + r" \\"
                )
                evidence.append(
                    {
                        "task": task,
                        "model": model,
                        "arm": arm,
                        "mean_prf_percent": means,
                        "f1_percent": f1,
                        "sample_sd_percent": sd,
                        "failed_tables": failed,
                    }
                )
        if task != TASKS[-1][0]:
            appendix_rows.append(r"\midrule")
    paper = Path(__file__).resolve().parents[1]
    for name, width, columns, header, data in [
        (
            "llm_tasks_table.tex",
            r"\linewidth",
            "llrrrrr",
            r"Model & Prompt & Det. & E2E & Rep. & Time (s) & Cost (\$) \\",
            main_rows,
        ),
        (
            "llm_repetitions_table.tex",
            r"\textwidth",
            "llrrrrrrl",
            r"Model & Prompt & Mean P & Mean R & $F_1$: Run 1 & Run 2 & Run 3 & Mean $F_1 \pm$ SD & Failed tables \\",
            appendix_rows,
        ),
    ]:
        text = [
            "% Generated by tools/build_llm_baseline.py; source hashes in build/generated/llm_baseline_evidence.json.",
            "% Source SHA-256: " + json.dumps(sources, sort_keys=True),
            rf"\begin{{tabular*}}{{{width}}}{{@{{\extracolsep{{\fill}}}}{columns}@{{}}}}",
            r"\toprule",
            header,
            r"\midrule",
            *data,
            r"\bottomrule",
            r"\end{tabular*}",
        ]
        if name == "llm_tasks_table.tex":
            text.insert(1, "% Resource evidence SHA-256: " + resource_sha)
        generated_asset(name, directory=paper / "assets/generated").write_text(
            "\n".join(text) + "\n"
        )
    target = paper / "build/generated/llm_baseline_evidence.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(
            {"source_sha256": sources, "benchmark_sha256": benchmark_hash, "rows": evidence},
            indent=2,
        )
        + "\n"
    )
    print("Validated 72 task/model/prompt results across three repetitions; wrote two tables.")


if __name__ == "__main__":
    main()
