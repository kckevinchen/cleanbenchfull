"""Render the existing ambiguous cases with the Figure 1 worksheet style."""

from __future__ import annotations

import argparse
import hashlib
import html
import json
from pathlib import Path

from build_ambiguous_options import audit as audit_options
from build_context_screenshots import column_letter, worksheet_row
from figure_style import COLUMN_WIDTH, FONT_SIZE
from playwright.sync_api import sync_playwright
from worksheet_style import TABLE_FONT_BP, check_worksheet_style, worksheet_css

PAPER = Path(__file__).resolve().parents[1]
WIDTH = 600


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit(config):
    options = json.loads((PAPER / config["options_file"]).read_text())
    views, _ = audit_options(options)
    cases = {case["id"]: case for case in options["examples"]}
    assert len(config["selected_ids"]) == 2
    assert len(set(config["selected_ids"])) == 2
    selected = [
        dict(cases[key], **config["display"][key], headers=views.load(cases[key]["dataset"])[0])
        for key in config["selected_ids"]
    ]
    # Additional display rows are context from the same hash-verified source.
    for case in selected:
        headers, source_rows = views.load(case["dataset"])
        case["rows"] = list(case["rows"])
        case["values"] = dict(case["values"])
        for row in case.get("display_rows", case["rows"]):
            if row is None:
                continue
            assert isinstance(row, int) and 0 <= row < len(source_rows)
            if row not in case["rows"]:
                case["rows"].append(row)
                case["values"][str(row)] = {
                    field: source_rows[row][headers.index(field)] for field in case["columns"]
                }
    return selected


def document(cases, panel_widths):
    assert len(panel_widths) == len(cases) and abs(sum(panel_widths) - 1) < 1e-9
    assert all(width > 0 for width in panel_widths)
    size = FONT_SIZE * WIDTH / (COLUMN_WIDTH * 72)
    font = PAPER / "build/fonts/LinLibertine_Rah.ttf"
    bold = PAPER / "build/fonts/LinLibertine_RBah.ttf"
    sections = []
    for letter, case, fraction in zip("ab", cases, panel_widths, strict=True):
        fields = case["columns"]
        assert set(case.get("clip_columns", [])) <= set(fields)
        header_labels = case.get("header_labels", {})
        assert set(header_labels) <= set(fields)
        columns = "".join(f"<th>{column_letter(case['headers'].index(f))}</th>" for f in fields)
        headers = "".join(
            f'<th title="{html.escape(f, quote=True)}">'
            f'<span class="header-label">{html.escape(header_labels.get(f, f))}</span></th>'
            for f in fields
        )
        rows = []
        marks = case.get("highlight_cells", case["marks"])
        assert all(field in fields and row in case["rows"] for row, field in marks)
        display_rows = case.get("display_rows", case["rows"])
        assert all(row is None or row in case["rows"] for row in display_rows)
        assert {row for row, _ in marks} <= set(display_rows)
        for row in display_rows:
            if row is None:
                rows.append(
                    '<tr class="omitted"><th class="coord">⋯</th>'
                    + "<td>⋯</td>" * len(fields)
                    + "</tr>"
                )
                continue
            selected = (
                "selected"
                if "highlight_cells" not in case and any(r == row for r, _ in marks)
                else ""
            )
            cells = "".join(
                f'<td class="{"cell-focus" if "highlight_cells" in case and [row, field] in marks else ""}">'
                f'<span class="{"clipped-value" if field in case.get("clip_columns", []) else ""}" '
                f'title="{html.escape(case["values"][str(row)][field], quote=True)}" '
                f'data-value="{row}:{html.escape(field)}">'
                f"{html.escape(case['values'][str(row)][field])}</span></td>"
                for field in fields
            )
            rows.append(
                f'<tr class="{selected}"><th class="coord">{worksheet_row(row)}</th>'
                f"{cells}</tr>"
            )
        widths = case["column_widths"]
        assert len(widths) == len(fields) and abs(sum(widths) - 1) < 1e-9
        cols = '<col style="width:32px">' + "".join(
            f'<col style="width:{((WIDTH - 20) * fraction - 32) * width}px">' for width in widths
        )
        interpretations = " / ".join(case["possible_interpretations"])
        interpretations_markup = (
            f'<div class="interpretations">{html.escape(interpretations)}</div>'
            if interpretations
            else ""
        )
        sections.append(f"""<section data-case="{case['id']}">
          <h2>({letter}) {case['title']}</h2>
          <div class="worksheet"><table class="source">
          <colgroup>{cols}</colgroup>
          <thead><tr class="column-letters"><th class="corner"></th>{columns}</tr>
          <tr class="field-names"><th class="coord">1</th>{headers}</tr></thead>
          <tbody>{''.join(rows)}</tbody></table></div>
          {interpretations_markup}
          </section>""")
    css = f"""
    @font-face {{font-family:Libertine;src:url('{font.as_uri()}')}}
    @font-face {{font-family:Libertine;src:url('{bold.as_uri()}');font-weight:700}}
    * {{box-sizing:border-box}} body {{margin:0;background:white;font:{size}px/1.25 Libertine}}
    #figure {{width:{WIDTH}px;padding:2px;display:grid;
      grid-template-columns:{" ".join(f"{width}fr" for width in panel_widths)};gap:16px}}
    section {{min-width:0}} h2 {{font:inherit;font-weight:700;margin:0 0 6px}}
    #figure table.source .field-names th {{height:32px}}
    #figure table.source .field-names th:not(.coord) {{padding-right:1.7em;
      white-space:nowrap}}
    #figure .header-label {{display:block;overflow:hidden;text-overflow:ellipsis;
      white-space:nowrap}}
    #figure .clipped-value {{display:block;overflow:hidden;text-overflow:ellipsis;
      white-space:nowrap}}
    #figure table.source tbody td, #figure table.source tbody th {{height:32px}}
    #figure table.source .omitted td, #figure table.source .omitted th {{height:18px;padding:0 6px}}
    .interpretations {{margin-top:6px;text-align:center;white-space:nowrap}}
    """ + worksheet_css(WIDTH)
    css += """
    #figure table.source td.cell-focus {outline:2px solid var(--sheet-selection);
      outline-offset:-1px;position:relative;z-index:1}
    """
    return (
        '<!doctype html><html lang="en"><meta charset="utf-8">'
        f'<style>{css}</style><body><main id="figure">{"".join(sections)}</main></body></html>'
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--browser", type=Path, required=True)
    args = parser.parse_args()
    config_path = PAPER / "figures/ambiguous_examples.json"
    config = json.loads(config_path.read_text())
    cases = audit(config)
    folder = PAPER / "build/ambiguous_examples"
    folder.mkdir(parents=True, exist_ok=True)
    markup = folder / "index.html"
    panel_widths = config["layout"].get("panel_widths", [0.5, 0.5])
    markup.write_text(document(cases, panel_widths))
    pdf = PAPER / "figures/paper/ambiguous_examples.pdf"
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=str(args.browser), headless=True)
        page = browser.new_page(viewport={"width": WIDTH, "height": 1000}, device_scale_factor=4)
        page.goto(markup.as_uri())
        page.evaluate("document.fonts.ready")
        page.locator("table.source tbody").evaluate_all("""bodies => {
          const height=Math.max(...bodies.map(b=>b.getBoundingClientRect().height));
          bodies.forEach(b=>b.style.height=`${height}px`);
        }""")
        for case in cases:
            for row, values in case["values"].items():
                if int(row) not in case.get("display_rows", case["rows"]):
                    continue
                for field in case["columns"]:
                    value = values[field]
                    selector = f'[data-case="{case["id"]}"] [data-value="{row}:{field}"]'
                    assert page.locator(selector).text_content() == value
            if "highlight_cells" in case:
                section = page.locator(f'[data-case="{case["id"]}"]')
                assert section.locator("tr.selected").count() == 0
                assert section.locator("td.cell-focus").count() == len(case["highlight_cells"])
                for row, field in case["highlight_cells"]:
                    cell = section.locator(f'[data-value="{row}:{field}"]').locator("..")
                    assert "cell-focus" in cell.get_attribute("class").split()
        overflow = page.locator("td,th,h2,.header-label,.interpretations").evaluate_all(
            "es => es.filter(e => e.scrollWidth > e.clientWidth+1).map(e => e.textContent)"
        )
        assert not overflow, overflow
        style = check_worksheet_style(page)
        canvas = page.locator("#figure").bounding_box()
        page.locator("#figure").screenshot(path=str(folder / "preview.png"))
        page.pdf(
            path=str(pdf),
            width=f"{WIDTH}px",
            height=f"{canvas['height']}px",
            print_background=True,
            margin=dict(top="0", bottom="0", left="0", right="0"),
        )
        browser.close()
    (folder / "evidence.json").write_text(
        json.dumps(
            dict(
                config_sha256=digest(config_path),
                pdf_sha256=digest(pdf),
                examples=cases,
                worksheet_style=style,
                table_font_size_bp=TABLE_FONT_BP,
                canvas=canvas,
                selected_ids=config["selected_ids"],
                panel_widths=panel_widths,
                additional_model_calls=0,
            ),
            indent=2,
        )
        + "\n"
    )
    print("Verified two ambiguous cases and rendered the shared worksheet style.")


if __name__ == "__main__":
    main()
