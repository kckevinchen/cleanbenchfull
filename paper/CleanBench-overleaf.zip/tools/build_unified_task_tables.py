"""Compose main task tables and an API/agent resource summary from frozen evidence.

Run after the historical, direct-LLM, agent, and resource table generators:
    venv/bin/python CleanBench/tools/build_unified_task_tables.py
No model calls or rescoring are performed.
"""

from __future__ import annotations

import hashlib
import json
import math
import statistics
from pathlib import Path

from build_resource_usage import main_table_resources
from experiment_presentation import reported_table

if __package__:
    from .tex_sources import generated_asset
else:
    from tex_sources import generated_asset

PAPER = Path(__file__).resolve().parents[1]
TASKS = ("detection", "e2e", "correction")
MODELS = ("gpt-4.1", "gpt-5.2", "gpt-5.5", "gpt-6-astra")
ARMS = (("baseline", "Base"), ("selected", "Prompt-tuned"))
AGENTS = (
    ("GPT-6-astra", "Codex"),
    ("GPT-6-astra", "Copilot"),
    ("Opus 5.5", "Claude Code"),
    ("Opus 5.5", "Copilot"),
)


def align_repair_rows(repair, detection):
    """Use the detection roster for paired tables; unsupported repair is not zero."""
    repair_rows = {line.split(" & ", 1)[0]: line for line in repair.splitlines() if " & " in line}
    lines = []
    seen = set()
    for line in detection.splitlines():
        if " & " in line:
            name = line.split(" & ", 1)[0]
            assert name not in seen
            seen.add(name)
            line = repair_rows.get(name, name + r" & -- & -- & -- \\")
        lines.append(line)
    assert set(repair_rows) <= seen
    assert seen - set(repair_rows) == {"dBoost", "FAHES", "Auto-Test", "FM data tasks"}
    return "\n".join(lines) + "\n"


def resource_columns(resources, model, interface):
    """Keep each task's time and cost in its own explicitly labeled column."""
    values = [resources[task, model, interface] for task in ["Detection/repair", "Correction"]]
    times = [f"{value['mean_seconds']:.1f}" for value in values]
    if interface.startswith("API"):
        costs = [f"{value['usd']:.2f}" for value in values]
    else:
        assert interface in {"Codex", "Copilot", "Claude Code"}
        costs = ["--", "--"]
    return " & ".join(times + costs)


def normalize_historical_task_labels(generated):
    """Adapt historical table displays without changing task keys or metrics."""
    letters = {"E": "C", "D": "D", "C": "R"}
    for name, column in (
        ("method_rows.tex", 2),
        ("method_table.tex", 2),
        ("legacy_rules_table.tex", 1),
    ):
        path = generated_asset(name, directory=generated)
        lines = path.read_text().splitlines(keepends=True)
        rows = []
        for index, line in enumerate(lines):
            parts = line.split(" & ")
            if len(parts) <= column:
                continue
            flags = parts[column].split("/")
            if all(flag in {"E", "D", "C", "R"} for flag in flags):
                rows.append((index, parts, flags))
        if not any("E" in flags for _, _, flags in rows):
            continue  # Already uses C/D/R; running this step twice is safe.
        assert not any("R" in flags for _, _, flags in rows), name
        for index, parts, flags in rows:
            parts[column] = "/".join(letters[flag] for flag in flags)
            lines[index] = " & ".join(parts)
        path.write_text("".join(lines))
    path = generated_asset("corpus_table.tex", directory=generated)
    text = path.read_text()
    path.write_text(text.replace("Eligible repair targets &", "Eligible replacement targets &"))
    path = generated_asset("broader_scope_table.tex", directory=generated)
    if path.exists():
        text = path.read_text()
        path.write_text(text.replace("Workbook prompting", "Cross-table prompting"))


def main():
    normalize_historical_task_labels(PAPER / "assets/generated")
    sources = {}

    def read(name):
        path = generated_asset(Path(name).name) if name.endswith(".tex") else PAPER / name
        sources[name] = hashlib.sha256(path.read_bytes()).hexdigest()
        return path.read_text()

    api = {}
    for row in json.loads(read("build/generated/llm_baseline_evidence.json"))["rows"]:
        key = (row["task"], row["model"], row["arm"])
        assert key not in api
        assert len(row["f1_percent"]) == 3
        assert math.isclose(row["mean_prf_percent"][2], statistics.mean(row["f1_percent"]))
        api[key] = row["mean_prf_percent"]
    assert set(api) == {(t, m, a) for t in TASKS for m in MODELS for a, _ in ARMS}

    agents = {}
    for task, name in zip(TASKS, ("", "_repair", "_correction"), strict=True):
        data = json.loads(read(f"build/generated/coding_agent{name}_evidence.json"))
        for row in data["rows"]:
            key = (task, row["model"], row["harness"])
            assert key not in agents
            m = row["metrics"]
            tp, fp, fn = (m[k] for k in ("tp", "fp", "fn"))
            assert tp + fn == (1409 if task == "detection" else 1093)
            expected = (tp / (tp + fp), tp / (tp + fn), 2 * tp / (2 * tp + fp + fn))
            assert all(
                math.isclose(m[k], v)
                for k, v in zip(("precision", "recall", "f1"), expected, strict=True)
            )
            agents[key] = [100 * m[k] for k in ("precision", "recall", "f1")]
    assert set(agents) == {(t, m, h) for t in TASKS for m, h in AGENTS}

    resources, digest = main_table_resources()
    sources["build/generated/resource_usage_evidence.json"] = digest
    output = {}
    for task in TASKS:
        rows = [r"\midrule", r"\multicolumn{4}{@{}l}{\textit{Direct LLMs}} \\"]
        for model in MODELS:
            rows.append(
                f"{model.replace('gpt', 'GPT')} & "
                + " & ".join(f"{v:.2f}" for v in api[task, model, "selected"])
                + r" \\"
            )
        rows += [r"\midrule", r"\multicolumn{4}{@{}l}{\textit{Coding agents}} \\"]
        for model, harness in AGENTS:
            rows.append(
                f"{model} ({harness}) & "
                + " & ".join(f"{v:.2f}" for v in agents[task, model, harness])
                + r" \\"
            )
        base = read(f"assets/generated/{task}_table.tex")
        if task == "e2e":
            base = align_repair_rows(base, read("assets/generated/detection_table.tex"))
        # Preserve metric rows, inserting API/agent results before the table footer.
        footer = "\\bottomrule\n\\end{tabular*}\n"
        assert base.endswith(footer) and base.count(r"\bottomrule") == 1
        output[f"all_{task}_table.tex"] = (
            base.removesuffix(footer) + "\n".join(rows) + "\n" + footer
        )

    rows = []
    for model in MODELS:
        for arm, label in ARMS:
            display = model.replace("gpt", "GPT")
            resource_key = "API Base" if arm == "baseline" else "API Tuned"
            usage = resource_columns(resources, display, resource_key)
            rows.append(
                f"{display} & API {label} & "
                + " & ".join(f"{api[t, model, arm][2]:.2f}" for t in TASKS)
                + f" & {usage}"
                + r" \\"
            )
    rows.append(r"\midrule")
    for model, harness in AGENTS:
        usage = resource_columns(resources, model, harness)
        rows.append(
            f"{model} & {harness} & "
            + " & ".join(f"{agents[t, model, harness][2]:.2f}" for t in TASKS)
            + f" & {usage}"
            + r" \\"
        )
    output["llm_resources_table.tex"] = "\n".join(
        [
            r"\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}llrrrrrrr@{}}",
            r"\toprule",
            r" & & \multicolumn{3}{c}{Final $F_1$ (\%)} & \multicolumn{2}{c}{Time (s/table)} & \multicolumn{2}{c}{Cost (USD/run)} \\",
            r"\cmidrule(lr){3-5}\cmidrule(lr){6-7}\cmidrule(l){8-9}",
            r"Model & Interface / prompt & Det. & E2E & Rep. & E2E & Rep. & E2E & Rep. \\",
            r"\midrule",
            *rows,
            r"\bottomrule",
            r"\end{tabular*}",
            "",
        ]
    )
    header = (
        "% Generated by tools/build_unified_task_tables.py from frozen evidence.\n"
        + "% Source SHA-256: "
        + json.dumps(sources, sort_keys=True)
        + "\n"
    )
    for name, content in output.items():
        generated_asset(name).write_text(header + reported_table(content))
    print("Wrote three combined P/R/F1 tables and one resource summary for reported methods.")


if __name__ == "__main__":
    main()
