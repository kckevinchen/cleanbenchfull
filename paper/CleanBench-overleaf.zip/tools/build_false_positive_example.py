"""Verify the saved numeric false positive and capture its literal table excerpt.

This reads construction records and the frozen snapshot without changing labels
or making model calls. Web verification uses a pinned official-page screenshot.
The Overleaf project uses frozen screenshots and does not need private inputs.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
from pathlib import Path

PAPER = Path(__file__).resolve().parents[1]


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def records(path: Path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def capture_table(case, rows, metadata):
    """Screenshot literal frozen CSV values in a compact spreadsheet viewer.

    This is a rendering of the CSV excerpt, not recovered workbook formatting.
    Web evidence remains a separate, unmodified screenshot of the official site.
    """
    from playwright.sync_api import sync_playwright

    screenshot = case["source_table_screenshot"]
    parts = [
        "<!doctype html><meta charset='utf-8'><style>",
        "*{box-sizing:border-box}body{margin:0;background:white}",
        "table{border-collapse:collapse;table-layout:fixed;width:448px;",
        "font:22px 'Liberation Sans',Arial,sans-serif;color:#000}",
        "th,td{height:34px;padding:0 4px;border:1px solid #44b3e1;",
        "white-space:nowrap;vertical-align:middle;text-align:left;font-weight:400}",
        ".letters th{height:30px;background:#f0f0f0;text-align:center;color:#333}",
        ".corner{background:linear-gradient(135deg,#eee 50%,#dadada 50%)}",
        ".coord{background:#f0f0f0;color:#596b77;text-align:center;padding:0}",
        ".fields th:not(.coord){background:#156082;color:white;font-weight:700;position:relative}",
        ".filter{position:absolute;right:4px;top:5px;width:22px;height:22px;background:#eee;",
        "border:1px solid #91afc0;display:flex;align-items:center;justify-content:center}",
        ".filter:after{content:'';border:5px solid transparent;border-top-color:#657780;",
        "transform:translateY(3px)}",
        ".stripe td{background:#c0e6f5}.amount{text-align:right;padding-right:12px}",
        "</style><table><colgroup><col style='width:42px'><col style='width:176px'>",
        "<col style='width:230px'></colgroup><thead>",
        "<tr class='letters'><th class='corner'></th><th>A</th><th>J</th></tr>",
        "<tr class='fields'><th class='coord'>1</th>",
        "<th>Project Number</th>",
        "<th>Approved Amount<span class='filter'></span></th></tr></thead><tbody>",
    ]
    for context in case["context"]:
        row = rows[metadata["exported_to_source"].index(context["source_row"])]
        style = "stripe" if context["worksheet_row"] % 2 == 0 else ""
        parts.append(
            f"<tr class='{style}'><th class='coord'>{context['worksheet_row']}</th>"
            f"<td data-project='{context['source_row']}'>{html.escape(row['Project Number'])}</td>"
            f"<td class='amount' data-amount='{context['source_row']}'>"
            f"{html.escape(row['Approved Amount'])}</td></tr>"
        )
    parts.append("</tbody></table>")
    document = "".join(parts)
    build = PAPER / "build/figure5_layout_20261023"
    build.mkdir(parents=True, exist_ok=True)
    (build / "source_table.html").write_text(document)
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=True)
        page = browser.new_page(viewport={"width": 448, "height": 400}, device_scale_factor=4)
        page.set_content(document)
        page.evaluate("document.fonts.ready")
        for context in case["context"]:
            row = str(context["source_row"])
            assert (
                page.locator(f"[data-project='{row}']").inner_text()
                == context["values"]["Project Number"]
            )
            assert (
                page.locator(f"[data-amount='{row}']").inner_text()
                == context["values"]["Approved Amount"]
            )
        page.locator("table").screenshot(path=str(PAPER / screenshot["file"]))
        browser.close()
    return digest(PAPER / screenshot["file"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, default=PAPER.parent)
    parser.add_argument(
        "--check", action="store_true", help="Verify all frozen inputs and screenshots"
    )
    parser.add_argument("--capture-table", action="store_true", help="Recapture the CSV excerpt")
    args = parser.parse_args()
    case = json.loads((PAPER / "figures/inconsistency_false_positive.json").read_text())
    for name, expected in case["input_sha256"].items():
        assert digest(args.data_root / name) == expected, f"Changed input: {name}"
    legacy = case["legacy_panel"]
    assert digest(PAPER / legacy["image"]) == legacy["sha256"]

    snapshot = args.data_root / case["snapshot"]
    metadata = json.loads((snapshot / "_manifest.json").read_text())["datasets"][case["dataset_id"]]
    source_row = case["source_row"]
    snapshot_row = metadata["exported_to_source"].index(source_row)
    assert snapshot_row == case["snapshot_row"]
    assert case["worksheet_row"] == source_row + 2
    with (snapshot / case["dataset_id"] / "dirty.csv").open(newline="") as handle:
        reader = csv.DictReader(handle)
        assert reader.fieldnames == metadata["columns"]
        rows = list(reader)
    column = case["column"]
    original = rows[snapshot_row][column]
    assert original == case["original_value"]
    assert metadata["columns"].index(column) == case["column_index"]
    for name, value in case["identity_context"].items():
        assert rows[snapshot_row][name] == value
    assert all(
        rows[metadata["exported_to_source"].index(r["source_row"])]["Fund Currency"] == "USD"
        for r in case["context"]
    )
    fields = case["external_verification"]["fields"]
    screenshot = case["external_verification"].get("screenshot")
    if screenshot:
        assert (
            digest(PAPER / screenshot["file"]) == screenshot["sha256"]
        ), "Changed official-page screenshot"
    assert fields["Project Number"] == case["identity_context"]["Project Number"]
    assert fields["Country"] == case["identity_context"]["Country"]
    amount = fields["Original Amount Approved"].removeprefix("USD ").replace(",", "")
    assert float(amount) == int(original)

    run = args.data_root / case["review_run"]
    history = records(run / "labels.jsonl")
    reviews = [
        (i, record)
        for i, record in enumerate(history, 1)
        if record["target_id"] == case["review_target_id"]
    ]
    line, review = reviews[-1]
    assert line == case["review_line"]
    assert review["status"] == case["review_status"] == "fp"
    assert review["source"] == case["source"]
    assert review["row"] == source_row
    assert review["column"] == column
    assert review["ts"] == case["review_timestamp"]
    assert review["corrected_value"] == case["review_suggestion"]
    assert case["proposal_accepted"] is False
    candidate = json.loads((run / "clusters.json").read_text())[case["cluster_index"]]
    assert candidate["cluster_id"] == case["review_target_id"]
    detection = next(
        d for d in candidate["detections"] if d["issue_id"] == case["detection_issue_id"]
    )
    assert detection["observed"] == original
    assert detection["corrected_value"] == case["proposed_value"] is None
    assert detection["explanation"] == case["proposal_explanation"]
    assert detection["suggested_fix"] == case["proposal_instruction"]

    reference = records(snapshot / "benchmark_cell.json")
    assert not any(
        r["source"] == case["source"] and r["row"] == source_row and r["column"] == column
        for r in reference
    ), "The illustrated cell is error- or ambiguous-labeled"
    for name in ("ignored.jsonl", "neutral_cells.jsonl"):
        assert not any(
            r["source"] == case["source"] for r in records(snapshot / name)
        ), f"Check immunity scopes in {name} before using this example"

    if args.capture_table:
        assert not args.check
        capture_table(case, rows, metadata)
    if table_screenshot := case.get("source_table_screenshot"):
        assert digest(PAPER / table_screenshot["file"]) == table_screenshot["sha256"]

    for context in case["context"]:
        row = rows[metadata["exported_to_source"].index(context["source_row"])]
        assert context["worksheet_row"] == context["source_row"] + 2
        for name in case["display_columns"]:
            assert context["values"][name] == row[name]
    print("Verified source values, saved FP, reference eligibility, and official-record amount.")


if __name__ == "__main__":
    main()
