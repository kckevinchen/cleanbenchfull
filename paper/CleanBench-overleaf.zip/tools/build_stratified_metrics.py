"""Separate correction coverage/quality from preservation using frozen counts."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path

PAPER = Path(__file__).resolve().parents[1]
GENERATED = PAPER / "assets/generated"
TYPES = ("overall", "typo-spelling", "typo-formatting", "inconsistency")
POPULATIONS = dict(zip(TYPES, (164, 106, 79, 61), strict=True))
COUNTS = (
    "tables",
    "target_tables",
    "no_target_tables",
    "predicted_tables",
    "predicted_target_tables",
    "false_alarm_tables",
    "failed_no_target_tables",
    "preserved_tables",
)
BASE_SCORES = (
    "conditional_precision",
    "target_conditional_precision",
    "target_recall",
    "coverage",
    "false_alarm_rate",
    "failed_no_target_rate",
    "preservation",
)


def harmonic(precision, recall):
    precision = precision or 0.0
    return 2 * precision * recall / (precision + recall) if precision + recall else 0.0


def finish(row):
    """Derive F1 and the equally weighted score after averaging their inputs."""
    row["target_f1"] = harmonic(row["target_conditional_precision"], row["target_recall"])
    row["balanced_score"] = (row["target_f1"] + row["preservation"]) / 2
    return row


def run_metrics(tables):
    """Treat a prediction as a completed output with at least one scored edit."""
    assert tables
    for table in tables:
        assert table["execution"] in {"complete", "failed", "unknown"}
        assert all(isinstance(table[k], int) and table[k] >= 0 for k in ("tp", "fp", "fn"))
        # The frozen scoring inputs contain no accepted partial failed outputs.
        assert table["execution"] == "complete" or table["tp"] + table["fp"] == 0
    targets = [t for t in tables if t["tp"] + t["fn"]]
    no_targets = [t for t in tables if not t["tp"] + t["fn"]]
    assert targets and no_targets
    predicted = [t for t in tables if t["execution"] == "complete" and t["tp"] + t["fp"]]
    predicted_targets = [t for t in predicted if t["tp"] + t["fn"]]
    false_alarms = [t for t in predicted if not t["tp"] + t["fn"]]
    failed = [t for t in no_targets if t["execution"] != "complete"]
    preserved = [t for t in no_targets if t["execution"] == "complete" and not t["fp"]]
    conditional = lambda rows: (
        100 * statistics.mean(t["tp"] / (t["tp"] + t["fp"]) for t in rows) if rows else None
    )
    result = {
        "tables": len(tables),
        "target_tables": len(targets),
        "no_target_tables": len(no_targets),
        "predicted_tables": len(predicted),
        "predicted_target_tables": len(predicted_targets),
        "false_alarm_tables": len(false_alarms),
        "failed_no_target_tables": len(failed),
        "preserved_tables": len(preserved),
        "conditional_precision": conditional(predicted),
        "target_conditional_precision": conditional(predicted_targets),
        "target_recall": 100
        * statistics.mean(
            t["tp"] / (t["tp"] + t["fn"]) if t["execution"] == "complete" else 0 for t in targets
        ),
        "coverage": 100 * len(predicted_targets) / len(targets),
        "false_alarm_rate": 100 * len(false_alarms) / len(no_targets),
        "failed_no_target_rate": 100 * len(failed) / len(no_targets),
        "preservation": 100 * len(preserved) / len(no_targets),
    }
    assert len(false_alarms) + len(failed) + len(preserved) == len(no_targets)
    assert math.isclose(
        result["false_alarm_rate"] + result["failed_no_target_rate"] + result["preservation"],
        100,
        abs_tol=1e-12,
    )
    return finish(result)


def summarize_runs(runs):
    result = {"runs": len(runs)}
    for field in COUNTS:
        values = [r[field] for r in runs]
        if field in ("tables", "target_tables", "no_target_tables"):
            assert len(set(values)) == 1
            result[field] = values[0]
        else:
            result[field] = statistics.mean(values)
    for field in BASE_SCORES:
        values = [r[field] for r in runs if r[field] is not None]
        result[field] = statistics.mean(values) if values else None
    result["precision_defined_runs"] = sum(r["conditional_precision"] is not None for r in runs)
    result["target_precision_defined_runs"] = sum(
        r["target_conditional_precision"] is not None for r in runs
    )
    return finish(result)


def read_csv(path):
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--validate-only", action="store_true")
    args = parser.parse_args()
    source_paths, groups, seen = [], defaultdict(list), set()
    for proof_name, kind in (
        ("macro_metrics_evidence.json", "overall"),
        ("macro_type_metrics_evidence.json", None),
    ):
        proof_path = PAPER / "build/generated" / proof_name
        proof = json.loads(proof_path.read_text())
        path = PAPER / proof["per_table_file"]
        assert hashlib.sha256(path.read_bytes()).hexdigest() == proof["per_table_sha256"]
        source_paths.extend((proof_path, path))
        for line in path.open():
            row = json.loads(line)
            key = row["method"], int(row["run"]), row["configuration"], kind or row["error_type"]
            coordinate = (*key, row["dataset"])
            assert coordinate not in seen
            seen.add(coordinate)
            groups[key].append(row)
    assert len(seen) == 148000 and len(groups) == 148
    old_path = GENERATED / "macro_type_metrics_runs.csv"
    old_summary_path = GENERATED / "macro_type_metrics.csv"
    old = {(r["method"], int(r["run"]), r["error_type"]): r for r in read_csv(old_path)}
    old_summary = {(r["method"], r["error_type"]): r for r in read_csv(old_summary_path)}
    source_paths.extend((old_path, old_summary_path))
    run_rows, by_method = [], defaultdict(list)
    for (method, repetition, configuration, kind), tables in groups.items():
        metrics = run_metrics(tables)
        assert metrics["tables"] == 1000 and metrics["target_tables"] == POPULATIONS[kind]
        source = old[method, repetition, kind]
        for new, previous in (("target_recall", "macro_recall"), ("preservation", "preservation")):
            assert math.isclose(metrics[new], float(source[previous]), abs_tol=1e-12)
        assert metrics["target_recall"] <= metrics["coverage"] + 1e-12
        assert math.isclose(
            (metrics["target_conditional_precision"] or 0) * metrics["coverage"] / 100,
            float(source["macro_precision"]),
            abs_tol=1e-12,
        )
        assert math.isclose(
            (metrics["conditional_precision"] or 0) * metrics["predicted_tables"],
            (metrics["target_conditional_precision"] or 0) * metrics["predicted_target_tables"],
            abs_tol=1e-9,
        )
        assert metrics["false_alarm_tables"] == int(source["zero_target_wrong_edit"])
        assert metrics["failed_no_target_tables"] == int(source["zero_target_failed"])
        assert metrics["preserved_tables"] == int(source["successful_zero_target"])
        identity = {key: source[key] for key in ("method", "category", "group", "error_type")}
        row = {**identity, "run": repetition, "configuration": configuration, **metrics}
        run_rows.append(row)
        by_method[method, kind].append(row)
    summary = []
    for (method, kind), runs in by_method.items():
        source = old_summary[method, kind]
        metrics = summarize_runs(runs)
        for new, previous in (("target_recall", "macro_recall"), ("preservation", "preservation")):
            assert math.isclose(metrics[new], float(source[previous]), abs_tol=1e-12)
        summary.append(
            {
                **{key: source[key] for key in ("method", "category", "group", "error_type")},
                **metrics,
            }
        )
    assert len(summary) == 92
    source_paths.append(Path(__file__).resolve())
    hashes = {
        str(p.relative_to(PAPER)): hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths
    }
    if not args.validate_only:
        write_csv(GENERATED / "stratified_metrics_runs.csv", run_rows)
        write_csv(GENERATED / "stratified_metrics.csv", summary)
        receipt = {
            "source_sha256": hashes,
            "per_table_records": len(seen),
            "run_type_rows": len(run_rows),
            "method_type_rows": len(summary),
            "units": "Percent (0-100)",
            "prediction": "A completed output with at least one scored edit; null replacements and immune/no-op edits do not qualify.",
            "precision": "Mean table precision conditional on prediction, for all tables and target tables separately. Undefined runs are excluded only from their precision averages; defined-run counts are retained.",
            "recall": "Fixed GT target-table macro recall; failed or silent target outputs receive zero.",
            "coverage": "Fraction of target tables with at least one scored edit.",
            "no_target_partition": "False alarm, failed/unknown, or completed with no scored edits. Rates sum to 100%.",
            "balanced_score": "0.5 * (H(summary target-conditional P, summary target R) + summary preservation).",
            "summary": summary,
        }
        destination = PAPER / "build/generated/stratified_metrics_evidence.json"
        destination.write_text(json.dumps(receipt, indent=2) + "\n")
    print("Validated 148,000 frozen records, 148 run/type rows, and 92 method/type summaries")


if __name__ == "__main__":
    main()
