"""Check table averaging and per-type preservation under all-error scoring."""

import pytest
from build_all_error_results import macro_scores


def row(*, tp=0, fp=0, fn=0, clean=0, execution="complete", hit=0, gt=0):
    return {
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "fp_clean": clean,
        "execution": execution,
        "types": {
            "typo-spelling": {"hit": hit, "gt": gt},
            "typo-formatting": {"hit": 0, "gt": 0},
            "inconsistency": {"hit": 0, "gt": 0},
        },
    }


def test_macro_averages_tables_and_keeps_failures():
    scores = macro_scores(
        [
            row(tp=1, fp=1, fn=1, clean=1, hit=1, gt=2),
            row(fn=2, gt=2, execution="failed"),
        ]
    )
    assert scores["precision"] == pytest.approx(50)
    assert scores["recall"] == pytest.approx(25)
    assert scores["f1"] == pytest.approx(25)
    assert scores["recall_typo-spelling"] == pytest.approx(25)
    assert scores["recall_typo-formatting"] is None


def test_zero_target_type_is_undefined_and_clean_false_edits_count_in_precision():
    scores = macro_scores([row(tp=1, fp=1, fn=0), row(clean=1, fp=1)])
    assert scores["recall_inconsistency"] is None
    assert scores["recall_typo-formatting"] is None
    assert scores["precision"] == 25
    assert scores["recall"] == 100
    assert scores["f1"] == pytest.approx(100 / 3)
