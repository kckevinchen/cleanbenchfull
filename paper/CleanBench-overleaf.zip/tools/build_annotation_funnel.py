"""Attribute construction proposals to automatic discovery or human additions.

Read frozen proposal and label histories; no inference, label changes, or
benchmark exports are performed. Publication outputs contain aggregate counts.
"""

from __future__ import annotations

import csv
import hashlib
import json
import sys
from collections import defaultdict
from pathlib import Path

if __package__:
    from .tex_sources import generated_asset
else:
    from tex_sources import generated_asset

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parent
VALID_LABELS = {"tp", "partial", "fp", "fn", "unsure"}
POOLS = ("Relational", "Spreadsheet")


def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def records(path):
    with path.open() as stream:
        for line, text in enumerate(stream, 1):
            if text.strip():
                yield line, json.loads(text)


class Coordinates:
    def __init__(self, snapshot, manifest):
        self.snapshot = snapshot
        self.meta = {m["source"]: (ds, m) for ds, m in manifest["datasets"].items()}
        self.row_maps = {
            s: {r: i for i, r in enumerate(m["exported_to_source"])}
            for s, (_, m) in self.meta.items()
        }
        self.grids = {}
        self.csv_hashes = {}

    def column(self, source, name):
        if source not in self.meta:
            return None
        columns = self.meta[source][1]["columns"]
        if name in columns:
            return name
        aliases = [c for c in columns if c.strip() == name]
        return aliases[0] if len(aliases) == 1 else None

    def frozen(self, record):
        source, row = record["source"], record["row"]
        col = self.column(source, record["column"])
        assert col is not None and 0 <= row < self.meta[source][1]["n_rows"], record
        return source, row, col

    def original(self, record):
        source = record.get("source")
        col = self.column(source, record.get("column"))
        row = self.row_maps.get(source, {}).get(record.get("row"))
        return None if col is None or row is None else (source, row, col)

    def grid(self, source):
        if source not in self.grids:
            ds, meta = self.meta[source]
            path = self.snapshot / ds / "dirty.csv"
            assert digest(path) == meta["dirty_sha256"], path
            with path.open(newline="") as stream:
                headers, *rows = list(csv.reader(stream))
            assert headers == meta["columns"] and len(rows) == meta["n_rows"]
            self.grids[source] = rows
            self.csv_hashes[str(path.relative_to(ROOT))] = meta["dirty_sha256"]
        return self.grids[source]

    def pool(self, key):
        prefix = self.meta[key[0]][1]["source_path"].split("/")[0]
        if prefix == "pbi_500":
            return "Relational"
        assert prefix == "bing21_500", prefix
        return "Spreadsheet"


def collect(config):
    for name, expected in config["source_sha256"].items():
        assert digest(ROOT / name) == expected, name
    snapshot = ROOT / config["snapshot"]
    manifest = json.loads((snapshot / "_manifest.json").read_text())
    coords = Coordinates(snapshot, manifest)
    initial = set()
    evidence = defaultdict(list)
    for line, row in records(ROOT / config["initial_candidates"]):
        key = coords.frozen(row)
        assert key not in initial
        initial.add(key)
        evidence[key].append(dict(kind="llm_discovery", line=line))

    group_proposals, auto_checks, llm_entries, human_records = set(), set(), set(), set()
    for run in config["runs"]:
        directory = ROOT / run["directory"]
        history = list(records(directory / "labels.jsonl"))
        model_groups = {
            row["target_id"] for _, row in history if "llm" in str(row.get("note") or "").lower()
        }
        for line, row in history:
            if row.get("target") != "cell":
                continue
            key = coords.original(row)
            if key is None:
                continue
            note = str(row.get("note") or "").lower()
            kind = None
            if "auto:" in note:
                # Exclusion bookkeeping does not discover a new candidate.
                if "exclusion" not in note:
                    auto_checks.add(key)
                    kind = "automated_check"
            elif "llm" in note:
                llm_entries.add(key)
                kind = "llm_entry"
            elif row.get("status") in {"fn", "tp", "partial", "unsure"}:
                human_records.add(key)
            if kind:
                evidence[key].append(dict(kind=kind, run=run["directory"], label_line=line))

        if not run.get("saved_groups"):
            continue
        for line, row in records(ROOT / run["saved_groups"]):
            source, raw_col = row.get("source"), row.get("column")
            col = coords.column(source, raw_col)
            if col is None:
                continue
            ci = coords.meta[source][1]["columns"].index(col)
            for group in row.get("clusters") or []:
                target = f"colclust\x00{source}\x00{raw_col}\x00{group['cluster_id']}"
                if target not in model_groups:
                    continue
                values = {
                    v.get("value") if isinstance(v, dict) else v for v in group.get("values") or []
                }
                for row_index, record in enumerate(coords.grid(source)):
                    if record[ci].strip() in values:
                        key = source, row_index, col
                        group_proposals.add(key)
                        evidence[key].append(
                            dict(kind="llm_group_edit", run=run["directory"], group_line=line)
                        )

    automatic = initial | group_proposals | auto_checks | llm_entries
    labeled = {
        coords.frozen(row)
        for _, row in records(ROOT / config["recorded_labels"])
        if any(e["status"] in VALID_LABELS for e in row["provenance"])
    }
    truth = {
        coords.frozen(row): row["status"] for _, row in records(snapshot / "benchmark_cell.json")
    }
    errors = {k for k, value in truth.items() if value == "error"}
    ambiguous = {k for k, value in truth.items() if value == "ambiguous"}
    human_only = (errors & human_records) - automatic
    assert not errors - automatic - human_only, "Unattributed final errors"
    assert not ambiguous - automatic - human_records, "Unattributed ambiguous entries"
    assert labeled <= automatic | human_records

    # Check header/row alignment against the scoring engine's integer identities.
    sys.path.insert(0, str(ROOT))
    from src.evaluation.paper_evaluation.analysis import GroundTruth

    scored_truth = GroundTruth(snapshot, manifest)

    def scoring_keys(keys):
        return {
            (coords.meta[s][0], row, coords.meta[s][1]["columns"].index(col))
            for s, row, col in keys
        }

    assert scoring_keys(errors) == scored_truth.errors
    assert scoring_keys(ambiguous) == scored_truth.ambiguous
    sets = dict(
        source_entries=None,
        initial_candidates=initial,
        llm_group_additions=group_proposals - initial,
        automated_check_additions=auto_checks - initial - group_proposals,
        automatic_candidates=automatic,
        labeled_candidates=labeled & automatic,
        human_only_errors=human_only,
        final_errors=errors,
        final_ambiguous=ambiguous,
    )
    counts = {}
    for name, keys in sets.items():
        if keys is None:
            by_pool = {
                pool: sum(
                    m["n_rows"] * m["n_cols"]
                    for source, (_, m) in coords.meta.items()
                    if coords.pool((source, 0, "")) == pool
                )
                for pool in POOLS
            }
        else:
            by_pool = {pool: sum(coords.pool(k) == pool for k in keys) for pool in POOLS}
        counts[name] = dict(by_pool, total=sum(by_pool.values()))
    candidate_sources = {source for source, _, _ in automatic}
    tables_by_pool = {
        pool: sum(coords.pool((source, 0, "")) == pool for source in candidate_sources)
        for pool in POOLS
    }
    counts["candidate_tables"] = dict(tables_by_pool, total=sum(tables_by_pool.values()))
    for name, expected in config["expected"].items():
        assert counts[name]["total"] == expected, (name, counts[name], expected)
    assert counts["source_entries"]["total"] == 364804
    return counts, evidence, coords.csv_hashes, sets


def write_outputs(counts, config_sha):
    out = PAPER / "assets/generated"
    lines = [
        "% Generated by tools/build_annotation_funnel.py; frozen inputs are hash-verified.",
        r"\begin{tabular}{lrrr}",
        r"\toprule",
        r"Statistic & \multicolumn{1}{p{.18\linewidth}}{\raggedleft\relationaldata{}} & "
        r"\multicolumn{1}{p{.18\linewidth}}{\raggedleft\spreadsheetdata{}} & Total \\",
        r"\midrule",
    ]
    for label, key in [
        ("Source cells", "source_entries"),
        ("Candidate cells", "automatic_candidates"),
        ("Final error locations", "final_errors"),
        ("Final ambiguous cells", "final_ambiguous"),
    ]:
        row = counts[key]
        lines.append(label + " & " + " & ".join(f"{row[p]:,}" for p in (*POOLS, "total")) + r" \\")
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    (generated_asset("annotation_funnel_table.tex", directory=out)).write_text(
        "\n".join(lines) + "\n"
    )
    ratio = 100 * counts["automatic_candidates"]["total"] / counts["source_entries"]["total"]
    macros = {
        "CBDiscoveryCandidates": f"{counts['automatic_candidates']['total']:,}",
        "CBDiscoveryPercent": f"{ratio:.2f}",
        "CBLabeledCandidates": f"{counts['labeled_candidates']['total']:,}",
        "CBHumanOnlyErrors": str(counts["human_only_errors"]["total"]),
    }
    (generated_asset("annotation_funnel_numbers.tex", directory=out)).write_text(
        "% Generated by tools/build_annotation_funnel.py.\n"
        + "".join(f"\\newcommand{{\\{name}}}{{{value}}}\n" for name, value in macros.items())
    )
    (out / "annotation_funnel_counts.json").write_text(
        json.dumps(dict(config_sha256=config_sha, counts=counts), indent=2) + "\n"
    )


def main():
    path = PAPER / "figures/annotation_funnel.json"
    config = json.loads(path.read_text())
    counts, evidence, csv_hashes, sets = collect(config)
    write_outputs(counts, digest(path))
    target = PAPER / "build/generated/discovery_origins"
    target.mkdir(parents=True, exist_ok=True)
    with (target / "automatic_candidates.jsonl").open("w") as stream:
        for key in sorted(sets["automatic_candidates"]):
            stream.write(
                json.dumps(dict(source=key[0], row=key[1], column=key[2], provenance=evidence[key]))
                + "\n"
            )
    (target / "validation.json").write_text(
        json.dumps(
            dict(
                counts=counts,
                source_csv_hashes=csv_hashes,
                scoring_coordinates_verified=True,
                all_final_errors_attributed=True,
                additional_model_calls=0,
            ),
            indent=2,
        )
        + "\n"
    )
    print(json.dumps(counts, indent=2))


if __name__ == "__main__":
    main()
