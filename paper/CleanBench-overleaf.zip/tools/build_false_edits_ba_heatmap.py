"""Show false positives, balanced accuracy, and repair results for all workflows."""

from __future__ import annotations

import csv
import hashlib
import json
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from build_accuracy_presentation import CMAP, NORM, positions
from build_macro_heatmap import category_label, read_csv
from figure_style import FIGURE_WIDTH, configure, save
from matplotlib.cm import ScalarMappable
from matplotlib.patches import Rectangle

if __package__:
    from .tex_sources import generated_asset
else:
    from tex_sources import generated_asset

PAPER = Path(__file__).resolve().parents[1]
GENERATED = PAPER / "assets/generated"
SOURCE = GENERATED / "false_edits_ba_metrics.csv"
ROSTER = GENERATED / "task_type_metrics.csv"
REPAIR = generated_asset("all_correction_table.tex", directory=GENERATED)
TARGET = GENERATED / "false_edits_ba_heatmap.pdf"
BLOCKS = (
    (
        "End-to-end correction",
        (
            ("correction_recall", "R ↑", "n=1,093"),
            ("fp_per_100_clean_cells", "FP/100 ↓", "clean cells"),
            ("clean_kept", "No edit ↑", "clean cells"),
        ),
    ),
    (
        "Balanced accuracy",
        (
            ("table_tpr", "TPR ↑", "n=164"),
            ("table_tnr", "TNR ↑", "n=836"),
            ("table_balanced_accuracy", "BA ↑", "mean"),
        ),
    ),
    (
        "Repair",
        (
            ("repair_precision", "P ↑", "edits > 0"),
            ("repair_recall", "R ↑", "n=1,093"),
        ),
    ),
    ("Runs", (("completion", "Success ↑", "n=1,000"),)),
)
UNSUPPORTED_REPAIR = {"KATARA (KB)", "LLUNATIC", "UniClean", "Excel", "Google Sheets"}


def reported_repairs(text):
    """Read reported P/R without changing their precision or evaluation scope."""
    result = {}
    for line in text.splitlines():
        parts = line.strip().removesuffix(r" \\").split(" & ")
        if len(parts) != 4 or parts[0] == "Method":
            continue
        try:
            values = [float(value) for value in parts[1:]]
        except ValueError:
            continue
        assert parts[0] not in result
        assert all(math.isfinite(value) and 0 <= value <= 100 for value in values)
        result[parts[0]] = values[:2]
    return result


def extend(row, repair):
    """Add complements and class rates without modifying any existing metric."""
    p = float(row["table_tp"]) + float(row["table_fn"])
    n = float(row["table_tn"]) + float(row["table_fp"])
    assert math.isclose(p, 164) and math.isclose(n, 836)
    fpr = float(row["fp_per_100_clean_cells"])
    tpr, tnr = 100 * float(row["table_tp"]) / p, 100 * float(row["table_tn"]) / n
    assert 0 <= fpr <= 100
    assert math.isclose((tpr + tnr) / 2, float(row["table_balanced_accuracy"]), abs_tol=1e-10)
    return {
        **row,
        "clean_kept": 100 - fpr,
        "table_tpr": tpr,
        "table_tnr": tnr,
        "repair_precision": repair[0] if repair is not None else None,
        "repair_recall": repair[1] if repair is not None else None,
    }


def inputs():
    roster = [
        r for r in read_csv(ROSTER) if r["task"] == "e2e" and not r["method"].endswith(" (Base)")
    ]
    assert len(roster) == 23
    source = {r["method"]: r for r in read_csv(SOURCE)}
    assert source.keys() == {r["method"] for r in roster} | {"Keep original"}
    repair = reported_repairs(REPAIR.read_text())
    missing = {
        r["method"] for r in roster if r["method"].removesuffix(" (Prompt-tuned)") not in repair
    }
    assert missing == UNSUPPORTED_REPAIR
    rows = [extend(source["Keep original"], [0.0, 0.0])]
    for row in roster:
        method = row["method"]
        rows.append(extend(source[method], repair.get(method.removesuffix(" (Prompt-tuned)"))))
    assert rows[0]["clean_kept"] == rows[0]["table_tnr"] == 100
    assert float(rows[0]["correction_recall"]) == rows[0]["table_tpr"] == 0
    return roster, rows


def draw(roster, rows):
    indexed = {r["method"]: r for r in rows}
    methods, categories, extent = positions(roster)
    shift = 1.4
    methods = [(y + shift, row) for y, row in methods]
    categories = [(y + shift, label) for y, label in categories]
    extent += shift
    grid_height = extent * 0.125
    height = grid_height + 0.86
    fig = plt.figure(figsize=(FIGURE_WIDTH, height))
    left, width, top = 0.29, 0.70, 1 - 0.53 / height
    ax = fig.add_axes([left, top - grid_height / height, width, grid_height / height])
    starts, end = [], 0.0
    for _, columns in BLOCKS:
        starts.append(end)
        end += len(columns) + 0.16
    xmax = end - 0.16
    label_x = (0.01 - left) / width * xmax
    label_pad = 0.04 / (width * FIGURE_WIDTH) * xmax
    ink = "#253342"
    ax.set_xlim(0, xmax)
    ax.set_ylim(extent, 0)
    ax.axis("off")
    for y, thickness in ((-3.35, 0.8), (-0.05, 0.6), (extent, 0.8)):
        ax.plot([label_x, xmax], [y, y], color=ink, linewidth=thickness, clip_on=False)
    for start, (label, columns) in zip(starts, BLOCKS, strict=True):
        ax.text(
            start + len(columns) / 2,
            -2.75,
            label,
            ha="center",
            va="center",
            weight="bold",
            color=ink,
        )
        ax.plot(
            [start + 0.05, start + len(columns) - 0.05],
            [-1.20, -1.20],
            color="#a8b2bd",
            linewidth=0.45,
            clip_on=False,
        )
        for i, (_, name, population) in enumerate(columns):
            ax.text(start + i + 0.5, -1.72, population, ha="center", va="center", color=ink)
            ax.text(start + i + 0.5, -0.66, name, ha="center", va="center", color=ink)
    ax.text(label_x + label_pad, -0.66, "Method", ha="left", va="center", weight="bold", color=ink)
    for y, label in categories:
        ax.add_patch(
            Rectangle(
                (label_x, y - 0.4),
                xmax - label_x,
                0.8,
                facecolor="#edf1f5",
                edgecolor="none",
                clip_on=False,
            )
        )
        ax.text(
            label_x + label_pad,
            y,
            category_label(label),
            ha="left",
            va="center",
            weight="bold",
            color=ink,
        )
    displayed = []
    for y, item in [(0.5, {"method": "Keep original"}), *methods]:
        method = item["method"]
        row = indexed[method]
        ax.text(
            label_x + label_pad, y, method.removesuffix(" (Prompt-tuned)"), ha="left", va="center"
        )
        ax.plot(
            [label_x, xmax], [y + 0.5, y + 0.5], color="#e4e9ee", lw=0.3, clip_on=False, zorder=0
        )
        for start, (_, columns) in zip(starts, BLOCKS, strict=True):
            for i, (key, _, _) in enumerate(columns):
                value = row[key]
                value = float(value) if value is not None else None
                assert value is None or math.isfinite(value) and 0 <= value <= 100
                neutral = key == "fp_per_100_clean_cells"
                color = "#f5f6f8" if value is None else "white" if neutral else CMAP(NORM(value))
                text = (
                    "—"
                    if value is None
                    else format(
                        value, ".4f" if neutral else ".3f" if key == "clean_kept" else ".2f"
                    )
                )
                ax.add_patch(
                    Rectangle(
                        (start + i, y - 0.5),
                        1,
                        1,
                        facecolor=color,
                        edgecolor="white",
                        linewidth=0.45,
                    )
                )
                ax.text(
                    start + i + 0.5,
                    y,
                    text,
                    ha="center",
                    va="center",
                    color="white" if value is not None and value >= 80 and not neutral else "black",
                )
                displayed.append(
                    {
                        "method": method,
                        "metric": key,
                        "value": value,
                        "text": text,
                        "shaded": not neutral,
                    }
                )
    color_ax = fig.add_axes([0.75, 0.22 / height, 0.22, 0.065 / height])
    bar = fig.colorbar(ScalarMappable(norm=NORM, cmap=CMAP), cax=color_ax, orientation="horizontal")
    bar.solids.set_rasterized(False)
    bar.solids.set_edgecolor("face")
    bar.set_ticks([0, 50, 100])
    bar.ax.tick_params(length=2, pad=2)
    bar.ax.text(-0.10, 0.5, "Percentage (%)", ha="right", va="center", transform=bar.ax.transAxes)
    bar.outline.set_linewidth(0.4)
    save(fig, TARGET, check_layout=True)
    plt.close(fig)
    return displayed, height


def main():
    roster, rows = inputs()
    target = GENERATED / "false_edits_ba_full_metrics.csv"
    with target.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    configure()
    displayed, height = draw(roster, rows)
    assert len(displayed) == 24 * 9
    proof = {
        "source_sha256": {
            str(p.relative_to(PAPER)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (SOURCE, ROSTER, REPAIR, Path(__file__))
        },
        "workflows": 23,
        "reference_rows": 1,
        "table_cells": len(displayed),
        "numeric_cells": sum(item["value"] is not None for item in displayed),
        "unsupported_cells": sum(item["value"] is None for item in displayed),
        "width_inches": FIGURE_WIDTH,
        "height_inches": height,
        "font_size_bp": 8,
        "model_calls": 0,
        "displayed_values": displayed,
        "clean_kept": "Exactly 100 minus FP per 100 clean cells; the same clean-cell behavior in percentage units, not an independent accuracy gain.",
        "table_rates": "TPR and TNR use the unchanged target/no-target table cohorts; BA is unchanged and equals their mean.",
        "repair": "Already-reported micro P/R from the separate known-location repair task; unsupported methods remain missing.",
        "color": "The common 0–100 blue scale applies to percentage columns only. FP/100 is unshaded and lower is better.",
    }
    (PAPER / "build/generated/false_edits_ba_heatmap_evidence.json").write_text(
        json.dumps(proof, indent=2) + "\n"
    )
    print("Rendered 23 workflows plus the unchanged-input reference with nine diagnostic columns.")


if __name__ == "__main__":
    main()
