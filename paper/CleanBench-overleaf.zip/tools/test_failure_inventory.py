"""Avoid treating numeric changes as mere display differences during review."""

from decimal import Decimal

from build_failure_inventory import numeric, reference_surface_match, transform


def test_decimal_comparison_keeps_all_digits():
    assert numeric("1.1234567890123456789012345678901") != numeric(
        "1.1234567890123456789012345678902"
    )
    assert numeric("12.50%") == Decimal("0.1250")
    assert numeric("1,234.00") == Decimal("1234")
    assert numeric("1,23") is None


def test_surface_match_does_not_hide_numeric_change():
    assert not reference_surface_match("-12", ["12"])
    assert not reference_surface_match("1.2", ["12"])
    assert reference_surface_match("Content Writing", ["Content writing"])
    assert not reference_surface_match("Nadine Jolly Courtney", ["Nadine Jolie Courtney"])
    assert not reference_surface_match(None, ["value"])


def test_change_patterns_preserve_content_and_type_distinctions():
    assert transform("K- K", "") == "blanked_value"
    assert transform("", "missing") == "filled_blank"
    assert transform("0", "0.0") == "numeric_representation"
    assert transform("00123", "123") == "numeric_representation"
    assert transform("-2", "2") == "numeric_value_change"
    assert (
        transform("2019-11-05 00:00:00.000", "2019-11-05 00:00:00")
        == "iso_date_time_representation"
    )
    assert transform("2020-13-01", "2020-12-01") == "content_change"
    assert transform("3/4/2020", "2020-03-04") == "content_change"  # No guessed locale.
    assert transform("OTHER ACCOMODATION", "RETAIL / WHOLESALE") == "content_change"
