"""Reflow benchmark statistics from frozen aggregates without changing their values."""

from __future__ import annotations

import csv
import hashlib
import json
from collections import Counter
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from figure_style import COLUMN_WIDTH, FIGURE_WIDTH, SOURCE_COLORS, configure, save
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.ticker import MaxNLocator

PAPER = Path(__file__).resolve().parents[1]
GENERATED = PAPER / "assets/generated"
SOURCES = ("Relational", "Spreadsheet")
ERROR_TYPES = ("Spelling", "Formatting", "Inconsistency")
COLUMN_TYPES = ("Numeric", "Categorical", "Date/time", "Text", "ID/Other")
COLUMN_LABELS = ("Numeric", "Categorical", "Date/time", "Long text", "Other")
FONT_SIZE = 7.5
OVERVIEW_HEIGHT = 1.60
ERROR_STATISTICS_HEIGHT = 1.95
ERROR_COUNT_COLORS = ("#e3e7eb", "#7d9d91", "#c2a66f", "#829bb3", "#9b8ca9")


def read(name):
    with (GENERATED / name).open(newline="") as stream:
        return list(csv.DictReader(stream))


def source_legend(fig, *, anchor, markers=False):
    handles = [
        Line2D(
            [],
            [],
            color=SOURCE_COLORS[source],
            marker=marker if markers else None,
            linestyle="none" if markers else "-",
            linewidth=3,
            markersize=3,
        )
        for source, marker in zip(SOURCES, ("o", "s"), strict=True)
    ]
    fig.legend(
        handles,
        SOURCES,
        loc="upper center",
        bbox_to_anchor=anchor,
        ncol=2,
        frameon=False,
        handlelength=1.4,
        handletextpad=0.4,
        columnspacing=1.0,
    )


def table_error_counts(concentration, dimensions):
    """Include clean tables, which do not appear in the error-ranked CDF."""
    groups = {}
    for source in SOURCES:
        group = sorted(
            (r for r in concentration if r["source"] == source), key=lambda r: int(r["rank"])
        )
        population = {
            metric: sum(
                int(r["tables"])
                for r in dimensions
                if r["source"] == source and r["dimension"] == metric
            )
            for metric in ("rows", "columns")
        }
        assert population["rows"] == population["columns"] >= len(group) > 0
        errors = [int(r["errors"]) for r in group]
        shares = [float(r["cumulative_share"]) for r in group]
        assert min(errors) > 0 and errors == sorted(errors, reverse=True)
        assert [int(r["rank"]) for r in group] == list(range(1, len(group) + 1))
        assert sum(errors) == int(group[-1]["total_errors"])
        assert np.allclose(shares, 100 * np.cumsum(errors) / sum(errors))
        counts = Counter(errors)
        counts[0] = population["rows"] - len(group)
        groups[source] = [
            ("0 errors", counts[0]),
            ("1 error", counts[1]),
            ("2 errors", counts[2]),
            ("3–5 errors", sum(n for errors, n in counts.items() if 3 <= errors <= 5)),
            ("≥6 errors", sum(n for errors, n in counts.items() if errors >= 6)),
        ]
        assert sum(n for _, n in groups[source]) == population["rows"]
    return groups


def draw_overview(concentration, dimensions):
    groups = table_error_counts(concentration, dimensions)
    fig = plt.figure(figsize=(COLUMN_WIDTH, OVERVIEW_HEIGHT))
    for index, source in enumerate(SOURCES):
        values = [n for _, n in groups[source]]
        # Keep the original pie size and top offsets while shortening the canvas.
        ax = fig.add_axes(
            [
                0.01 + index * 0.50,
                (OVERVIEW_HEIGHT - 1.3875) / OVERVIEW_HEIGHT,
                0.48,
                1.036 / OVERVIEW_HEIGHT,
            ]
        )
        wedges, _ = ax.pie(
            values,
            colors=ERROR_COUNT_COLORS,
            startangle=90,
            counterclock=False,
            wedgeprops=dict(edgecolor="white", linewidth=0.5),
        )
        assert np.allclose(
            [w.theta2 - w.theta1 for w in wedges], 360 * np.array(values) / sum(values)
        )
        for i, (wedge, value) in enumerate(zip(wedges, values, strict=True)):
            angle = np.deg2rad((wedge.theta1 + wedge.theta2) / 2)
            x, y = np.cos(angle), np.sin(angle)
            if i == 0:
                ax.text(0.50 * x, 0.50 * y, f"{value}\ntables", ha="center", va="center")
            else:
                ax.annotate(
                    str(value),
                    xy=(0.94 * x, 0.94 * y),
                    xytext=(-1.30, 0.20 + (i - 1) * 0.35),
                    ha="right",
                    va="center",
                    arrowprops=dict(
                        arrowstyle="-|>",
                        color="#6a7887",
                        linewidth=0.55,
                        mutation_scale=5,
                        shrinkA=2,
                        shrinkB=0,
                    ),
                )
        ax.set_xlim(-1.65, 1.15)
        ax.set_ylim(-1.12, 1.45)
        ax.set_axis_off()
        fig.text(
            0.25 + index * 0.50,
            1 - 0.259 / OVERVIEW_HEIGHT,
            f"{source} ({sum(values)} tables)",
            ha="center",
            va="bottom",
            weight="bold",
        )
    fig.text(
        0.5,
        1 - 0.0185 / OVERVIEW_HEIGHT,
        "(a) Number of errors per table",
        ha="center",
        va="top",
        weight="bold",
    )
    fig.legend(
        handles=[
            Patch(facecolor=color, label=label)
            for (label, _), color in zip(groups[SOURCES[0]], ERROR_COUNT_COLORS, strict=True)
        ],
        loc="lower center",
        bbox_to_anchor=(0.5, 2 / (72 * OVERVIEW_HEIGHT)),
        ncol=5,
        frameon=False,
        handlelength=0.8,
        handletextpad=0.3,
        columnspacing=0.6,
        borderpad=0,
        borderaxespad=0,
    )
    save(
        fig,
        PAPER / "figures/paper/benchmark_overview_compact.pdf",
        width=COLUMN_WIDTH,
        font_size=FONT_SIZE,
        check_layout=True,
    )
    plt.close(fig)
    return groups


def draw_error_statistics(counts, prevalence):
    fig = plt.figure(figsize=(FIGURE_WIDTH, ERROR_STATISTICS_HEIGHT))
    maximum = max(int(r["errors"]) for r in counts)
    for panel, source, bottom in zip("ab", SOURCES, (0.73, 0.33), strict=True):
        ax = fig.add_axes([0.122, bottom, 0.37, 0.17])
        column_counts = []
        for kind in COLUMN_TYPES:
            totals = {
                int(row["columns"])
                for row in counts
                if (row["source"], row["column_type"]) == (source, kind)
            }
            assert len(totals) == 1
            column_counts.append(totals.pop())
        values = np.array(
            [
                [
                    next(
                        int(r["errors"])
                        for r in counts
                        if (r["source"], r["error_type"], r["column_type"]) == (source, error, kind)
                    )
                    for kind in COLUMN_TYPES
                ]
                for error in ERROR_TYPES
            ]
        )
        image = ax.imshow(values, cmap="Blues", vmin=0, vmax=maximum, aspect="auto")
        assert np.array_equal(image.get_array(), values)
        for (y, x), value in np.ndenumerate(values):
            ax.text(
                x,
                y,
                str(value),
                ha="center",
                va="center",
                color="white" if value > maximum * 0.6 else "#263442",
            )
        ax.set_yticks(range(3), ERROR_TYPES)
        ax.set_xticks(
            range(5),
            [f"{label}\n(n={n:,})" for label, n in zip(COLUMN_LABELS, column_counts, strict=True)],
        )
        ax.set_xticks(np.arange(-0.5, 5, 1), minor=True)
        ax.set_yticks(np.arange(-0.5, 3, 1), minor=True)
        ax.grid(which="minor", color="white", linewidth=0.7)
        ax.tick_params(which="both", length=0, pad=3)
        ax.set_title(f"({panel}) {source}", loc="left", pad=3)
        ax.spines[:].set_visible(False)
    color_ax = fig.add_axes([0.27, 0.11, 0.22, 0.025])
    bar = fig.colorbar(image, cax=color_ax, orientation="horizontal", ticks=[0, 100, 200, maximum])
    bar.outline.set_visible(False)
    bar.ax.tick_params(length=2, pad=2)
    fig.text(0.122, 0.1225, "Errors", ha="left", va="center")
    fig.text(0.122, 0.01, "n = columns", ha="left", va="bottom")

    source_legend(fig, anchor=(0.77, 1.015), markers=True)
    for panel, key, left, title in zip(
        "cd", "ab", (0.565, 0.80), ("Errors/table", "Errors/1,000"), strict=True
    ):
        ax = fig.add_axes([left, 0.31, 0.18, 0.42])
        buckets = list(dict.fromkeys(r["bucket"] for r in prevalence if r["panel"] == key))
        for index, (source, marker) in enumerate(zip(SOURCES, ("o", "s"), strict=True)):
            group = [
                next(
                    r
                    for r in prevalence
                    if (r["panel"], r["source"], r["bucket"]) == (key, source, b)
                )
                for b in buckets
            ]
            values, lo, hi = (
                np.array([float(r[k]) for r in group]) for k in ("estimate", "lower", "upper")
            )
            positions = np.arange(len(group)) + (index - 0.5) * 0.25
            color = SOURCE_COLORS[source]
            lines = ax.vlines(positions, lo, hi, color=color, lw=0.8)
            ax.hlines(lo, positions - 0.055, positions + 0.055, color=color, lw=0.7)
            ax.hlines(hi, positions - 0.055, positions + 0.055, color=color, lw=0.7)
            points = ax.scatter(
                positions, values, s=8, linewidths=0.4, color=color, marker=marker, zorder=3
            )
            assert np.array_equal(points.get_offsets()[:, 1], values)
            assert np.array_equal(
                [segment[:, 1] for segment in lines.get_segments()], np.column_stack((lo, hi))
            )
        ax.set_title(f"({panel}) {title}", loc="left", pad=5)
        ax.set_xticks(range(3), ["<200", "200–\n499", "≥500"])
        ax.set_xlim(-0.5, 2.5)
        ax.set_ylim(bottom=0)
        ax.set_xlabel("Cells per table", labelpad=3)
        ax.set_ylabel("Mean errors" if key == "a" else "Errors / 1,000", labelpad=3)
        ax.yaxis.set_major_locator(MaxNLocator(3))
        ax.tick_params(length=2, pad=2)
        ax.grid(axis="y")
        ax.set_axisbelow(True)
    save(
        fig,
        PAPER / "figures/paper/benchmark_error_statistics.pdf",
        width=FIGURE_WIDTH,
        font_size=FONT_SIZE,
        check_layout=True,
    )
    plt.close(fig)


def main():
    names = (
        "table_dimensions.csv",
        "error_concentration_cdf.csv",
        "error_column_types.csv",
        "error_prevalence.csv",
    )
    hashes = {name: hashlib.sha256((GENERATED / name).read_bytes()).hexdigest() for name in names}
    configure(font_size=FONT_SIZE)
    table_error_groups = draw_overview(read(names[1]), read(names[0]))
    draw_error_statistics(read(names[2]), read(names[3]))
    assert hashes == {
        name: hashlib.sha256((GENERATED / name).read_bytes()).hexdigest() for name in names
    }
    folder = PAPER / "build/statistics_layout"
    folder.mkdir(exist_ok=True, parents=True)
    (folder / "evidence.json").write_text(
        json.dumps(
            {
                "input_sha256": hashes,
                "font_size_bp": FONT_SIZE,
                "overview_inches": [COLUMN_WIDTH, OVERVIEW_HEIGHT],
                "table_error_groups": table_error_groups,
                "error_statistics_inches": [FIGURE_WIDTH, ERROR_STATISTICS_HEIGHT],
                "data_unchanged": True,
                "confidence_intervals_unchanged": True,
            },
            indent=2,
        )
        + "\n"
    )
    print(
        "Reflowed benchmark statistics; all counts, CDF points, estimates and intervals match frozen CSVs."
    )


if __name__ == "__main__":
    main()
