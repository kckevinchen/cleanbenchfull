"""Render blue review copies of updated full-version result tables."""

import csv
from pathlib import Path

from build_constraint_score_analysis import METHODS
from build_diagnostic_task_tables import draw as macro
from build_e2e_variance_table import draw as micro

PAPER = Path(__file__).resolve().parents[1]


def main():
    with (
        PAPER / "assets/generated/e2e_table_variability_all_errors.csv"
    ).open() as stream:
        rows = list(csv.DictReader(stream))
    for row in rows:
        for key, value in list(row.items()):
            if key in {"task", "category", "method"}:
                continue
            if key in {"constraint_selection", "variance_requested"}:
                row[key] = value.lower() == "true"
            elif key == "repetitions":
                row[key] = int(value)
            else:
                try:
                    row[key] = float(value) if value else None
                except ValueError:
                    pass
    micro(
        rows,
        output=PAPER / "figures/paper/e2e_type_all_errors_review.pdf",
        review_methods=set(METHODS.values()),
    )
    with (PAPER / "assets/generated/e2e_macro_all_errors.csv").open() as stream:
        rows = list(csv.DictReader(stream))
    macro(
        rows,
        "macro_e2e",
        overall_label="Overall macro (%)",
        output=PAPER / "figures/paper/macro_e2e_all_errors_review.pdf",
        review_methods={r["method"] for r in rows},
    )


if __name__ == "__main__":
    main()
