import pytest
from build_diagnostic_task_tables import macro_rows
from build_e2e_variance_table import METRICS, aggregate, read
from repetition_inputs import replacement_groups


def trials():
    return [
        dict(
            method="SymSpell",
            run=index,
            identity=f"fresh-{index}",
            tables=1000,
            targets=1093,
            settings={"mode": "default"},
            metrics=dict.fromkeys(METRICS, value),
            macro_metrics={key: value for key in METRICS if key != "fpr"},
        )
        for index, value in enumerate((10, 20, 30), 1)
    ]


def test_micro_and_macro_use_same_fresh_three_trials_without_adding_historical_run():
    fresh = trials()
    micro = aggregate(
        read("task_type_metrics.csv"),
        read("macro_type_metrics_runs.csv"),
        read("false_edits_ba_runs.csv"),
        replacement_runs=fresh,
    )
    macro = macro_rows(
        read("task_type_metrics.csv"),
        read("macro_metrics.csv"),
        read("empty_match_type_metrics.csv"),
        replacement_runs=fresh,
    )
    row = next(row for row in micro if row["method"] == "SymSpell")
    assert row["repetitions"] == 3 and row["f1"] == 20 and row["sd_f1"] == 10
    row = next(row for row in macro if row["method"] == "SymSpell")
    assert row["repetitions"] == 3 and row["f1"] == 20


def test_partial_fresh_baseline_cannot_be_filled_by_one_old_run():
    with pytest.raises(ValueError, match="three independent"):
        replacement_groups(trials()[:2], {"SymSpell"})
    fresh = trials()
    fresh[0]["tables"] = 999
    with pytest.raises(ValueError, match="Partial"):
        replacement_groups(fresh, {"SymSpell"})
