"""Check the alternate empty-match convention and its population weighting."""

import statistics

import pytest
from build_empty_match_metrics import combine, empty_match_table_scores


def table(tp=0, fp=0, fn=0, execution="complete"):
    return {"tp": tp, "fp": fp, "fn": fn, "execution": execution}


def test_empty_match_gets_all_three_credits_but_false_alarm_gets_none():
    assert empty_match_table_scores(table()) == {"precision": 1, "recall": 1, "f1": 1}
    assert empty_match_table_scores(table(fp=1)) == {"precision": 0, "recall": 0, "f1": 0}


@pytest.mark.parametrize("status", ["failed", "unknown"])
@pytest.mark.parametrize("counts", [{}, {"fn": 2}, {"tp": 1, "fn": 1}])
def test_failures_do_not_get_credit_even_for_empty_or_partial_outputs(status, counts):
    assert empty_match_table_scores(table(**counts, execution=status)) == {
        "precision": 0,
        "recall": 0,
        "f1": 0,
    }


def test_target_empty_output_loses_all_metrics_and_wrong_repair_retains_miss():
    for counts in ({"fn": 1}, {"fp": 1, "fn": 1}):
        assert empty_match_table_scores(table(**counts)) == {"precision": 0, "recall": 0, "f1": 0}


def test_completed_target_table_uses_individual_ratios():
    scores = empty_match_table_scores(table(tp=2, fp=1, fn=2))
    assert scores["precision"] == pytest.approx(2 / 3)
    assert scores["recall"] == 0.5
    assert scores["f1"] == pytest.approx(4 / 7)


def test_weighted_cohorts_equal_direct_all_table_mean_for_every_metric():
    target = empty_match_table_scores(table(tp=1, fp=1, fn=2))
    zero = [
        empty_match_table_scores(row) for row in (table(), table(fp=2), table(execution="failed"))
    ]
    for metric in ("precision", "recall", "f1"):
        direct = 100 * statistics.mean([target[metric], *(row[metric] for row in zero)])
        weighted = combine(100 * target[metric], 100 / 3, 1, 3)
        assert weighted == pytest.approx(direct)


def test_empty_population_edges_and_keep_original_reference():
    assert combine(None, 75, 0, 4) == 75
    assert combine(25, None, 4, 0) == 25
    assert combine(0, 100, 164, 836) == 83.6
    with pytest.raises(AssertionError):
        combine(None, None, 0, 0)
