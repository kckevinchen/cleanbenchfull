"""Check the FP/FN decomposition and the method-selection rule."""

import hashlib
import json
import statistics

import build_failure_comparison as comparison
import pytest
from build_failure_comparison import aggregate, published_outcomes, select, write_outcomes


def row(**updates):
    return dict(
        method="method",
        category="Constraint-based",
        correct=4,
        unchanged_completed=2,
        unchanged_failed=3,
        unchanged_unknown=0,
        wrong_value=1,
        clean_edits=9,
        **updates,
    )


def test_wrong_replacement_counts_in_fp_and_fn_with_failures_retained():
    result = aggregate([row()])[0]
    assert result["targets"] == 10
    assert result["fn"] == 6
    assert result["fp"] == 10
    assert result["micro_f1"] == pytest.approx(100 / 3)


def test_repeated_runs_average_f1_before_ranking():
    a = row()
    b = dict(a, correct=2, unchanged_completed=4, clean_edits=1)
    combined = aggregate([a, b])[0]
    expected = (aggregate([a])[0]["micro_f1"] + aggregate([b])[0]["micro_f1"]) / 2
    assert combined["runs"] == 2
    assert combined["micro_f1"] == pytest.approx(expected)
    pooled = 200 * combined["correct"] / (2 * combined["correct"] + combined["fp"] + combined["fn"])
    assert combined["micro_f1"] != pytest.approx(pooled)


def test_select_compares_every_llm_group_and_uses_f1():
    rows = [
        dict(method="c-low", category="Constraint-based", micro_f1=1),
        dict(method="c-best", category="Constraint-based", micro_f1=2),
        dict(method="direct", category="Direct LLMs", micro_f1=20),
        dict(method="agent", category="Coding agents", micro_f1=30),
        dict(method="workflow", category="LLM workflows", micro_f1=40),
        dict(method="other", category="Industrial workflows", micro_f1=90),
    ]
    assert [r["method"] for r in select(rows)] == ["c-best", "workflow"]


@pytest.fixture
def published_bundle(tmp_path):
    datasets = [f"d{i:04d}" for i in range(1000)]
    files, runs, scores = {}, [], []

    def save(name, value):
        path = tmp_path / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(value)
        files[name] = hashlib.sha256(path.read_bytes()).hexdigest()

    save(
        "reference.json",
        json.dumps(
            {
                "tables": dict.fromkeys(datasets, {}),
                "population": {"targets": 1093, "clean_cells": 100000},
            }
        ),
    )
    for repetition, (tp, fp, clean) in enumerate(((10, 15, 12), (20, 20, 18), (0, 0, 0)), 1):
        rows = [
            dict(dataset=ds, tp=0, fp=0, fn=0, fp_clean=0, execution="complete") for ds in datasets
        ]
        rows[0].update(
            tp=tp,
            fp=fp,
            fn=1093 - tp,
            fp_clean=clean,
            execution="failed" if repetition == 3 else "complete",
        )
        name = f"run_{repetition}/counts.jsonl"
        save(name, "".join(json.dumps(r) + "\n" for r in rows))
        runs.append(dict(method="BigDansing", run=repetition, point_view=True, counts=name))
        scores.append(200 * tp / (2 * tp + fp + 1093 - tp))
    save(
        "expected/table3_point.csv",
        "method,repetitions,f1\nBigDansing,3," + str(statistics.mean(scores)) + "\n",
    )
    manifest = {"runs": runs, "sha256": files}
    (tmp_path / "manifest.json").write_text(json.dumps(manifest))
    return tmp_path, manifest, scores


def test_published_outcomes_include_failed_and_clean_tables_and_average_run_scores(
    published_bundle,
):
    root, _, scores = published_bundle
    result = published_outcomes(root, methods=("BigDansing",))[0]
    assert result["repetitions"] == 3
    assert result["correct"] == 10
    assert result["clean_edits"] == 10
    assert result["wrong_repairs"] == pytest.approx(5 / 3)
    assert result["unchanged"] == pytest.approx((1080 + 1071 + 1093) / 3)
    assert result["f1"] == pytest.approx(statistics.mean(scores))
    assert result["correct"] + result["unchanged"] + result["wrong_repairs"] == pytest.approx(1093)


def test_published_outcomes_reject_wrong_cohort_and_changed_counts(published_bundle):
    root, manifest, _ = published_bundle
    original = json.dumps(manifest)
    manifest["runs"].pop()
    (root / "manifest.json").write_text(json.dumps(manifest))
    with pytest.raises(ValueError, match="cohorts differ"):
        published_outcomes(root, methods=("BigDansing",))
    (root / "manifest.json").write_text(original)
    path = root / "run_1/counts.jsonl"
    path.write_text(path.read_text() + "\n")
    with pytest.raises(ValueError, match="checksum"):
        published_outcomes(root, methods=("BigDansing",))


def test_published_outcomes_reject_excluded_clean_tables(published_bundle):
    root, manifest, _ = published_bundle
    name = "run_1/counts.jsonl"
    path = root / name
    path.write_text("\n".join(path.read_text().splitlines()[:-1]) + "\n")
    manifest["sha256"][name] = hashlib.sha256(path.read_bytes()).hexdigest()
    (root / "manifest.json").write_text(json.dumps(manifest))
    with pytest.raises(ValueError, match="exclude benchmark tables"):
        published_outcomes(root, methods=("BigDansing",))


def test_cached_outcomes_cannot_redraw_against_a_new_table3_cohort(published_bundle, monkeypatch):
    root, _, _ = published_bundle
    rows = published_outcomes(root, methods=("BigDansing",))
    point = (root / "expected/table3_point.csv").read_text().replace(",3,", ",1,")
    (root / "e2e_table_point.csv").write_text(point)
    monkeypatch.setattr(comparison, "ASSETS", root)
    with pytest.raises(ValueError, match="same published Table 3 bundle"):
        write_outcomes(rows)
