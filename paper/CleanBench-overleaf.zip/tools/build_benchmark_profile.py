"""Build full-version distribution exhibits from frozen tables and error labels.

Refresh aggregate CSVs with --refresh; the default redraws committed aggregates.
No model calls, benchmark edits, or changes to experimental scores.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator

if __package__:
    from .tex_sources import generated_asset
else:
    from tex_sources import generated_asset

if __package__:
    from .build_error_prevalence import SOURCES, TYPES, collect, write_rows
    from .build_family_distribution import counts as family_counts
    from .build_family_distribution import draw as draw_families
    from .figure_style import (
        COLUMN_WIDTH,
        FIGURE_WIDTH,
        SOURCE_COLORS,
        configure,
        paired_pies,
        save,
    )
    from .paper_taxonomy import DISPLAY_TYPES, project_sets
else:
    from build_error_prevalence import SOURCES, TYPES, collect, write_rows
    from build_family_distribution import counts as family_counts
    from build_family_distribution import draw as draw_families
    from figure_style import COLUMN_WIDTH, FIGURE_WIDTH, SOURCE_COLORS, configure, paired_pies, save
    from paper_taxonomy import DISPLAY_TYPES, project_sets

PAPER = Path(__file__).resolve().parents[1]
GENERATED = PAPER / "assets/generated"
SNAPSHOT = PAPER.parent / "outputs/baseline_campaign/20260910/snapshot"
SELECTED = PAPER.parent / "outputs/paper_evaluation/20260920/selected_results.json"
CONFIG = PAPER / "figures/benchmark_profile_config.json"


def read_rows(name):
    with (generated_asset(name, directory=GENERATED)).open(newline="") as stream:
        return list(csv.DictReader(stream))


def joint_types(columns, fine):
    """Count each coordinate once per paper type within its whole-column profile."""
    projected = project_sets(fine)
    counts = {kind: Counter((ds, j) for ds, _, j in cells) for kind, cells in projected.items()}
    rows = []
    for source, label in SOURCES.items():
        for kind in TYPES:
            group = [c for c in columns if c["source"] == source and c["column_type"] == kind]
            denominator = sum(c["scorable"] for c in group)
            assert denominator > 0
            for key, display in DISPLAY_TYPES:
                errors = sum(counts[key][c["dataset"], c["column"]] for c in group)
                rows.append(
                    dict(
                        source=label,
                        column_type=kind,
                        columns=len(group),
                        error_type=display,
                        errors=errors,
                        scorable_cells=denominator,
                        errors_per_1000=1000 * errors / denominator,
                    )
                )
    assert sum(r["errors"] for r in rows) == sum(len(s) for s in projected.values())
    return rows


def dimensions(tables, config):
    rows = []
    for source, label in SOURCES.items():
        group = [t for t in tables if t["source"] == source]
        for metric, bins in (("rows", config["row_bins"]), ("columns", config["column_bins"])):
            for lo, hi in bins:
                n = sum(lo <= t[metric] <= hi for t in group)
                rows.append(dict(source=label, dimension=metric, lower=lo, upper=hi, tables=n))
            assert sum(
                r["tables"] for r in rows if r["source"] == label and r["dimension"] == metric
            ) == len(group)
    return rows


def concentration(tables):
    rows = []
    for source, label in SOURCES.items():
        counts = sorted(
            (t["labeled_errors"] for t in tables if t["source"] == source), reverse=True
        )
        total = sum(counts)
        assert len(counts) == 500
        for name, errors in (
            ("Top ten tables", sum(counts[:10])),
            ("Other tables", sum(counts[10:])),
        ):
            rows.append(dict(source=label, group=name, errors=errors, share=100 * errors / total))
    return rows


def corpus_table(tables, truth):
    funnel = json.loads((GENERATED / "annotation_funnel_counts.json").read_text())["counts"]
    candidates = funnel["automatic_candidates"]
    candidate_tables = funnel["candidate_tables"]
    assert sum(candidates[source] for source in SOURCES.values()) == candidates["total"]
    assert sum(candidate_tables[source] for source in SOURCES.values()) == candidate_tables["total"]
    groups = [[t for t in tables if t["source"] == source] for source in SOURCES]
    ambiguous = [
        sum(truth.tables[c[0]]["source"] == source for c in truth.ambiguous) for source in SOURCES
    ]
    stats = [
        ("Tables", [len(g) for g in groups]),
        ("Data rows", [sum(t["rows"] for t in g) for g in groups]),
        ("Cells", [sum(t["cells"] for t in g) for g in groups]),
        (
            "Candidate tables flagged for review",
            [candidate_tables[source] for source in SOURCES.values()],
        ),
        ("Proposed candidate cells", [candidates[source] for source in SOURCES.values()]),
        ("Labeled errors", [sum(t["labeled_errors"] for t in g) for g in groups]),
        ("Ambiguous cells", ambiguous),
    ]
    lines = [
        r"\begin{tabular}{lrrr}",
        r"\toprule",
        r"Statistic & Relational & Spreadsheet & Total \\",
        r"\midrule",
    ]
    for name, values in stats:
        lines.append(name + " & " + " & ".join(f"{v:,}" for v in [*values, sum(values)]) + r" \\")
    errors = dict(stats)["Labeled errors"]
    cells = [sum(t["detection_scorable"] for t in g) for g in groups]
    values = [
        1000 * e / n for e, n in zip([*errors, sum(errors)], [*cells, sum(cells)], strict=True)
    ]
    lines.extend(
        [
            "Errors / 1,000 cells & " + " & ".join(f"{v:.2f}" for v in values) + r" \\",
            r"\bottomrule",
            r"\end{tabular}",
        ]
    )
    (generated_asset("corpus_table_full.tex", directory=GENERATED)).write_text(
        "\n".join(lines) + "\n"
    )


def refresh():
    config = json.loads((PAPER / "figures/error_prevalence_config.json").read_text())
    tables, columns, hashes = collect(SNAPSHOT, SELECTED, config)
    sys.path.insert(0, str(PAPER.parent))
    from src.evaluation.paper_evaluation.analysis import GroundTruth

    truth = GroundTruth(SNAPSHOT, json.loads((SNAPSHOT / "_manifest.json").read_text()))
    joint = joint_types(columns, truth.fine)
    assert sum(r["errors"] for r in joint) == 1503
    write_rows(GENERATED / "error_column_types.csv", joint)
    write_rows(
        GENERATED / "table_dimensions.csv", dimensions(tables, json.loads(CONFIG.read_text()))
    )
    write_rows(GENERATED / "error_concentration.csv", concentration(tables))
    corpus_table(tables, truth)
    evidence = {
        "source_sha256": hashes,
        "config_sha256": hashlib.sha256(CONFIG.read_bytes()).hexdigest(),
        "column_profile_config_sha256": hashlib.sha256(
            (PAPER / "figures/error_prevalence_config.json").read_bytes()
        ).hexdigest(),
        "builder_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "type_projection_sha256": hashlib.sha256(
            (PAPER / "tools/paper_taxonomy.py").read_bytes()
        ).hexdigest(),
        "tables": len(tables),
        "columns": len(columns),
        "errors": len(truth.errors),
        "scorable_cells": sum(t["detection_scorable"] for t in tables),
        "type_counts": {label: len(project_sets(truth.fine)[key]) for key, label in DISPLAY_TYPES},
        "joint_counts": joint,
        "columns_private": columns,
        "model_calls": 0,
    }
    path = PAPER / "build/generated/benchmark_profile.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(evidence, indent=2) + "\n")


def validate_aggregates():
    """Tie every displayed partition to the existing published source totals."""
    joint = read_rows("error_column_types.csv")
    prevalence = read_rows("error_prevalence.csv")
    for old in family_counts():
        selected = [
            r for r in joint if r["source"] == old["source"] and r["error_type"] == old["family"]
        ]
        assert sum(int(r["errors"]) for r in selected) == old["memberships"]
    for old in (r for r in prevalence if r["panel"] == "d"):
        group = [
            r for r in joint if r["source"] == old["source"] and r["column_type"] == old["bucket"]
        ]
        assert len(group) == 3
        assert all(int(r["scorable_cells"]) == int(old["scorable_cells"]) for r in group)
        assert all(
            np.isclose(
                float(r["errors_per_1000"]), 1000 * int(r["errors"]) / int(r["scorable_cells"])
            )
            for r in group
        )
    for source in SOURCES.values():
        for metric in ("rows", "columns"):
            assert (
                sum(
                    int(r["tables"])
                    for r in read_rows("table_dimensions.csv")
                    if r["source"] == source and r["dimension"] == metric
                )
                == 500
            )
        group = [r for r in read_rows("error_concentration.csv") if r["source"] == source]
        errors = next(r["distinct_error_cells"] for r in family_counts() if r["source"] == source)
        assert sum(int(r["errors"]) for r in group) == errors
        assert all(np.isclose(float(r["share"]), 100 * int(r["errors"]) / errors) for r in group)


def funnel_table():
    counts = json.loads((GENERATED / "annotation_funnel_counts.json").read_text())["counts"]
    lines = [
        r"\begin{tabular}{lrrr}",
        r"\toprule",
        r"Statistic & \multicolumn{1}{p{.18\linewidth}}{\raggedleft\relationaldata{}} & "
        r"\multicolumn{1}{p{.18\linewidth}}{\raggedleft\spreadsheetdata{}} & Total \\",
        r"\midrule",
    ]
    for label, key in [
        ("Source cells", "source_entries"),
        ("Candidate cells", "automatic_candidates"),
        ("Final error cells", "final_errors"),
        ("Final ambiguous cells", "final_ambiguous"),
    ]:
        row = counts[key]
        assert row["Relational"] + row["Spreadsheet"] == row["total"]
        lines.append(
            label + " & " + " & ".join(f"{row[p]:,}" for p in (*SOURCES.values(), "total")) + r" \\"
        )
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    (generated_asset("annotation_funnel_full_table.tex", directory=GENERATED)).write_text(
        "\n".join(lines) + "\n"
    )


def draw_concentration(rows):
    fig = plt.figure(figsize=(COLUMN_WIDTH, 1.44))
    groups = [
        [int(r["errors"]) for r in rows if r["source"] == source] for source in SOURCES.values()
    ]
    paired_pies(
        fig,
        groups,
        sources=tuple(SOURCES.values()),
        categories=("Top ten tables", "Other tables"),
        colors=("#486a89", "#dce3eb"),
        text_colors=("white", "black"),
        title="Error concentration (%)",
    )
    save(fig, GENERATED / "error_concentration.pdf", width=COLUMN_WIDTH, check_layout=True)
    plt.close(fig)


def draw_dimensions(rows):
    fig, axes = plt.subplots(2, 1, figsize=(COLUMN_WIDTH, 2.9))
    for ax, metric, title in zip(
        axes, ("rows", "columns"), ("(a) Rows per table", "(b) Columns per table"), strict=True
    ):
        for i, source in enumerate(SOURCES.values()):
            group = [r for r in rows if r["source"] == source and r["dimension"] == metric]
            x = np.arange(len(group)) + (i - 0.5) * 0.34
            ax.bar(
                x,
                [int(r["tables"]) for r in group],
                width=0.32,
                color=SOURCE_COLORS[source],
                label=source,
            )
        ax.set_xticks(range(len(group)), [f"{r['lower']}–{r['upper']}" for r in group])
        ax.set_ylabel("Tables")
        ax.set_title(title, loc="left", pad=7)
        ax.yaxis.set_major_locator(MaxNLocator(3, integer=True))
        ax.set_ylim(bottom=0)
        ax.set_axisbelow(True)
        ax.grid(axis="y")
    fig.legend(*axes[0].get_legend_handles_labels(), loc="upper center", ncol=2, frameon=False)
    fig.subplots_adjust(left=0.18, right=0.98, bottom=0.09, top=0.80, hspace=0.85)
    save(fig, GENERATED / "table_dimensions.pdf", width=COLUMN_WIDTH, check_layout=True)
    plt.close(fig)


def draw_joint(rows):
    fig = plt.figure(figsize=(COLUMN_WIDTH, 3.2))
    vmax = max(float(r["errors_per_1000"]) for r in rows)
    for i, source in enumerate(SOURCES.values()):
        ax = fig.add_axes([0.265, 0.72 - i * 0.32, 0.71, 0.19])
        values = np.array(
            [
                [
                    next(
                        float(r["errors_per_1000"])
                        for r in rows
                        if r["source"] == source
                        and r["error_type"] == label
                        and r["column_type"] == kind
                    )
                    for kind in TYPES
                ]
                for _, label in DISPLAY_TYPES
            ]
        )
        image = ax.imshow(values, cmap="Blues", vmin=0, vmax=vmax, aspect="auto")
        for y in range(3):
            for x in range(5):
                ax.text(
                    x,
                    y,
                    f"{values[y,x]:.2f}",
                    ha="center",
                    va="center",
                    color="white" if values[y, x] > vmax * 0.6 else "black",
                )
        ax.set_yticks(range(3), [label for _, label in DISPLAY_TYPES])
        if i == 0:
            ax.set_xticks([])
        else:
            ax.set_xticks(range(5), TYPES, rotation=60, ha="right")
        ax.tick_params(axis="both", length=0, pad=4)
        ax.set_title(source, loc="left", pad=8)
        ax.spines[:].set_visible(False)
    color_ax = fig.add_axes([0.36, 0.075, 0.57, 0.025])
    bar = fig.colorbar(image, cax=color_ax, orientation="horizontal")
    bar.outline.set_linewidth(0.4)
    bar.ax.xaxis.set_major_locator(MaxNLocator(3))
    fig.text(0.64, 0.155, "Errors / 1,000 cells", ha="center", va="center")
    save(fig, GENERATED / "error_column_types.pdf", width=COLUMN_WIDTH, check_layout=True)
    plt.close(fig)


def joint_count_panels(fig, rows, *, left=0, width=1, panel_letters="ab"):
    """Place source heatmaps in a column-wide region without scaling their fonts."""
    vmax = max(int(r["errors"]) for r in rows)
    for i, source in enumerate(SOURCES.values()):
        ax = fig.add_axes([left + width * 0.275, 0.685 - i * 0.315, width * 0.71, 0.23])
        values = np.array(
            [
                [
                    next(
                        int(r["errors"])
                        for r in rows
                        if (r["source"], r["error_type"], r["column_type"]) == (source, label, kind)
                    )
                    for kind in TYPES
                ]
                for _, label in DISPLAY_TYPES
            ]
        )
        image = ax.imshow(values, cmap="Blues", vmin=0, vmax=vmax, aspect="auto")
        for (y, x), value in np.ndenumerate(values):
            ax.text(
                x,
                y,
                str(value),
                ha="center",
                va="center",
                color="white" if value > vmax * 0.6 else "#263442",
            )
        ax.set_yticks(range(3), [label for _, label in DISPLAY_TYPES])
        ax.set_xticks(range(5) if i else [])
        if i:
            ax.set_xticklabels(
                ["Numeric", "Categorical", "Date/time", "Text", "Other"],
                rotation=50,
                ha="right",
                rotation_mode="anchor",
            )
        ax.set_xticks(np.arange(-0.5, 5, 1), minor=True)
        ax.set_yticks(np.arange(-0.5, 3, 1), minor=True)
        ax.grid(which="minor", color="white", linewidth=1)
        ax.tick_params(axis="both", which="both", length=0, pad=4)
        ax.set_title(f"({panel_letters[i]}) {source}", loc="left", pad=7)
        ax.spines[:].set_visible(False)
    color_ax = fig.add_axes([left + width * 0.43, 0.105, width * 0.50, 0.025])
    bar = fig.colorbar(image, cax=color_ax, orientation="horizontal", ticks=[0, 100, 200, vmax])
    bar.outline.set_visible(False)
    fig.text(left + width * 0.275, 0.1175, "Errors", ha="left", va="center")


def draw_joint_counts(rows):
    """Retain the standalone count heatmap as a reproducible asset."""
    fig = plt.figure(figsize=(COLUMN_WIDTH, 2.65))
    joint_count_panels(fig, rows)
    save(fig, GENERATED / "error_column_counts.pdf", width=COLUMN_WIDTH, check_layout=True)
    plt.close(fig)


def draw_statistics(size_rows, error_rows):
    """Combine table dimensions and error counts from unchanged frozen aggregates."""
    fig = plt.figure(figsize=(FIGURE_WIDTH, 2.65))
    axes = []
    for i, metric in enumerate(("rows", "columns")):
        ax = fig.add_axes([0.065, 0.665 - i * 0.40, 0.37, 0.25])
        axes.append(ax)
        for j, source in enumerate(SOURCES.values()):
            group = [r for r in size_rows if r["source"] == source and r["dimension"] == metric]
            assert len(group) == 4
            counts = [int(r["tables"]) for r in group]
            assert sum(counts) == 500
            ax.bar(
                np.arange(4) + (j - 0.5) * 0.34,
                counts,
                width=0.32,
                color=SOURCE_COLORS[source],
                label=source,
            )
        ax.set_xticks(range(4), [f"{r['lower']}–{r['upper']}" for r in group])
        ax.set_ylim(0, 320)
        ax.set_yticks([0, 150, 300])
        ax.set_ylabel("Tables")
        ax.set_title(f"({'ab'[i]}) {metric.capitalize()} per table", loc="left", pad=7)
        ax.set_axisbelow(True)
        ax.grid(axis="y")
    fig.legend(
        *axes[0].get_legend_handles_labels(),
        loc="lower center",
        bbox_to_anchor=(0.25, 0.08),
        ncol=2,
        frameon=False,
    )
    width = COLUMN_WIDTH / FIGURE_WIDTH
    joint_count_panels(fig, error_rows, left=1 - width, width=width, panel_letters="cd")
    save(fig, GENERATED / "benchmark_statistics.pdf", width=FIGURE_WIDTH, check_layout=True)
    plt.close(fig)


def draw_prevalence(rows):
    fig = plt.figure(figsize=(COLUMN_WIDTH, 2.95))
    grid = fig.add_gridspec(
        2,
        2,
        left=0.21,
        right=0.97,
        bottom=0.18,
        top=0.81,
        wspace=0.95,
        hspace=1.4,
        height_ratios=[1, 1.4],
    )
    axes = [fig.add_subplot(grid[0, 0]), fig.add_subplot(grid[0, 1]), fig.add_subplot(grid[1, :])]
    for panel, ax, title in zip(
        "abd", axes, ("(a) Errors/table", "(b) Errors/1,000", "(c) Column type"), strict=True
    ):
        horizontal = panel == "d"
        buckets = list(dict.fromkeys(r["bucket"] for r in rows if r["panel"] == panel))
        for i, (source, marker) in enumerate(zip(SOURCES.values(), ("o", "s"), strict=True)):
            group = [
                next(
                    r
                    for r in rows
                    if r["panel"] == panel and r["source"] == source and r["bucket"] == b
                )
                for b in buckets
            ]
            positions = np.arange(len(group)) + (i - 0.5) * 0.25
            values, lo, hi = (
                np.array([float(r[k]) for r in group]) for k in ("estimate", "lower", "upper")
            )
            color = SOURCE_COLORS[source]
            if horizontal:
                ax.hlines(positions, lo, hi, color=color, lw=1.5)
                ax.vlines(lo, positions - 0.055, positions + 0.055, color=color, lw=1.1)
                ax.vlines(hi, positions - 0.055, positions + 0.055, color=color, lw=1.1)
                ax.scatter(
                    values, positions, s=26, color=color, marker=marker, zorder=3, clip_on=False
                )
            else:
                ax.vlines(positions, lo, hi, color=color, lw=1.5)
                ax.hlines(lo, positions - 0.055, positions + 0.055, color=color, lw=1.1)
                ax.hlines(hi, positions - 0.055, positions + 0.055, color=color, lw=1.1)
                ax.scatter(positions, values, s=26, color=color, marker=marker, zorder=3)
            ax.set_title(title, loc="left", pad=7)
        ax.set_axisbelow(True)
        ax.grid(axis="x" if horizontal else "y")
        if horizontal:
            ax.set_yticks(range(5), TYPES)
            ax.set_ylim(4.5, -0.5)
            ax.set_xlim(left=0)
            ax.set_xlabel("Errors / 1,000 cells", labelpad=4)
            ax.tick_params(axis="y", length=0, pad=5)
            ax.spines["left"].set_visible(False)
            ax.xaxis.set_major_locator(MaxNLocator(4))
        else:
            ax.set_xticks(range(3), ["<200", "200–\n499", "≥500"])
            ax.set_xlim(-0.5, 2.5)
            ax.set_ylim(bottom=0)
            ax.set_xlabel("Cells per table", labelpad=3)
            ax.set_ylabel("Mean errors" if panel == "a" else "Errors / 1,000")
            ax.yaxis.set_major_locator(MaxNLocator(3))
    handles = [
        Line2D([], [], color=SOURCE_COLORS[s], marker=m, linestyle="none", markersize=5)
        for s, m in zip(SOURCES.values(), ("o", "s"), strict=True)
    ]
    fig.legend(
        handles,
        list(SOURCES.values()),
        loc="upper center",
        bbox_to_anchor=(0.53, 1),
        ncol=2,
        frameon=False,
        handletextpad=0.4,
    )
    save(fig, GENERATED / "error_prevalence_full.pdf", width=COLUMN_WIDTH, check_layout=True)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--refresh",
        action="store_true",
        help="Verify private frozen inputs and reconstruct aggregate CSVs",
    )
    args = parser.parse_args()
    if args.refresh:
        refresh()
    validate_aggregates()
    funnel_table()
    configure()
    draw_concentration(read_rows("error_concentration.csv"))
    draw_dimensions(read_rows("table_dimensions.csv"))
    draw_joint(read_rows("error_column_types.csv"))
    draw_joint_counts(read_rows("error_column_types.csv"))
    draw_statistics(read_rows("table_dimensions.csv"), read_rows("error_column_types.csv"))
    draw_prevalence(read_rows("error_prevalence.csv"))
    draw_families(
        family_counts(), target=GENERATED / "family_distribution_full.pdf", cell_labels=True
    )
    print("Rendered benchmark profile exhibits from frozen aggregates; no model calls.")


if __name__ == "__main__":
    main()
