"""Render failure comparisons and Table 3 outcome counts from saved runs.

Uses frozen run counts, preserves their FP/FN partition, and makes no model calls.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path

from figure_style import COLUMN_WIDTH, configure, save

PAPER = Path(__file__).resolve().parents[1]
ASSETS = PAPER / "assets/generated"
LLM_CATEGORIES = {"LLM workflows", "Direct LLMs", "Coding agents"}
COUNTS = (
    "correct",
    "unchanged_completed",
    "unchanged_failed",
    "unchanged_unknown",
    "wrong_value",
    "clean_edits",
)
OUTCOME_METHODS = {
    "BigDansing": "BigDansing",
    "NADEEF": "NADEEF",
    "GPT-6-astra (Prompt-tuned)": "GPT-6-Astra",
    "GPT-6-astra (Codex)": "GPT-6-Astra (Codex CLI)",
    "GPT-6-astra (Copilot)": "GPT-6-Astra (Copilot CLI)",
}


def published_outcomes(root, methods=tuple(OUTCOME_METHODS)):
    """Use the same complete run cohorts as the published Table 3 point view."""
    root = root.resolve()
    manifest = json.loads((root / "manifest.json").read_text())

    def data(name):
        path = (root / name).resolve()
        if not path.is_relative_to(root):
            raise ValueError("Outcome input is outside its artifact bundle")
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != manifest["sha256"][name]:
            raise ValueError("Outcome artifact checksum mismatch")
        return raw.decode()

    reference = json.loads(data("reference.json"))
    target_count = reference["population"]["targets"]
    if len(reference["tables"]) != 1000 or target_count <= 0:
        raise ValueError("Outcome table requires the full Table 3 population")
    expected = {
        r["method"]: r for r in csv.DictReader(data("expected/table3_point.csv").splitlines())
    }
    rows = []
    for method in methods:
        runs = [r for r in manifest["runs"] if r["method"] == method and r["point_view"]]
        if len(runs) != int(expected[method]["repetitions"]) or len(
            {r["run"] for r in runs}
        ) != len(runs):
            raise ValueError("Outcome table and Table 3 run cohorts differ")
        totals = []
        for run in runs:
            counts = [json.loads(line) for line in data(run["counts"]).splitlines() if line.strip()]
            if len(counts) != 1000 or {r["dataset"] for r in counts} != set(reference["tables"]):
                raise ValueError("Outcome counts exclude benchmark tables")
            tp, fp, fn, clean = (sum(r[k] for r in counts) for k in ("tp", "fp", "fn", "fp_clean"))
            wrong = fp - clean
            if tp + fn != target_count or not 0 <= wrong <= fn:
                raise ValueError("Invalid FP/FN outcome partition")
            totals.append(
                dict(
                    correct=tp,
                    clean_edits=clean,
                    unchanged=fn - wrong,
                    wrong_repairs=wrong,
                    f1=200 * tp / (2 * tp + fp + fn),
                )
            )
        means = {key: statistics.mean(r[key] for r in totals) for key in totals[0]}
        if not math.isclose(means["f1"], float(expected[method]["f1"]), abs_tol=1e-10):
            raise ValueError("Outcome scores differ from Table 3")
        rows.append(dict(method=method, repetitions=len(runs), **means))
    return rows


def write_outcomes(rows, *, scores=None, output=None):
    if scores is None:
        with (ASSETS / "e2e_table_point.csv").open() as stream:
            scores = list(csv.DictReader(stream))
    expected = {r["method"]: r for r in scores}
    for row in rows:
        other = expected[row["method"]]
        if int(row["repetitions"]) != int(other["repetitions"]) or not math.isclose(
            float(row["f1"]), float(other["f1"]), abs_tol=1e-10
        ):
            raise ValueError("Refresh outcome counts from the same published Table 3 bundle")

    def count(value):
        value = float(value)
        return f"{value:,.0f}" if value.is_integer() else f"{value:,.1f}"

    astra = next(r for r in rows if r["method"] == "GPT-6-astra (Prompt-tuned)")
    definitions = {
        "CBOutcomeAstraClean": count(astra["clean_edits"]),
        "CBOutcomeAstraUnchanged": count(astra["unchanged"]),
        "CBOutcomeAstraWrong": count(astra["wrong_repairs"]),
        "CBOutcomeAstraUnchangedShare": f"{100*float(astra['unchanged'])/(float(astra['unchanged'])+float(astra['wrong_repairs'])):.1f}",
    }
    lines = [f"\\newcommand{{\\{name}}}{{{value}}}" for name, value in definitions.items()]
    lines.append(r"\newcommand{\CBOutcomeRows}{%")
    for row in rows:
        cells = [
            OUTCOME_METHODS[row["method"]],
            *(count(row[k]) for k in ("correct", "clean_edits", "unchanged", "wrong_repairs")),
        ]
        lines.append(" & ".join(cells) + r" \\")
    lines.append("}")
    target = output or PAPER / "failure_outcomes_selected.tex"
    target.write_text("\n".join(lines) + "\n")
    return target


def aggregate(rows):
    groups = defaultdict(list)
    for row in rows:
        values = {key: int(row[key]) for key in COUNTS}
        unchanged = sum(values[k] for k in COUNTS if k.startswith("unchanged_"))
        values["fn"] = unchanged + values["wrong_value"]
        values["fp"] = values["clean_edits"] + values["wrong_value"]
        values["targets"] = values["correct"] + values["fn"]
        denominator = 2 * values["correct"] + values["fp"] + values["fn"]
        values["micro_f1"] = 200 * values["correct"] / denominator if denominator else 0.0
        groups[row["method"], row["category"]].append(values)
    result = []
    for (method, category), runs in groups.items():
        assert len({r["targets"] for r in runs}) == 1
        result.append(
            dict(
                method=method,
                category=category,
                runs=len(runs),
                **{key: statistics.mean(r[key] for r in runs) for key in runs[0]},
            )
        )
    return result


def select(rows):
    """Select by mean run micro F1, using the same task for both groups."""
    return [
        max((r for r in rows if r["category"] == "Constraint-based"), key=lambda r: r["micro_f1"]),
        max((r for r in rows if r["category"] in LLM_CATEGORIES), key=lambda r: r["micro_f1"]),
    ]


def render(rows):
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch

    configure()
    fig, axes = plt.subplots(2, 1, figsize=(COLUMN_WIDTH, 3.02))
    fig.subplots_adjust(left=0.25, right=0.96, top=0.89, bottom=0.34, hspace=1.05)
    gray, coral, blue = "#c2cbd2", "#bd654e", "#566f86"
    panels = [
        ("(a) Unresolved errors (FN)", ["unchanged_completed", "unchanged_failed", "wrong_value"]),
        ("(b) Incorrect edits (FP)", ["clean_edits", "wrong_value"]),
    ]
    colors = dict(
        unchanged_completed=gray, unchanged_failed=gray, wrong_value=coral, clean_edits=blue
    )
    for ax, (title, keys) in zip(axes, panels, strict=True):
        for i, row in enumerate(rows):
            assert row["unchanged_unknown"] == 0, "Unknown execution needs a separate legend entry"
            offset = 0
            for key in keys:
                value = row[key]
                ax.barh(
                    i,
                    value,
                    left=offset,
                    height=0.5,
                    color=colors[key],
                    hatch="////" if key == "unchanged_failed" else None,
                    edgecolor="#7b8792" if key == "unchanged_failed" else "none",
                    linewidth=0,
                )
                offset += value
            label = f"{offset:,.0f}" if float(offset).is_integer() else f"{offset:,.1f}"
            ax.annotate(label, (offset, i), xytext=(4, 0), textcoords="offset points", va="center")
        ax.set_title(title, loc="left", pad=8)
        ax.set_yticks(range(len(rows)), [r["method"].replace(" (Prompt-tuned)", "") for r in rows])
        ax.tick_params(axis="y", length=0, pad=5)
        ax.set_ylim(len(rows) - 0.5, -0.5)
        ax.set_xlim(0, 1450)
        ax.set_xticks([0, 400, 800, 1200], ["0", "400", "800", "1,200"])
        ax.spines["left"].set_visible(False)
        ax.grid(axis="x")
        ax.set_axisbelow(True)
    axes[1].set_xlabel("Cells per run")
    fig.legend(
        handles=[
            Patch(facecolor=gray, label="Unchanged errors"),
            Patch(facecolor=gray, hatch="////", edgecolor="#7b8792", label="Failed execution"),
            Patch(facecolor=coral, label="Wrong replacements"),
            Patch(facecolor=blue, label="Clean-cell edits"),
        ],
        loc="lower center",
        bbox_to_anchor=(0.52, 0.015),
        ncol=2,
        frameon=False,
        handlelength=1.15,
        handletextpad=0.45,
        columnspacing=0.9,
    )
    save(fig, PAPER / "figures/paper/failure_comparison.pdf", width=COLUMN_WIDTH, check_layout=True)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--outcomes-table", action="store_true")
    parser.add_argument("--artifacts", type=Path)
    args = parser.parse_args()
    if args.outcomes_table:
        source = ASSETS / "failure_outcomes_selected.csv"
        if args.artifacts:
            rows = published_outcomes(args.artifacts)
            with source.open("w", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
                writer.writeheader()
                writer.writerows(rows)
        else:
            with source.open() as stream:
                rows = list(csv.DictReader(stream))
        print(write_outcomes(rows))
        return
    if args.artifacts:
        parser.error("--artifacts requires --outcomes-table")
    source = ASSETS / "failure_taxonomy_runs.csv"
    with source.open() as f:
        all_rows = aggregate(list(csv.DictReader(f)))
    with (ASSETS / "macro_metrics.csv").open() as f:
        existing = {r["method"]: r for r in csv.DictReader(f)}
    for row in all_rows:
        old = existing[row["method"]]
        for key in ("fp", "fn", "micro_f1"):
            assert math.isclose(row[key], float(old[key]), abs_tol=1e-10), (row["method"], key)
    selected = select(all_rows)
    assert [r["method"] for r in selected] == ["NADEEF", "GPT-6-astra (Prompt-tuned)"]
    assert all(r["targets"] == 1093 for r in selected)
    with (ASSETS / "failure_comparison.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(selected[0]))
        writer.writeheader()
        writer.writerows(selected)
    render(selected)
    target = PAPER / "build/generated/failure_comparison"
    target.mkdir(parents=True, exist_ok=True)
    (target / "evidence.json").write_text(
        json.dumps(
            dict(
                policy="Highest mean run micro F1 in end-to-end correction within each method group.",
                source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                ranking=all_rows,
                selected=selected,
                additional_model_calls=0,
            ),
            indent=2,
        )
        + "\n"
    )
    print(json.dumps(selected))


if __name__ == "__main__":
    main()
