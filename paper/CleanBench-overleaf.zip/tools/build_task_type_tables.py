"""Render paired type-slice P/R heatmaps and overall P/R/F1 from frozen scores.

Run build_type_precision.py first, then this script. No model calls.
Type slices share clean-cell negatives; no predicted type is inferred.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import statistics
import sys
from collections import defaultdict
from pathlib import Path

from build_coding_agents import END_TO_END_PREDICTIONS
from build_error_types import IDENTITY
from build_unified_task_tables import AGENTS, ARMS, MODELS
from experiment_presentation import method_category
from paper_taxonomy import DISPLAY_TYPES, overlaps, project_run, read_predictions

if __package__:
    from .tex_sources import generated_asset
else:
    from tex_sources import generated_asset

PAPER = Path(__file__).resolve().parents[1]
REPO = PAPER.parent
SHORT = {
    "Excel Clean Data": "Excel",
    "Google Sheets Cleanup": "Google Sheets",
    "KATARA (KB component)": "KATARA (KB)",
}
METRICS = ("precision", "recall", "f1")
REPORTED_TYPES = DISPLAY_TYPES


def summarize(task, category, method, runs):
    """Average within-run micro metrics after projecting coordinate unions."""
    support = [512, 270, 721 if task == "detection" else 405]
    recalls = []
    for overall, fine in runs:
        tp, fp, fn = (overall[k] for k in ("tp", "fp", "fn"))
        assert tp + fn == (1409 if task == "detection" else 1093)
        for key, a, b in zip(
            METRICS, (tp, tp, 2 * tp), (tp + fp, tp + fn, 2 * tp + fp + fn), strict=True
        ):
            assert math.isclose(overall[key], a / b if b else 0)
        coarse = fine
        assert [coarse[t]["gt"] for t, _ in DISPLAY_TYPES] == support
        for t, _ in DISPLAY_TYPES:
            assert 0 <= coarse[t]["hit"] <= coarse[t]["gt"]
            assert math.isclose(coarse[t]["recall"], coarse[t]["hit"] / coarse[t]["gt"])
        recalls.append([100 * coarse[t]["recall"] for t, _ in DISPLAY_TYPES])
    return {
        "task": task,
        "category": method_category(method, category),
        "method": method,
        "repetitions": len(runs),
        "_runs": runs,
        **{
            f"recall_{t}": statistics.mean(r[i] for r in recalls)
            for i, (t, _) in enumerate(DISPLAY_TYPES)
        },
        **{k: 100 * statistics.mean(r[0][k] for r in runs) for k in METRICS},
    }


def collect(include_runs=False):
    sources = {}

    def read(path, expected=None):
        data = path.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        if expected is not None:
            assert digest == expected, path
        sources[str(path.relative_to(REPO))] = digest
        return json.loads(data)

    folder = REPO / "outputs/paper_evaluation/20260920"
    presentation = read(folder / "presentation_selection.json")
    selected = read(folder / "selected_results.json", presentation["source_manifest_sha256"])
    candidates = selected["rows"][:]
    for name in ("excel_public", "cleanagent_repaired"):
        candidates.extend(read(folder / name / "selected_results.json")["rows"])
    sys.path.insert(0, str(REPO))
    from external.gpt5_detect.secure_tuning import digest
    from src.evaluation.paper_evaluation.analysis import GroundTruth

    config = read(REPO / "outputs/prompt_tuning/dev200_none_20260930_continuation/config.json")
    datasets = Path(config["datasets"])
    data_manifest = read(datasets / "_manifest.json")
    truth = GroundTruth(datasets, data_manifest)
    for filename in ("benchmark_cell.json", "neutral_cells.jsonl", "ignored.jsonl"):
        path = datasets / filename
        sources[str(path.relative_to(REPO))] = hashlib.sha256(path.read_bytes()).hexdigest()
    overlap_tables = {c[0] for c in overlaps(truth.fine)}

    def records(path, detector=None, expected=None):
        path = Path(path)
        if not path.is_absolute():
            path = REPO / path
        digest_value = hashlib.sha256(path.read_bytes()).hexdigest()
        if expected is not None:
            assert digest_value == expected, path
        sources[str(path.relative_to(REPO))] = digest_value
        return read_predictions(path, detector)

    rows = []
    for task in ("e2e", "detection"):
        grouped = defaultdict(list)
        for entry in presentation["main"][task]:
            matches = [r for r in candidates if all(r.get(k) == entry.get(k) for k in IDENTITY)]
            assert len(matches) == 1
            r = matches[0]
            assert r["analysis"]["full"] == entry["metrics"]
            projected = project_run(
                r["analysis"]["per_type"],
                records(r["prediction_path"], r["configuration"], r["prediction_sha256"]),
                truth,
                task,
            )
            grouped[entry["method"]].append((entry["metrics"], projected))
        for category, methods in presentation["categories"].items():
            for method in methods:
                if method in grouped:
                    rows.append(
                        summarize(task, category, SHORT.get(method, method), grouped[method])
                    )

    api = read(PAPER / "build/generated/llm_baseline_evidence.json")
    paths = api["source_sha256"]
    det_path = next(p for p in paths if p.endswith("final_report/RESULTS.json"))
    rep_path = next(p for p in paths if p.endswith("e2e_scores.json"))
    detection = read(REPO / det_path, paths[det_path])
    repair = read(REPO / rep_path, paths[rep_path])
    derivation_path = next(p for p in paths if p.endswith("derivation.json"))
    derivation = read(REPO / derivation_path, paths[derivation_path])
    campaign = (REPO / det_path).parents[1]
    api_repairs = defaultdict(list)
    for record in records((REPO / rep_path).parent / "valued_predictions.jsonl"):
        api_repairs[record["detector"]].append(record)

    def api_records(task, model, arm, rep):
        if task == "e2e":
            return api_repairs[f"rep_{rep:02d}/{model}/{arm}"]
        recovered = campaign / f"rep_{rep:02d}/recovered"
        prompt_path = recovered / f"compare_{model}_{arm}/prompt.txt"
        prompt = prompt_path.read_text()
        stage = read(prompt_path.with_name("receipt.json"))
        assert hashlib.sha256(prompt.encode()).hexdigest() == stage["prompt_sha256"]
        sources[str(prompt_path.relative_to(REPO))] = stage["prompt_sha256"]
        result = []
        for ds in sorted(overlap_tables):
            path = recovered / "requests" / model / digest(prompt) / f"{ds}.json"
            raw = read(path, derivation["receipt_hashes"][str(path.relative_to(REPO))])
            if raw["status"] == "success":
                columns = data_manifest["datasets"][ds]["columns"]
                result.extend(
                    dict(dataset=ds, row=i["row"], col=columns.index(i["column"]))
                    for i in raw["issues"]
                )
            else:
                assert not raw["issues"]
        return result

    for task in ("e2e", "detection"):
        for model in MODELS:
            for arm, label in ARMS:
                metrics = (
                    [repair["results"][f"rep_{i:02d}/{model}/{arm}"] for i in (1, 2, 3)]
                    if task == "e2e"
                    else [
                        next(r for r in rep["comparison"] if r["name"] == f"compare_{model}_{arm}")
                        for rep in detection["repetitions"]
                    ]
                )
                runs = [
                    (
                        m,
                        project_run(
                            m["per_type_recall_fine"] if task == "e2e" else m["per_type_recall"],
                            api_records(task, model, arm, rep),
                            truth,
                            task,
                        ),
                    )
                    for rep, m in enumerate(metrics, 1)
                ]
                row = summarize(
                    task, "Direct LLMs (API)", f"{model.replace('gpt', 'GPT')} ({label})", runs
                )
                old = next(
                    r
                    for r in api["rows"]
                    if (r["task"], r["model"], r["arm"]) == (task, model, arm)
                )
                assert all(
                    math.isclose(row[k], v)
                    for k, v in zip(METRICS, old["mean_prf_percent"], strict=True)
                )
                rows.append(row)
        suffix = "_repair" if task == "e2e" else ""
        agents = read(PAPER / f"build/generated/coding_agent{suffix}_evidence.json")
        assert [(r["model"], r["harness"]) for r in agents["rows"]] == list(AGENTS)
        for r in agents["rows"]:
            m = r["metrics"]
            rows.append(
                summarize(
                    task,
                    "Coding agents",
                    f"{r['model']} ({r['harness']})",
                    [
                        (
                            m,
                            project_run(
                                m["per_type_recall_fine"],
                                records(
                                    REPO / END_TO_END_PREDICTIONS
                                    if task == "e2e"
                                    else REPO
                                    / "outputs/coding_agents"
                                    / r["run"]
                                    / "predictions.jsonl",
                                    r["arm"] if task == "e2e" else r["agent"],
                                ),
                                truth,
                                task,
                            ),
                        )
                    ],
                )
            )

    # Every aggregate and supported method must agree with the existing main
    # table, including its repetition averaging. Unsupported rows are omitted.
    for task, expected_count in (("e2e", 27), ("detection", 31)):
        old = {}
        path = generated_asset(f"all_{task}_table.tex")
        sources[str(path.relative_to(REPO))] = hashlib.sha256(path.read_bytes()).hexdigest()
        for line in path.read_text().splitlines():
            parts = line.removesuffix(r" \\").split(" & ")
            if len(parts) == 4 and parts[0] != "Method" and parts[1] != "--":
                old[parts[0]] = [float(x) for x in parts[1:]]
        current = [r for r in rows if r["task"] == task]
        assert len(current) == expected_count
        displayed = set()
        for row in current:
            name = row["method"]
            if name not in old and name.endswith(" (Base)"):
                continue
            if name not in old:
                name = name.removesuffix(" (Prompt-tuned)")
            assert name in old, row["method"]
            assert [float(f"{row[k]:.2f}") for k in METRICS] == old[name]
            displayed.add(name)
        assert displayed == set(old)
    run_details = {(row["task"], row["method"]): row.pop("_runs") for row in rows}
    return (rows, sources, run_details) if include_runs else (rows, sources)


def heat(value):
    """One fixed white-to-blue scale for all types and both tasks (0--100%)."""
    rgb = tuple(round(255 + (c - 255) * value / 100) for c in (20, 86, 135))
    color = "".join(f"{c:02X}" for c in rgb)
    foreground = "white" if value >= 80 else "black"
    return (
        rf"\cellcolor[HTML]{{{color}}}"
        rf"\makebox[0.065\textwidth]{{\textcolor{{{foreground}}}{{{value:.1f}}}}}"
    )


def render(rows, task, precision):
    lines = [
        "% Generated by tools/build_task_type_tables.py; type slices in task_type_precision.csv; overall in task_type_metrics.csv.",
        r"\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}l*{6}{c}@{\hspace{10pt}}rrr@{}}",
        r"\toprule",
        " & "
        + " & ".join(rf"\multicolumn{{2}}{{c}}{{{name}}}" for _, name in REPORTED_TYPES)
        + r" & \multicolumn{3}{c}{Overall (\%)} \\",
        r"\cmidrule(lr){2-3}\cmidrule(lr){4-5}\cmidrule(lr){6-7}\cmidrule(l){8-10}",
        r"Method & P & R & P & R & P & R & P & R & $F_1$ \\",
    ]
    group = None
    for row in rows:
        if row["task"] != task:
            continue
        if row["category"] != group:
            group = row["category"]
            lines += [
                r"\midrule",
                rf"\multicolumn{{10}}{{@{{}}l}}{{\textit{{{group.removesuffix(' (API)')}}}}} \\",
            ]
        values = [
            heat(float(precision[task, row["method"], kind][metric]))
            for kind, _ in REPORTED_TYPES
            for metric in ("precision", "recall")
        ]
        values += [rf"\makebox[0.060\textwidth][r]{{{row[k]:.2f}}}" for k in METRICS]
        lines.append(row["method"] + " & " + " & ".join(values) + r" \\")
    return "\n".join([*lines, r"\bottomrule", r"\end{tabular*}", ""])


def main():
    rows, sources = collect()
    generated = PAPER / "assets/generated"
    path = generated / "task_type_precision.csv"
    sources[str(path.relative_to(PAPER))] = hashlib.sha256(path.read_bytes()).hexdigest()
    with path.open() as handle:
        precision = {(r["task"], r["method"], r["error_type"]): r for r in csv.DictReader(handle)}
    assert len(precision) == len(DISPLAY_TYPES) * len(rows)
    for row in rows:
        for kind, _ in DISPLAY_TYPES:
            scored = precision[row["task"], row["method"], kind]
            assert math.isclose(float(scored["recall"]), row[f"recall_{kind}"])
            assert int(scored["repetitions"]) == row["repetitions"]
    for task in ("e2e", "detection"):
        (generated_asset(f"{task}_type_table.tex", directory=generated)).write_text(
            render(rows, task, precision)
        )
    with (generated / "task_type_metrics.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    evidence = {
        "source_sha256": sources,
        "builder_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "policy": "Mean within-run micro metrics across the same frozen repetitions as the original tables. Type slices use benchmark labels, shared clean-cell false positives, and wrong replacements at the type's own targets; other-type errors are excluded. Overlapping labels remain in every applicable slice. Historical inconsistency, semantic-domain and numeric-outlier targets are unioned by coordinate; overlapping targets are counted once within Inconsistency. Unsupported tasks are omitted. Both tasks share a fixed 0--100 P/R color scale.",
        "rows": rows,
    }
    (PAPER / "build/generated/task_type_evidence.json").write_text(
        json.dumps(evidence, indent=2) + "\n"
    )
    print("Validated unchanged overall P/R/F1; wrote 27 repair and 31 detection rows.")


if __name__ == "__main__":
    main()
