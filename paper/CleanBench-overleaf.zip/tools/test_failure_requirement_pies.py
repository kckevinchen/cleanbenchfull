"""A wrong replacement belongs to FP and FN; clean edits belong only to FP."""

import pytest
from build_failure_requirement_pies import adjudicate, aggregate, llm_rows


@pytest.mark.parametrize(
    "deduplicate,fp_counts,fn_counts",
    [(False, [2, 3, 0], [2, 0, 4]), (True, [1, 1, 0], [1, 0, 1])],
)
def test_false_positive_and_false_negative_denominators(deduplicate, fp_counts, fn_counts):
    groups = [
        dict(
            original="A",
            outcome="wrong_value",
            analysis_category="Knowledge",
            occurrences=[(1, "a", 0, 0), (2, "a", 0, 0)],
        ),
        dict(
            original="B",
            outcome="clean_edit",
            analysis_category="Formatting convention",
            occurrences=[(1, "b", 0, 0), (1, "b", 1, 0), (2, "b", 0, 0)],
        ),
        dict(
            original="C",
            outcome="unchanged_error",
            analysis_category="Reasoning",
            occurrences=[(1, "c", 0, 0), (2, "c", 0, 0), (2, "c", 1, 0), (2, "c", 2, 0)],
        ),
    ]
    config = dict(
        repetitions=[1, 2], categories=["Knowledge", "Formatting convention", "Reasoning"]
    )
    rows = aggregate(groups, config, deduplicate=deduplicate)
    pooled = {(r["outcome"], r["category"]): r for r in rows if r["run"] == "pooled"}
    assert [pooled["FP", c]["count"] for c in config["categories"]] == fp_counts
    assert [pooled["FN", c]["count"] for c in config["categories"]] == fn_counts
    assert pooled["FP", "Knowledge"]["total"] == sum(fp_counts)
    assert pooled["FN", "Knowledge"]["total"] == sum(fn_counts)
    assert pooled["FP", "Knowledge"]["percentage"] == pytest.approx(
        100 * fp_counts[0] / sum(fp_counts)
    )
    assert pooled["FN", "Knowledge"]["percentage"] == pytest.approx(
        100 * fn_counts[0] / sum(fn_counts)
    )
    assert len(groups[1]["occurrences"]) == 3


def test_same_value_merges_across_tables_outputs_references_and_runs():
    groups = [
        dict(
            original="July",
            proposed=proposed,
            accepted=accepted,
            outcome=outcome,
            analysis_category="Formatting convention",
            occurrences=[(run, table, 0, col), (run, table, 1, col)],
        )
        for run, table, col, proposed, accepted, outcome in [
            (1, "a", 0, "JULY", ["Jul"], "wrong_value"),
            (2, "b", 1, "Jul.", ["Jul", "JUL"], "wrong_value"),
            (2, "c", 2, None, ["Jul"], "unchanged_error"),
        ]
    ]
    config = dict(repetitions=[1, 2], categories=["Formatting convention", "Reasoning"])
    rows = aggregate(groups, config, deduplicate=True)
    assert all(row["total"] == 1 for row in rows)
    assert all(row["count"] == 1 for row in rows if row["category"] == "Formatting convention")
    assert sum(len(group["occurrences"]) for group in groups) == 6
    groups[1]["analysis_category"] = "Reasoning"
    with pytest.raises(AssertionError, match="conflicting analysis categories"):
        aggregate(groups, config, deduplicate=True)


def test_llm_totals_retain_unclassified_cases_in_the_denominator():
    categories = ["Knowledge", "Formatting convention", "Reasoning", "Uncertain"]
    records = [
        dict(outcome=outcome, category=category, count=count, total=100, percentage=count)
        for outcome in ["FP", "FN"]
        for category, count in zip(categories, [20, 60, 18, 2], strict=True)
    ]
    metadata = dict(
        completed_groups=492,
        total_groups=492,
        source_method="GPT-6-astra (Prompt-tuned)",
        repetitions=[1, 2, 3],
    )
    rows = llm_rows(records, metadata, {"FP": 100, "FN": 100})
    assert rows[1]["percentage"] == 60
    assert rows[3]["category"] == "Uncertain" and rows[3]["count"] == 2
    with pytest.raises(AssertionError):
        llm_rows(records[:-1], metadata, {"FP": 100, "FN": 100})
    with pytest.raises(AssertionError):
        llm_rows(records, metadata, {"FP": 100, "FN": 101})


def test_author_adjudication_preserves_raw_labels_and_all_failure_occurrences():
    judgments = [
        dict(
            group_id=gid,
            primary_category="Uncertain",
            issue_kind="insufficient_reference",
            rationale="Original model explanation",
        )
        for gid in ("G087", "G095", "G096", "G435")
    ]
    review = dict(
        assignments=[
            dict(
                group_id=row["group_id"],
                previous_category="Uncertain",
                category="Formatting convention" if i == 3 else "Reasoning",
                issue_kind="surface_only" if i == 3 else "arithmetic_or_relationship",
                rationale="Author decision",
            )
            for i, row in enumerate(judgments)
        ]
    )
    active = adjudicate(judgments, review)
    assert all(row["primary_category"] == "Uncertain" for row in judgments)
    assert all(row["llm_primary_category"] == "Uncertain" for row in active)
    groups = [
        dict(
            outcome="wrong_value" if i == 3 else "unchanged_error",
            analysis_category=row["primary_category"],
            occurrences=[(1, "table", n, 0) for n in range(count)],
        )
        for i, (row, count) in enumerate(zip(active, (6, 3, 3, 4), strict=True))
    ]
    rows = aggregate(
        groups,
        dict(repetitions=[1], categories=["Knowledge", "Formatting convention", "Reasoning"]),
    )
    counts = {(r["outcome"], r["category"]): r["count"] for r in rows if r["run"] == "pooled"}
    assert counts["FP", "Formatting convention"] == counts["FN", "Formatting convention"] == 4
    assert counts["FP", "Reasoning"] == 0 and counts["FN", "Reasoning"] == 12
    assert sum(n for (outcome, _), n in counts.items() if outcome == "FN") == 16
    with pytest.raises(AssertionError):
        adjudicate(active, review)


def test_assistant_review_does_not_claim_author_annotation():
    judgments = [
        dict(
            group_id="G001",
            primary_category="Uncertain",
            issue_kind="mixed_no_primary",
            rationale="Model draft",
        )
    ]
    review = dict(
        assignments=[
            dict(
                group_id="G001",
                previous_category="Uncertain",
                category="Knowledge",
                issue_kind="lexical_or_entity",
                rationale="Lexical defect remains, with a separate representation issue.",
                reviewer="assistant",
            )
        ]
    )
    active = adjudicate(judgments, review)
    assert active[0]["primary_category"] == "Knowledge"
    assert active[0]["llm_primary_category"] == "Uncertain"
    assert active[0]["review_source"] == "assistant"
    assert active[0]["author_adjudicated"] is False
