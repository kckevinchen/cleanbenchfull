"""Plot error incidence by relative cell position from frozen aggregate counts.

Use --refresh to recompute counts from the same snapshot as Section 4.
The default redraw needs only the aggregate CSV and figure configuration.
Raw coordinates and input-file provenance remain under ignored build/.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

if __package__:
    from .figure_style import FIGURE_WIDTH, configure, save
else:
    from figure_style import FIGURE_WIDTH, configure, save

PAPER = Path(__file__).resolve().parents[1]
REPO = PAPER.parent
GENERATED = PAPER / "assets/generated"
CONFIG = PAPER / "figures/error_position.json"
SOURCE_LABELS = {"BI": "Relational", "Web": "Spreadsheet"}
PANELS = ("All", *SOURCE_LABELS.values())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def position_bins(length, bins=5):
    """Assign each cell's center (i + 1/2) / length to an equal-width bin.

    Integer arithmetic makes boundary assignments exact. Narrow tables can
    leave some column bins empty; their cells are never spread or duplicated.
    """
    if length < 1 or bins < 1:
        raise ValueError("Table dimensions and bin count must be positive")
    return (2 * np.arange(length) + 1) * bins // (2 * length)


def aggregate(tables, errors, ambiguous=(), immune=None, *, bins=5, min_rows=1, min_columns=1):
    """Count distinct errors and eligible cells at their within-table positions."""
    if min_rows < 1 or min_columns < 1:
        raise ValueError("Minimum table dimensions must be positive")
    errors, ambiguous = set(errors), set(ambiguous)
    if errors & ambiguous:
        raise ValueError("A cell cannot be both erroneous and ambiguous")
    for ds, row, column in errors | ambiguous:
        if ds not in tables or not (
            0 <= row < tables[ds]["rows"] and 0 <= column < tables[ds]["columns"]
        ):
            raise ValueError("Label coordinate outside its table")
    counts = {
        source: {
            "errors": np.zeros((bins, bins), dtype=np.int64),
            "cells": np.zeros((bins, bins), dtype=np.int64),
            "tables": 0,
        }
        for source in PANELS
    }
    for ds, table in sorted(tables.items()):
        if table["rows"] < min_rows or table["columns"] < min_columns:
            continue
        source = SOURCE_LABELS[table["source"]]
        row_bins = position_bins(table["rows"], bins)
        column_bins = position_bins(table["columns"], bins)
        for group in ("All", source):
            counts[group]["tables"] += 1
        for row, row_bin in enumerate(row_bins):
            for column, column_bin in enumerate(column_bins):
                cell = (ds, row, column)
                if cell in ambiguous or (immune is not None and immune(cell)):
                    continue
                for group in ("All", source):
                    counts[group]["cells"][row_bin, column_bin] += 1
                    counts[group]["errors"][row_bin, column_bin] += cell in errors
    for source in PANELS:
        assert np.all(counts[source]["errors"] <= counts[source]["cells"])
    for metric in ("errors", "cells", "tables"):
        assert np.all(
            counts["All"][metric] == counts["Relational"][metric] + counts["Spreadsheet"][metric]
        )
    return counts


def rates(errors, cells, scale=1000):
    """Leave regions with no eligible cells undefined, rather than calling them clean."""
    return np.divide(
        scale * errors,
        cells,
        out=np.full_like(cells, np.nan, dtype=float),
        where=cells > 0,
    )


def summarize(counts, *, scale=1000):
    result = {}
    for source, group in counts.items():
        errors, cells = group["errors"], group["cells"]
        summary = {
            "tables": group["tables"],
            "errors": int(errors.sum()),
            "cells": int(cells.sum()),
            "errors_per_1000": float(scale * errors.sum() / cells.sum()),
        }
        for name, axis in (("row", 1), ("column", 0)):
            a, b = errors.sum(axis=axis), cells.sum(axis=axis)
            summary[name] = {
                "errors": a.tolist(),
                "cells": b.tolist(),
                "errors_per_1000": rates(a, b, scale).tolist(),
                "error_share_percent": (100 * a / errors.sum()).tolist(),
                "cell_share_percent": (100 * b / cells.sum()).tolist(),
            }
        result[source] = summary
    return result


def write_counts(path, counts, *, bins=5, scale=1000):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(
            stream,
            lineterminator="\n",
            fieldnames=[
                "source",
                "row_bin",
                "column_bin",
                "row_start_percent",
                "row_end_percent",
                "column_start_percent",
                "column_end_percent",
                "errors",
                "cells",
                "errors_per_1000",
            ],
        )
        writer.writeheader()
        for source in PANELS:
            errors, cells = counts[source]["errors"], counts[source]["cells"]
            values = rates(errors, cells, scale)
            for row in range(bins):
                for column in range(bins):
                    writer.writerow(
                        dict(
                            source=source,
                            row_bin=row,
                            column_bin=column,
                            row_start_percent=100 * row / bins,
                            row_end_percent=100 * (row + 1) / bins,
                            column_start_percent=100 * column / bins,
                            column_end_percent=100 * (column + 1) / bins,
                            errors=errors[row, column],
                            cells=cells[row, column],
                            errors_per_1000=(
                                f"{values[row, column]:.8f}" if cells[row, column] else ""
                            ),
                        )
                    )


def read_counts(path, *, bins=5, scale=1000):
    counts = {
        source: {key: np.zeros((bins, bins), dtype=np.int64) for key in ("errors", "cells")}
        for source in PANELS
    }
    seen = set()
    with path.open(newline="") as stream:
        for record in csv.DictReader(stream):
            source = record["source"]
            row, column = int(record["row_bin"]), int(record["column_bin"])
            key = (source, row, column)
            assert source in PANELS and 0 <= row < bins and 0 <= column < bins
            assert key not in seen, "Duplicate aggregate region"
            seen.add(key)
            for metric in ("errors", "cells"):
                counts[source][metric][row, column] = int(record[metric])
            a, b = int(record["errors"]), int(record["cells"])
            assert 0 <= a <= b
            assert (not record["errors_per_1000"] and b == 0) or (
                b > 0 and np.isclose(float(record["errors_per_1000"]), scale * a / b)
            )
    assert len(seen) == len(PANELS) * bins * bins, "Incomplete aggregate regions"
    for metric in ("errors", "cells"):
        assert np.array_equal(
            counts["All"][metric], counts["Relational"][metric] + counts["Spreadsheet"][metric]
        )
    return counts


def refresh(snapshot, selected, config, *, stem="error_position"):
    sys.path.insert(0, str(REPO))
    from src.evaluation.paper_evaluation.analysis import GroundTruth

    manifest_path = snapshot / "_manifest.json"
    manifest = json.loads(manifest_path.read_text())
    hashes = {str(manifest_path): sha(manifest_path), str(selected): sha(selected)}
    for name, expected in manifest["input_sha256"].items():
        path = snapshot / name
        assert sha(path) == expected, f"Frozen input changed: {name}"
        hashes[str(path)] = expected
    truth = GroundTruth(snapshot, manifest)
    assert truth.tables == json.loads(selected.read_text())["table_manifest"]
    for ds, table in manifest["datasets"].items():
        path = snapshot / ds / "dirty.csv"
        assert sha(path) == table["dirty_sha256"]
        hashes[str(path)] = table["dirty_sha256"]
        with path.open(newline="", encoding="utf-8-sig") as stream:
            headers, *rows = csv.reader(stream)
        assert headers == table["columns"] and len(rows) == table["n_rows"]
        assert all(len(row) == table["n_cols"] for row in rows)
    assert len(truth.tables) == 1000
    assert len(truth.errors) == 1409
    assert sum(t["detection_scorable"] for t in truth.tables.values()) == 363802
    min_rows, min_columns = config.get("min_rows", 1), config.get("min_columns", 1)
    cohort = {
        ds: table
        for ds, table in truth.tables.items()
        if table["rows"] >= min_rows and table["columns"] >= min_columns
    }
    if not cohort:
        raise ValueError("No tables match the requested minimum dimensions")
    counts = aggregate(
        truth.tables,
        truth.errors,
        truth.ambiguous,
        truth.immune,
        bins=config["bins"],
        min_rows=min_rows,
        min_columns=min_columns,
    )
    summary = summarize(counts, scale=config["scale"])
    assert summary["All"]["tables"] == len(cohort)
    assert summary["All"]["errors"] == sum(t["labeled_errors"] for t in cohort.values())
    assert summary["All"]["cells"] == sum(t["detection_scorable"] for t in cohort.values())
    for source, label in SOURCE_LABELS.items():
        group = [t for t in cohort.values() if t["source"] == source]
        assert summary[label]["errors"] == sum(t["labeled_errors"] for t in group)
        assert summary[label]["cells"] == sum(t["detection_scorable"] for t in group)
    GENERATED.mkdir(parents=True, exist_ok=True)
    write_counts(GENERATED / f"{stem}.csv", counts, bins=config["bins"], scale=config["scale"])
    evidence = {
        "binning": "floor(bins * (index + 0.5) / dimension), zero-based data cells",
        "denominator": "all cells excluding ambiguous and immune coordinates",
        "numerator": "distinct confirmed error cells, counted once across error types",
        "groups": summary,
        "manifest_sha256": sha(manifest_path),
        "selected_results_sha256": sha(selected),
        "builder_sha256": sha(Path(__file__)),
        "config": config,
        "model_calls": 0,
    }
    (GENERATED / f"{stem}_summary.json").write_text(json.dumps(evidence, indent=2) + "\n")
    provenance = PAPER / f"build/generated/{stem}_provenance.json"
    provenance.parent.mkdir(parents=True, exist_ok=True)
    provenance.write_text(json.dumps({"source_sha256": hashes, **evidence}, indent=2) + "\n")
    return counts


def draw(counts, config, target):
    configure()
    fig, axes = plt.subplots(1, 3, figsize=(FIGURE_WIDTH, 2.48), sharey=True)
    fig.subplots_adjust(
        left=0.12 if config["bins"] == 3 else 0.083,
        right=0.90,
        bottom=0.24,
        top=0.86,
        wspace=0.18,
    )
    if config.get("min_rows", 1) > 1 or config.get("min_columns", 1) > 1:
        fig.suptitle(
            f"Tables with at least {config.get('min_rows', 1)} rows "
            f"and {config.get('min_columns', 1)} columns",
            y=0.99,
            fontsize=8,
        )
    bins = config["bins"]
    values = [
        rates(counts[source]["errors"], counts[source]["cells"], config["scale"])
        for source in PANELS
    ]
    maximum = np.ceil(max(np.nanmax(value) for value in values))
    labels = [f"{100 * i / bins:.3g}–{100 * (i + 1) / bins:.3g}" for i in range(bins)]
    cmap = plt.get_cmap(config["colormap"]).copy()
    cmap.set_bad("#eeeeee")
    for index, (ax, source, value) in enumerate(zip(axes, PANELS, values, strict=True)):
        image = ax.imshow(value, origin="upper", cmap=cmap, vmin=0, vmax=maximum, aspect="auto")
        ax.set_title(f"({'abc'[index]}) {source}")
        ax.set_xticks(range(bins), labels)
        ax.set_yticks(range(bins), labels)
        ax.set_xlabel("Column position (%)")
        ax.tick_params(length=0, pad=3)
        ax.set_xticks(np.arange(-0.5, bins, 1), minor=True)
        ax.set_yticks(np.arange(-0.5, bins, 1), minor=True)
        ax.grid(which="minor", color="white", linewidth=0.8)
        ax.tick_params(which="minor", length=0)
        for row in range(bins):
            for column in range(bins):
                v = value[row, column]
                ax.text(
                    column,
                    row,
                    f"{v:.1f}" if np.isfinite(v) else "–",
                    ha="center",
                    va="center",
                    color="white" if v > 0.58 * maximum else "#263442",
                )
        for spine in ax.spines.values():
            spine.set_visible(False)
    axes[0].set_ylabel("Row position (%)")
    colorbar = fig.colorbar(image, cax=fig.add_axes([0.925, 0.24, 0.016, 0.62]), format="%.2g")
    colorbar.set_label("Errors / 1,000 cells", labelpad=5)
    colorbar.set_ticks([0, maximum / 3, 2 * maximum / 3, maximum])
    target.parent.mkdir(parents=True, exist_ok=True)
    save(fig, target, check_layout=True)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--refresh", action="store_true")
    parser.add_argument("--config", type=Path, default=CONFIG)
    parser.add_argument(
        "--snapshot", type=Path, default=REPO / "outputs/baseline_campaign/20260910/snapshot"
    )
    parser.add_argument(
        "--selected",
        type=Path,
        default=REPO / "outputs/paper_evaluation/20260920/selected_results.json",
    )
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    assert config["position"] == "cell_center"
    stem = args.config.stem
    if args.refresh:
        counts = refresh(args.snapshot, args.selected, config, stem=stem)
    else:
        counts = read_counts(GENERATED / f"{stem}.csv", bins=config["bins"], scale=config["scale"])
    target = PAPER / config.get("output", f"figures/paper/{stem}.pdf")
    draw(counts, config, target)
    print(target)


if __name__ == "__main__":
    main()
