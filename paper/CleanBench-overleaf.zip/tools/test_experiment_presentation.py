"""Check method omission without changing retained rows or bootstrap results."""

from experiment_presentation import astra_interval, reported_method, reported_table


def test_model_filter_keeps_astra_and_both_interfaces():
    for name in ["GPT-6-astra (Codex)", "GPT-6-astra (Copilot)", "Excel"]:
        assert reported_method(name)
    for name in ["Opus 5.5", "Opus 5.5 (Claude Code)", "Opus 5.5 (Copilot)", "FM data tasks"]:
        assert not reported_method(name)


def test_tex_filter_removes_only_excluded_rows_verbatim():
    before = (
        "% frozen table\n"
        "Model & F1 \\\\\n"
        "GPT-6-astra (Codex) & 65.27 \\\\\n"
        "Opus 5.5 (Claude Code) & 45.15 \\\\\n"
        "GPT-6-astra (Copilot) & 65.54 \\\\\n"
        "Opus 5.5 (Copilot) & 33.18 \\\\\n"
    )
    expected = "".join(
        line for line in before.splitlines(keepends=True) if not line.startswith("Opus")
    )
    assert reported_table(before) == expected
    assert reported_table(expected) == expected


def test_interval_keeps_the_retained_pair_and_sign():
    text = astra_interval([-1.2336672775897406, 2.2047507975310063])
    assert "[-1.23, 2.20]" in text and "Copilot minus Codex" in text
    assert "Opus" not in text
    assert "repair $F_1$" in astra_interval([-0.558855726118054, 0.7276522594769229], repair=True)
