"""Render a standalone, source-verified draft of three error-type figures."""

from __future__ import annotations

import argparse
import difflib
import json
from pathlib import Path

from build_context_screenshots import esc, highlight_edits
from build_error_type_examples import WIDTH, document, prepare_display
from build_example_options import audit, digest
from figure_style import COLUMN_WIDTH
from playwright.sync_api import sync_playwright
from worksheet_style import check_worksheet_style

PAPER = Path(__file__).resolve().parents[1]


def correction_markup(original, repair, *, original_side=False, show_deletions=False):
    """Mark edits in a badge, keeping removed characters separate from the repair."""
    if len(original) == len(repair):
        return highlight_edits(original, repair, show_repair=not original_side)
    pieces = []
    for operation, a, b, c, d in difflib.SequenceMatcher(None, original, repair).get_opcodes():
        if operation == "delete":
            if original_side or show_deletions:
                removed = original[a:b]
                visible = removed.replace(" ", "␣")
                pieces.append(
                    f'<del class="edit deletion" data-original="{esc(removed)}">'
                    f"{esc(visible)}</del>"
                )
        else:
            value = original[a:b] if original_side else repair[c:d]
            if value:
                text = esc(value)
                pieces.append(f'<b class="edit">{text}</b>' if operation != "equal" else text)
    return "".join(pieces)


def mark_source_deletions(page, correction, views):
    """Strike removals in the source cell without changing its literal text."""
    record = correction["record"]
    original, repair = record["original_value"], record["corrected_value"]
    pieces, removed = [], []
    for operation, a, b, _, _ in difflib.SequenceMatcher(None, original, repair).get_opcodes():
        text = esc(original[a:b])
        if operation == "delete":
            removed.append(original[a:b])
            whitespace = " whitespace" if original[a:b].isspace() else ""
            text = f'<del class="source-deletion deletion{whitespace}">{text}</del>'
        pieces.append(text)
    if not removed:
        return
    headers, _ = views.load(correction["dataset"])
    key = f'{correction["dataset"]}:{record["row"]}:{headers.index(record["column"])}'
    cell = page.locator(f'[data-cell="{key}"]')
    assert cell.text_content() == original
    cell.evaluate("(e,markup)=>e.innerHTML=markup", "".join(pieces))
    assert cell.text_content() == original
    assert cell.locator(".source-deletion").all_text_contents() == removed


def prepare_preview(page, figure, cases, views):
    scale = WIDTH / (COLUMN_WIDTH * 72)
    page.add_style_tag(
        content=f"""
        #figure {{row-gap:12px}}
        #figure h2 {{font-size:{7.5 * scale}px;line-height:1.2}}
        #figure .scope-label {{grid-column:1/-1;margin:7px 0 0;padding:0 0 5px;
          border-bottom:1px solid #b8c4cd;color:#33424d;font-size:{7.5 * scale}px;
          line-height:1.2;font-weight:700}}
        #figure .scope-label:first-child {{margin-top:0}}
        #figure table.source [data-cell] {{display:block;white-space:pre;
          overflow:hidden;text-overflow:ellipsis}}
        #figure [data-case='F6'] table.source tbody td {{text-align:left}}
        #figure .directional-row {{text-align:left}}
        #figure .proposed-change {{position:relative;transform:translateX(-50%);
          display:inline-grid;grid-template-columns:1fr auto 1fr;align-items:center;
          column-gap:5px;line-height:1.2;
          padding:4px 7px;border:1px solid #b64b43;background:#fff1ed;color:#ac2f25}}
        #figure .proposed-change .change-from {{text-align:right}}
        #figure .proposed-change .change-to {{text-align:left}}
        #figure .proposed-change .change-arrow {{width:1em;height:1.2em;
          display:flex;align-items:center;justify-content:center}}
        #figure .change-arrow svg {{display:block;width:1em;height:.6em;
          fill:none;stroke:currentColor;stroke-width:1.4;
          stroke-linecap:round;stroke-linejoin:round}}
        #figure .proposed-change.corrected,
        #figure [data-case='I5'] .correction {{
          border:1px solid #8ebb9f;background:#e2f1e7;color:#086c40}}
        #figure section.direction-focus table.source tbody tr.selected {{outline:none}}
        #figure section.direction-focus table.source td.active-cell {{
          outline:2px solid #1a8b4f;outline-offset:-1px}}
        """
    )
    if figure.get("hide_panel_titles"):
        page.locator("section > h2").evaluate_all(
            "es=>es.forEach(e=>e.replaceChildren(e.querySelector('.panel-letter')))"
        )
    if figure.get("panel_caption_position") == "bottom":
        page.locator("section").evaluate_all(
            "sections=>sections.forEach(section=>section.append(section.querySelector('h2')))"
        )
        page.add_style_tag(content="#figure section > h2 {margin:8px 0 0;text-align:center}")
    if figure.get("panel_scope_captions"):
        for row in figure["scope_rows"]:
            for case_id in row["ids"]:
                page.locator(f'[data-case="{case_id}"]').evaluate(
                    """(section,label)=>{
                      const heading=section.querySelector('h2');
                      heading.append(document.createTextNode(' '+label));
                      section.append(heading);
                    }""",
                    row["label"],
                )
        page.add_style_tag(
            content="""
            #figure section > h2 {margin:8px 0 0;text-align:center}
            """
        )
    else:
        for row in figure.get("scope_rows", []):
            page.locator(f'[data-case="{row["ids"][0]}"]').evaluate(
                """(section,text)=>{
                  const label=document.createElement('h3');
                  label.className='scope-label';label.textContent=text;
                  section.before(label);
                }""",
                row["label"],
            )
    if figure.get("center_table_labels"):
        page.add_style_tag(content="#figure .table-name {text-align:center}")
    # Equal title heights keep the worksheet grids aligned in each paired row.
    page.locator("section").evaluate_all("""sections=>{
      const groups=new Map();
      sections.forEach(e=>{
        const y=Math.round(e.getBoundingClientRect().top);
        if(!groups.has(y))groups.set(y,[]);
        groups.get(y).push(e.querySelector('h2'));
      });
      groups.forEach(headings=>{
        const h=Math.max(...headings.map(e=>e.getBoundingClientRect().height));
        headings.forEach(e=>e.style.height=h+'px');
      });
    }""")
    prepare_display(page, figure, {"examples": list(cases.values())})
    if figure.get("highlight_correction_edits", False):
        page.add_style_tag(
            content="""
            #figure .correction .edit,#figure .proposed-change .edit {
              color:#c60000;font-weight:inherit;background:none}
            #figure .deletion {text-decoration:line-through;text-decoration-thickness:1.5px}
            #figure table.source .source-deletion {color:#c60000}
            #figure .source-deletion.whitespace {
              position:relative;display:inline-block;width:.65em}
            #figure .source-deletion.whitespace::after {content:"␣";position:absolute;
              left:0;top:0;text-decoration:line-through;text-decoration-thickness:1.5px}
            """
        )
        for panel in figure["panels"]:
            case = cases[panel["id"]]
            for index, correction in enumerate(case["corrections"]):
                record = correction["record"]
                label = page.locator(f'[data-correction="{case["id"]}-{index}"]')
                label.evaluate(
                    "(e,markup)=>e.innerHTML=markup",
                    correction_markup(
                        record["original_value"],
                        record["corrected_value"],
                        show_deletions=figure.get("show_correction_deletions", False),
                    ),
                )
                if figure.get("mark_source_deletions", False):
                    mark_source_deletions(page, correction, views)
    directions = []
    for panel in figure["panels"]:
        direction = panel.get("directional_note")
        if not direction:
            continue
        case = cases[panel["id"]]
        assert not case["corrections"]
        values = [
            value
            for spec in case["tables"]
            for row in spec["values"].values()
            for value in row.values()
        ]
        assert any(direction["from"] in value for value in values)
        assert any(direction["to"] in value for value in values)
        spec = case["tables"][direction["anchor_table"]]
        headers, _ = views.load(spec["dataset"])
        key = f'{spec["dataset"]}:{direction["anchor_row"]}:{headers.index(direction["anchor_column"])}'
        section = page.locator(f'[data-case="{panel["id"]}"]')
        note = section.locator(".note")
        text = direction["from"] + " → " + direction["to"]
        tone = direction.get("tone", "conflict")
        assert tone in {"correction", "conflict"}
        before, after = esc(direction["from"]), esc(direction["to"])
        if figure.get("highlight_correction_edits", False):
            before = correction_markup(direction["from"], direction["to"], original_side=True)
            after = correction_markup(direction["from"], direction["to"])
        note.evaluate(
            "(e,markup)=>e.innerHTML=markup",
            '<div class="directional-row">'
            f'<span class="proposed-change {"corrected" if tone == "correction" else "conflict"}" '
            f'data-direction="{panel["id"]}">'
            f'<span class="change-from">{before}</span> '
            '<span class="change-arrow"><svg viewBox="0 0 20 12" role="img">'
            '<title>→</title><path d="M1 6H18M13 1L18 6L13 11"/></svg></span> '
            f'<span class="change-to">{after}</span></span></div>',
        )
        cell = section.locator(f'[data-cell="{key}"]').locator("..")
        if tone == "correction":
            assert section.locator(f'[data-cell="{key}"]').text_content() == direction["from"]
        if direction.get("focus_cell", False):
            assert tone == "correction"
            section.evaluate("e=>e.classList.add('direction-focus')")
            section.locator(".active-cell,.active-heading").evaluate_all(
                "es=>es.forEach(e=>e.classList.remove('active-cell','active-heading'))"
            )
            cell.evaluate("e=>e.classList.add('active-cell')")
            column = spec["columns"].index(direction["anchor_column"]) + 1
            section.locator(".column-letters th").nth(column).evaluate(
                "e=>e.classList.add('active-heading')"
            )
            assert section.locator("td.active-cell > [data-cell]").get_attribute("data-cell") == key
            assert cell.evaluate("e=>getComputedStyle(e).outlineStyle") == "solid"
            assert cell.locator("..").evaluate("e=>getComputedStyle(e).outlineStyle") == "none"
        cell_box, note_box = cell.bounding_box(), note.bounding_box()
        alignment = direction.get("alignment", "cell")
        assert alignment in {"panel", "cell"}
        anchor_box = section.bounding_box() if alignment == "panel" else cell_box
        center = anchor_box["x"] + anchor_box["width"] / 2
        annotation = section.locator("[data-direction]")
        annotation.evaluate("(e,x)=>e.style.left=x+'px'", center - note_box["x"])
        box = annotation.bounding_box()
        assert abs(box["x"] + box["width"] / 2 - center) < 1
        assert box["y"] >= cell_box["y"] + cell_box["height"]
        assert annotation.text_content() == text
        # Center the arrow on the visible text, rather than the font line box.
        # The original arrow glyph sits too low even when its span is centered.
        ink = annotation.evaluate("""e=>{
          const canvas=document.createElement('canvas');
          const context=canvas.getContext('2d');
          const centers=[...e.querySelectorAll('.change-from,.change-to')].map(side=>{
            const style=getComputedStyle(side);
            context.font=`${style.fontWeight} ${style.fontSize} ${style.fontFamily}`;
            const metrics=context.measureText(side.textContent);
            const probe=document.createElement('span');
            probe.style.cssText='display:inline-block;width:0;height:0;vertical-align:baseline';
            side.append(probe);
            const baseline=probe.getBoundingClientRect().top;
            probe.remove();
            return baseline+(metrics.actualBoundingBoxDescent-metrics.actualBoundingBoxAscent)/2;
          });
          const center=centers.reduce((a,b)=>a+b,0)/centers.length;
          const holder=e.querySelector('.change-arrow');
          const bounds=holder.getBoundingClientRect();
          const shift=center-bounds.top-bounds.height/2;
          holder.style.transform=`translateY(${shift}px)`;
          return {center,shift};
        }""")
        arrow = annotation.locator(".change-arrow svg").bounding_box()
        assert abs(arrow["x"] + arrow["width"] / 2 - box["x"] - box["width"] / 2) < 1
        assert abs(arrow["y"] + arrow["height"] / 2 - ink["center"]) < 0.5
        directions.append(
            {
                "case": panel["id"],
                "text": text,
                "anchor": key,
                "box": box,
                "tone": tone,
                "alignment": alignment,
                "center_x": center,
                "arrow_ink_alignment": ink,
            }
        )
    return directions


def verify_preview(page, figure, cases, views):
    displayed = page.locator("[data-cell]").evaluate_all(
        "es=>es.map(e=>({key:e.dataset.cell,value:e.textContent}))"
    )
    for cell in displayed:
        assert views.cells[cell["key"]] == cell["value"], cell
    for panel in figure["panels"]:
        case = cases[panel["id"]]
        section = page.locator(f'[data-case="{panel["id"]}"]')
        for index, spec in enumerate(case["tables"]):
            rows = panel.get("display_rows", spec["rows"])
            table = section.locator("table.source").nth(index)
            assert table.locator("tbody tr").count() == len(rows)
            assert table.locator("[data-source-row]").evaluate_all(
                "es=>es.map(e=>Number(e.dataset.sourceRow))"
            ) == [row for row in rows if row is not None]
        for index, correction in enumerate(case["corrections"]):
            accepted = correction["record"]["corrected_value"]
            label = section.locator(f'[data-correction="{case["id"]}-{index}"]')
            assert (
                label.evaluate("""e=>{
              const repaired=e.cloneNode(true);
              repaired.querySelectorAll('.deletion').forEach(node=>node.remove());
              return repaired.textContent;
            }""")
                == accepted
            )
            original = correction["record"]["original_value"]
            expected_deletions = []
            if figure.get("show_correction_deletions", False) and len(original) != len(accepted):
                expected_deletions = [
                    original[a:b]
                    for operation, a, b, _, _ in difflib.SequenceMatcher(
                        None, original, accepted
                    ).get_opcodes()
                    if operation == "delete"
                ]
            assert (
                label.locator(".deletion").evaluate_all("es=>es.map(e=>e.dataset.original)")
                == expected_deletions
            )
            column = case["tables"][0]["columns"].index(correction["record"]["column"])
            source = section.locator(".field-names th:not(.coord)").nth(column)
            a, b = source.bounding_box(), label.bounding_box()
            assert abs(a["x"] + a["width"] / 2 - b["x"] - b["width"] / 2) < 1
        # Error strings must remain fully visible; only long neighboring values
        # and the payee description may be visually truncated.
        if case["id"] not in {"I4"}:
            for spec in case["tables"]:
                headers, _ = views.load(spec["dataset"])
                for row, field in spec["marks"]:
                    key = f'{spec["dataset"]}:{row}:{headers.index(field)}'
                    assert section.locator(f'[data-cell="{key}"]').evaluate(
                        "e=>e.scrollWidth<=e.clientWidth+1"
                    ), key
    rows = page.locator("section").evaluate_all("""sections=>{
      const rows=[];
      sections.forEach(e=>{
        const y=Math.round(e.getBoundingClientRect().top);
        let row=rows.find(row=>Math.abs(row.top-y)<1);
        if(!row){row={top:y,ids:[]};rows.push(row);}
        row.ids.push(e.dataset.case);
      });
      return rows;
    }""")
    expected = (
        [row["ids"] for row in figure["scope_rows"]]
        if "scope_rows" in figure
        else [[panel["id"] for panel in figure["panels"]]]
    )
    assert [row["ids"] for row in rows] == expected
    if figure.get("hide_panel_titles"):
        scope = {key: row["label"] for row in figure.get("scope_rows", []) for key in row["ids"]}
        assert [text.strip() for text in page.locator("section > h2").all_text_contents()] == [
            f'({panel["letter"]})'
            + (" " + scope[panel["id"]] if figure.get("panel_scope_captions") else "")
            for panel in figure["panels"]
        ]
    if figure.get("panel_scope_captions") or figure.get("panel_caption_position") == "bottom":
        assert page.locator("section").evaluate_all("""es=>es.every(e=>{
          const caption=e.querySelector('h2').getBoundingClientRect();
          const example=e.querySelector('.example').getBoundingClientRect();
          return caption.top>=example.bottom;
        })""")
    alignment = []
    for row in rows:
        boxes = [
            page.locator(f'[data-case="{key}"]').evaluate("""e=>{
              const table=e.querySelector('table.source').getBoundingClientRect();
              const note=e.querySelector('.note').getBoundingClientRect();
              return {top:table.top,bottom:table.bottom,noteTop:note.top};
            }""")
            for key in row["ids"]
        ]
        for dimension in ("top", "bottom", "noteTop"):
            assert max(b[dimension] for b in boxes) - min(b[dimension] for b in boxes) < 1, (
                figure["asset"],
                row,
                dimension,
                boxes,
            )
        alignment.append({"ids": row["ids"], "boxes": boxes})
    overflow = page.locator(
        "table.source td,table.source th,h2,.scope-label,.correction"
    ).evaluate_all("es=>es.filter(e=>e.scrollWidth>e.clientWidth+1).map(e=>e.textContent)")
    assert not overflow, overflow
    assert page.locator(".clipped-value").evaluate_all("""es=>es.every(e=>{
      const range=document.createRange();
      range.setStart(e.firstChild,0);range.setEnd(e.firstChild,5);
      return range.getBoundingClientRect().width+10<e.clientWidth;
    })""")
    outside = page.locator("section,table.source,.note,.correction,.proposed-change").evaluate_all("""es=>{
      const f=document.querySelector('#figure').getBoundingClientRect();
      return es.filter(e=>{
        const r=e.getBoundingClientRect();
        return r.left<f.left-1||r.right>f.right+1||r.bottom>f.bottom+1;
      }).map(e=>e.textContent);
    }""")
    assert not outside, outside
    edits = page.locator(".correction .edit,.proposed-change .edit,.source-deletion").evaluate_all("""es=>es.map(e=>({
      text:e.textContent,color:getComputedStyle(e).color,
      deleted:e.classList.contains('deletion'),
      inSource:!!e.closest('table.source'),
      decoration:getComputedStyle(e).textDecorationLine
    }))""")
    assert all(edit["color"] == "rgb(198, 0, 0)" for edit in edits)
    assert all("line-through" in edit["decoration"] for edit in edits if edit["deleted"])
    return {
        "selected_ids": [panel["id"] for panel in figure["panels"]],
        "displayed_cells": displayed,
        "alignment": alignment,
        "worksheet_style": check_worksheet_style(page),
        "canvas": page.locator("#figure").bounding_box(),
        "printed_width_inches": COLUMN_WIDTH,
        "scope_labels": page.locator(".scope-label").all_text_contents(),
        "panel_captions": page.locator("section > h2").all_text_contents(),
        "display_headers": page.locator("[data-source-header]").evaluate_all(
            "es=>es.map(e=>({original:e.dataset.sourceHeader,display:e.textContent}))"
        ),
        "highlighted_corrections": edits,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--browser", required=True, type=Path)
    parser.add_argument("--asset", help="Render only one figure; preserve the other PDFs.")
    args = parser.parse_args()
    config_path = PAPER / "figures/error_type_preview.json"
    config = json.loads(config_path.read_text())
    options_path = PAPER / config["options"]
    options = json.loads(options_path.read_text())
    views = audit(options)
    cases = {case["id"]: case for case in options["examples"]}
    ids = [panel["id"] for figure in config["figures"] for panel in figure["panels"]]
    assert len(ids) == len(set(ids)) == 11
    figures = config["figures"]
    if args.asset:
        figures = [figure for figure in figures if figure["asset"] == args.asset]
        assert len(figures) == 1, args.asset
    folder = PAPER / "build/error_type_preview"
    folder.mkdir(parents=True, exist_ok=True)
    results = []
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(executable_path=str(args.browser), headless=True)
        for figure in figures:
            html = folder / f'{figure["asset"]}.html'
            html.write_text(document(figure, options, views))
            page = browser.new_page(
                viewport={"width": WIDTH, "height": 2400}, device_scale_factor=4
            )
            page.goto(html.as_uri())
            page.evaluate("document.fonts.ready")
            directions = prepare_preview(page, figure, cases, views)
            try:
                proof = verify_preview(page, figure, cases, views)
            except AssertionError:
                page.locator("#figure").screenshot(path=str(folder / "debug.png"))
                raise
            html.write_text(page.content())
            page.locator("#figure").screenshot(path=str(folder / f'{figure["asset"]}.png'))
            pdf = PAPER / "figures/paper" / f'{figure["asset"]}.pdf'
            page.pdf(
                path=str(pdf),
                width=f"{WIDTH}px",
                height=f'{proof["canvas"]["height"]}px',
                print_background=True,
                margin={"top": "0", "bottom": "0", "left": "0", "right": "0"},
            )
            results.append(
                {"asset": figure["asset"], "sha256": digest(pdf), "directions": directions, **proof}
            )
            page.close()
        browser.close()
    audit_name = f"audit_{args.asset}.json" if args.asset else "audit.json"
    (folder / audit_name).write_text(
        json.dumps(
            {
                "config_sha256": digest(config_path),
                "options_sha256": digest(options_path),
                "figures": results,
                "additional_model_calls": 0,
            },
            indent=2,
        )
        + "\n"
    )
    print(
        f"Verified {sum(len(r['selected_ids']) for r in results)} examples and "
        f"{sum(len(r['displayed_cells']) for r in results)} displayed source cells; "
        "manuscript text unchanged."
    )


if __name__ == "__main__":
    main()
