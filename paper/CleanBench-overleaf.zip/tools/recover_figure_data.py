"""Recover Figures 5/9 evidence offline; never initialize a model client.

Run with the harness environment: ../venv/bin/python tools/recover_figure_data.py
Raw call-level exports and the complete source manifest stay under build/.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
import subprocess
import sys
from collections import Counter, defaultdict
from pathlib import Path

PAPER = Path(__file__).resolve().parents[1]
HARNESS = PAPER.parent
MODELS = ("gpt-4.1", "gpt-5.2", "gpt-5.5", "gpt-6-astra")
CAMPAIGN = "outputs/prompt_tuning/dev200_none_20260930_continuation"
REPAIR = "outputs/prompt_tuning/task_scores_20261001"
CORRECTION = "outputs/prompt_tuning/correction_retuned_final_20261002"
SNAPSHOT = "outputs/baseline_campaign/20260910/snapshot"
EXPECTED = {
    "gpt-4.1": (27.65, 12.24, 86.87, 1.27),
    "gpt-5.2": (20.41, 17.61, 90.22, 1.05),
    "gpt-5.5": (58.15, 22.83, 91.71, 3.64),
    "gpt-6-astra": (72.69, 47.70, 93.98, 4.42),
}


class Evidence:
    def __init__(self, root):
        self.root = root
        self.hashes = {}

    def name(self, path):
        return str(Path(path).resolve().relative_to(self.root))

    def bytes(self, path, expected=None):
        path = Path(path)
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        if expected is not None:
            assert digest == expected, (path, "source hash mismatch")
        name = self.name(path)
        assert name not in self.hashes or self.hashes[name] == digest, path
        self.hashes[name] = digest
        return raw

    def read(self, path, expected=None):
        return json.loads(self.bytes(path, expected))

    def lines(self, path, expected=None):
        return [
            json.loads(s) for s in self.bytes(path, expected).decode().splitlines() if s.strip()
        ]


def json_write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def csv_write(path, rows):
    assert rows
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def index_events(evidence, roots):
    """Deduplicate copied ledgers by event ID, retaining every source location."""
    seen, locations = {}, defaultdict(list)
    for root in roots:
        path = root / "telemetry.jsonl"
        for line, event in enumerate(evidence.lines(path), 1):
            key = event["event_id"]
            assert key not in seen or seen[key] == event, (path, key)
            seen[key] = event
            locations[key].append({"path": evidence.name(path), "line": line})
    index = defaultdict(list)
    for event in seen.values():
        index[event["repetition"], event["request_sha256"]].append(event)
    return index, locations, seen


def unpriced_reason(tokens, rate, tier):
    if tokens is None:
        return "missing_or_invalid_usage"
    if rate is None:
        return "no_frozen_model_rate"
    if tier not in (None, "default", "standard", "auto"):
        return "unsupported_service_tier"
    if tokens["input_tokens"] > rate["max_priced_input_tokens"]:
        return "input_exceeds_frozen_pricing_limit"
    if tokens["cache_write_tokens"] and rate.get("cache_write") is None:
        return "no_cache_write_rate"
    return ""


def summarize(runs):
    rows = []
    for task in ("e2e", "correction"):
        for model in MODELS:
            group = [r for r in runs if r["task"] == task and r["model"] == model]
            assert len(group) == 3 and {r["repetition"] for r in group} == {1, 2, 3}
            offset = 0 if task == "e2e" else 2
            row = dict(task=task, model=model, repetitions=3)
            for metric in ("f1_percent", "recorded_cost_usd"):
                values = [r[metric] for r in group]
                row[metric + "_runs"] = json.dumps(values)
                for label, value in (
                    ("mean", statistics.mean(values)),
                    ("sample_sd", statistics.stdev(values)),
                    ("min", min(values)),
                    ("max", max(values)),
                ):
                    row[metric + "_" + label] = value
            row["paper_f1_percent"] = EXPECTED[model][offset]
            row["paper_cost_usd"] = EXPECTED[model][offset + 1]
            row["f1_rounding_matches"] = round(row["f1_percent_mean"], 2) == row["paper_f1_percent"]
            row["cost_rounding_matches"] = (
                round(row["recorded_cost_usd_mean"], 2) == row["paper_cost_usd"]
            )
            row["uncertainty_interpretation"] = "Three-run variability; not a confidence interval"
            rows.append(row)
    return rows


def recover_runs(evidence, out):
    sys.path.insert(0, str(evidence.root))
    from build_llm_baseline import load_runs
    from build_resource_usage import digest_text, price

    from external.gpt5_detect.secure_tuning import validate_issues
    from external.gpt5_detect.telemetry import normalized_usage
    from src.evaluation.llm_correction import changed_predictions, user_payload, validate_response
    from src.evaluation.paper_evaluation.analysis import GroundTruth, classify_table

    root = evidence.root
    campaign, repair, correction = (root / p for p in (CAMPAIGN, REPAIR, CORRECTION))
    # Existing verifier binds the selected configurations, benchmark, 24 repair
    # score records (both arms), correction selection locks and all receipt hashes.
    verified, benchmark_hash, sources = load_runs(campaign, repair, correction)
    for name, digest in sources.items():
        evidence.bytes(root / name, digest)
    derivation = evidence.read(repair / "derivation.json")
    for name, digest in derivation["receipt_hashes"].items():
        evidence.bytes(root / name, digest)
    report = evidence.read(campaign / "final_report/RESULTS.json")
    config = evidence.read(campaign / "config.json")
    selector = evidence.read(correction / "RESULTS.json")
    pricing = report["pricing"]
    json_write(out / "frozen_pricing.json", pricing)
    snapshot = root / SNAPSHOT
    manifest = evidence.read(snapshot / "_manifest.json")
    for name, digest in manifest["input_sha256"].items():
        evidence.bytes(snapshot / name, digest)
    truth = GroundTruth(snapshot, manifest)
    assert len(truth.eligible) == 1093 and len({c[0] for c in truth.eligible}) == 164
    tables = {}
    for ds, entry in manifest["datasets"].items():
        raw = evidence.bytes(snapshot / ds / "dirty.csv", entry["dirty_sha256"])
        import io

        grid = list(csv.reader(io.StringIO(raw.decode("utf-8-sig"), newline="")))
        assert grid[0] == entry["columns"]
        tables[ds] = grid[0], grid[1:]
    # Check the frozen numerical resource evidence without regenerating other tables.
    resource = evidence.read(PAPER / "build/generated/resource_usage_evidence.json")
    plans = []
    catalogs = {}
    index, locations, all_events = index_events(evidence, [campaign])
    catalogs[str(campaign)] = (index, locations, all_events)
    for model in MODELS:
        for rep in report["repetitions"]:
            n = rep["repetition"]
            record = next(r for r in rep["comparison"] if r["name"] == f"compare_{model}_selected")
            plans.append(
                (
                    "e2e",
                    model,
                    n,
                    n,
                    campaign,
                    [campaign],
                    campaign / f"rep_{n:02d}/recovered",
                    record,
                    config,
                )
            )
        current = root / selector["summary"][model]["source"]
        roots = [current]
        while (roots[-1] / "cache_provenance.json").exists():
            provenance = evidence.read(roots[-1] / "cache_provenance.json")
            roots.append(root / provenance["source"])
            assert len(roots) == len(set(roots)), "Cyclic cache provenance"
        if str(current) not in catalogs:
            catalogs[str(current)] = index_events(evidence, roots)
        correction_config = evidence.read(current / "config.json")
        assert correction_config["pricing"] == pricing
        result = evidence.read(current / model / "RESULTS.json")
        for rep in result["comparisons"]:
            n = rep["repetition"]
            plans.append(
                (
                    "correction",
                    model,
                    n,
                    n + 3,
                    current,
                    roots,
                    current / f"rep_{n+3:02d}",
                    rep["arms"]["selected"],
                    correction_config,
                )
            )

    runs, calls, used_events, per_table = [], [], set(), []
    for task, model, rep, original_rep, current, roots, phase, record, cfg in plans:
        index, locations, _ = catalogs[str(current)]
        prompt_path = phase / record["name"] / "prompt.txt"
        prompt = evidence.bytes(prompt_path, record["prompt_sha256"]).decode()
        prompt_hash = record["prompt_sha256"]
        effort = "low" if model == "gpt-6-astra" else "none"
        configuration = f"{task}/{model}/effort={effort}/prompt={prompt_hash}"
        run_id = f"{evidence.name(current)}/{task}/{model}/rep_{rep:02d}"
        folder = phase / "requests" / model / digest_text(prompt)
        receipts = sorted(folder.glob("*.json"))
        expected = 1000 if task == "e2e" else 164
        assert len(receipts) == expected
        if task == "correction":
            assert {p.stem for p in receipts} == set(cfg["locations"])
            evidence.bytes(
                phase / record["name"] / "predictions.jsonl", record["predictions_sha256"]
            )
        total = Counter()
        cost, predictions, failed = 0.0, {}, []
        run_calls = []
        for path in receipts:
            receipt = evidence.read(path)
            ds = path.stem
            headers, data = tables[ds]
            payload = (
                json.dumps(
                    {
                        "headers": headers,
                        "rows": [{"row": i, "values": row} for i, row in enumerate(data)],
                    },
                    ensure_ascii=False,
                )
                if task == "e2e"
                else user_payload(headers, data, cfg["locations"][ds])
            )
            assert digest_text([model, effort, prompt, payload]) == receipt["request_sha256"]
            matched = index[original_rep, receipt["request_sha256"]]
            invocations = sorted(
                (e for e in matched if e["event"] == "sdk_invocation"),
                key=lambda e: (e["started_at"], e["event_id"]),
            )
            assert invocations and any(e["event"] == "query" for e in matched), path
            starts = {e["invocation_id"] for e in matched if e["event"] == "sdk_invocation_started"}
            assert starts == {e["event_id"] for e in invocations}, path
            if receipt["status"] == "success":
                assert any(
                    e.get("response_text_sha256") == digest_text(receipt["raw"])
                    for e in invocations
                ), path
                if task == "e2e":
                    issues = validate_issues(receipt["raw"], headers, data)
                    assert issues == receipt["issues"]
                    changes = [
                        dict(
                            dataset=ds,
                            row=x["row"],
                            col=headers.index(x["column"]),
                            corrected_value=x["corrected_value"],
                        )
                        for x in issues
                        if x["corrected_value"] is not None
                        and x["corrected_value"] != data[x["row"]][headers.index(x["column"])]
                    ]
                else:
                    corrections = validate_response(receipt["raw"], headers, cfg["locations"][ds])
                    assert corrections == receipt["corrections"]
                    changes = changed_predictions(ds, headers, data, corrections)
                for change in changes:
                    cell = (ds, change["row"], change["col"])
                    # Existing valued-prediction loaders use last-write coordinate dedupe.
                    predictions[cell] = change["corrected_value"]
            else:
                failed.append(ds)
            for attempt, event in enumerate(invocations, 1):
                assert event["model"] == model
                assert (
                    event["event_id"] not in used_events
                ), "An invocation was charged to two final runs"
                used_events.add(event["event_id"])
                tokens = event.get("tokens")
                assert tokens == normalized_usage(event.get("usage"))
                rate = pricing["models"][model]
                reason = unpriced_reason(tokens, rate, event.get("service_tier"))
                usd = price(tokens, rate, event.get("service_tier"))
                assert (usd is None) == bool(reason)
                cost += usd if usd is not None else 0.0
                total["unpriced_calls"] += usd is None
                total["missing_usage_calls"] += tokens is None
                stage = event.get("stage", "")
                reused = stage != record["name"]
                locs = locations[event["event_id"]]
                call = dict(
                    task=task,
                    model=model,
                    actual_model=event.get("response_model"),
                    configuration_id=configuration,
                    prompt_sha256=prompt_hash,
                    run_id=run_id,
                    repetition=rep,
                    original_repetition_id=original_rep,
                    table_id=ds,
                    request_sha256=receipt["request_sha256"],
                    event_id=event["event_id"],
                    invocation_id=event["event_id"],
                    query_id=event.get("query_id"),
                    response_id=event.get("response_id"),
                    attempt_id=attempt,
                    attempt_unit="Recorded SDK invocation; internal SDK retries are not individually observed",
                    is_final_evaluation=True,
                    is_retry=attempt > 1,
                    reused_development_response=reused,
                    origin_stage=stage,
                    origin_phase=event.get("phase"),
                    origin_role=event.get("role"),
                    copied_cache_ledger=len(locs) > 1,
                    status=event.get("status"),
                    final_receipt_status=receipt["status"],
                    usage_present=event.get("usage") is not None,
                    normalized_usage_present=tokens is not None,
                    **{
                        k: tokens[k] if tokens else None
                        for k in (
                            "input_tokens",
                            "output_tokens",
                            "cached_input_tokens",
                            "cache_write_tokens",
                            "reasoning_tokens",
                            "total_tokens",
                        )
                    },
                    service_tier=event.get("service_tier"),
                    sdk_max_retries=event.get("sdk_max_retries"),
                    pricing_checked_on=pricing["checked_on"],
                    pricing_unit_tokens=pricing["unit_tokens"],
                    input_rate=rate["input"],
                    cache_read_rate=rate["cached_input"],
                    cache_write_rate=rate["cache_write"],
                    output_rate=rate["output"],
                    max_priced_input_tokens=rate["max_priced_input_tokens"],
                    cost_kind="Frozen standard text-token reference estimate; not an invoice",
                    cost_usd=usd,
                    priced=usd is not None,
                    unpriced_reason=reason,
                    usage_error=event.get("usage_error"),
                    http_status=event.get("http_status"),
                    raw_usage_json=json.dumps(event.get("usage"), sort_keys=True),
                    source_log=locs[0]["path"],
                    source_log_sha256=evidence.hashes[locs[0]["path"]],
                    source_line=locs[0]["line"],
                    all_source_locations_json=json.dumps(locs),
                    receipt_source=evidence.name(path),
                    receipt_sha256=evidence.hashes[evidence.name(path)],
                )
                calls.append(call)
                run_calls.append(call)
        assert len(failed) == (
            record["failed_tables"]
            if isinstance(record["failed_tables"], int)
            else len(record["failed_tables"])
        )
        counts = Counter()
        by_table = defaultdict(dict)
        for cell, value in predictions.items():
            by_table[cell[0]][cell] = value
        for ds in (p.stem for p in receipts):
            errors = {c for c in truth.errors if c[0] == ds}
            row, _ = classify_table(
                by_table[ds],
                errors,
                truth.ambiguous,
                errors & truth.eligible,
                truth.accepted,
                task,
                "failed" if ds in failed else "complete",
                truth.immune,
            )
            counts.update({k: row[k] for k in ("tp", "fp", "fn")})
            per_table.append(
                dict(
                    run_id=run_id,
                    task=task,
                    model=model,
                    repetition=rep,
                    table_id=ds,
                    tp=row["tp"],
                    fp=row["fp"],
                    fn=row["fn"],
                    execution=row["execution"],
                )
            )
        frozen = verified[task, model, "selected"][rep - 1]
        assert all(counts[k] == frozen[k] for k in ("tp", "fp", "fn")), (run_id, counts, frozen)
        ref = next(
            r
            for r in resource["rows"]
            if r["task"] == ("Detection/repair" if task == "e2e" else "Correction")
            and r["model"] == model.replace("gpt", "GPT")
            and r["interface"] == "API Tuned"
        )
        ref = ref["repetitions"][rep - 1]
        assert math.isclose(cost, ref["usd"], rel_tol=1e-12)
        assert len(run_calls) == ref["sdk_invocations"]
        assert total["unpriced_calls"] == ref.get("unpriced_calls", 0)
        assert total["missing_usage_calls"] == ref.get("missing_usage", 0)
        tp, fp, fn = (counts[k] for k in ("tp", "fp", "fn"))
        assert tp + fn == 1093
        runs.append(
            dict(
                task=task,
                model=model,
                configuration_id=configuration,
                prompt_sha256=prompt_hash,
                run_id=run_id,
                repetition=rep,
                original_repetition_id=original_rep,
                tables_expected=expected,
                tables_scored=len(receipts),
                successful_tables=expected - len(failed),
                tp=tp,
                fp=fp,
                fn=fn,
                precision=tp / (tp + fp) if tp + fp else 0.0,
                recall=tp / (tp + fn),
                f1_percent=100 * 2 * tp / (2 * tp + fp + fn),
                recorded_cost_usd=cost,
                priced_calls=len(run_calls) - total["unpriced_calls"],
                unpriced_calls=total["unpriced_calls"],
                missing_usage_calls=total["missing_usage_calls"],
                failed_tables=len(failed),
                failed_table_ids=json.dumps(failed),
                reused_development_calls=sum(c["reused_development_response"] for c in run_calls),
                retry_invocations=sum(c["is_retry"] for c in run_calls),
                metrics_source=(
                    f"{REPAIR}/e2e_scores.json#rep_{rep:02d}/{model}/selected"
                    if task == "e2e"
                    else f"{evidence.name(current)}/{model}/RESULTS.json#comparisons/{rep}/arms/selected"
                ),
                cost_source=json.dumps([evidence.name(p / "telemetry.jsonl") for p in roots]),
                benchmark_sha256=benchmark_hash,
                reasoning_effort=effort,
                configuration_source=evidence.name(current / "config.json"),
                scope_policy="Full population includes development tables; not a held-out score",
            )
        )
        print(
            f"Verified {task} {model} run {rep}: F1={runs[-1]['f1_percent']:.5f}, USD={cost:.8f}",
            flush=True,
        )
    assert len(runs) == 24
    csv_write(out / "figure9_runs.csv", runs)
    csv_write(out / "figure9_cost_calls.csv", calls)
    csv_write(out / "figure9_table_counts.csv", per_table)
    csv_write(out / "figure9_summary.csv", summarize(runs))
    # Supplementary accounting: union each physical invocation across copied
    # search ledgers. Final invocations are removed before reporting search costs.
    unique, locs = {}, defaultdict(list)
    search_roots = {p for plan in plans for p in plan[5]}
    search_roots.add(root / "outputs/prompt_tuning/dev200_none_20260930")
    proposal_root = root / "outputs/prompt_tuning/correction_gpt52_astra_proposals_20261002"
    if (proposal_root / "telemetry.jsonl").exists():
        search_roots.add(proposal_root)
    for current in sorted(search_roots):
        if not (current / "telemetry.jsonl").exists():
            continue
        _, places, events = index_events(evidence, [current])
        for key, event in events.items():
            assert key not in unique or unique[key] == event
            unique[key] = event
            locs[key].extend(places[key])
    phases = defaultdict(lambda: Counter())
    for event in unique.values():
        if event["event"] != "sdk_invocation":
            continue
        role, stage = event.get("role", ""), event.get("stage", "")
        if event["event_id"] in used_events:
            phase_name = "selected_final_evaluation"
        elif role == "writer":
            phase_name = "strategy_writing"
        elif role == "judge":
            phase_name = "judge_validation"
        elif (
            stage.startswith("develop_")
            or stage.startswith("optimize_")
            or stage.startswith("initial")
            or stage == "optimizer_baseline"
        ):
            phase_name = "development_evaluation"
        elif stage.startswith("compare_"):
            phase_name = "other_comparison_evaluation"
        else:
            phase_name = "other_recorded_search"
        group = phases[phase_name, event["model"]]
        tokens, rate = event.get("tokens"), pricing["models"].get(event["model"])
        usd = price(tokens, rate, event.get("service_tier")) if rate else None
        group["calls"] += 1
        group["priced_calls"] += usd is not None
        group["unpriced_calls"] += usd is None
        group["missing_usage_calls"] += tokens is None
        group["recorded_cost_usd"] += usd if usd is not None else 0
    csv_write(
        out / "optimization_costs.csv",
        [
            dict(
                phase=p,
                calling_model=m,
                **values,
                attribution="Recorded model is the caller, not a beneficiary allocation; search overhead remains shared",
                scope="Observed deduplicated ledgers, not a complete optimization invoice",
            )
            for (p, m), values in sorted(phases.items())
        ],
    )
    json_write(
        out / "figure9_accounting.json",
        dict(
            final_invocations=len(calls),
            distinct_final_event_ids=len(used_events),
            source_ledger_roots=[evidence.name(p) for p in sorted(search_roots)],
            unpriced_reasons=dict(Counter(c["unpriced_reason"] for c in calls if not c["priced"])),
            internal_sdk_retry_visibility="SDK invocations are observed; SDK-internal HTTP attempts may retry up to sdk_max_retries and are not separately logged.",
            unknown_cost_recovery="Missing response usage cannot be recovered from these files; provider usage/billing records would be needed. No unknown call is assigned zero cost.",
            token_policy="input includes cache reads/writes; ordinary=input-read-write; output includes reasoning. Cached/reasoning tokens are not added twice.",
            source_hash_policy="SHA-256 hashes file bytes. Request/prompt cache identities hash JSON-encoded objects; prompt_sha256 hashes actual prompt file bytes.",
            pricing_kind=pricing["interpretation"],
        ),
    )
    return runs, calls


def recover_agents(evidence, out):
    """Export only already audited native CLI evidence, without converting credits to USD."""
    resource = evidence.read(PAPER / "build/generated/resource_usage_evidence.json")
    rows = []
    for row in resource["rows"]:
        if row["interface"].startswith("API"):
            continue
        rows.append(row)
    verified_native_sources = 0
    for name, digest in resource["source_sha256"].items():
        if name.startswith("outputs/coding_agents/"):
            evidence.bytes(evidence.root / name, digest)
            verified_native_sources += 1
    csv_write(
        out / "coding_agent_costs.csv",
        [
            dict(
                task=row["task"],
                model=row["model"],
                interface=row["interface"],
                tables=int(row["mean"]["tables"]),
                failed_tables=int(row["mean"].get("failed_tables", 0)),
                premium_requests=row["mean"].get("premium_requests"),
                nano_aiu=row["mean"].get("nano_aiu"),
                cli_reference_cost_usd=row["mean"].get("usd"),
                actual_invoice_usd=None,
                attributable_subscription_usd=None,
                comparable_api_usd=None,
                cost_basis="Claude Code CLI reference estimate"
                if row["interface"] == "Claude Code"
                else "Native premium-request/AIU counters"
                if row["interface"] == "Copilot"
                else "Native token telemetry only",
                coverage="Final retained table invocations only; discarded or historical CLI attempts are not covered",
            )
            for row in rows
        ],
    )
    json_write(
        out / "coding_agent_cost_evidence.json",
        dict(
            records=rows,
            policy="Native CLI telemetry is not an invoice. Premium-request/AIU counters, subscription charges, and CLI reference USD remain distinct. No credit-to-USD conversion or comparison with API USD is made.",
            verified_native_source_files=verified_native_sources,
            source_evidence_sha256=evidence.hashes[
                evidence.name(PAPER / "build/generated/resource_usage_evidence.json")
            ],
            limitation="The existing resource audit covers final retained table invocations, not every historical or discarded CLI attempt. Actual invoices and subscription allocation are unavailable.",
        ),
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--harness", type=Path, default=HARNESS)
    parser.add_argument("--out", type=Path, default=PAPER / "build/figure_data_recovery")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    evidence = Evidence(args.harness.resolve())
    from recover_figure_examples import recover_examples

    recover_examples(evidence, args.out, SNAPSHOT)
    recover_runs(evidence, args.out)
    recover_agents(evidence, args.out)
    # Bind extraction and scoring implementations as well as input artifacts.
    for name in (
        "recover_figure_data.py",
        "recover_figure_examples.py",
        "verify_figure_data.py",
        "test_recover_figure_data.py",
    ):
        evidence.bytes(PAPER / "tools" / name)
    for name in (
        "CleanBench/tools/build_llm_baseline.py",
        "CleanBench/tools/build_resource_usage.py",
        "src/evaluation/paper_evaluation/analysis.py",
        "external/rein/score.py",
        "external/rein/score_repair.py",
        "external/gpt5_detect/secure_tuning.py",
        "external/gpt5_detect/telemetry.py",
        "src/evaluation/llm_correction.py",
        "experiments/export_row_benchmark.py",
        "src/evaluation/broader_scope/prepare.py",
    ):
        evidence.bytes(evidence.root / name)
    json_write(
        args.out / "source_hashes.json",
        dict(
            algorithm="SHA-256 of file bytes",
            sources=dict(sorted(evidence.hashes.items())),
            harness_revision=subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=evidence.root, text=True
            ).strip(),
            paper_revision=subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=PAPER, text=True
            ).strip(),
            requested_paper_revision="d329674",
            local_changes_policy="Actual file bytes are hashed; working-tree changes are not reset or staged.",
        ),
    )
    print(f"Recovered evidence to {args.out}; {len(evidence.hashes)} source hashes", flush=True)


if __name__ == "__main__":
    main()
