"""Independently verify recovered exports, source bytes, joins and arithmetic."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path


def load_csv(path):
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle))


def verify_pairing(runs, calls):
    by_run = defaultdict(list)
    seen = set()
    for call in calls:
        assert call["event_id"] not in seen, "Duplicate physical invocation"
        seen.add(call["event_id"])
        by_run[call["run_id"]].append(call)
        if call["priced"] == "True":
            assert call["cost_usd"] != "" and call["unpriced_reason"] == ""
            ordinary = (
                int(call["input_tokens"])
                - int(call["cached_input_tokens"])
                - int(call["cache_write_tokens"])
            )
            assert ordinary >= 0
            cost = (
                ordinary * float(call["input_rate"])
                + int(call["cached_input_tokens"]) * float(call["cache_read_rate"])
                + int(call["cache_write_tokens"]) * float(call["cache_write_rate"] or 0)
                + int(call["output_tokens"]) * float(call["output_rate"])
            ) / int(call["pricing_unit_tokens"])
            assert math.isclose(float(call["cost_usd"]), cost, rel_tol=1e-12)
        else:
            assert call["cost_usd"] == "", "Unknown cost must be empty, not zero"
            assert call["unpriced_reason"]
    assert set(by_run) == {r["run_id"] for r in runs}
    for run in runs:
        matched = by_run[run["run_id"]]
        for call in matched:
            for key in (
                "task",
                "model",
                "configuration_id",
                "prompt_sha256",
                "repetition",
                "original_repetition_id",
            ):
                assert call[key] == run[key], ("Quality/cost join mismatch", key)
        assert len({c["table_id"] for c in matched}) == int(run["tables_expected"])
        priced = [c for c in matched if c["priced"] == "True"]
        assert len(priced) == int(run["priced_calls"])
        assert len(matched) - len(priced) == int(run["unpriced_calls"])
        assert sum(c["normalized_usage_present"] == "False" for c in matched) == int(
            run["missing_usage_calls"]
        )
        assert math.isclose(
            math.fsum(float(c["cost_usd"]) for c in priced),
            float(run["recorded_cost_usd"]),
            rel_tol=1e-12,
        )
        assert int(run["tables_scored"]) == int(run["tables_expected"])
        assert int(run["tables_expected"]) == (1000 if run["task"] == "e2e" else 164)
        assert int(run["original_repetition_id"]) == int(run["repetition"]) + (
            3 if run["task"] == "correction" else 0
        )
        tp, fp, fn = (int(run[k]) for k in ("tp", "fp", "fn"))
        assert tp + fn == 1093
        for key, value in (
            ("precision", tp / (tp + fp)),
            ("recall", tp / (tp + fn)),
            ("f1_percent", 100 * 2 * tp / (2 * tp + fp + fn)),
        ):
            assert math.isclose(float(run[key]), value, rel_tol=1e-12)


def verify(folder, harness):
    manifest = json.loads((folder / "source_hashes.json").read_text())
    for name, digest in manifest["sources"].items():
        assert hashlib.sha256((harness / name).read_bytes()).hexdigest() == digest, name
    runs = load_csv(folder / "figure9_runs.csv")
    calls = load_csv(folder / "figure9_cost_calls.csv")
    assert len(runs) == 24
    assert len({(r["task"], r["model"], r["repetition"]) for r in runs}) == 24
    assert len({r["model"] for r in runs}) == 4 and {r["task"] for r in runs} == {
        "e2e",
        "correction",
    }
    verify_pairing(runs, calls)
    for summary in load_csv(folder / "figure9_summary.csv"):
        group = [r for r in runs if r["model"] == summary["model"] and r["task"] == summary["task"]]
        assert {r["repetition"] for r in group} == {"1", "2", "3"}
        for key in ("f1_percent", "recorded_cost_usd"):
            values = [float(r[key]) for r in group]
            assert math.isclose(
                statistics.mean(values), float(summary[key + "_mean"]), rel_tol=1e-12
            )
            assert math.isclose(
                statistics.stdev(values), float(summary[key + "_sample_sd"]), rel_tol=1e-12
            )
    by_table = defaultdict(lambda: [0, 0, 0])
    for row in load_csv(folder / "figure9_table_counts.csv"):
        for i, k in enumerate(("tp", "fp", "fn")):
            by_table[row["run_id"]][i] += int(row[k])
    for run in runs:
        assert by_table[run["run_id"]] == [int(run[k]) for k in ("tp", "fp", "fn")]
    examples = json.loads((folder / "figure5_examples.json").read_text())
    snapshot = json.loads((harness / examples["snapshot"]["path"] / "_manifest.json").read_text())
    for example in examples["examples"]:
        for excerpt in example["excerpt"]:
            entry = snapshot["datasets"][excerpt["dataset_id"]]
            with (harness / excerpt["frozen_csv_path"]).open(
                newline="", encoding="utf-8-sig"
            ) as handle:
                grid = list(csv.reader(handle))
            assert grid[0] == excerpt["original_columns"]
            cols = [c["csv_column"] for c in excerpt["column_mapping"]]
            for row in excerpt["records"]:
                assert entry["exported_to_source"][row["snapshot_row"]] == row["original_row"]
                original = grid[row["snapshot_row"] + 1]
                assert row["full_original_record"] == original
                assert row["values"] == [original[c] for c in cols]
        if example["scope"] == "multi_table":
            assert example["correction"]["human_accepted_replacement_values"] == []
            assert example["correction"]["target"] is None
    result = dict(
        status="passed",
        final_runs=len(runs),
        distinct_invocations=len(calls),
        literal_examples=len(examples["examples"]),
        verified_source_files=len(manifest["sources"]),
        source_integrity=True,
        quality_cost_pairing=True,
        micro_counts=True,
        missing_cost_is_not_zero=True,
        excerpt_strings_and_coordinates=True,
        output_sha256={
            p.name: hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(folder.iterdir())
            if p.is_file() and p.name != "verification.json"
        },
    )
    (folder / "verification.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "output_sha256"}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--out",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "build/figure_data_recovery",
    )
    parser.add_argument("--harness", type=Path, default=Path(__file__).resolve().parents[2])
    args = parser.parse_args()
    verify(args.out, args.harness)
