"""Render the separate all-table precision / target-table recall comparison.

Precision and recall are copied from the frozen summary scores. F1 is the
harmonic mean of those unrounded summaries, computed after run aggregation.
Neither existing table-level F1 definition is substituted for this new score.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from build_accuracy_presentation import CMAP, NORM, TYPES, positions
from build_macro_heatmap import category_label, read_csv, score
from figure_style import FIGURE_WIDTH, configure, save
from matplotlib.cm import ScalarMappable
from matplotlib.patches import Rectangle

PAPER = Path(__file__).resolve().parents[1]
GENERATED = PAPER / "assets/generated"
PRECISION_SOURCE = GENERATED / "empty_match_type_metrics.csv"
RECALL_SOURCE = GENERATED / "macro_type_metrics.csv"
ROSTER = GENERATED / "task_type_metrics.csv"
CSV_TARGET = GENERATED / "no_empty_recall_type_metrics.csv"
PDF_TARGET = GENERATED / "no_empty_recall_heatmap.pdf"
BLOCKS = (("overall", "Overall (%)", ("P", "R", "F1")),) + tuple(
    (key, label, ("P", "R")) for key, label in TYPES
)
FIELDS = {"P": "macro_precision", "R": "macro_recall", "F1": "macro_f1"}
CSV_FIELDS = (
    "method",
    "category",
    "group",
    "error_type",
    "error_type_label",
    "runs",
    "tables",
    "target_tables",
    "macro_precision_tables",
    "macro_recall_tables",
    "macro_precision",
    "macro_recall",
    "macro_f1",
    "f1_aggregation",
    "source_all_table_macro_f1",
    "source_target_macro_f1",
    "source_all_table_macro_recall",
    "source_target_macro_precision",
    "preservation_tables",
    "preservation",
)


def harmonic(precision, recall):
    return 2 * precision * recall / (precision + recall) if precision + recall else 0.0


def inputs():
    roster = [
        row
        for row in read_csv(ROSTER)
        if row["task"] == "e2e"
        and not (row["category"] == "Direct LLMs (API)" and row["method"].endswith(" (Base)"))
    ]
    expected = {(row["method"], key) for row in roster for key, _, _ in BLOCKS}
    if len(roster) != 23 or len(expected) != 92:
        raise ValueError("Expected 23 published workflows and four score groups")
    all_rows, target_rows = read_csv(PRECISION_SOURCE), read_csv(RECALL_SOURCE)
    all_scores = {(row["method"], row["error_type"]): row for row in all_rows}
    target_scores = {(row["method"], row["error_type"]): row for row in target_rows}
    if (
        len(all_rows) != 92
        or len(target_rows) != 92
        or all_scores.keys() != expected
        or target_scores.keys() != expected
    ):
        raise ValueError("Source summary rosters differ")
    derived = []
    for method in (row["method"] for row in roster):
        for key, _, _ in BLOCKS:
            all_row, target_row = all_scores[method, key], target_scores[method, key]
            if all_row["runs"] != target_row["runs"] or all_row["tables"] != target_row["tables"]:
                raise ValueError(f"Source evaluation populations differ: {method}, {key}")
            if int(all_row["macro_precision_tables"]) != 1000 or int(
                target_row["macro_recall_tables"]
            ) != int(target_row["target_tables"]):
                raise ValueError(f"Unexpected P/R averaging populations: {method}, {key}")
            precision, recall = score(all_row, "macro_precision"), score(target_row, "macro_recall")
            if precision is None or recall is None:
                raise ValueError(f"Undefined P/R summary: {method}, {key}")
            row = {field: target_row[field] for field in CSV_FIELDS if field in target_row}
            row.update(
                macro_precision_tables="1000",
                macro_recall_tables=target_row["target_tables"],
                macro_precision=all_row["macro_precision"],
                macro_recall=target_row["macro_recall"],
                macro_f1=repr(harmonic(precision, recall)),
                f1_aggregation="harmonic_of_unrounded_summary_precision_and_recall",
                source_all_table_macro_f1=all_row["macro_f1"],
                source_target_macro_f1=target_row["macro_f1"],
                source_all_table_macro_recall=all_row["macro_recall"],
                source_target_macro_precision=target_row["macro_precision"],
            )
            derived.append(row)
    return roster, derived


def draw(roster, rows, *, target=PDF_TARGET, conditional_precision=False, balanced_accuracy=False):
    blocks = (
        tuple((key, label, ("TPR", "TNR", "BA")) for key, label, _ in BLOCKS)
        if balanced_accuracy
        else BLOCKS
    )
    fields = (
        {"TPR": "table_tpr", "TNR": "table_tnr", "BA": "table_balanced_accuracy"}
        if balanced_accuracy
        else FIELDS
    )
    indexed = {(row["method"], row["error_type"]): row for row in rows}
    methods, categories, extent = positions(roster)
    grid_height = extent * 0.125
    height = grid_height + 0.86
    fig = plt.figure(figsize=(FIGURE_WIDTH, height))
    left, width, top = 0.29, 0.70, 1 - 0.53 / height
    ax = fig.add_axes([left, top - grid_height / height, width, grid_height / height])
    starts, end = [], 0.0
    for _, _, metrics in blocks:
        starts.append(end)
        end += len(metrics) + 0.16
    xmax = end - 0.16
    label_x = (0.01 - left) / width * xmax
    label_pad = 0.04 / (width * FIGURE_WIDTH) * xmax
    ink = "#253342"
    ax.set_xlim(0, xmax)
    ax.set_ylim(extent, 0)
    ax.axis("off")
    for y, thickness in ((-3.35, 0.8), (-0.05, 0.6), (extent, 0.8)):
        ax.plot([label_x, xmax], [y, y], color=ink, linewidth=thickness, clip_on=False)
    for start, (key, label, metrics) in zip(starts, blocks, strict=True):
        ax.text(
            start + len(metrics) / 2,
            -2.75,
            label,
            ha="center",
            va="center",
            weight="bold",
            color=ink,
        )
        ax.plot(
            [start + 0.05, start + len(metrics) - 0.05],
            [-1.20, -1.20],
            color="#a8b2bd",
            linewidth=0.45,
            clip_on=False,
        )
        first = indexed[roster[0]["method"], key]
        for index, metric in enumerate(metrics):
            if balanced_accuracy:
                population = (
                    "mean"
                    if metric == "BA"
                    else f"n={int(first['target_tables' if metric == 'TPR' else 'no_target_tables']):,}"
                )
            elif conditional_precision and metric == "P":
                population = "edits > 0"
            elif conditional_precision and metric == "F1":
                population = "from P,R"
            else:
                population = (
                    "H(P,R)"
                    if metric == "F1"
                    else f"n={int(first['macro_precision_tables' if metric == 'P' else 'macro_recall_tables']):,}"
                )
            ax.text(start + index + 0.5, -1.72, population, ha="center", va="center", color=ink)
            ax.text(start + index + 0.5, -0.66, metric, ha="center", va="center", color=ink)
    ax.text(label_x + label_pad, -0.66, "Method", ha="left", va="center", weight="bold", color=ink)
    for y, label in categories:
        ax.add_patch(
            Rectangle(
                (label_x, y - 0.4),
                xmax - label_x,
                0.8,
                facecolor="#edf1f5",
                edgecolor="none",
                clip_on=False,
            )
        )
        ax.text(
            label_x + label_pad,
            y,
            category_label(label),
            ha="left",
            va="center",
            weight="bold",
            color=ink,
        )
    displayed = []
    for y, row in methods:
        method = row["method"]
        ax.text(
            label_x + label_pad, y, method.removesuffix(" (Prompt-tuned)"), ha="left", va="center"
        )
        ax.plot(
            [label_x, xmax],
            [y + 0.5, y + 0.5],
            color="#e4e9ee",
            linewidth=0.3,
            clip_on=False,
            zorder=0,
        )
        for start, (key, _, metrics) in zip(starts, blocks, strict=True):
            for index, metric in enumerate(metrics):
                value = score(indexed[method, key], fields[metric])
                text = "—" if value is None else format(value, ".2f" if key == "overall" else ".1f")
                x = start + index
                ax.add_patch(
                    Rectangle(
                        (x, y - 0.5),
                        1,
                        1,
                        facecolor="#f3f5f7" if value is None else CMAP(NORM(value)),
                        edgecolor="white",
                        linewidth=0.45,
                    )
                )
                ax.text(
                    x + 0.5,
                    y,
                    text,
                    ha="center",
                    va="center",
                    color="white" if value is not None and value >= 80 else "black",
                    weight="bold" if key == "overall" else "normal",
                )
                displayed.append(
                    {
                        "method": method,
                        "error_type": key,
                        "metric": metric,
                        "value": value,
                        "text": text,
                    }
                )
    color_ax = fig.add_axes([0.75, 0.22 / height, 0.22, 0.065 / height])
    bar = fig.colorbar(ScalarMappable(norm=NORM, cmap=CMAP), cax=color_ax, orientation="horizontal")
    bar.solids.set_rasterized(False)
    bar.solids.set_edgecolor("face")
    bar.set_ticks([0, 50, 100])
    bar.ax.tick_params(length=2, pad=2)
    bar.ax.text(-0.10, 0.5, "Score (%)", ha="right", va="center", transform=bar.ax.transAxes)
    bar.outline.set_linewidth(0.4)
    save(fig, target, check_layout=True)
    plt.close(fig)
    return displayed, height


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--validate-only", action="store_true", help="Check inputs without writing derived assets"
    )
    arguments = parser.parse_args()
    sources = (PRECISION_SOURCE, RECALL_SOURCE, ROSTER)
    source_hashes = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in sources}
    roster, rows = inputs()
    if arguments.validate_only:
        print("Validated 92 P/R summaries and their post-aggregation harmonic F1")
        return
    with CSV_TARGET.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    configure()
    displayed, height = draw(roster, read_csv(CSV_TARGET))
    if len(displayed) != 207:
        raise ValueError("Expected nine displayed metrics for each of the 23 workflows")
    for path in sources:
        if hashlib.sha256(path.read_bytes()).hexdigest() != source_hashes[path.name]:
            raise ValueError(f"Source changed during rendering: {path.name}")
    evidence = {
        "sources_sha256": source_hashes,
        "derived_csv_sha256": hashlib.sha256(CSV_TARGET.read_bytes()).hexdigest(),
        "workflows": 23,
        "method_subgroups": len(positions(roster)[1]),
        "score_rows": len(rows),
        "numeric_cells": len(displayed),
        "width_inches": FIGURE_WIDTH,
        "height_inches": height,
        "font_size_bp": 8,
        "precision_tables": 1000,
        "recall_tables": {
            key: int(rows[index]["macro_recall_tables"]) for index, (key, _, _) in enumerate(BLOCKS)
        },
        "f1_aggregation": "Harmonic mean of unrounded summary P and R, after each source has averaged retained runs.",
        "keep_original": {"precision": 83.6, "recall": 0.0, "f1": 0.0},
        "displayed_values": displayed,
    }
    destination = PAPER / "build/generated/no_empty_recall_table_evidence.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(evidence, indent=2) + "\n", encoding="utf-8")
    print(f"Rendered 23 workflows and 207 values: {PDF_TARGET.relative_to(PAPER)}")


if __name__ == "__main__":
    main()
