"""Boundary cases for the native-flag and repair-outcome decomposition."""

import sys
from pathlib import Path
from types import SimpleNamespace

import pytest
from build_error_analysis import changed_values, partition

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from src.evaluation.paper_evaluation.analysis import classify_table


def test_abstentions_wrong_values_and_scoring_immunity():
    cells = [("table", 0, j) for j in range(9)]
    original = {c: "original" for c in cells}
    truth = SimpleNamespace(
        eligible=set(cells[:5]),
        errors=set(cells[:6]),  # Cell 5 accepts its original value: repair-immune.
        ambiguous={cells[6]},
        accepted={c: {"" if j == 0 else "accepted"} for j, c in enumerate(cells[:5])},
        immune=lambda c: c == cells[7],
    )
    # Target 0 needs deletion; target 1 gets a wrong value; 2 and 3 abstain;
    # target 4 is never flagged. Only cell 8 is a scored edit outside targets.
    values = {0: "", 1: "wrong", 2: None, 3: "original", 5: "edit", 6: "edit", 7: "edit", 8: "edit"}
    rows = [dict(dataset="table", row=0, col=j, corrected_value=v) for j, v in values.items()]
    changes = changed_values(rows, original.__getitem__)
    flags = {cells[j] for j in values}
    groups = partition(truth, flags, changes)
    assert groups["correct"] == {cells[0]}
    assert groups["wrong"] == {cells[1]}
    assert groups["flagged_no_edit"] == {cells[2], cells[3]}
    assert groups["not_flagged"] == {cells[4]}
    assert groups["outside"] == {cells[8]}
    canonical, _ = classify_table(
        changes,
        truth.errors,
        truth.ambiguous,
        truth.eligible,
        truth.accepted,
        "e2e",
        "complete",
        truth.immune,
    )
    assert (canonical["tp"], canonical["fp"], canonical["fn"]) == (1, 2, 4)


def test_repairs_must_have_a_native_flag():
    truth = SimpleNamespace(eligible=set(), errors=set(), ambiguous=set(), immune=lambda _: False)
    with pytest.raises(AssertionError, match="absent from native detection"):
        partition(truth, set(), {("table", 0, 0): "new"})


def test_duplicate_abstentions_are_not_silently_merged():
    row = dict(dataset="table", row=0, col=0, corrected_value=None)
    with pytest.raises(AssertionError, match="Duplicate prediction"):
        changed_values([row, row], lambda _: "original")
