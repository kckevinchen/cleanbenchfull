"""Describe frozen errors by table size, column length, and inferred column type.

No model calls, label edits, or new benchmark ground truth. Whole-table
bootstrap draws preserve dependence among cells and columns in a table.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import statistics
import sys
from collections import Counter
from pathlib import Path

import numpy as np

if __package__:
    from .figure_style import COLUMN_WIDTH, SOURCE_COLORS, configure, save
else:
    from figure_style import COLUMN_WIDTH, SOURCE_COLORS, configure, save

PAPER = Path(__file__).resolve().parents[1]
REPO = PAPER.parent
SOURCES = {"BI": "Relational", "Web": "Spreadsheet"}
TYPES = ("Numeric", "Categorical", "Date/time", "Text", "ID/Other")
MONTH = re.compile(
    r"^(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|"
    r"aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)$",
    re.I,
)
DATE = re.compile(
    r"^(?:\d{4}[-/]\d{1,2}[-/]\d{1,2}|\d{1,2}[-/]\d{1,2}[-/]\d{2,4}|"
    r"\d{1,2}[- ](?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*[- ,]+\d{2,4}|"
    r"(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*[ /-]+\d{1,2},? +\d{4})"
    r"(?:[ T].*)?$",
    re.I,
)
TIME = re.compile(r"^\d{1,2}:\d{2}(?::\d{2}(?:\.\d+)?)?\s*(?:[ap]m)?$", re.I)
WEEKDAY = re.compile(
    r"^(mon(?:day)?|tue(?:sday)?|wed(?:nesday)?|thu(?:rsday)?|fri(?:day)?|sat(?:urday)?|sun(?:day)?)$",
    re.I,
)
NUMBER = re.compile(r"^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def numeric(value):
    text = value.strip().replace(",", "").replace("−", "-")
    text = re.sub(r"^[\$£€¥]", "", text).strip().removesuffix("%").strip()
    if text.startswith("(") and text.endswith(")"):
        text = "-" + text[1:-1]
    return bool(NUMBER.fullmatch(text))


def infer_type(header, values, config):
    """Label a whole column without consulting error verdicts or accepted repairs."""
    missing = set(config["missing_tokens"])
    values = [str(v).strip() for v in values if str(v).strip().lower() not in missing]
    semantic_header = re.sub(r"^\s*key\s*#\s*\d+\s*", "", header, flags=re.I)
    name = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", semantic_header)
    name = re.sub(r"[_\W]+", " ", name).strip().lower()
    if not values:
        return "ID/Other", {"reason": "empty", "nonempty": 0}
    n = len(values)
    numeric_share = sum(numeric(v) for v in values) / n
    date_share = sum(bool(DATE.fullmatch(v) or TIME.fullmatch(v)) for v in values) / n
    month_share = sum(bool(MONTH.fullmatch(v) or WEEKDAY.fullmatch(v)) for v in values) / n
    temporal_share = (
        sum(
            bool(
                numeric(v)
                or DATE.fullmatch(v)
                or TIME.fullmatch(v)
                or MONTH.fullmatch(v)
                or WEEKDAY.fullmatch(v)
            )
            for v in values
        )
        / n
    )
    unique = len(set(values))
    profile = dict(
        nonempty=n,
        distinct=unique,
        numeric_share=numeric_share,
        date_share=date_share,
        month_share=month_share,
    )
    dominant = config["dominant_share"]

    def result(kind, reason):
        return kind, {**profile, "reason": reason}

    explicit_key = re.search(r"\b(id|key|code)\b", name)
    if numeric_share >= dominant and re.search(config["measure_header"], name) and not explicit_key:
        return result("Numeric", "numerical measurement header and values")
    if date_share >= dominant and not explicit_key:
        return result("Date/time", "dominant date/time forms")
    descriptive_suffix = re.search(r"\b(title|name|description|label)\s*$", name)
    if not descriptive_suffix and (
        re.search(config["identifier_header"], name) or "#" in semantic_header
    ):
        return result("ID/Other", "identifier header")
    if (
        re.search(config["temporal_header"], name)
        and temporal_share >= config["semantic_header_share"]
    ):
        return result("Date/time", "temporal header and compatible value forms")
    if max(date_share, month_share) >= dominant:
        return result("Date/time", "dominant date/time or temporal-name forms")
    if re.search(config["category_header"], name) and not (
        numeric_share >= dominant and re.search(config["measure_header"], name)
    ):
        return result("Categorical", "categorical header")
    if numeric_share >= dominant:
        leading_zero = sum(bool(re.fullmatch(r"0\d{3,}", v)) for v in values) / n
        if leading_zero >= dominant and not re.search(config["measure_header"], name):
            return result("ID/Other", "zero-padded numeric codes")
        return result("Numeric", "dominant numerical values")
    if numeric_share >= 1 - dominant:
        return result("ID/Other", "mixed numerical and text values")
    if (
        unique <= config["category_max_distinct"]
        and unique / n <= config["category_max_share"]
        and statistics.median(len(v.split()) for v in values) <= config["category_max_median_words"]
    ):
        return result("Categorical", "repeated short labels")
    return result("Text", "remaining text values")


def collect(snapshot, selected, config):
    sys.path.insert(0, str(REPO))
    from src.evaluation.paper_evaluation.analysis import GroundTruth

    manifest_path = snapshot / "_manifest.json"
    manifest = json.loads(manifest_path.read_text())
    hashes = {str(manifest_path.relative_to(REPO)): sha(manifest_path)}
    for name in ("benchmark_cell.json", "neutral_cells.jsonl", "ignored.jsonl"):
        path = snapshot / name
        digest = sha(path)
        assert digest == manifest["input_sha256"][name]
        hashes[str(path.relative_to(REPO))] = digest
    truth = GroundTruth(snapshot, manifest)
    expected = json.loads(selected.read_text())["table_manifest"]
    hashes[str(selected.relative_to(REPO))] = sha(selected)
    assert truth.tables == expected, "Population differs from published evaluation"
    error_counts = Counter((ds, col) for ds, _, col in truth.errors)
    ambiguous = truth.ambiguous
    tables, columns = [], []
    for ds in sorted(expected):
        entry = manifest["datasets"][ds]
        path = snapshot / ds / "dirty.csv"
        digest = sha(path)
        assert digest == entry["dirty_sha256"]
        hashes[str(path.relative_to(REPO))] = digest
        gt_path = snapshot / ds / "gt_cells.jsonl"
        if gt_path.exists():
            hashes[str(gt_path.relative_to(REPO))] = sha(gt_path)
        with path.open(newline="", encoding="utf-8-sig") as handle:
            headers, *grid = csv.reader(handle)
        assert headers == entry["columns"] and len(grid) == entry["n_rows"]
        assert all(len(r) == len(headers) for r in grid)
        table = {"dataset": ds, **expected[ds], "cells": len(grid) * len(headers)}
        tables.append(table)
        local = []
        for j, header in enumerate(headers):
            kind, profile = infer_type(header, [r[j] for r in grid], config)
            scorable = sum(
                (ds, i, j) not in ambiguous and not truth.immune((ds, i, j))
                for i in range(len(grid))
            )
            local.append(
                dict(
                    dataset=ds,
                    source=table["source"],
                    column=j,
                    header=header,
                    column_type=kind,
                    profile=profile,
                    scorable=scorable,
                    errors=error_counts[ds, j],
                )
            )
        assert sum(c["scorable"] for c in local) == table["detection_scorable"]
        assert sum(c["errors"] for c in local) == table["labeled_errors"]
        columns.extend(local)
    assert len(tables) == 1000 and len(columns) == 5920
    assert sum(t["labeled_errors"] for t in tables) == 1409
    assert sum(t["detection_scorable"] for t in tables) == 363802
    return tables, columns, hashes


def estimate(numerators, denominators, weights, scale):
    """Ratio of summed counts; resample the table, never individual cells."""
    a, b = np.asarray(numerators), np.asarray(denominators)
    assert a.shape == b.shape == (weights.shape[1],)
    value = scale * a.sum() / b.sum()
    sampled_a, sampled_b = weights @ a, weights @ b
    valid = sampled_b > 0
    samples = scale * sampled_a[valid] / sampled_b[valid]
    lo, hi = np.quantile(samples, [0.025, 0.975])
    return float(value), float(lo), float(hi)


def summarize(tables, columns, config):
    rows = []
    for source in SOURCES:
        population = [t for t in tables if t["source"] == source]
        ids = {t["dataset"]: i for i, t in enumerate(population)}
        assert len(ids) == 500
        rng = np.random.default_rng(config["bootstrap_seed"] + list(SOURCES).index(source))
        weights = rng.multinomial(500, np.full(500, 1 / 500), size=config["bootstrap_repetitions"])

        def add(panel, bucket, selected_tables=None, selected_columns=None):
            errors, cells, units = [np.zeros(500, dtype=int) for _ in range(3)]
            if selected_tables is not None:
                for t in selected_tables:
                    i = ids[t["dataset"]]
                    errors[i] += t["labeled_errors"]
                    cells[i] += t["detection_scorable"]
                    units[i] += 1
            else:
                for c in selected_columns:
                    i = ids[c["dataset"]]
                    errors[i] += c["errors"]
                    cells[i] += c["scorable"]
                    units[i] += 1
            value, lower, upper = estimate(
                errors, units if panel == "a" else cells, weights, 1 if panel == "a" else 1000
            )
            rows.append(
                dict(
                    panel=panel,
                    bucket=bucket,
                    source=SOURCES[source],
                    tables=int((units > 0).sum()),
                    units=int(units.sum()),
                    errors=int(errors.sum()),
                    scorable_cells=int(cells.sum()),
                    estimate=value,
                    lower=lower,
                    upper=upper,
                )
            )

        for lo, hi in config["table_cell_bins"]:
            group = [t for t in population if lo <= t["cells"] <= hi]
            for panel in ("a", "b"):
                add(panel, f"{lo}-{hi}", selected_tables=group)
        source_columns = [c for c in columns if c["source"] == source and c["scorable"] > 0]
        for lo, hi in config["column_length_bins"]:
            group = [c for c in source_columns if lo <= c["scorable"] <= hi]
            add("c", f"{lo}-{hi}", selected_columns=group)
        for kind in TYPES:
            add("d", kind, selected_columns=[c for c in source_columns if c["column_type"] == kind])
    for source in SOURCES.values():
        for panel in "abcd":
            subset = [r for r in rows if r["panel"] == panel and r["source"] == source]
            assert sum(r["errors"] for r in subset) == (347 if source == "Relational" else 1062)
            assert sum(r["scorable_cells"] for r in subset) == (
                142075 if source == "Relational" else 221727
            )
    return rows


def sensitivity(columns, snapshot, config):
    """Check type-frequency ordering under declared alternative thresholds."""
    cache, results = {}, []
    for name, changes in {"primary": {}, **config["sensitivity_variants"]}.items():
        totals = {}
        for c in columns:
            ds = c["dataset"]
            if ds not in cache:
                with (snapshot / ds / "dirty.csv").open(newline="", encoding="utf-8-sig") as h:
                    cache[ds] = list(csv.reader(h))[1:]
            kind, _ = infer_type(
                c["header"], [r[c["column"]] for r in cache[ds]], {**config, **changes}
            )
            if name == "primary":
                assert kind == c["column_type"]
            values = totals.setdefault((c["source"], kind), [0, 0, 0])
            values[0] += c["scorable"] > 0
            values[1] += c["errors"]
            values[2] += c["scorable"]
        for (source, kind), (n, errors, cells) in sorted(totals.items()):
            results.append(
                dict(
                    variant=name,
                    source=SOURCES[source],
                    column_type=kind,
                    columns=n,
                    errors=errors,
                    scorable_cells=cells,
                    errors_per_1000=1000 * errors / cells,
                )
            )
    return results


def write_rows(path, rows):
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def draw(rows, target):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    from matplotlib.ticker import MaxNLocator

    configure(font_size=8)
    fig = plt.figure(figsize=(COLUMN_WIDTH, 3.8))
    grid = fig.add_gridspec(
        3,
        2,
        left=0.22,
        right=0.98,
        bottom=0.12,
        top=0.88,
        wspace=0.95,
        hspace=1.50,
        height_ratios=(1, 1, 1.35),
    )
    axes = [
        fig.add_subplot(grid[0, 0]),
        fig.add_subplot(grid[0, 1]),
        fig.add_subplot(grid[1, :]),
        fig.add_subplot(grid[2, :]),
    ]
    markers = ("o", "s")
    titles = (
        "(a) Errors/table",
        "(b) Errors/1,000",
        "(c) Column length",
        "(d) Inferred column type",
    )
    for panel, ax, title in zip("abcd", axes, titles, strict=True):
        ax.set_title(title, loc="left", pad=8)
        ax.set_axisbelow(True)
        horizontal = panel == "d"
        ax.grid(axis="x" if horizontal else "y")
        buckets = list(dict.fromkeys(r["bucket"] for r in rows if r["panel"] == panel))
        for j, source in enumerate(SOURCES.values()):
            group = [
                next(
                    r
                    for r in rows
                    if r["panel"] == panel and r["source"] == source and r["bucket"] == bucket
                )
                for bucket in buckets
            ]
            values = np.array([r["estimate"] for r in group])
            lower = np.array([r["lower"] for r in group])
            upper = np.array([r["upper"] for r in group])
            # The percentile interval need not contain the point estimate at a boundary.
            positions = np.arange(len(group)) + (j - 0.5) * 0.22
            color = SOURCE_COLORS[source]
            if horizontal:
                ax.hlines(positions, lower, upper, color=color, linewidth=1.3)
                ax.scatter(
                    values, positions, s=25, marker=markers[j], color=color, zorder=3, clip_on=False
                )
            else:
                ax.vlines(positions, lower, upper, color=color, linewidth=1.3)
                ax.scatter(positions, values, s=25, marker=markers[j], color=color, zorder=3)
        if horizontal:
            ax.set_yticks(range(len(buckets)), buckets)
            ax.set_ylim(len(buckets) - 0.5, -0.5)
            ax.set_xlim(left=0)
            ax.set_xlabel("Errors / 1,000 cells")
            ax.xaxis.set_major_locator(MaxNLocator(4))
            ax.tick_params(axis="y", length=0, pad=6)
            ax.spines["left"].set_visible(False)
        else:
            labels = ["<200", "200–\n499", "≥500"] if panel in "ab" else ["1–24", "25–49", "50–100"]
            if panel == "c":
                for i, bucket in enumerate(buckets):
                    sizes = [
                        next(
                            r["units"]
                            for r in rows
                            if r["panel"] == panel and r["bucket"] == bucket and r["source"] == s
                        )
                        for s in SOURCES.values()
                    ]
                    labels[i] += f"\nn={sizes[0]:,}/{sizes[1]:,}"
            ax.set_xticks(range(len(buckets)), labels)
            ax.set_xlim(-0.5, len(buckets) - 0.5)
            ax.set_ylim(bottom=0)
            ax.yaxis.set_major_locator(MaxNLocator(4))
            ax.set_xlabel("Cells per table" if panel in "ab" else "Cells per column", labelpad=6)
            ax.set_ylabel("Mean errors" if panel == "a" else "Errors / 1,000")
    ymax = max(axes[1].get_ylim()[1], axes[2].get_ylim()[1])
    for ax in (axes[1], axes[2]):
        ax.set_ylim(0, ymax)
    fig.legend(
        [
            Line2D([], [], color=SOURCE_COLORS[s], marker=m, linestyle="none", markersize=5)
            for s, m in zip(SOURCES.values(), markers, strict=True)
        ],
        list(SOURCES.values()),
        loc="upper center",
        bbox_to_anchor=(0.53, 1.0),
        ncol=2,
        frameon=False,
        handletextpad=0.4,
        columnspacing=1.0,
    )
    save(fig, target, width=COLUMN_WIDTH, font_size=8, check_layout=True)
    # Catch clipped labels in the actual figure canvas, including category names.
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    frame = fig.bbox
    labels = list(fig.legends[0].get_texts())
    for ax in axes:
        labels.extend([ax.title, ax._left_title, ax.xaxis.label, ax.yaxis.label])
        for axis in (ax.xaxis, ax.yaxis):
            lo, hi = sorted(axis.get_view_interval())
            labels.extend(
                tick.label1 for tick in axis.get_major_ticks() if lo <= tick.get_loc() <= hi
            )
    for label in labels:
        if label.get_visible() and label.get_text():
            assert label.get_fontsize() == 8
            box = label.get_window_extent(renderer)
            assert box.x0 >= frame.x0 - 1 and box.y0 >= frame.y0 - 1, label.get_text()
            assert box.x1 <= frame.x1 + 1 and box.y1 <= frame.y1 + 1, label.get_text()
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--snapshot", type=Path, default=REPO / "outputs/baseline_campaign/20260910/snapshot"
    )
    parser.add_argument(
        "--selected",
        type=Path,
        default=REPO / "outputs/paper_evaluation/20260920/selected_results.json",
    )
    parser.add_argument(
        "--config", type=Path, default=PAPER / "figures/error_prevalence_config.json"
    )
    args = parser.parse_args()
    args.snapshot = args.snapshot.resolve()
    args.selected = args.selected.resolve()
    args.config = args.config.resolve()
    config = json.loads(args.config.read_text())
    tables, columns, hashes = collect(args.snapshot, args.selected, config)
    hashes[str(args.config.relative_to(PAPER))] = sha(args.config)
    hashes[str(Path(__file__).relative_to(PAPER))] = sha(__file__)
    rows = summarize(tables, columns, config)
    target = PAPER / "assets/generated"
    write_rows(target / "error_prevalence.csv", rows)
    checks = sensitivity(columns, args.snapshot, config)
    write_rows(target / "error_prevalence_sensitivity.csv", checks)
    draw(rows, target / "error_prevalence.pdf")
    evidence = PAPER / "build/generated/error_prevalence.json"
    evidence.write_text(
        json.dumps(
            dict(
                config=config,
                source_sha256=hashes,
                tables=tables,
                columns=columns,
                aggregates=rows,
                sensitivity=checks,
            ),
            indent=2,
        )
        + "\n"
    )
    print(
        json.dumps(
            dict(
                tables=len(tables),
                columns=len(columns),
                errors=sum(t["labeled_errors"] for t in tables),
                scorable_cells=sum(t["detection_scorable"] for t in tables),
                type_counts=Counter(c["column_type"] for c in columns),
            ),
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
