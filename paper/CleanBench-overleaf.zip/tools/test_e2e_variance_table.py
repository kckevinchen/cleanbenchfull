"""Run-to-run variability must not manufacture observations or replace micro scores."""

import statistics

import pytest
from build_e2e_variance_table import METRICS, aggregate, read, sample_summary


def test_sample_sd_uses_runs_and_is_undefined_for_a_single_run():
    assert sample_summary([2, 4, 6]) == (4, 2)
    assert sample_summary([3]) == (3, None)
    assert sample_summary([3, 3, 3]) == (3, 0)
    with pytest.raises(ValueError):
        sample_summary([])


def test_variability_preserves_every_frozen_mean_and_actual_repetition_count():
    roster = read("task_type_metrics.csv")
    rows = aggregate(roster, read("macro_type_metrics_runs.csv"), read("false_edits_ba_runs.csv"))
    original = {r["method"]: r for r in read("e2e_table_metrics.csv")}
    assert len(rows) == 21
    assert sum(row["variance_requested"] for row in rows) == 9
    assert sum(row["variance_requested"] and int(row["repetitions"]) == 3 for row in rows) == 7
    for row in rows:
        for metric in METRICS:
            assert float(row[metric]) == pytest.approx(float(original[row["method"]][metric]))
            assert (row[f"sd_{metric}"] is None) == (
                not row["variance_requested"] or int(row["repetitions"]) == 1
            )
    api = next(r for r in rows if r["method"] == "GPT-6-astra (Prompt-tuned)")
    assert api["sd_f1"] == pytest.approx(statistics.stdev([71.50, 72.75, 73.82]), abs=0.01)


def test_duplicate_run_observations_cannot_be_counted_as_repetitions():
    types = read("macro_type_metrics_runs.csv")
    with pytest.raises(ValueError, match="Duplicate"):
        aggregate(read("task_type_metrics.csv"), types + types[:1], read("false_edits_ba_runs.csv"))


def test_all_repeated_baselines_receive_measured_standard_deviations():
    rows = aggregate(
        read("task_type_metrics.csv"),
        read("macro_type_metrics_runs.csv"),
        read("false_edits_ba_runs.csv"),
    )
    indexed = {r["method"]: r for r in rows}
    types = read("macro_type_metrics_runs.csv")
    for method in ("CleanAgent", "Cocoon", "Relative Trust"):
        values = [
            float(r["micro_f1"])
            for r in types
            if r["method"] == method and r["error_type"] == "overall"
        ]
        assert len(values) == 3
        assert indexed[method]["variance_requested"]
        assert indexed[method]["sd_f1"] == pytest.approx(statistics.stdev(values))
    assert not indexed["SymSpell"]["variance_requested"]
    assert indexed["SymSpell"]["sd_f1"] is None
    assert indexed["GPT-6-astra (Codex)"]["variance_requested"]
    assert indexed["GPT-6-astra (Codex)"]["sd_f1"] is None


def test_complete_additional_agent_trials_update_means_without_pooling_scores():
    inputs = [
        read(name)
        for name in (
            "task_type_metrics.csv",
            "macro_type_metrics_runs.csv",
            "false_edits_ba_runs.csv",
        )
    ]
    original = next(r for r in aggregate(*inputs) if r["method"] == "GPT-6-astra (Codex)")
    trials = [
        dict(
            identity=f"trial-{i}",
            method=original["method"],
            tables=1000,
            targets=1093,
            metrics={key: value for key in METRICS},
        )
        for i, value in ((2, 10), (3, 20))
    ]
    row = next(
        r for r in aggregate(*inputs, additional_runs=trials) if r["method"] == original["method"]
    )
    assert row["repetitions"] == 3
    assert row["f1"] == pytest.approx(statistics.mean([float(original["f1"]), 10, 20]))
    assert row["sd_f1"] == pytest.approx(statistics.stdev([float(original["f1"]), 10, 20]))
    assert row["mean_fp_clean"] == pytest.approx(row["fpr"] * float(row["clean_cells"]) / 100)
    with pytest.raises(ValueError, match="twice"):
        aggregate(*inputs, additional_runs=trials + trials[:1])
    trials[0]["tables"] = 999
    with pytest.raises(ValueError, match="Partial"):
        aggregate(*inputs, additional_runs=trials)
