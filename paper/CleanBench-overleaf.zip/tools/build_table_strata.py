"""Reaggregate frozen per-table outcomes by table size and source, offline.

Run: venv/bin/python CleanBench/tools/build_table_strata.py
Every method/run must reproduce the published overall counts before slicing.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
import sys
from collections import defaultdict
from pathlib import Path

from build_error_types import IDENTITY
from build_task_type_tables import SHORT
from build_unified_task_tables import ARMS, MODELS

if __package__:
    from .tex_sources import generated_asset
else:
    from tex_sources import generated_asset

PAPER = Path(__file__).resolve().parents[1]
REPO = PAPER.parent
SIZE_BINS = {
    "columns": [(2, 4), (5, 8), (9, 20)],
    "rows": [(10, 24), (25, 49), (50, 100)],
}
SOURCE_NAMES = {"BI": "Relational", "Web": "Spreadsheet"}
METRICS = ("precision", "recall", "f1")


def metric(counts):
    tp, fp, fn = counts
    return [
        a / b if b else 0 for a, b in ((tp, tp + fp), (tp, tp + fn), (2 * tp, 2 * tp + fp + fn))
    ]


def sum_counts(counts, ids):
    return [sum(counts[ds][i] for ds in ids) for i in range(3)]


class Evidence:
    def __init__(self):
        self.hashes = {}

    def read(self, path, expected=None):
        path = Path(path)
        if not path.is_absolute():
            path = REPO / path
        data = path.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        if expected is not None:
            assert digest == expected, path
        self.hashes[str(path.relative_to(REPO))] = digest
        return json.loads(data)


def collect(evidence):
    read = evidence.read
    root = REPO / "outputs/paper_evaluation/20260920"
    selection = read(root / "presentation_selection.json")
    selected = read(root / "selected_results.json", selection["source_manifest_sha256"])
    manifest = selected["table_manifest"]
    candidates = selected["rows"][:]
    for name in ("excel_public", "cleanagent_repaired"):
        candidates.extend(read(root / name / "selected_results.json")["rows"])
    runs = []

    def add(task, category, method, counts, expected):
        assert set(counts) == set(manifest)
        field = "labeled_errors" if task == "detection" else "repair_targets"
        assert all(v[0] + v[2] == manifest[ds][field] for ds, v in counts.items())
        assert all(
            len(v) == 3 and all(isinstance(x, int) and x >= 0 for x in v) for v in counts.values()
        )
        total = sum_counts(counts, manifest)
        assert total == [expected[k] for k in ("tp", "fp", "fn")], (task, method)
        assert all(
            math.isclose(v, expected[k]) for k, v in zip(METRICS, metric(total), strict=True)
        )
        runs.append(dict(task=task, category=category, method=method, counts=counts))

    for task in ("detection", "e2e"):
        for entry in selection["main"][task]:
            matches = [r for r in candidates if all(r.get(k) == entry.get(k) for k in IDENTITY)]
            assert len(matches) == 1
            row = matches[0]
            tables = read(row["per_table_path"])
            for ds, value in tables.items():
                assert all(
                    value[k] == manifest[ds][k]
                    for k in ("rows", "columns", "source", "labeled_errors", "repair_targets")
                )
            counts = {ds: [v[k] for k in ("tp", "fp", "fn")] for ds, v in tables.items()}
            add(
                task,
                entry["category"],
                SHORT.get(entry["method"], entry["method"]),
                counts,
                entry["metrics"],
            )

    # Direct-API per-table results are reconstructed from the same immutable
    # validated responses used in the final detection and repair score files.
    sys.path.insert(0, str(REPO))
    from external.gpt5_detect.secure_tuning import digest
    from src.evaluation.paper_evaluation.analysis import GroundTruth

    api = read(PAPER / "build/generated/llm_baseline_evidence.json")
    paths = api["source_sha256"]
    report_path = next(p for p in paths if p.endswith("final_report/RESULTS.json"))
    repair_path = next(p for p in paths if p.endswith("e2e_scores.json"))
    derivation_path = next(p for p in paths if p.endswith("derivation.json"))
    report = read(report_path, paths[report_path])
    repair = read(repair_path, paths[repair_path])
    derivation = read(derivation_path, paths[derivation_path])
    campaign = (REPO / report_path).parents[1]
    config = read(
        campaign / "config.json", paths[str((campaign / "config.json").relative_to(REPO))]
    )
    datasets = Path(config["datasets"])
    data_manifest = read(datasets / "_manifest.json")
    truth = GroundTruth(datasets, data_manifest)
    assert truth.tables == manifest
    for name in ("benchmark_cell.json", "neutral_cells.jsonl"):
        path = datasets / name
        evidence.hashes[str(path.relative_to(REPO))] = hashlib.sha256(path.read_bytes()).hexdigest()
    for repetition in report["repetitions"]:
        rep = repetition["repetition"]
        recovered = campaign / f"rep_{rep:02d}/recovered"
        for model in MODELS:
            for arm, label in ARMS:
                expected_detection = next(
                    r for r in repetition["comparison"] if r["name"] == f"compare_{model}_{arm}"
                )
                stage = read(recovered / f"compare_{model}_{arm}/receipt.json")
                assert stage["prompt_sha256"] == expected_detection["prompt_sha256"]
                prompt_path = recovered / f"compare_{model}_{arm}/prompt.txt"
                prompt = prompt_path.read_text()
                assert hashlib.sha256(prompt.encode()).hexdigest() == stage["prompt_sha256"]
                request_key = digest(prompt)
                detection_records, repair_records, statuses = [], [], {}
                for ds in manifest:
                    path = recovered / "requests" / model / request_key / f"{ds}.json"
                    raw = read(path, derivation["receipt_hashes"][str(path.relative_to(REPO))])
                    statuses[ds] = "complete" if raw["status"] == "success" else "failed"
                    if raw["status"] != "success":
                        assert not raw["issues"] and ds in stage["failed_tables"]
                        continue
                    columns = data_manifest["datasets"][ds]["columns"]
                    for issue in raw["issues"]:
                        record = dict(
                            dataset=ds, row=issue["row"], col=columns.index(issue["column"])
                        )
                        detection_records.append(record)
                        value = issue["corrected_value"]
                        if value is not None and value != issue["observed"]:
                            repair_records.append(dict(record, corrected_value=value))
                for task, records, expected in [
                    ("detection", detection_records, expected_detection),
                    ("e2e", repair_records, repair["results"][f"rep_{rep:02d}/{model}/{arm}"]),
                ]:
                    tables, _ = truth.analyze(records, task, statuses)
                    counts = {ds: [v[k] for k in ("tp", "fp", "fn")] for ds, v in tables.items()}
                    add(
                        task,
                        "Direct LLMs (API)",
                        f"{model.replace('gpt', 'GPT')} ({label})",
                        counts,
                        expected,
                    )
        print(f"Audited API repetition {rep} against original score totals.", flush=True)
    for task, suffix in (("detection", ""), ("e2e", "_repair")):
        agents = read(PAPER / f"build/generated/coding_agent{suffix}_evidence.json")
        for row in agents["rows"]:
            add(
                task,
                "Coding agents",
                f"{row['model']} ({row['harness']})",
                row["per_table_counts"],
                row["metrics"],
            )
    return manifest, runs


def strata(manifest):
    groups = []
    for dimension, bounds in SIZE_BINS.items():
        for lo, hi in bounds:
            ids = [ds for ds, t in manifest.items() if lo <= t[dimension] <= hi]
            groups.append((dimension, f"{lo}-{hi}", "All", ids))
    for source, label in SOURCE_NAMES.items():
        ids = [ds for ds, t in manifest.items() if t["source"] == source]
        groups.append(("source", label, "All", ids))
        for dimension, bounds in SIZE_BINS.items():
            for lo, hi in bounds:
                subset = [ds for ds in ids if lo <= manifest[ds][dimension] <= hi]
                groups.append((dimension, f"{lo}-{hi}", label, subset))
    for scope, field in (("All", None), *[(s, s) for s in SOURCE_NAMES.values()]):
        expected = {
            ds for ds, t in manifest.items() if field is None or SOURCE_NAMES[t["source"]] == field
        }
        for dim in SIZE_BINS:
            partition = [ds for d, _, s, ids in groups if d == dim and s == scope for ds in ids]
            assert len(partition) == len(set(partition)) and set(partition) == expected
    return groups


def aggregate(manifest, runs):
    groups = strata(manifest)
    roster = defaultdict(list)
    for run in runs:
        roster[run["task"], run["category"], run["method"]].append(run["counts"])
    rows = []
    for (task, category, method), repetitions in roster.items():
        for dimension, bucket, source, ids in groups:
            counts = [sum_counts(c, ids) for c in repetitions]
            values = [metric(c) for c in counts]
            targets = sum(
                manifest[ds]["labeled_errors" if task == "detection" else "repair_targets"]
                for ds in ids
            )
            assert all(c[0] + c[2] == targets for c in counts)
            rows.append(
                {
                    "task": task,
                    "category": category,
                    "method": method,
                    "dimension": dimension,
                    "bucket": bucket,
                    "source_filter": source,
                    "tables": len(ids),
                    "targets": targets,
                    "repetitions": len(repetitions),
                    **{
                        f"mean_{k}": statistics.mean(c[i] for c in counts)
                        for i, k in enumerate(("tp", "fp", "fn"))
                    },
                    **{
                        k: 100 * statistics.mean(v[i] for v in values)
                        for i, k in enumerate(METRICS)
                    },
                }
            )
    # Source and dimension slicing must not change any main-table number.
    with (PAPER / "assets/generated/task_type_metrics.csv").open() as handle:
        overall = {(r["task"], r["method"]): r for r in csv.DictReader(handle)}
    assert len(roster) == len(overall) == 58
    for (task, _, method), reps in roster.items():
        values = [metric(sum_counts(c, manifest)) for c in reps]
        assert all(
            math.isclose(
                100 * statistics.mean(v[i] for v in values), float(overall[task, method][k])
            )
            for i, k in enumerate(METRICS)
        )
    populations = []
    for dim, bucket, source, ids in groups:
        populations.append(
            {
                "dimension": dim,
                "bucket": bucket,
                "source_filter": source,
                "tables": len(ids),
                "relational_tables": sum(manifest[ds]["source"] == "BI" for ds in ids),
                "spreadsheet_tables": sum(manifest[ds]["source"] == "Web" for ds in ids),
                "labeled_errors": sum(manifest[ds]["labeled_errors"] for ds in ids),
                "repair_targets": sum(manifest[ds]["repair_targets"] for ds in ids),
            }
        )
    return rows, populations


def write_csv(path, rows):
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def render(rows):
    """Show P and R separately with one fixed scale across tasks and buckets."""
    bins = [(d, f"{lo}-{hi}") for d, bounds in SIZE_BINS.items() for lo, hi in bounds]
    bins += [("source", s) for s in SOURCE_NAMES.values()]
    selected = {
        (r["task"], r["method"], r["dimension"], r["bucket"]): r
        for r in rows
        if r["source_filter"] == "All"
    }
    with (PAPER / "assets/generated/task_type_metrics.csv").open() as handle:
        roster = list(csv.DictReader(handle))

    def cell(value):
        value = float(value)
        assert 0 <= value <= 100
        rgb = tuple(round(255 + (c - 255) * value / 100) for c in (20, 86, 135))
        color = "".join(f"{c:02X}" for c in rgb)
        fg = "white" if value >= 80 else "black"
        return rf"\cellcolor[HTML]{{{color}}}\makebox[0.037\textwidth]{{\textcolor{{{fg}}}{{{value:.1f}}}}}"

    for task in ("e2e", "detection"):
        lines = [
            "% Generated by tools/build_table_strata.py from frozen per-table scores.",
            r"\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}l*{16}{c}@{}}",
            r"\toprule",
            r" & \multicolumn{6}{c}{Columns per table} & \multicolumn{6}{c}{Rows per table} & \multicolumn{4}{c}{Source} \\",
            r"\cmidrule(lr){2-7}\cmidrule(lr){8-13}\cmidrule(l){14-17}",
            " & "
            + " & ".join(rf"\multicolumn{{2}}{{c}}{{{b.replace('-', '--')}}}" for _, b in bins)
            + r" \\",
            "".join(rf"\cmidrule(lr){{{i}-{i+1}}}" for i in range(2, 18, 2)),
            "Method & " + " & ".join(["P", "R"] * 8) + r" \\",
        ]
        category = None
        for method in roster:
            if method["task"] != task:
                continue
            if method["category"] != category:
                category = method["category"]
                lines += [
                    r"\midrule",
                    rf"\multicolumn{{17}}{{@{{}}l}}{{\textit{{{category.removesuffix(' (API)')}}}}} \\",
                ]
            vals = [
                cell(selected[task, method["method"], d, b][m])
                for d, b in bins
                for m in ("precision", "recall")
            ]
            lines.append(method["method"] + " & " + " & ".join(vals) + r" \\")
        lines += [r"\bottomrule", r"\end{tabular*}", ""]
        (generated_asset(f"{task}_strata_table.tex")).write_text("\n".join(lines))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--render-only",
        action="store_true",
        help="Render the frozen aggregate CSV without repeating the input audit.",
    )
    args = parser.parse_args()
    if args.render_only:
        with (PAPER / "assets/generated/table_strata_metrics.csv").open() as handle:
            render(list(csv.DictReader(handle)))
        return
    evidence = Evidence()
    manifest, runs = collect(evidence)
    rows, populations = aggregate(manifest, runs)
    target = PAPER / "assets/generated"
    write_csv(target / "table_strata_metrics.csv", rows)
    write_csv(target / "table_strata_populations.csv", populations)
    render(rows)
    output = PAPER / "build/generated/table_strata_evidence.json"
    output.write_text(
        json.dumps(
            {
                "source_sha256": evidence.hashes,
                "builder_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                "policy": "Fixed bins chosen from table-size distributions, before inspecting outcomes. Sum TP/FP/FN within each bucket and repetition, then average run-level micro scores. Preserve failed/abstaining targets and original immunity rules. Include all 1000 tables, including tables with no labeled errors. Within-source size slices are retained to diagnose source-composition confounding. No new model calls.",
                "populations": populations,
                "runs": runs,
            },
            indent=2,
        )
        + "\n"
    )
    print(f"Wrote {len(rows)} strata with P/R/F1 for all 58 task/method entries.")


if __name__ == "__main__":
    main()
