"""Aggregate audited per-table counts at each exact row/column count, offline."""

from __future__ import annotations

import csv
import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path
from statistics import mean

from build_table_strata import METRICS, SIZE_BINS, metric, sum_counts, write_csv

PAPER = Path(__file__).resolve().parents[1]


def aggregate_exact(manifest, runs):
    methods = defaultdict(list)
    for run in runs:
        methods[run["task"], run["category"], run["method"]].append(run["counts"])
    rows = []
    for (task, category, method), repetitions in methods.items():
        target_field = "labeled_errors" if task == "detection" else "repair_targets"
        for dimension in ("columns", "rows"):
            groups = defaultdict(list)
            for ds, table in manifest.items():
                groups[table[dimension]].append(ds)
            for size, ids in sorted(groups.items()):
                counts = [sum_counts(run, ids) for run in repetitions]
                targets = sum(manifest[ds][target_field] for ds in ids)
                assert all(c[0] + c[2] == targets for c in counts)
                values = [metric(c) for c in counts]
                rows.append(
                    {
                        "task": task,
                        "category": category,
                        "method": method,
                        "dimension": dimension,
                        "size": size,
                        "tables": len(ids),
                        "targets": targets,
                        "repetitions": len(repetitions),
                        **{
                            f"mean_{k}": mean(c[i] for c in counts)
                            for i, k in enumerate(("tp", "fp", "fn"))
                        },
                        **{k: 100 * mean(v[i] for v in values) for i, k in enumerate(METRICS)},
                        # Preserve the benchmark's zero-denominator convention in
                        # CSV scores, but do not plot a score with no events at all.
                        "f1_defined": any(2 * c[0] + c[1] + c[2] > 0 for c in counts),
                    }
                )
    return rows


def main():
    evidence_path = PAPER / "build/generated/table_strata_evidence.json"
    evidence = json.loads(evidence_path.read_text())
    relative = "outputs/paper_evaluation/20260920/selected_results.json"
    raw = (PAPER.parent / relative).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == evidence["source_sha256"][relative]
    manifest = json.loads(raw)["table_manifest"]
    runs = evidence["runs"]
    grouped = defaultdict(list)
    for run in runs:
        assert set(run["counts"]) == set(manifest)
        field = "labeled_errors" if run["task"] == "detection" else "repair_targets"
        for ds, c in run["counts"].items():
            assert len(c) == 3 and all(isinstance(v, int) and v >= 0 for v in c)
            assert c[0] + c[2] == manifest[ds][field]
        grouped[run["task"], run["method"]].append(run["counts"])
    generated = PAPER / "assets/generated"
    with (generated / "task_type_metrics.csv").open() as handle:
        overall = list(csv.DictReader(handle))
    assert len(grouped) == len(overall) == 58
    for row in overall:
        repetitions = grouped[row["task"], row["method"]]
        assert len(repetitions) == int(row["repetitions"])
        scores = [metric(sum_counts(c, manifest)) for c in repetitions]
        assert all(
            math.isclose(100 * mean(v[i] for v in scores), float(row[k]))
            for i, k in enumerate(METRICS)
        )
    # Independently reproduce the old bucket totals and scores before changing
    # only the partition. Failures and clean tables remain in every partition.
    with (generated / "table_strata_metrics.csv").open() as handle:
        for row in csv.DictReader(handle):
            if row["source_filter"] != "All" or row["dimension"] not in SIZE_BINS:
                continue
            lo, hi = map(int, row["bucket"].split("-"))
            ids = [ds for ds, t in manifest.items() if lo <= t[row["dimension"]] <= hi]
            counts = [sum_counts(c, ids) for c in grouped[row["task"], row["method"]]]
            assert all(
                math.isclose(mean(c[i] for c in counts), float(row[f"mean_{k}"]))
                for i, k in enumerate(("tp", "fp", "fn"))
            )
            scores = [metric(c) for c in counts]
            assert all(
                math.isclose(100 * mean(v[i] for v in scores), float(row[k]))
                for i, k in enumerate(METRICS)
            )
    rows = aggregate_exact(manifest, runs)
    write_csv(generated / "table_exact_size_metrics.csv", rows)
    provenance = {
        "source_sha256": {
            str(evidence_path.relative_to(PAPER)): hashlib.sha256(
                evidence_path.read_bytes()
            ).hexdigest(),
            relative: hashlib.sha256(raw).hexdigest(),
        },
        "policy": "Exact observed row/column counts. Sum TP/FP/FN within size and run, then average run-level micro scores. These source scores are unsmoothed; undefined scores are marked by f1_defined. Display-only smoothing is recorded separately by build_accuracy_presentation.py. No new model calls.",
    }
    (PAPER / "build/generated/exact_size_evidence.json").write_text(
        json.dumps(provenance, indent=2) + "\n"
    )
    print(
        f"Validated all 58 overall scores and existing buckets; wrote {len(rows)} exact-size scores."
    )


if __name__ == "__main__":
    main()
