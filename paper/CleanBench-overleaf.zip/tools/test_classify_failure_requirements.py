"""Validate independent inputs and reject incomplete or contradictory judgments."""

import copy

import pytest
from classify_failure_requirements import difference, failure_payload, seal, validate


def result(**updates):
    return {
        "items": [
            {
                "group_id": "G001",
                "issue_kind": "lexical_or_entity",
                "primary_category": "Knowledge",
                "secondary_categories": [],
                "confidence": "high",
                "needs_review": False,
                "reference_status": "usable",
                "rationale": "The remaining mismatch is lexical.",
                **updates,
            }
        ]
    }


def test_old_classification_and_review_notes_are_not_sent():
    group = {
        "group_id": "G001",
        "outcome": "wrong_value",
        "col": 0,
        "column": "Name",
        "original": "Abc",
        "proposed": "ABC",
        "accepted": ["Abc"],
        "occurrences": [(1, "table", 0, 0), (2, "table", 0, 0)],
        "analysis_category": "Reasoning",
        "error_types": ["inconsistency"],
        "review_note": "Old opinion",
    }
    payload = failure_payload(group, [["Abc"]])
    assert payload["row_indices"] == [0]
    assert not {"analysis_category", "error_types", "review_note"} & payload.keys()
    altered = copy.deepcopy(group)
    altered["analysis_category"] = "Formatting convention"
    assert failure_payload(altered, [["Abc"]]) == payload


def test_wrong_coordinates_or_missing_ids_are_rejected():
    with pytest.raises(AssertionError):
        validate(result(), ["G002"])
    with pytest.raises(AssertionError):
        validate({"items": [*result()["items"], *result()["items"]]}, ["G001", "G002"])


def test_issue_category_mismatch_and_unflagged_uncertainty_are_rejected():
    validate(result(), ["G001"])
    with pytest.raises(AssertionError):
        validate(result(primary_category="Formatting convention"), ["G001"])
    with pytest.raises(AssertionError):
        validate(result(confidence="low"), ["G001"])
    with pytest.raises(AssertionError):
        validate(result(reference_status="questionable"), ["G001"])
    validate(
        result(
            issue_kind="insufficient_reference",
            primary_category="Uncertain",
            confidence="low",
            needs_review=True,
        ),
        ["G001"],
    )


def test_prompt_or_model_changes_invalidate_request_identity():
    before = {"model": "gpt-5.2", "prompt": "v1"}
    assert seal(before) == seal(dict(reversed(list(before.items()))))
    assert seal(before) != seal({**before, "prompt": "v2"})


def test_contextual_convention_is_reasoning_even_for_surface_edits():
    validate(result(issue_kind="contextual_convention", primary_category="Reasoning"), ["G001"])
    with pytest.raises(AssertionError):
        validate(
            result(issue_kind="contextual_convention", primary_category="Formatting convention"),
            ["G001"],
        )
    validate(result(issue_kind="surface_only", primary_category="Formatting convention"), ["G001"])


def test_exact_difference_exposes_small_spelling_errors_and_numeric_damage():
    edits = difference("PROGRAMING, DATA", "PROGRAMMING,DATA")["edits"]
    assert any(e["reference_fragment"] == "M" for e in edits)
    assert difference("1235", "12345")["numeric_value_changed"] is True
    assert difference("-0.0000634", "-6.34e-05")["numeric_value_changed"] is False
    assert difference("001", "1")["numeric_value_changed"] is False
    assert difference("+64 210 876 086 6", "+64 21 087 60866")["digit_sequence_changed"] is False
    assert difference("+64 210 876 086 6", "+64 21 087 6086")["digit_sequence_changed"] is True


def test_clean_edits_have_a_concrete_keep_original_reference():
    group = {
        "group_id": "G001",
        "outcome": "clean_edit",
        "col": 0,
        "column": "Amount",
        "original": "12345",
        "proposed": "1235",
        "accepted": [],
        "occurrences": [(1, "table", 0, 0)],
    }
    payload = failure_payload(group, [["12345"]])
    assert payload["accepted"] == []
    assert payload["reference_values"] == ["12345"]
    assert payload["residual_differences"][0]["numeric_value_changed"] is True
