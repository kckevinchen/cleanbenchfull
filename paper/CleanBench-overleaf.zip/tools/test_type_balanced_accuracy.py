"""Check class weighting and the existing empty/failed-output convention."""

import pytest
from build_type_balanced_accuracy import inputs, rates


def counts(tp=0, fp=0, failed=0, positive=10, negative=90):
    return dict(
        target_tables=positive,
        no_target_tables=negative,
        predicted_target_tables=tp,
        false_alarm_tables=fp,
        failed_no_target_tables=failed,
        preserved_tables=negative - fp - failed,
    )


def test_silent_and_always_edit_controls_both_score_fifty():
    assert rates(counts())["table_balanced_accuracy"] == 50
    assert rates(counts(tp=10, fp=90))["table_balanced_accuracy"] == 50


def test_perfect_table_decisions_score_one_hundred():
    r = rates(counts(tp=10))
    assert r["table_tpr"] == r["table_tnr"] == r["table_balanced_accuracy"] == 100


def test_failures_are_negative_outputs_not_successful_preservation():
    a, b = rates(counts(tp=5, fp=9)), rates(counts(tp=5, fp=9, failed=20))
    assert a == b
    assert b["table_tpr"] == 50 and b["table_tnr"] == 90
    assert b["table_balanced_accuracy"] == 70


def test_inconsistent_negative_table_partition_is_rejected():
    row = counts()
    row["preserved_tables"] -= 1
    with pytest.raises(AssertionError):
        rates(row)


def test_all_frozen_run_types_match_existing_overall_scores():
    roster, runs, summary = inputs()
    assert len(roster) == 24 and len(runs) == 148 and len(summary) == 96
    assert len({r["method"] for r in summary}) == 24
    control = [r for r in summary if r["method"] == "Keep original"]
    assert len(control) == 4 and all(r["table_balanced_accuracy"] == 50 for r in control)
