"""Select methods for paper displays while retaining frozen experiment records."""


def reported_method(name):
    """Omit excluded baselines and model configurations from reported results."""
    return name.casefold() != "fm data tasks" and not name.casefold().startswith("opus ")


def method_category(method, category):
    """Classify semantic-domain checks by mechanism, including frozen aggregates."""
    return "Constraint-based" if method == "Auto-Test" else category


def reported_table(text):
    """Remove excluded method rows; preserve all other TeX bytes and values."""
    return "".join(
        line
        for line in text.splitlines(keepends=True)
        if " & " not in line or reported_method(line.lstrip().split(" & ", 1)[0])
    )


def astra_interval(interval, *, repair=False):
    task = "repair " if repair else ""
    return (
        f"The paired 95\\% table-bootstrap interval for the {task}$F_1$ difference is "
        f"[{interval[0]:.2f}, {interval[1]:.2f}] percentage points for Astra "
        "(Copilot minus Codex).\n"
    )
