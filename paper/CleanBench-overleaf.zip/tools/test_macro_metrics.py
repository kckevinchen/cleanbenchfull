"""Boundary cases for table-macro correction and unchanged micro scoring."""

import sys
from pathlib import Path

import pytest
from build_macro_metrics import average_runs, run_scores, table_scores

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from src.evaluation.paper_evaluation.analysis import classify_table


def table(tp=0, fp=0, fn=0, execution="complete"):
    return {"tp": tp, "fp": fp, "fn": fn, "execution": execution}


def test_completed_clean_empty_table_gets_preservation_outside_correction_cohort():
    assert table_scores(table()) == {
        "precision": None,
        "recall": None,
        "f1": None,
        "preservation": 1.0,
        "all_table_f1": 1.0,
    }
    scores = run_scores({"empty": table(), "error": table(tp=1)})
    assert scores["macro_f1"] == 100
    assert scores["macro_precision"] == scores["macro_recall"] == 100
    assert scores["target_tables"] == scores["macro_precision_tables"] == 1
    assert scores["macro_recall_tables"] == scores["macro_f1_tables"] == 1
    assert scores["preservation"] == 100
    assert scores["preservation_tables"] == 1
    assert scores["all_table_macro_f1"] == 100


def test_missed_empty_table_stays_in_fixed_target_cohort_and_scores_zero():
    assert table_scores(table(fn=1)) == {
        "precision": 0,
        "recall": 0,
        "f1": 0,
        "preservation": None,
        "all_table_f1": 0,
    }
    assert table_scores(table(fp=1)) == {
        "precision": None,
        "recall": None,
        "f1": None,
        "preservation": 0,
        "all_table_f1": 0,
    }
    scores = run_scores({"changed_clean": table(fp=2), "left_error": table(fn=1)})
    assert scores["macro_f1"] == 0
    assert scores["macro_precision"] == 0
    assert scores["macro_precision_tables"] == 1
    assert scores["macro_recall"] == 0
    assert scores["preservation"] == 0
    assert scores["successful_zero_target"] == 0
    assert scores["zero_target_wrong_edit"] == 1


@pytest.mark.parametrize("status", ["failed", "unknown"])
def test_execution_failure_or_unknown_does_not_earn_empty_table_credit(status):
    failed_target = table_scores(table(fn=1, execution=status))
    assert failed_target == {
        "precision": 0,
        "recall": 0,
        "f1": 0,
        "preservation": None,
        "all_table_f1": 0,
    }
    failed_clean = table_scores(table(execution=status))
    assert failed_clean == {
        "precision": None,
        "recall": None,
        "f1": None,
        "preservation": 0,
        "all_table_f1": 0,
    }
    scores = run_scores(
        {"incomplete": table(execution=status), "empty": table(), "target": table(fn=1)}
    )
    assert scores["macro_f1"] == scores["macro_precision"] == scores["macro_recall"] == 0
    assert scores["macro_precision_tables"] == 1
    assert scores["preservation"] == 50
    assert scores["preservation_tables"] == 2
    assert scores["all_table_macro_f1"] == pytest.approx(100 / 3)
    assert scores["zero_target_failed"] == 1
    assert scores["successful_zero_target"] == 1


def test_failed_partial_output_keeps_micro_counts_but_has_zero_table_f1():
    scores = run_scores({"partial": table(tp=1, fn=1, execution="failed")})
    assert scores["micro_f1"] == pytest.approx(200 / 3)
    assert scores["macro_f1"] == scores["macro_precision"] == scores["macro_recall"] == 0
    assert scores["target_tables"] == 1
    assert scores["preservation"] is None


def test_wrong_replacement_counts_as_false_positive_and_unrecovered_target():
    coordinate = ("t", 0, 0)
    counts, _ = classify_table(
        {coordinate: "wrong"},
        {coordinate},
        set(),
        {coordinate},
        {coordinate: {"accepted"}},
        "e2e",
        "complete",
        lambda _: False,
    )
    assert (counts["tp"], counts["fp"], counts["fn"]) == (0, 1, 1)
    assert table_scores(counts)["f1"] == 0


def test_ambiguous_ignored_and_original_acceptable_edits_preserve_immunity():
    ambiguous, ignored, unchanged = [("t", 0, col) for col in range(3)]
    counts, _ = classify_table(
        {ambiguous: "edit", ignored: "edit", unchanged: "accepted"},
        {unchanged},
        {ambiguous},
        set(),
        {},
        "e2e",
        "complete",
        lambda cell: cell == ignored,
    )
    assert (counts["tp"], counts["fp"], counts["fn"]) == (0, 0, 0)
    assert table_scores(counts)["precision"] is None
    assert table_scores(counts)["f1"] is None
    assert table_scores(counts)["preservation"] == 1
    assert table_scores(counts)["all_table_f1"] == 1


def test_all_macro_metrics_use_same_target_cohort_and_preservation_is_separate():
    scores = run_scores(
        {
            "edited": table(tp=1, fp=1),
            "clean": table(),
            "missed": table(fn=1),
            "failed": table(execution="failed"),
        }
    )
    assert scores["macro_precision"] == 25
    assert scores["macro_precision_tables"] == 2
    assert scores["micro_precision"] == scores["micro_recall"] == scores["micro_f1"] == 50
    assert scores["macro_recall"] == 50
    assert scores["macro_recall_tables"] == 2
    assert scores["macro_f1_tables"] == scores["target_tables"] == 2
    assert scores["macro_f1"] == pytest.approx(100 / 3)
    assert scores["preservation_tables"] == 2
    assert scores["preservation"] == 50
    assert scores["all_table_macro_f1"] == pytest.approx(100 * (2 / 3 + 1) / 4)


def test_target_abstention_does_not_drop_out_of_cross_run_average():
    abstained = run_scores({"clean": table(), "missed": table(fn=1)})
    assert abstained["macro_precision"] == abstained["macro_recall"] == abstained["macro_f1"] == 0
    assert abstained["macro_precision_tables"] == 1
    assert abstained["preservation"] == 100
    productive = run_scores({"clean": table(), "correct": table(tp=1)})
    mean = average_runs([abstained, productive])
    assert mean["macro_precision"] == 50
    assert mean["macro_precision_tables"] == 1
    assert mean["macro_recall"] == 50
    assert mean["macro_f1"] == 50
    assert mean["preservation"] == 100
    assert mean["all_table_macro_f1"] == 75


def test_no_target_run_has_undefined_correction_metrics_and_defined_preservation():
    scores = run_scores(
        {"clean": table(), "modified": table(fp=1), "failed": table(execution="failed")}
    )
    for key in ("macro_precision", "macro_recall", "macro_f1"):
        assert scores[key] is None
        assert average_runs([scores])[key] is None
    assert scores["target_tables"] == scores["macro_f1_tables"] == 0
    assert scores["preservation_tables"] == 3
    assert scores["preservation"] == scores["all_table_macro_f1"] == pytest.approx(100 / 3)


def test_no_preservation_population_leaves_correction_scores_defined():
    scores = run_scores({"correct": table(tp=1), "missed": table(fn=1)})
    assert scores["target_tables"] == 2
    assert scores["preservation_tables"] == 0
    assert scores["preservation"] is None
    assert average_runs([scores])["preservation"] is None
    assert scores["macro_f1"] == scores["all_table_macro_f1"] == 50


def test_false_alarm_on_zero_target_table_affects_micro_and_preservation_only():
    scores = run_scores({"correct": table(tp=1), "false_alarm": table(fp=1)})
    assert scores["micro_precision"] == 50
    assert scores["micro_recall"] == 100
    assert scores["micro_f1"] == pytest.approx(200 / 3)
    assert scores["macro_precision"] == scores["macro_recall"] == scores["macro_f1"] == 100
    assert scores["preservation"] == 0
    assert scores["all_table_macro_f1"] == 50


def test_macro_f1_averages_table_f1_not_precision_recall_or_summed_counts():
    scores = run_scores({"easy": table(tp=1), "hard": table(fn=9)})
    assert scores["micro_f1"] == pytest.approx(200 / 11)
    assert scores["macro_f1"] == 50
    assert scores["macro_precision"] == 50
    assert scores["macro_recall"] == 50


def test_repetitions_are_averaged_after_each_run_is_scored():
    first = run_scores({"a": table(tp=1), "b": table(fn=9)})
    second = run_scores({"a": table(tp=9), "b": table(fn=1)})
    result = average_runs([first, second])
    assert result["runs"] == 2
    assert result["micro_f1"] == pytest.approx((200 / 11 + 1800 / 19) / 2)
    assert result["micro_f1"] != pytest.approx(200 / 3)
    assert result["macro_f1"] == 50
