"""Check exact-size micro aggregation and unsupported F1 display points."""

import pytest
from build_exact_size_metrics import aggregate_exact


def test_exact_sizes_sum_cells_then_average_runs():
    manifest = {
        "a": dict(columns=2, rows=10, labeled_errors=1),
        "b": dict(columns=2, rows=11, labeled_errors=9),
        "c": dict(columns=3, rows=10, labeled_errors=0),
    }
    runs = [
        dict(task="detection", category="test", method="M", counts=c)
        for c in (
            {"a": [1, 0, 0], "b": [0, 0, 9], "c": [0, 2, 0]},
            {"a": [0, 0, 1], "b": [9, 9, 0], "c": [0, 0, 0]},
        )
    ]
    results = {(r["dimension"], r["size"]): r for r in aggregate_exact(manifest, runs)}
    two = results["columns", 2]
    assert two["tables"] == 2 and two["targets"] == 10
    assert two["f1"] == pytest.approx(100 * ((2 / 11) + (18 / 28)) / 2)
    assert two["precision"] == 75
    assert results["rows", 10]["tables"] == 2
    assert results["rows", 11]["targets"] == 9
    assert results["columns", 3]["f1"] == 0
    assert results["columns", 3]["f1_defined"]


def test_no_events_are_gaps_but_failed_targets_remain_zero():
    manifest = {
        "a": dict(columns=2, rows=10, repair_targets=0),
        "b": dict(columns=3, rows=11, repair_targets=2),
    }
    runs = [dict(task="e2e", category="test", method="M", counts={"a": [0, 0, 0], "b": [0, 0, 2]})]
    results = {(r["dimension"], r["size"]): r for r in aggregate_exact(manifest, runs)}
    assert not results["columns", 2]["f1_defined"]
    assert results["columns", 3]["f1_defined"]
    assert results["columns", 3]["f1"] == 0
