"""Recompute macro metrics from the published Table 3 counts, excluding zero denominators.

Usage: python tools/build_defined_macro_results.py --public-repo /path/to/CleanBench
Then:  python tools/build_diagnostic_task_tables.py --macro-only
Reads Git objects at a fixed revision, leaving working-tree scoring experiments untouched.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import statistics
import subprocess
from pathlib import Path

PAPER = Path(__file__).resolve().parents[1]
REVISION = "3c0d6cc64585af3cda9f52d44c6e0aee06b7068d"
KINDS = ("typo-spelling", "typo-formatting", "inconsistency")
METRICS = ("precision", "recall", "f1")


def table_scores(table):
    tp, fp, fn = (table[key] for key in ("tp", "fp", "fn"))
    if any(not isinstance(value, int) or value < 0 for value in (tp, fp, fn)):
        raise ValueError("Counts must be nonnegative integers")
    return {
        "precision": tp / (tp + fp) if tp + fp else None,
        "recall": tp / (tp + fn) if tp + fn else None,
        "f1": 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else None,
    }


def average_defined(values):
    values = [value for value in values if value is not None]
    return (100 * statistics.mean(values) if values else None), len(values)


def run_scores(tables):
    scores = [table_scores(table) for table in tables]
    result, denominators = {}, {}
    for metric in METRICS:
        result[metric], denominators[metric] = average_defined(row[metric] for row in scores)
    for kind in KINDS:
        field = f"recall_{kind}"
        result[field], denominators[field] = average_defined(
            table["types"][kind]["hit"] / table["types"][kind]["gt"]
            if table["types"][kind]["gt"]
            else None
            for table in tables
        )
    return result, denominators


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--public-repo", type=Path, required=True)
    parser.add_argument("--revision", default=REVISION)
    args = parser.parse_args()

    def git(*arguments):
        return subprocess.check_output(["git", "-C", str(args.public_repo), *arguments])

    revision = git("rev-parse", f"{args.revision}^{{commit}}").decode().strip()
    hashes = {}

    def read(path):
        data = git("show", f"{revision}:{path}")
        hashes[path] = hashlib.sha256(data).hexdigest()
        return data.decode()

    root = "reproducibility/table3"
    roster = list(csv.DictReader(io.StringIO(read(f"{root}/expected/table3_point.csv"))))
    paths = git("ls-tree", "-r", "--name-only", revision, f"{root}/methods").decode().splitlines()
    grouped = {row["method"]: [] for row in roster}
    for path in paths:
        if not path.endswith("/table_counts.jsonl"):
            continue
        tables = [json.loads(line) for line in read(path).splitlines()]
        metadata = json.loads(read(path.replace("table_counts.jsonl", "run.json")))
        assert len(tables) == len({table["dataset"] for table in tables}) == 1000
        totals = {key: sum(table[key] for table in tables) for key in ("tp", "fp", "fn")}
        assert totals["tp"] + totals["fn"] == 1093
        # Published failed/incomplete outputs have no correct repairs.
        assert all(table["tp"] == 0 for table in tables if table["execution"] != "complete")
        macro, denominators = run_scores(tables)
        assert all(value is not None for value in macro.values())
        assert denominators["recall"] == 164
        assert [denominators[f"recall_{kind}"] for kind in KINDS] == [106, 79, 61]
        grouped[metadata["method"]].append(
            {
                "run": metadata["run"],
                "macro": macro,
                "tables": denominators,
                "micro": table_scores(totals),
            }
        )

    rows = []
    for reference in roster:
        runs = grouped[reference["method"]]
        assert len(runs) == len({run["run"] for run in runs}) == int(reference["repetitions"])
        for metric in METRICS:
            micro = 100 * statistics.mean(run["micro"][metric] or 0 for run in runs)
            assert math.isclose(micro, float(reference[metric]), abs_tol=1e-9)
        row = {key: reference[key] for key in ("task", "category", "method", "repetitions")}
        for metric in (*(f"recall_{kind}" for kind in KINDS), *METRICS):
            row[metric] = statistics.mean(run["macro"][metric] for run in runs)
        rows.append(row)
    assert len(rows) == 21 and sum(len(runs) for runs in grouped.values()) == 59
    generated = PAPER / "assets/generated"
    with (generated / "e2e_macro_results.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    evidence = {
        "source_revision": revision,
        "source_sha256": hashes,
        "policy": "Average each per-table metric only where its denominator is positive; "
        "average per-table F1 independently of macro precision and recall; "
        "then average the run scores. Type recall uses tables with targets of that type.",
        "runs": grouped,
    }
    (generated / "e2e_defined_macro_evidence.json").write_text(
        json.dumps(evidence, indent=2) + "\n"
    )
    print("Recomputed 21 methods / 59 runs; all published micro scores verified unchanged.")


if __name__ == "__main__":
    main()
