"""Check FPR units, clean-cell scope, and consistency with frozen results."""

import statistics

import build_accuracy_presentation as presentation
import pytest
from build_accuracy_presentation import e2e_display_rows, e2e_table_rows, read


def test_table_preserves_overall_scores_and_type_recalls():
    roster = read("task_type_metrics.csv")
    rows = e2e_table_rows(roster, read("false_edits_ba_runs.csv"))
    original = {row["method"]: row for row in roster if row["task"] == "e2e"}
    assert len(rows) == 21
    for row in rows:
        assert not row["method"].endswith(" (Base)")
        assert not row["method"].startswith("Opus ")
        assert all(row[key] == value for key, value in original[row["method"]].items())


def test_fpr_excludes_wrong_replacements_at_errors():
    rows = e2e_table_rows(read("task_type_metrics.csv"), read("false_edits_ba_runs.csv"))
    symspell = next(row for row in rows if row["method"] == "SymSpell")
    assert symspell["fpr"] == pytest.approx(100 * 12493 / 362393)
    assert symspell["fpr"] != pytest.approx(100 * 12638 / 362393)
    daisy = next(row for row in rows if row["method"] == "DaisyP")
    assert daisy["fpr"] == pytest.approx(100 * 14 / 362393)
    assert f"{daisy['fpr']:.4f}" == "0.0039"


def test_fpr_uses_the_same_retained_repetitions():
    raw = read("false_edits_ba_runs.csv")
    rows = e2e_table_rows(read("task_type_metrics.csv"), raw)
    for row in rows:
        runs = [run for run in raw if run["method"] == row["method"]]
        assert len(runs) == int(row["repetitions"])
        expected = statistics.mean(
            100 * int(run["fp_clean"]) / int(run["clean_cells"]) for run in runs
        )
        assert row["fpr"] == pytest.approx(expected)


def test_default_point_redraw_uses_published_trials_instead_of_historical_runs():
    roster = read("task_type_metrics.csv")
    types = {(r["task"], r["method"], r["error_type"]): r for r in read("task_type_precision.csv")}
    assert e2e_display_rows(roster, types) == read("e2e_table_point.csv")
    assert e2e_display_rows(roster, types, recompute=True) == e2e_table_rows(
        roster, read("false_edits_ba_runs.csv")
    )


@pytest.mark.parametrize("field", ["precision", "repetitions"])
def test_point_redraw_rejects_a_different_mean_or_run_cohort(monkeypatch, field):
    original = presentation.read

    def changed(name):
        rows = original(name)
        if name == "e2e_table_point.csv":
            rows[0][field] = str(float(rows[0][field]) + 1) if field == "precision" else "99"
        return rows

    monkeypatch.setattr(presentation, "read", changed)
    with pytest.raises(ValueError, match="summaries differ"):
        e2e_display_rows(original("task_type_metrics.csv"), {})
