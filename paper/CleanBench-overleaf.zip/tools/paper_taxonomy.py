"""Project historical cell labels into three paper types without changing labels.

Overlapping historical types are merged as coordinate unions. Frozen per-type
hit counts are sufficient except at their intersections, which are rescored
from the original predictions before inclusion-exclusion is applied.
"""

from __future__ import annotations

import json
from pathlib import Path

DISPLAY_TYPES = [
    ("typo-spelling", "Spelling"),
    ("typo-formatting", "Formatting"),
    ("inconsistency", "Inconsistency"),
]
INCONSISTENCY_TYPES = ("inconsistency", "semantic_incompatible", "numeric_outlier")


def project_sets(fine):
    return {
        "typo-spelling": set(fine.get("typo-spelling", set())),
        "typo-formatting": set(fine.get("typo-formatting", set())),
        "inconsistency": set().union(*(fine.get(k, set()) for k in INCONSISTENCY_TYPES)),
    }


def overlaps(fine):
    seen, duplicate = set(), set()
    for kind in INCONSISTENCY_TYPES:
        cells = fine.get(kind, set())
        duplicate |= seen & cells
        seen |= cells
    return duplicate


def project_counts(fine_counts, fine_sets, correct_overlap):
    """Merge counts using raw-coordinate hits on overlapping target sets."""
    duplicate = overlaps(fine_sets)
    assert correct_overlap <= duplicate
    for kind in INCONSISTENCY_TYPES:
        row = fine_counts[kind]
        assert row["gt"] == len(fine_sets[kind])
        assert 0 <= row["hit"] <= row["gt"]
        expected = row["hit"] / row["gt"] if row["gt"] else 0
        assert abs(row["recall"] - expected) < 1e-12
    excess = sum(
        sum(cell in fine_sets[k] for k in INCONSISTENCY_TYPES) - 1 for cell in correct_overlap
    )
    hit = sum(fine_counts[k]["hit"] for k in INCONSISTENCY_TYPES) - excess
    support = len(project_sets(fine_sets)["inconsistency"])
    assert 0 <= hit <= support
    return {
        **{k: fine_counts[k] for k in ("typo-spelling", "typo-formatting")},
        "inconsistency": dict(hit=hit, gt=support, recall=hit / support if support else 0),
    }


def correct_overlap(records, truth, task):
    from external.rein.score_repair import _extract_value

    targets = overlaps(truth.fine)
    if task != "detection":
        targets &= truth.eligible
    result = set()
    for row in records:
        cell = (row["dataset"], int(row["row"]), int(row["col"]))
        if cell in targets and (task == "detection" or _extract_value(row) in truth.accepted[cell]):
            result.add(cell)
    return result


def project_run(fine, records, truth, task):
    targets = {
        k: cells if task == "detection" else cells & truth.eligible
        for k, cells in truth.fine.items()
    }
    return project_counts(fine, targets, correct_overlap(records, truth, task))


def read_predictions(path, detector=None):
    records = [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]
    return records if detector is None else [r for r in records if r["detector"] == detector]
