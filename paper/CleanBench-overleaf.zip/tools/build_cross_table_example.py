"""Render Figure 1(b): a confirmed conflict found by comparing two tables.

The tables reproduce frozen CSV strings. A shared email establishes the link;
human labels establish the conflict. No website or replacement is inferred.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
import subprocess
from pathlib import Path

from PIL import Image
from playwright.sync_api import sync_playwright

if __package__:
    from .figure_style import COLUMN_WIDTH
else:
    from figure_style import COLUMN_WIDTH

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parent
CASE = PAPER / "figures/cross_table_detection.json"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def records(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]


def audit(case):
    for name, expected in case["source_sha256"].items():
        assert digest(ROOT / name) == expected, name
    assert digest(PAPER / "figures/figure5_examples.json") == case["recovered_example_sha256"]
    snapshot = ROOT / case["snapshot"]["path"]
    manifest = json.loads((snapshot / "_manifest.json").read_text())
    targets = []
    for table, key in zip(case["tables"], case["linkage"]["keys_by_table"], strict=True):
        metadata = manifest["datasets"][table["dataset_id"]]
        with (ROOT / table["csv_path"]).open(newline="", encoding="utf-8-sig") as stream:
            reader = csv.DictReader(stream)
            rows = list(reader)
            assert reader.fieldnames == table["headers"] == metadata["columns"]
        assert table["source_path"] == metadata["source_path"]
        assert table["display_columns"] == ["First Name", "Last Name", key[0]]
        for item in table["context"]:
            assert rows[item["snapshot_row"]] == item["values"]
            assert metadata["exported_to_source"][item["snapshot_row"]] == item["source_row"]
        target = rows[table["target_snapshot_row"]]
        assert sum(row[key[0]] == target[key[0]] for row in rows) == 1
        targets.append(target)
    keys = case["linkage"]["keys_by_table"]
    assert targets[0][keys[0][0]] == targets[1][keys[1][0]]
    assert targets[0]["Last Name"] != targets[1]["Last Name"]
    for field in case["linkage"]["corroborating_fields"]:
        assert targets[0][field] == targets[1][field]
    for annotation in case["annotations"]:
        history = records(ROOT / annotation["source"])
        latest = [r for r in history if r["violation_id"] == annotation["annotation_id"]][-1]
        assert latest == history[annotation["source_line"] - 1] == annotation["record"]
        assert latest["status"] == "confirmed_inconsistency"
        assert latest["workbook"] == case["workbook"]
    for witness in case["witnesses"]:
        assert records(ROOT / witness["source"])[witness["source_line"] - 1] == witness["record"]
        r = witness["record"]
        target_keys = {(t["dataset_id"] + ".csv", t["target_snapshot_row"]) for t in case["tables"]}
        assert (r["sheet"], r["row"]) in target_keys
        assert all((link["sheet"], link["row"]) in target_keys for link in r["linked"])
    benchmark = records(ROOT / "benchmark/CleanBench/benchmark_row.json")
    for record in case["benchmark_records"]:
        assert record in benchmark and record["status"] == "error"
        assert record["workbook"] == case["workbook"]
    assert case["directional_correction"] is None
    ref = case["display"]["reference_style"]
    assert digest(PAPER / ref["file"]) == ref["sha256"]
    with Image.open(PAPER / ref["file"]) as image:
        assert list(image.size) == ref["canvas_px"]
        for name, sample in ref["color_samples"].items():
            expected = tuple(bytes.fromhex(ref["colors"][name].removeprefix("#")))
            assert image.getpixel(tuple(sample))[:3] == expected, name
    assert (
        abs(case["display"]["font_size_bp"] - ref["body_font_px"] / 3684 * COLUMN_WIDTH * 72) < 1e-9
    )


def document(case):
    spec = case["display"]
    ref = spec["reference_style"]
    colors = ref["colors"]
    scale = spec["width_css_px"] / ref["canvas_px"][0]
    px = lambda value: f"{value * scale:g}px"
    blocks = []
    for index, table in enumerate(case["tables"]):
        columns = table["display_columns"]
        styles = f"left:{px(ref['table_left_px'])};top:{px(ref['table_top_px'][index])}"
        blocks.append(f'<section class="sheet" style="{styles}"><table><colgroup>')
        blocks.extend(f'<col style="width:{px(w)}">' for w in ref["column_widths_px"])
        blocks.append('</colgroup><thead><tr class="letters"><th class="corner"></th>')
        for column in columns:
            letter = chr(65 + table["headers"].index(column))
            blocks.append(f"<th>{letter}</th>")
        blocks.append('</tr><tr class="fields"><th class="coord">1</th>')
        for column in columns:
            blocks.append(
                f'<th>{html.escape(column)}<span class="filter" aria-hidden="true"></span></th>'
            )
        blocks.append("</tr></thead><tbody>")
        for item in table["context"]:
            target = item["snapshot_row"] == table["target_snapshot_row"]
            worksheet_row = item["source_row"] + 2
            classes = ("banded " if worksheet_row % 2 == 0 else "") + ("target" if target else "")
            blocks.append(f'<tr class="{classes}"><th class="coord">{worksheet_row}</th>')
            for column in columns:
                value = item["values"][column]
                key = (
                    f"{table['dataset_id']}:{item['snapshot_row']}:{table['headers'].index(column)}"
                )
                blocks.append(f'<td data-cell="{html.escape(key)}">{html.escape(value)}</td>')
            blocks.append("</tr>")
        blocks.append("</tbody></table></section>")
    names = [
        next(
            r["values"]["Last Name"]
            for r in t["context"]
            if r["snapshot_row"] == t["target_snapshot_row"]
        )
        for t in case["tables"]
    ]
    return f"""<!doctype html><meta charset="utf-8"><style>
*{{box-sizing:border-box}}html,body{{margin:0;background:white}}
#figure{{position:relative;width:{spec['width_css_px']}px;height:{spec['height_css_px']}px;
font:{px(ref['body_font_px'])}/1.2 "Liberation Sans",Arial,sans-serif;color:{colors['text']}}}
.sheet{{position:absolute}}table{{border-collapse:collapse;table-layout:fixed;width:{px(ref['table_width_px'])}}}
th,td{{height:{px(ref['row_height_px'])};padding:0 {px(8)};text-align:left;white-space:nowrap;
font-weight:400;border:{px(ref['grid_width_px'])} solid {colors['grid']};vertical-align:middle}}
.fields th{{position:relative;background:{colors['header']};color:white;font-weight:700;
font-size:{px(ref['header_font_px'])};padding-right:{px(100)}}}
.letters th,.coord{{background:{colors['coordinate']};text-align:center;padding:0;
border-color:#d3d3d3;color:black}}
.letters th{{height:{px(ref['column_heading_height_px'])}}}
.fields th.coord{{background:{colors['coordinate']};color:black;font-weight:400;
font-size:{px(ref['body_font_px'])};padding:0;border-color:#d3d3d3}}
.corner{{position:relative}}.corner:after{{content:"";position:absolute;right:{px(12)};bottom:{px(12)};
border-left:{px(72)} solid transparent;border-bottom:{px(72)} solid #d9d9d9}}
td{{background:{colors['plain']}}}.banded td{{background:{colors['stripe']}}}
.filter{{position:absolute;right:{px(4)};top:{px(8)};width:{px(ref['filter_button_px'])};
height:{px(ref['filter_button_px'])};border:{px(4)} solid #a2b4bf;background:linear-gradient(white,#edf0f2)}}
.filter:after{{content:"";position:absolute;left:50%;top:50%;transform:translate(-50%,-25%);
border-left:{px(16)} solid transparent;border-right:{px(16)} solid transparent;border-top:{px(16)} solid #707070}}
.links{{position:absolute;inset:0;width:100%;height:100%;overflow:visible;pointer-events:none}}
</style><div id="figure">{''.join(blocks)}
<svg class="links" viewBox="0 0 3684 1543" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
<defs><marker id="join-arrow" viewBox="0 0 60 60" refX="52" refY="30" markerWidth="60" markerHeight="60"
markerUnits="userSpaceOnUse" orient="auto"><path d="M0 0 L60 30 L0 60 Z" fill="{colors['selection']}"/></marker></defs>
<rect id="selection-0" class="selection" fill="none" stroke="{colors['selection']}" stroke-width="{ref['selection_width_px']}"/>
<rect id="selection-1" class="selection" fill="none" stroke="{colors['selection']}" stroke-width="{ref['selection_width_px']}"/>
<path id="join" fill="none" stroke="{colors['selection']}" stroke-width="14" marker-end="url(#join-arrow)"/>
<text x="2750" y="790" fill="{colors['selection']}" font-family="Liberation Sans,Arial,sans-serif"
font-size="76" font-weight="700"><tspan x="2750">Same</tspan><tspan x="2750" dy="100">email</tspan></text>
<text class="finding" x="150" y="1450" fill="{colors['annotation']}" font-family="Liberation Sans,Arial,sans-serif"
font-size="76">Last names: <tspan font-weight="700">{html.escape(names[0])} ≠ {html.escape(names[1])}</tspan></text>
</svg></div>"""


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--browser", type=Path)
    parser.add_argument("--tectonic", type=Path, default=Path("tectonic"))
    args = parser.parse_args()
    case = json.loads(CASE.read_text())
    audit(case)
    folder = PAPER / "build/figure1_style_match"
    folder.mkdir(parents=True, exist_ok=True)
    page_path = folder / "cross_table_detection.html"
    page_path.write_text(document(case))
    spec = case["display"]
    with sync_playwright() as p:
        options = {"headless": True}
        if args.browser:
            options["executable_path"] = str(args.browser.resolve())
        browser = p.chromium.launch(**options)
        page = browser.new_page(viewport={"width": 921, "height": 386}, device_scale_factor=4)
        page.goto(page_path.as_uri())
        page.evaluate("document.fonts.ready")
        # Route a single matching link outside the tables, using their actual bounds.
        page.evaluate("""() => {
          const rows=[...document.querySelectorAll('tr.target')].map(e=>e.getBoundingClientRect());
          const scale=3684/document.querySelector('#figure').getBoundingClientRect().width;
          const x=rows[0].right*scale+20;
          const y1=(rows[0].top+rows[0].height/2)*scale;
          const y2=(rows[1].top+rows[1].height/2)*scale;
          rows.forEach((r,i)=>{
            const frame=document.querySelector(`#selection-${i}`);
            for(const [key,value] of Object.entries({x:r.left*scale,y:r.top*scale,width:r.width*scale,height:r.height*scale}))
              frame.setAttribute(key,value);
          });
          document.querySelector('#join').setAttribute('d',`M ${x} ${y1} H 2670 V ${y2} H ${x}`);
        }""")
        cells = page.locator("[data-cell]").evaluate_all(
            "es => es.map(e => [e.dataset.cell, e.textContent])"
        )
        expected = {
            f"{t['dataset_id']}:{r['snapshot_row']}:{t['headers'].index(c)}": r["values"][c]
            for t in case["tables"]
            for r in t["context"]
            for c in t["display_columns"]
        }
        assert dict(cells) == expected and len(cells) == 12
        assert page.locator("tr.target td:nth-of-type(2)").all_text_contents() == [
            "Lederman",
            "Ledderman",
        ]
        assert (
            page.locator("tr.target td:nth-of-type(3)").all_text_contents()
            == ["seth.lederman@tonixpharma.com"] * 2
        )
        assert page.locator("tr.letters").all_text_contents() == ["ABC", "ABC"]
        assert page.locator(".coord").all_text_contents() == ["1", "59", "60", "1", "19", "20"]
        assert page.locator(".filter").count() == 6
        overflow = page.locator("th,td").evaluate_all(
            "es => es.filter(e => e.scrollWidth > e.clientWidth+1).map(e => e.textContent)"
        )
        assert not overflow, overflow
        clipped = page.locator("th,td,.finding").evaluate_all(
            "es => {const b=document.querySelector('#figure').getBoundingClientRect();"
            "return es.filter(e=>{const r=e.getBoundingClientRect();return r.right>b.right+1||r.bottom>b.bottom+1||r.left<b.left-1;}).map(e=>e.textContent)}"
        )
        assert not clipped, clipped
        ref = spec["reference_style"]
        scale = spec["width_css_px"] / ref["canvas_px"][0]
        styles = page.locator("th,td,tr.target,.filter").evaluate_all("""es=>es.map(e=>{
          const s=getComputedStyle(e),r=e.getBoundingClientRect();
          return {tag:e.tagName,cls:e.className,parent:e.parentElement.className,
            text:e.textContent,fontsize:parseFloat(s.fontSize),weight:s.fontWeight,
            height:r.height,width:r.width,fill:s.backgroundColor,color:s.color,
            outline:s.outlineColor,outlineWidth:parseFloat(s.outlineWidth)};
        })""")
        for item in styles:
            if item["tag"] == "TD":
                assert item["fontsize"] == ref["body_font_px"] * scale
                assert item["weight"] == "400" and item["color"] == "rgb(0, 0, 0)"
                expected_fill = (
                    "rgb(192, 230, 245)" if "banded" in item["parent"] else "rgb(255, 255, 255)"
                )
                assert item["fill"] == expected_fill
                assert abs(item["height"] - ref["row_height_px"] * scale) < 0.1
            elif item["tag"] == "TH" and item["parent"] == "fields" and item["cls"] != "coord":
                assert item["fontsize"] == ref["header_font_px"] * scale
                assert item["weight"] == "700" and item["fill"] == "rgb(21, 96, 130)"
        selections = page.locator("rect.selection").evaluate_all(
            "es=>es.map(e=>({stroke:e.getAttribute('stroke'),width:parseFloat(e.getAttribute('stroke-width'))}))"
        )
        assert len(selections) == 2
        assert all(
            s["stroke"] == ref["colors"]["selection"] and s["width"] == ref["selection_width_px"]
            for s in selections
        )
        target = PAPER / "figures/paper/cross_table_detection.pdf"
        raw_pdf = folder / "cross_table_raw.pdf"
        page.locator("#figure").screenshot(path=str(target.with_suffix(".png")))
        page.pdf(
            path=str(raw_pdf),
            width=f"{spec['width_css_px']}px",
            height=f"{spec['height_css_px']}px",
            margin={"top": "0", "bottom": "0", "left": "0", "right": "0"},
            print_background=True,
        )
        # Chromium rounds paper dimensions. Preserve the reference's exact
        # frame using a vector clip; no table pixels or lettering are redrawn.
        width_bp = COLUMN_WIDTH * 72
        height_bp = width_bp * ref["canvas_px"][1] / ref["canvas_px"][0]
        tex = folder / "cross_table_detection.tex"
        tex.write_text(
            r"\documentclass[border=0pt]{standalone}\usepackage{graphicx,tikz}"
            + r"\begin{document}\begin{tikzpicture}[x=1bp,y=-1bp]"
            + rf"\begin{{scope}}\clip (0,0) rectangle ({width_bp:.8f},{height_bp:.8f});"
            + r"\node[inner sep=0,outer sep=0,anchor=north west] at (0,0) {"
            + rf"\includegraphics[width={width_bp:.8f}bp]{{\detokenize{{{raw_pdf.as_posix()}}}}}"
            + r"};\end{scope}\pgfresetboundingbox"
            + rf"\path[use as bounding box] (0,0) rectangle ({width_bp:.8f},{height_bp:.8f});"
            + r"\end{tikzpicture}\end{document}"
            + "\n"
        )
        subprocess.run(
            [str(args.tectonic), "--only-cached", "--outdir", str(target.parent), str(tex)],
            cwd=PAPER,
            check=True,
            stdout=subprocess.DEVNULL,
        )
        evidence = dict(
            case_sha256=digest(CASE),
            source_sha256=case["source_sha256"],
            displayed_cells=cells,
            font_size_bp=spec["font_size_bp"],
            reference_style=ref,
            verified_styles=styles,
            verified_row_selections=selections,
            canvas=page.locator("#figure").bounding_box(),
            overflow=overflow,
            clipped=clipped,
            model_calls=0,
            web_lookups=0,
            figure_sha256=digest(target),
            direction_inferred=False,
            exact_frame_bp=[width_bp, height_bp],
            raw_browser_pdf_sha256=digest(raw_pdf),
        )
        (folder / "render_evidence.json").write_text(json.dumps(evidence, indent=2) + "\n")
        browser.close()
    print(
        "Verified frozen coordinates, unique shared email, positive human labels, 12 displayed cells, and layout bounds."
    )


if __name__ == "__main__":
    main()
