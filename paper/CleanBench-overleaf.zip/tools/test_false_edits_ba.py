"""Check clean-cell counts, table alarms, and unsuccessful execution."""

from build_false_edits_ba_table import run_counts, run_scores


def table(tp=0, wrong=0, outside=0, targets=0, clean=100, execution="complete"):
    return dict(
        tp=tp,
        fp=wrong + outside,
        fn=targets - tp,
        wrong_at_target=wrong,
        outside_target=outside,
        scorable_cells=targets + clean,
        execution=execution,
    )


def test_wrong_repair_is_separate_from_clean_cell_fp():
    counts = run_counts({"dirty": table(wrong=1, targets=1), "clean": table()})
    scores = run_scores(counts)
    assert counts["fp"] == 1 and counts["fp_clean"] == 0
    assert scores["fp_per_100_clean_cells"] == scores["correction_recall"] == 0
    assert scores["table_balanced_accuracy"] == 100


def test_table_selection_does_not_require_an_edit_at_an_error():
    counts = run_counts({"dirty": table(outside=1, targets=1), "clean": table()})
    scores = run_scores(counts)
    assert scores["table_balanced_accuracy"] == 100
    assert scores["fp_per_100_clean_cells"] == 0.5
    assert counts["target_tables_with_correct_repairs"] == 0


def test_silent_baseline_is_fifty_despite_clean_majority():
    counts = run_counts({"dirty": table(targets=1), **{str(i): table() for i in range(9)}})
    assert run_scores(counts)["table_balanced_accuracy"] == 50


def test_failure_is_an_empty_alarm_but_not_a_completed_output():
    counts = run_counts({"dirty": table(targets=1), "failed": table(execution="failed")})
    scores = run_scores(counts)
    assert scores["table_balanced_accuracy"] == scores["completion"] == 50
    assert counts["failed_tables"] == 1
