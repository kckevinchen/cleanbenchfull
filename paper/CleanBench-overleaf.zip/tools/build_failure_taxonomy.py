"""Classify selected LLM/constraint correction outcomes; no model calls.

Default renders frozen counts. --refresh replays the canonical scorer against
the selected predictions and checks every run against the existing results.
"""

from __future__ import annotations

import argparse
import json
import statistics
import sys
from collections import defaultdict
from itertools import chain

from build_false_edits_ba_table import digest, read_csv, write_csv
from build_macro_metrics import PAPER, ROOT
from experiment_presentation import reported_method

if __package__:
    from .tex_sources import generated_asset
else:
    from tex_sources import generated_asset

GENERATED = PAPER / "assets/generated"
RUN_FILE = GENERATED / "failure_taxonomy_runs.csv"
CATEGORIES = ("Constraint-based", "LLM workflows", "Direct LLMs", "Coding agents")
FIELDS = (
    "correct",
    "unchanged_completed",
    "unchanged_failed",
    "unchanged_unknown",
    "wrong_value",
    "clean_edits",
)


def counts(tables):
    """Disjoint target outcomes; wrong values contribute to both FP and FN."""
    result = dict.fromkeys(FIELDS, 0)
    for row in tables.values():
        values = dict(
            correct=row["tp"],
            unchanged_completed=row["unrepaired_completed"],
            unchanged_failed=row["unrepaired_failed"],
            unchanged_unknown=row["unrepaired_unknown"],
            wrong_value=row["wrong_at_target"],
            clean_edits=row["outside_target"],
        )
        assert all(isinstance(v, int) and v >= 0 for v in values.values())
        unchanged = sum(values[k] for k in FIELDS if k.startswith("unchanged_"))
        assert row["fn"] == unchanged + values["wrong_value"]
        assert row["fp"] == values["wrong_value"] + values["clean_edits"]
        for key, value in values.items():
            result[key] += value
    return result


def refresh():
    sys.path.insert(0, str(ROOT))
    from build_macro_metrics import Inputs, agent_runs, api_runs, historical_runs

    from src.evaluation.paper_evaluation.analysis import GroundTruth

    inputs = Inputs()
    snapshot = ROOT / "outputs/baseline_campaign/20260910/snapshot"
    truth = GroundTruth(snapshot, inputs.read(snapshot / "_manifest.json"))
    existing = {
        (r["method"], int(r["run"])): r for r in read_csv(GENERATED / "false_edits_ba_runs.csv")
    }
    rows = []
    for run in chain(
        historical_runs(inputs, truth), api_runs(inputs, truth), agent_runs(inputs, truth)
    ):
        if run["category"] not in CATEGORIES:
            continue
        values = counts(run["tables"])
        unchanged = sum(values[k] for k in FIELDS if k.startswith("unchanged_"))
        assert values["correct"] + unchanged + values["wrong_value"] == len(truth.eligible) == 1093
        old = existing[run["method"], run["run"]]
        for field, value in (
            ("tp", values["correct"]),
            ("fn", unchanged + values["wrong_value"]),
            ("fp", values["wrong_value"] + values["clean_edits"]),
        ):
            assert value == int(old[field]) == run["expected"][field]
        assert values["clean_edits"] == int(old["fp_clean"])
        rows.append(dict(method=run["method"], category=run["category"], run=run["run"], **values))
    assert len(rows) == 32 and len({r["method"] for r in rows}) == 18
    write_csv(RUN_FILE, rows)
    (PAPER / "build/generated/failure_taxonomy_sources.json").write_text(
        json.dumps(dict(source_sha256=inputs.hashes, runs=len(rows), model_calls=0), indent=2)
        + "\n"
    )


def summarize(rows):
    groups = defaultdict(list)
    for row in rows:
        values = {k: int(row[k]) for k in FIELDS}
        values["unchanged"] = sum(values[k] for k in FIELDS if k.startswith("unchanged_"))
        assert values["correct"] + values["unchanged"] + values["wrong_value"] == 1093
        groups[row["category"], row["method"]].append(values)
    return [
        dict(
            category=c,
            method=m,
            runs=len(runs),
            **{k: statistics.mean(r[k] for r in runs) for k in runs[0]},
        )
        for (c, m), runs in groups.items()
    ]


def render(rows):
    lines = [
        r"\begingroup",
        r"\setlength{\tabcolsep}{3pt}",
        r"\small",
        r"\begin{tabular*}{\columnwidth}{@{\extracolsep{\fill}}lrrrr@{}}",
        r"\toprule",
        r"& \multicolumn{3}{c}{1,093 errors requiring correction} & Clean \\",
        r"Method & Correct & Unchanged & Wrong & edits \\",
    ]
    for category in CATEGORIES:
        lines += [r"\midrule", rf"\multicolumn{{5}}{{@{{}}l}}{{\textit{{{category}}}}} \\"]
        for row in rows:
            if row["category"] != category or not reported_method(row["method"]):
                continue
            label = row["method"].replace(" (Prompt-tuned)", "")
            digits = 1 if row["runs"] > 1 else 0
            values = [
                f"{row[k]:,.{digits}f}"
                for k in ("correct", "unchanged", "wrong_value", "clean_edits")
            ]
            lines.append(label + " & " + " & ".join(values) + r" \\")
    return "\n".join([*lines, r"\bottomrule", r"\end{tabular*}", r"\endgroup", ""])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--refresh", action="store_true")
    args = parser.parse_args()
    if args.refresh:
        refresh()
    rows = summarize(read_csv(RUN_FILE))
    write_csv(GENERATED / "failure_taxonomy_summary.csv", rows)
    (generated_asset("failure_taxonomy_table.tex", directory=GENERATED)).write_text(render(rows))
    (PAPER / "build/generated/failure_taxonomy_evidence.json").write_text(
        json.dumps(
            {
                "source_sha256": {str(RUN_FILE.relative_to(PAPER)): digest(RUN_FILE)},
                "methods": len(rows),
                "displayed_methods": sum(reported_method(row["method"]) for row in rows),
                "runs": sum(r["runs"] for r in rows),
                "model_calls": 0,
                "failure_classes": ["Unchanged error", "Wrong replacement", "Clean-cell edit"],
                "target_partition": "correct + unchanged + wrong_value = 1093",
                "false_negatives": "unchanged + wrong_value",
                "false_positives": "wrong_value + clean_edits",
            },
            indent=2,
        )
        + "\n"
    )
    print(
        f"Validated {len(rows)} methods and {sum(r['runs'] for r in rows)} runs; "
        f"rendered {sum(reported_method(row['method']) for row in rows)} methods."
    )


if __name__ == "__main__":
    main()
