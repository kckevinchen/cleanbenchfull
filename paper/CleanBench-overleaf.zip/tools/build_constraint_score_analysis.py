"""Build the full-paper constraint score diagnostic from frozen native outputs.

Default: redraw the saved aggregate CSVs. --refresh rescores existing predictions
with the full paper's all-error scorer; it never invokes a cleaning method or LLM.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import math
import statistics
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from figure_style import FIGURE_WIDTH, configure, validate_layout

PAPER = Path(__file__).resolve().parents[1]
DATA = PAPER / "assets/generated"
METHODS = {
    "bigdansing": "BigDansing",
    "holistic": "Holistic",
    "daisyp": "DaisyP",
    "horizon": "Horizon",
    "nadeef": "NADEEF",
    "llunatic": "LLUNATIC",
    "uniclean": "UniClean",
}
THRESHOLDS = (0, 20, 40, 60, 80, 90)
STEM = "constraint_score_all_errors"


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_csv(path, rows):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def refresh(study, scoring_root):
    sys.path.insert(0, str(PAPER.parent))
    from src.evaluation.semantic_threshold_analysis import cross_fit

    scorer = scoring_root / "src/reproducibility/table3.py"
    spec = importlib.util.spec_from_file_location("constraint_all_error_scorer", scorer)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    reference_path = scoring_root / "reproducibility/table3/reference.json"
    reference = read(reference_path)
    full_paper = read(DATA / "all_error_results.json")
    assert digest(reference_path) == full_paper["reference_sha256"]
    assert reference["population"]["targets"] == len(reference["targets"]) == 1409
    assert reference["scoring"]["accepted_unchanged_original"] == "correct"
    no_edits = module.score_run([], reference, {name: "complete" for name in reference["tables"]})
    no_edit_metrics, _ = module.metrics(no_edits)
    protocol = read(study / "protocol.json")
    assert digest(study / "candidate_bank.json") == protocol["candidate_bank_sha256"]
    assert protocol["rules"] == 1912 and protocol["tables"] == 168
    plans = read(study / "sweep/plans.json")
    assert len(plans) == 4 and set(plans["numeric"]) == set(map(str, THRESHOLDS))
    folds_path = Path(protocol["config"]["folds"])
    if not folds_path.is_absolute():
        folds_path = PAPER.parent / folds_path
    folds = read(folds_path)
    checksums = {str(p): digest(p) for p in (scorer, reference_path, folds_path)}
    cache = {}
    curve_rows, comparison, fold_results = [], [], {}
    for method, label in METHODS.items():
        outcomes = {}
        for policy, plan in plans.items():
            curves = {}
            for threshold in THRESHOLDS:
                bank = plan[str(threshold)]
                key = method, bank
                root = study / "sweep/native" / bank
                if key not in cache:
                    run = root / "results" / method / "run_01"
                    prediction, execution = run / "predictions.jsonl", run / "execution.json"
                    tables = module.score_run(
                        module.records(prediction), reference, read(execution)
                    )
                    scores, counts = module.metrics(tables)
                    assert counts["tables"] == 1000 and counts["targets"] == 1409
                    checksums.update({str(p): digest(p) for p in (prediction, execution)})
                    cache[key] = tables, scores, counts
                tables, scores, counts = cache[key]
                curves[threshold] = tables
                if policy == "numeric":
                    summary = read(root / "protocol.json")["summary"]
                    curve_rows.append(
                        dict(
                            method=label,
                            threshold=threshold,
                            candidate_rules=summary["shared_rules"],
                            consumed_rules=summary["methods"][method]["consumed_rules"],
                            **scores,
                            tp=counts["tp"],
                            fp=counts["fp"],
                            fn=counts["fn"],
                            failed_tables=sum(
                                t["execution"] != "complete" for t in tables.values()
                            ),
                        )
                    )
            outcomes[policy] = cross_fit(curves, folds)[0]
        selected = outcomes["numeric"]["out_of_fold"]
        random = [r["out_of_fold"]["f1"] for p, r in outcomes.items() if p != "numeric"]
        comparison.append(
            dict(
                method=label,
                all_f1=outcomes["numeric"]["all_constraints"]["f1"],
                numeric_f1=selected["f1"],
                random_mean_f1=statistics.mean(random),
                random_min_f1=min(random),
                random_max_f1=max(random),
                precision=selected["precision"],
                recall=selected["recall"],
            )
        )
        fold_results[method] = outcomes
        print(label, comparison[-1], flush=True)
    write_csv(DATA / f"{STEM}_thresholds.csv", curve_rows)
    write_csv(DATA / f"{STEM}_comparison.csv", comparison)
    evidence = dict(
        study=str(study),
        candidate_bank_sha256=protocol["candidate_bank_sha256"],
        population=reference["population"],
        scoring=reference["scoring"],
        thresholds=THRESHOLDS,
        distinct_method_banks=len(cache),
        folds=fold_results,
        source_sha256=checksums,
        no_edit_metrics=no_edit_metrics,
    )
    (DATA / f"{STEM}_evidence.json").write_text(json.dumps(evidence, indent=2) + "\n")


def draw():
    with (DATA / f"{STEM}_thresholds.csv").open() as stream:
        rows = list(csv.DictReader(stream))
    lookup = {(r["method"], int(r["threshold"])): r for r in rows}
    assert len(rows) == len(lookup) == len(METHODS) * len(THRESHOLDS)
    labels = list(METHODS.values())
    values = np.array([[float(lookup[m, t]["f1"]) for t in THRESHOLDS] for m in labels])
    for row in rows:
        tp, fp, fn = (int(row[k]) for k in ("tp", "fp", "fn"))
        assert tp + fn == 1409
        assert math.isclose(float(row["f1"]), 200 * tp / (2 * tp + fp + fn), abs_tol=1e-10)
    counts = [int(lookup[labels[0], t]["candidate_rules"]) for t in THRESHOLDS]
    assert all(
        int(lookup[m, t]["candidate_rules"]) == counts[j]
        for m in labels
        for j, t in enumerate(THRESHOLDS)
    )
    configure(font_size=9)
    fig = plt.figure(figsize=(FIGURE_WIDTH, 2.5))
    ax = fig.add_axes([0.18, 0.22, 0.66, 0.58])
    maximum = math.ceil(values.max() / 5) * 5
    cmap = plt.get_cmap("Blues")
    im = ax.imshow(values, cmap=cmap, vmin=0, vmax=maximum, aspect="auto")
    ax.set_xticks(range(6), [f"$\\geq${t}" for t in THRESHOLDS])
    ax.xaxis.tick_top()
    ax.xaxis.set_label_position("top")
    fig.text(0.51, 0.985, "Minimum semantic validity score", ha="center", va="top")
    ax.set_yticks(range(7), labels)
    ax.tick_params(axis="both", length=0, pad=6)
    for spine in ax.spines.values():
        spine.set_visible(False)
    for i in range(7):
        for j in range(6):
            rgba = cmap(values[i, j] / maximum)
            luminance = sum(c * w for c, w in zip(rgba[:3], (0.2126, 0.7152, 0.0722)))
            ax.text(
                j,
                i,
                f"{values[i, j]:.2f}",
                ha="center",
                va="center",
                color="white" if luminance < 0.5 else "#172a3b",
                weight="bold" if values[i, j] == values[i].max() else "normal",
            )
    for x in np.arange(-0.5, 6, 1):
        ax.axvline(x, color="white", linewidth=1)
    for y in np.arange(-0.5, 7, 1):
        ax.axhline(y, color="white", linewidth=1)
    for j, count in enumerate(counts):
        ax.text(j, -0.11, f"{count:,}", transform=ax.get_xaxis_transform(), ha="center", va="top")
    ax.text(-0.7, -0.11, "Constraints", transform=ax.get_xaxis_transform(), ha="right", va="top")
    cax = fig.add_axes([0.865, 0.22, 0.018, 0.58])
    fig.colorbar(im, cax=cax).set_label("End-to-end $F_1$ (%)", labelpad=6)
    validate_layout(fig)
    pdf = PAPER / "figures/paper/constraint_score_thresholds.pdf"
    preview = PAPER / "build/figure_previews/constraint_score_thresholds.png"
    preview.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(pdf)
    fig.savefig(preview, dpi=220)
    plt.close(fig)
    with (DATA / f"{STEM}_comparison.csv").open() as stream:
        comparison = list(csv.DictReader(stream))
    with (DATA / "constraint_original_table3.csv").open() as stream:
        original = {r["method"]: float(r["f1"]) for r in csv.DictReader(stream)}
    lines = [
        "% Generated by tools/build_constraint_score_analysis.py.",
        r"\newcommand{\CBConstraintScoreRows}{%",
    ]
    for row in comparison:
        lines.append(
            row["method"]
            + " & "
            + f"{original[row['method']]:.2f} & "
            + " & ".join(f"{float(row[key]):.2f}" for key in ("numeric_f1", "random_mean_f1"))
            + r" \\"
        )
    lines.append("}")
    (PAPER / "constraint_score_rows.tex").write_text("\n".join(lines) + "\n")
    with (DATA / "constraint_score_coverage.csv").open() as stream:
        coverage = list(csv.DictReader(stream))
    lines = [r"\newcommand{\CBConstraintCoverageRows}{%"]
    for row in coverage:
        if row["method"] == "Shared bank":
            lines.append(
                f"{row['threshold']} & {int(row['constraints']):,} & "
                f"{int(row['error_cells']):,} & {float(row['coverage_percent']):.1f}" + r" \\"
            )
    lines.append("}")
    (PAPER / "constraint_coverage_rows.tex").write_text("\n".join(lines) + "\n")
    print(pdf)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--refresh", action="store_true")
    parser.add_argument("--study", type=Path)
    parser.add_argument("--scoring-root", type=Path)
    args = parser.parse_args()
    if args.refresh:
        if args.study is None or args.scoring_root is None:
            parser.error("--refresh needs --study and --scoring-root")
        refresh(args.study.resolve(), args.scoring_root.resolve())
    draw()


if __name__ == "__main__":
    main()
