"""Build the full-paper constraint score diagnostic from frozen native outputs.

Redraw the aggregates produced by cleanbenchfull/scripts/reproduce_constraints.py.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from build_accuracy_presentation import CMAP, NORM
from figure_style import FIGURE_WIDTH, configure, validate_layout
from matplotlib.patches import Rectangle

PAPER = Path(__file__).resolve().parents[1]
DATA = PAPER / "assets/generated"
METHODS = {
    "bigdansing": "BigDansing",
    "holistic": "Holistic",
    "daisyp": "DaisyP",
    "horizon": "Horizon",
    "nadeef": "NADEEF",
    "llunatic": "LLUNATIC",
    "uniclean": "UniClean",
}
THRESHOLDS = (0, 20, 40, 60, 80, 90)
STEM = "constraint_score_consistency"


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_csv(path, rows):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def draw():
    with (DATA / f"{STEM}_thresholds.csv").open() as stream:
        rows = list(csv.DictReader(stream))
    lookup = {(r["method"], int(r["threshold"])): r for r in rows}
    assert len(rows) == len(lookup) == len(METHODS) * len(THRESHOLDS)
    labels = list(METHODS.values())
    for row in rows:
        tp, fp, fn = (int(row[k]) for k in ("tp", "fp", "fn"))
        assert tp + fn == 1178
        assert math.isclose(float(row["f1"]), 200 * tp / (2 * tp + fp + fn), abs_tol=1e-10)
    with (DATA / f"{STEM}_comparison.csv").open() as stream:
        comparison = list(csv.DictReader(stream))
    with (DATA / "e2e_consistency_point.csv").open() as stream:
        original = {r["method"]: r for r in csv.DictReader(stream)}
    selected = {r["method"]: int(r["threshold"]) for r in comparison}
    configure(font_size=8)
    fig = plt.figure(figsize=(FIGURE_WIDTH, 3.65))
    ax = fig.add_axes([0.002, 0.005, 0.996, 0.99])
    ax.set_xlim(0, 1)
    ax.set_ylim(18.1, -2.8)
    ax.axis("off")

    def label(x, y, text, *, ha="center", **style):
        ax.text(x, y, text, va="center", ha=ha, **style)

    def cell(x, y, width, value, digits, *, shade=True, bold=False):
        ax.add_patch(
            Rectangle(
                (x, y - 0.5),
                width,
                1,
                facecolor=CMAP(NORM(value)) if shade else "white",
                edgecolor="white",
                linewidth=0.55,
            )
        )
        label(
            x + width / 2,
            y,
            f"{value:.{digits}f}",
            color="white" if shade and value >= 80 else "black",
            weight="bold" if bold else "normal",
        )

    metrics = (
        ("precision", "P", 2),
        ("recall", "R", 2),
        ("f1", r"$F_1$", 2),
        ("fpr", "FPR", 3),
        ("recall_typo-spelling", "Spell.", 1),
        ("recall_typo-formatting", "Fmt.", 1),
        ("recall_inconsistency", "Incons.", 1),
    )
    width = 0.060
    filtered = {m: lookup[m, selected[m]] for m in labels}
    for start, heading, records in (
        (0.101, "Original constraints (Table 3)", original),
        (0.576, "Oracle-selected constraints", filtered),
    ):
        label(start + 3.5 * width, -2.15, heading, weight="bold")
        label(start + 2 * width, -1.15, "Overall (%)")
        label(start + 5.5 * width, -1.15, "Recall by type (%)")
        ax.hlines(
            [-0.67, -0.67],
            [start, start + 4 * width + 0.002],
            [start + 4 * width - 0.002, start + 7 * width],
            color="#8494a0",
            lw=0.5,
        )
        for j, (key, name, digits) in enumerate(metrics):
            x = start + width * j
            label(x + width / 2, 0, name)
            for i, method in enumerate(labels, start=1):
                cell(x, i, width, float(records[method][key]), digits, shade=key != "fpr")
    label(0.004, 0, "Method", ha="left")
    label(0.55, 0, r"$\tau$")
    for i, method in enumerate(labels, start=1):
        label(0.004, i, method, ha="left")
        label(0.55, i, selected[method])
    ax.hlines([0.5, 7.5], 0, 1, color="#324556", lw=0.65)

    label(0.5, 9.05, r"End-to-end $F_1$ (%) by minimum semantic validity score", weight="bold")
    label(0.004, 10.25, "Method", ha="left")
    sweep_start = 0.14
    sweep_width = (1 - sweep_start) / len(THRESHOLDS)
    for j, threshold in enumerate(THRESHOLDS):
        x = sweep_start + sweep_width * j
        label(x + sweep_width / 2, 10.25, threshold)
        for i, method in enumerate(labels):
            value = float(lookup[method, threshold]["f1"])
            peak = float(filtered[method]["f1"])
            assert value <= peak
            cell(x, 11.25 + i, sweep_width, value, 2, bold=value == peak)
    for i, method in enumerate(labels):
        label(0.004, 11.25 + i, method, ha="left")
    ax.hlines([10.75, 17.75], 0, 1, color="#324556", lw=0.65)
    validate_layout(fig)
    pdf = PAPER / "figures/paper/constraint_score_thresholds.pdf"
    preview = PAPER / "build/figure_previews/constraint_score_thresholds.png"
    preview.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(pdf)
    fig.savefig(preview, dpi=220)
    plt.close(fig)
    lines = [
        "% Generated by tools/build_constraint_score_analysis.py.",
        r"\newcommand{\CBConstraintScoreRows}{%",
    ]
    for row in comparison:
        lines.append(
            row["method"]
            + " & "
            + f"{float(original[row['method']]['f1']):.2f} & "
            + row["threshold"]
            + " & "
            + " & ".join(f"{float(row[key]):.2f}" for key in ("numeric_f1", "random_mean_f1"))
            + r" \\"
        )
    lines.append("}")
    (PAPER / "constraint_score_rows.tex").write_text("\n".join(lines) + "\n")
    with (DATA / "constraint_score_coverage.csv").open() as stream:
        coverage = list(csv.DictReader(stream))
    lines = [r"\newcommand{\CBConstraintCoverageRows}{%"]
    for row in coverage:
        if row["method"] == "Shared bank":
            lines.append(
                f"{row['threshold']} & {int(row['constraints']):,} & "
                f"{int(row['error_cells']):,} & {float(row['coverage_percent']):.1f}" + r" \\"
            )
    lines.append("}")
    (PAPER / "constraint_coverage_rows.tex").write_text("\n".join(lines) + "\n")
    print(pdf)


def main():
    draw()


if __name__ == "__main__":
    main()
