"""Redraw retained experiment figures from frozen evidence using the shared style.

Run after the historical renderers; no labels, predictions, or scores are changed.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import defaultdict
from pathlib import Path
from statistics import mean

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

if __package__:
    from .build_dataset_profile import draw as draw_profile
    from .build_error_types import draw as draw_types
    from .build_error_types import select_rows
    from .figure_style import FIGURE_WIDTH, FONT_SIZE, configure, save
    from .paper_taxonomy import project_run, read_predictions
else:
    from build_dataset_profile import draw as draw_profile
    from build_error_types import draw as draw_types
    from build_error_types import select_rows
    from figure_style import FIGURE_WIDTH, FONT_SIZE, configure, save
    from paper_taxonomy import project_run, read_predictions

PAPER = Path(__file__).resolve().parents[1]
SHORT = {
    "Excel Clean Data": "Excel",
    "KATARA (KB component)": "KATARA (KB)",
    "Google Sheets Cleanup": "Google Sheets",
}


def draw_repair(rows, categories, target):
    """Render the retained correction outcomes and outside-target editing rates."""
    configure()
    grouped = defaultdict(list)
    for row in rows:
        grouped[row["method"]].append(row)
    methods = [m for group in categories.values() for m in group if m in grouped]

    def average(method, field):
        return mean(r["analysis"]["full"][field] for r in grouped[method])

    fig, axes = plt.subplots(
        1,
        3,
        figsize=(FIGURE_WIDTH, 3.6),
        sharey=True,
        gridspec_kw={"width_ratios": [2.1, 1, 0.55]},
    )
    y, left = np.arange(len(methods)), np.zeros(len(methods))
    fields = [
        ("tp", "Correct value", "#247b68"),
        ("wrong_at_target", "Wrong value", "#cc6846"),
        ("unrepaired_completed", "No correction: completed", "#d0d6dc"),
        ("unrepaired_failed", "No correction: failed", "#606a76"),
        ("unrepaired_unknown", "No correction: status unknown", "#a58bb4"),
    ]
    for field, label, color in fields:
        values = np.array([100 * average(m, field) / average(m, "targets") for m in methods])
        if field == "unrepaired_unknown" and not np.any(values):
            continue
        axes[0].barh(y, values, left=left, color=color, label=label, height=0.72)
        left += values
    assert np.allclose(left, 100)
    axes[0].set_yticks(y, [SHORT.get(m, m) for m in methods])
    axes[0].invert_yaxis()
    axes[0].set_xlim(0, 100)
    axes[0].set_xlabel("Eligible replacement targets (%)")
    outside = [average(m, "outside_target") for m in methods]
    axes[1].barh(y, outside, color="#cc6846", height=0.72)
    axes[1].set_xscale("symlog", linthresh=10)
    axes[1].set_xticks([0, 100, 10000], ["0", "100", "10,000"])
    for i, value in enumerate(outside):
        axes[1].text(value, i, f" {value:,.0f}", va="center")
    axes[1].set_xlim(0, 10000000)
    axes[1].set_xlabel("Incorrect edits outside targets")
    axes[2].set_xlim(0, 1)
    axes[2].axis("off")
    axes[2].set_title("No labeled errors\nedits / 1,000")
    for i, method in enumerate(methods):
        rate = mean(
            r["analysis"]["subsets"]["no_labeled_errors"]["actions_per_1000_cells"]
            for r in grouped[method]
        )
        axes[2].text(0.5, i, f"{rate:.2f}", ha="center", va="center")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=3, frameon=False)
    fig.subplots_adjust(left=0.205, right=0.99, bottom=0.13, top=0.82, wspace=0.10)
    save(fig, target)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--results", type=Path, default=PAPER.parent / "outputs/paper_evaluation/20260920"
    )
    args = parser.parse_args()
    sources = {}

    def read(path):
        raw = path.read_bytes()
        sources[str(path)] = hashlib.sha256(raw).hexdigest()
        return json.loads(raw)

    selected_path = args.results / "selected_results.json"
    selected = read(selected_path)
    presentation = read(args.results / "presentation_selection.json")
    assert sources[str(selected_path)] == presentation["source_manifest_sha256"]
    rows = select_rows(args.results, selected, presentation)
    for name in ("excel_public", "cleanagent_repaired"):
        read(args.results / name / "selected_results.json")
    target = PAPER / "assets/generated"
    draw_repair(rows, presentation["categories"], target / "repair_diagnostics.pdf")
    sys.path.insert(0, str(PAPER.parent))
    from src.evaluation.paper_evaluation.analysis import GroundTruth

    snapshot = PAPER.parent / "outputs/baseline_campaign/20260910/snapshot"
    truth = GroundTruth(snapshot, read(snapshot / "_manifest.json"))
    for row in rows:
        path = Path(row["prediction_path"])
        if not path.is_absolute():
            path = PAPER.parent / path
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        assert actual == row["prediction_sha256"]
        sources[str(path)] = actual
        row["analysis"]["per_type"] = project_run(
            row["analysis"]["per_type"],
            read_predictions(path, row["configuration"]),
            truth,
            "e2e",
        )
    draw_types(rows, presentation["categories"], target / "type_source_diagnostics.pdf")
    profile = read(PAPER / "build/generated/corpus_profile.json")
    draw_profile(profile, target / "corpus_profile.pdf")
    evidence = {
        "sources": sources,
        "figures": {
            name: hashlib.sha256((target / name).read_bytes()).hexdigest()
            for name in (
                "corpus_profile.pdf",
                "repair_diagnostics.pdf",
                "type_source_diagnostics.pdf",
            )
        },
    }
    (PAPER / "build/generated/figure_typography.json").write_text(
        json.dumps(evidence, indent=2) + "\n"
    )
    print(f"Redrew retained figures with Linux Libertine at {FONT_SIZE} bp and fixed width.")


if __name__ == "__main__":
    main()
