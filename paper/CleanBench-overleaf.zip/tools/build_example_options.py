"""Render numbered, source-verified example options without changing the manuscript."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime
from pathlib import Path

from build_context_screenshots import FrozenSourceViews, SourceViews, esc, highlight_edits
from build_cross_table_example import audit as audit_cross_table
from figure_style import FIGURE_WIDTH, FONT_SIZE
from playwright.sync_api import sync_playwright
from worksheet_style import TABLE_FONT_BP, check_worksheet_style, worksheet_css

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parent
WIDTH = 1200
GAP = 32
CARD_WIDTH = (WIDTH - 2 * 24 - GAP) / 2


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def records(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def audit(config):
    snapshot = ROOT / config["snapshot"]
    assert digest(snapshot / "_manifest.json") == config["manifest_sha256"]
    assert digest(snapshot / "benchmark_cell.json") == config["benchmark_sha256"]
    for name, expected in config["source_references"].items():
        assert digest(PAPER / name) == expected, name
    FrozenSourceViews(PAPER / "figures/source_excerpt_reference.json").verify()
    payroll = json.loads((PAPER / "figures/figure5_examples.json").read_text())
    payroll = next(e for e in payroll["examples"] if e["example_id"] == "payroll_deadline_row_4")
    for proof in payroll["annotations"]:
        path = ROOT / proof["source"]
        assert digest(path) == proof["source_sha256"]
        assert records(path)[proof["source_line"] - 1] == proof["record"]
    row_proof = config["row_benchmark"]
    assert digest(ROOT / row_proof["path"]) == row_proof["sha256"]
    labels = records(snapshot / "benchmark_cell.json")
    relations = records(ROOT / row_proof["path"])
    views = SourceViews(snapshot)
    ids = [case["id"] for case in config["examples"]]
    assert ids and len(ids) == len(set(ids))
    assert sorted(ids) == sorted(c for group in config["groups"] for c in group["cases"])
    groups = {group["id"]: group for group in config["groups"]}
    # The mentor-review PDF must retain every option, including unselected ones.
    assert len(config["review_groups"]) == len(groups)
    assert set(config["review_groups"]) == set(groups)
    assert set(groups["selected"]["cases"]) <= set(config["selected_ids"])
    assert all(key in ids for key in config["selected_ids"])
    for case in config["examples"]:
        tables = {t["dataset"]: t for t in case["tables"]}
        for spec in case["tables"]:
            ds = spec["dataset"]
            headers, rows = views.load(ds)
            assert headers == spec["headers"]
            assert views.sources[ds]["sha256"] == spec["source_sha256"]
            assert set(map(int, spec["values"])) == set(spec["rows"]) - {None}
            for row, fields in spec["values"].items():
                assert list(fields) == spec["columns"]
                for field, value in fields.items():
                    assert rows[int(row)][headers.index(field)] == value
            assert all(r in spec["rows"] and c in spec["columns"] for r, c in spec["marks"])
        for correction in case["corrections"]:
            ds, record = correction["dataset"], correction["record"]
            assert record in labels and record["status"] == "error"
            assert record["source"] == views.manifest[ds]["source"]
            assert isinstance(record["corrected_value"], str)
            spec = tables[ds]
            assert record["original_value"] == spec["values"][str(record["row"])][record["column"]]
            assert [record["row"], record["column"]] in spec["marks"]
            expected = {
                "Spelling": {"typo-spelling"},
                "Formatting": {"typo-formatting"},
                "Inconsistency": {"inconsistency", "numeric_outlier", "semantic_incompatible"},
            }
            assert expected[case["type"]].intersection(record["error_types"])
        if "relation_record" in case:
            assert case["relation_record"] in relations
            assert case["relation_record"]["status"] == "error"
        if "same_entity_fields" in case:
            spec = case["tables"][0]
            headers, rows = views.load(spec["dataset"])
            selected_rows = [row for row in spec["rows"] if row is not None]
            assert selected_rows == case["relation_record"]["rows"]
            for field in case["same_entity_fields"]:
                assert len({rows[row][headers.index(field)] for row in selected_rows}) == 1
        if "relation_review" in case:
            proof = case["relation_review"]
            path = ROOT / proof["path"]
            assert digest(path) == proof["sha256"]
            history = records(path)
            record = history[proof["line"] - 1]
            assert record == proof["record"] and record["status"] == "tp"
            assert [r for r in history if r.get("target_id") == record["target_id"]][-1] == record
        if case["id"] == "I4":
            spec = case["tables"][0]
            for row, fields in spec["values"].items():
                match = fields["Payee"].split()[0] == fields["Payee Identification"]
                assert match == (int(row) != case["relation_record"]["target_row"])
            assert not case["corrections"]  # A confirmed conflict does not establish its repair.
        if case["id"] == "I5":
            spec = case["tables"][0]
            dates = [datetime.strptime(v, "%m/%d/%Y") for v in spec["values"]["4"].values()]
            accepted = datetime.strptime(
                case["corrections"][0]["record"]["corrected_value"], "%m/%d/%Y"
            )
            assert dates[2] < dates[0] <= accepted <= dates[1]
        if case["id"] == "I6":
            spec = case["tables"][0]
            _, rows = views.load(spec["dataset"])
            assert rows[10] == rows[11] and len(rows[10]) == 6
            assert case["relation_record"]["rows"] == spec["rows"]
            assert case["relation_record"]["corrected_value"] == "drop_row"
        if case["id"] == "I7":
            cross = json.loads((PAPER / case["cross_table_evidence"]).read_text())
            audit_cross_table(cross)
            for spec, original in zip(case["tables"], cross["tables"], strict=True):
                assert spec["dataset"] == original["dataset_id"]
                target = next(
                    r
                    for r in original["context"]
                    if r["snapshot_row"] == original["target_snapshot_row"]
                )
                assert spec["rows"] == [target["source_row"]]
            assert not case["corrections"]
    return views


def source_table(views, spec, case_id):
    headers, _ = views.load(spec["dataset"])
    columns = [headers.index(f) for f in spec["columns"]]
    ratios = {
        "S3": [0.28, 0.72],
        "F2": [0.58, 0.42],
        "I3": [0.2, 0.26, 0.27, 0.27],
        "I4": [0.73, 0.27],
        "I5": [0.3, 0.3, 0.4],
        "I6": [0.22, 0.36, 0.25, 0.17],
        "I7": [0.16, 0.22, 0.62],
        "I14": [0.34, 0.4, 0.26],
    }.get(case_id, [1 / len(columns)] * len(columns))
    return views.table(
        spec["dataset"],
        spec["rows"],
        columns,
        [(CARD_WIDTH - 34) * r for r in ratios],
        marks={(r, headers.index(c)): "error" for r, c in spec["marks"]},
        coordinate_width=34,
    )


def card(case, views, show_type=False, selected=False):
    tables = []
    for i, spec in enumerate(case["tables"]):
        heading = (
            f'<div class="table-name">Table {"AB"[i]}</div>' if len(case["tables"]) > 1 else ""
        )
        tables.append(
            f'<div class="excerpt">{heading}{source_table(views, spec, case["id"])}</div>'
        )
    notes = []
    for i, correction in enumerate(case["corrections"]):
        record = correction["record"]
        original, accepted = record["original_value"], record["corrected_value"]
        field = (
            f'<span class="field">{esc(record["column"])}</span>'
            if len(case["corrections"]) > 1
            else ""
        )
        notes.append(
            f'<div class="change">{field}<span class="original">'
            f'{highlight_edits(original, accepted)}</span><span class="arrow">→</span>'
            f'<span class="correction" data-correction="{case["id"]}-{i}">'
            f'{highlight_edits(original, accepted, show_repair=True)}</span></div>'
        )
    if case.get("note"):
        kind = case.get("note_kind", "")
        notes.append(f'<div class="finding {esc(kind)}">{esc(case["note"])}</div>')
    full = " full" if len(case["tables"]) > 1 else ""
    title = f'{case["type"]}: {case["topic"]}' if show_type else case["topic"]
    badge = '<div class="choice">Selected for Section 3</div>' if selected else ""
    return (
        f'<section class="card{full}" data-case="{case["id"]}">'
        f'<h2><span class="id">{case["id"]}</span>{esc(title)}</h2>'
        f'{badge}'
        f'<div class="tables">{"".join(tables)}</div><div class="notes">{"".join(notes)}</div></section>'
    )


def document(config, group, views):
    font = PAPER / "build/fonts/LinLibertine_Rah.ttf"
    bold = PAPER / "build/fonts/LinLibertine_RBah.ttf"
    assert font.is_file() and bold.is_file()
    size = FONT_SIZE * WIDTH / (FIGURE_WIDTH * 72)
    css = f"""
    @font-face {{font-family:Libertine;src:url('{font.as_uri()}')}}
    @font-face {{font-family:Libertine;src:url('{bold.as_uri()}');font-weight:700}}
    * {{box-sizing:border-box}} body {{margin:0;background:white;font:{size}px/1.3 Libertine;color:#202b33}}
    #figure {{width:{WIDTH}px;padding:24px}}
    header {{border-bottom:2px solid #bcc6ce;margin-bottom:24px;padding-bottom:12px}}
    .eyebrow {{color:#60707c;font-size:0.9em;margin-bottom:5px}}
    h1 {{font-size:1.5em;line-height:1.2;margin:0 0 10px}}
    .guide {{margin:0;color:#46545e}}
    .cards {{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:28px {GAP}px;align-items:start}}
    .card {{min-width:0;padding:0 0 16px;border-bottom:1px solid #ccd5db}}
    .card.full {{grid-column:span 2}}
    h2 {{font:inherit;font-weight:700;margin:0 0 12px;display:flex;align-items:center;gap:12px}}
    .id {{display:inline-block;border:1px solid #61727e;padding:3px 8px;background:#f3f6f8}}
    .choice {{color:#00883d;font-size:.9em;margin:-5px 0 10px}}
    .tables {{display:grid;gap:{GAP}px}} .full .tables {{grid-template-columns:1fr 1fr}}
    .excerpt {{min-width:0}} .table-name {{margin:0 0 8px}}
    .sheet-bar {{display:none}}
    .notes {{margin-top:13px;display:grid;gap:5px}}
    .change {{display:flex;align-items:baseline;justify-content:center;gap:10px;flex-wrap:wrap}}
    .field {{flex:0 0 5em;color:#60707c;font-size:0.9em}}
    .original .edit {{color:#c60000;background:#ffe9e3;white-space:pre-wrap}}
    .correction {{color:#00883d}}
    .correction .edit {{font-weight:700;background:#e3f3e9;white-space:pre-wrap}}
    .arrow {{color:#00883d}}
    .finding {{text-align:center}} .conflict {{color:#c60000}}
    #figure .field-names th {{height:34px;overflow-wrap:normal}}
    #figure table.source tbody td,#figure table.source tbody th {{height:32px}}
    #figure [data-case='I7'] td {{overflow-wrap:anywhere}}
    #figure [data-case='F6'] table.source td.numeric,
    #figure [data-case='I12'] table.source td.numeric,
    #figure [data-case='I15'] table.source td.numeric {{text-align:left}}
    #figure [data-case='I13'] table.source td {{text-align:right}}
    footer {{margin-top:24px;color:#60707c;font-size:.85em}}
    """ + worksheet_css(WIDTH, FIGURE_WIDTH)
    cases = {c["id"]: c for c in config["examples"]}
    panels = "".join(
        card(cases[key], views, group["id"] == "selected", key in config["selected_ids"])
        for key in group["cases"]
    )
    guide = (
        "Current choices: "
        + ", ".join(config["selected_ids"])
        + ". All candidates retained for review."
        if group["id"] == "selected"
        else "Source values → reference corrections. Select examples by ID."
    )
    return (
        '<!doctype html><html lang="en"><meta charset="utf-8">'
        f'<title>CleanBench example options — {esc(group["title"])}</title>'
        f'<style>{css}</style><body><main id="figure"><header>'
        '<div class="eyebrow">CleanBench · Section 3 example options</div>'
        f'<h1>{esc(group["title"])}</h1>'
        f'<p class="guide">{esc(guide)}</p>'
        f'</header><div class="cards">{panels}</div>'
        '<footer>Actual benchmark excerpts; original column names and values retained.</footer>'
        '</main></body></html>'
    )


def render(config, views, browser_path, folder):
    checks = []
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=str(browser_path), headless=True)
        page = browser.new_page(viewport={"width": WIDTH, "height": 1600}, device_scale_factor=2)
        for group in config["groups"]:
            markup = folder / f'{group["id"]}.html'
            markup.write_text(document(config, group, views))
            page.goto(markup.as_uri())
            page.evaluate("document.fonts.ready")
            shown = page.locator("[data-cell]").evaluate_all(
                "es=>es.map(e=>[e.dataset.cell,e.textContent])"
            )
            for key, value in shown:
                assert views.cells[key] == value
            for case in config["examples"]:
                if case["id"] not in group["cases"]:
                    continue
                for i, correction in enumerate(case["corrections"]):
                    key = f'{case["id"]}-{i}'
                    assert (
                        page.locator(f'[data-correction="{key}"]').text_content()
                        == correction["record"]["corrected_value"]
                    )
            styles = check_worksheet_style(page)
            selected = set(group["cases"]) & set(config["selected_ids"])
            assert page.locator(".choice").count() == len(selected)
            for key, alignment in {
                "F6": "left",
                "I12": "left",
                "I13": "right",
                "I15": "left",
            }.items():
                if key in group["cases"]:
                    measured = page.locator(f'[data-case="{key}"] table.source td').evaluate_all(
                        "es=>es.map(e=>getComputedStyle(e).textAlign)"
                    )
                    assert set(measured) == {alignment}, (key, measured)
            overflow = page.locator("td,th,h1,h2,.notes,.change").evaluate_all(
                "es=>es.filter(e=>e.scrollWidth>e.clientWidth+1).map(e=>e.textContent)"
            )
            assert not overflow, (group["id"], overflow)
            bounds = page.locator("section,table.source,.notes").evaluate_all("""es=>{
              const f=document.querySelector('#figure').getBoundingClientRect();
              return es.filter(e=>{const r=e.getBoundingClientRect();
                return r.left<f.left-1||r.right>f.right+1||r.bottom>f.bottom+1;}).map(e=>e.textContent);
            }""")
            assert not bounds, (group["id"], bounds)
            canvas = page.locator("#figure").bounding_box()
            pdf = PAPER / f'assets/generated/example_options_{group["id"]}.pdf'
            page.locator("#figure").screenshot(path=str(folder / f'{group["id"]}.png'))
            page.pdf(
                path=str(pdf),
                width=f"{WIDTH}px",
                height=f"{canvas['height']}px",
                print_background=True,
                margin=dict(top="0", bottom="0", left="0", right="0"),
            )
            checks.append(
                dict(
                    group=group["id"],
                    cases=group["cases"],
                    displayed_cells=shown,
                    worksheet_style=styles,
                    canvas=canvas,
                    pdf_sha256=digest(pdf),
                )
            )
        browser.close()
    return checks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--browser", required=True, type=Path)
    args = parser.parse_args()
    config_path = PAPER / "figures/example_options.json"
    config = json.loads(config_path.read_text())
    views = audit(config)
    folder = PAPER / "build/example_options"
    folder.mkdir(parents=True, exist_ok=True)
    checks = render(config, views, args.browser, folder)
    proof = dict(
        config_sha256=digest(config_path),
        pages=checks,
        source_proofs=views.sources,
        table_font_bp=TABLE_FONT_BP,
        annotation_font_bp=FONT_SIZE,
        additional_model_calls=0,
    )
    (folder / "audit.json").write_text(json.dumps(proof, indent=2) + "\n")
    print(
        f"Verified {len(config['examples'])} options, {len(views.cells)} source cells, "
        f"and {sum(len(c['corrections']) for c in config['examples'])} reference corrections."
    )


if __name__ == "__main__":
    main()
