"""Render source-verified Astra failures with separate output comparisons."""

from __future__ import annotations

import argparse
import html
import json
from pathlib import Path

from build_astra_error_analysis_options import (
    classified_groups,
    verify_phone_sources,
    verify_relation,
)
from build_context_screenshots import SourceViews
from build_failure_examples import digest, marked
from failure_evidence import saved_issue
from figure_style import COLUMN_WIDTH, FIGURE_WIDTH, FONT_SIZE
from playwright.sync_api import sync_playwright
from worksheet_style import TABLE_FONT_BP, check_worksheet_style, worksheet_css

PAPER = Path(__file__).resolve().parents[1]
WIDTH = 960
GROUPS = ("Knowledge", "Formatting convention", "Reasoning")
DISPLAY_GROUPS = {"Formatting convention": "Formatting"}


def audited_examples(config):
    requirements, groups, _ = classified_groups(
        dict(
            requirements_config=config["source_config"],
            classification_source=config["classification_source"],
        )
    )
    indexed = {g["group_id"]: g for g in groups}
    views = SourceViews(PAPER / requirements["snapshot"])
    cases = []
    for spec in config["examples"]:
        group = indexed[spec["group_id"]]
        assert group["analysis_category"] == spec["analysis_group"]
        assert group["outcome"] in (
            {"clean_edit", "wrong_value"}
            if spec["focus"] == "FP"
            else {"unchanged_error", "wrong_value"}
        )
        ds, row, col = group["dataset"], group["row"], group["col"]
        run = next(e[0] for e in group["occurrences"] if e[1:] == (ds, row, col))
        evidence = saved_issue(
            PAPER,
            requirements["recorded_response_archive"],
            run=run,
            dataset=ds,
            row=row,
            column=group["column"],
            original=group["original"],
            proposed=group["proposed"],
        )
        headers, rows = views.load(ds)
        coords = views.manifest[ds]["exported_to_source"]
        fields = [headers.index(name) for name in spec["columns"]]
        selected = [coords[i] if i is not None else None for i in spec["rows"]]
        assert row in spec["rows"] and col in fields
        assert rows[coords[row]][col] == group["original"]
        assert len(fields) == len(spec["column_weights"])
        if spec.get("web_verification"):
            verify_phone_sources(group["original"], group["proposed"], spec["web_verification"])
        verified_facts = []
        if spec.get("verified_relations"):
            table = [dict(zip(headers, rows[index], strict=True)) for index in coords]
            verified_facts = [
                verify_relation(check, group, table) for check in spec["verified_relations"]
            ]
        for term in spec.get("required_explanation_terms", []):
            assert term in (evidence["explanation"] or "").casefold()
        reference = group["original"] if group["outcome"] == "clean_edit" else group["accepted"][0]
        if group["outcome"] != "clean_edit":
            assert len(group["accepted"]) == 1
        if "context_field" in spec:
            context = rows[coords[row]][headers.index(spec["context_field"])]
        elif "context_fields" in spec:
            context = " ".join(rows[coords[row]][headers.index(f)] for f in spec["context_fields"])
        else:
            context = spec.get("context", "")
        if spec.get("context_label"):
            context = spec["context_label"] + ": " + context
        cases.append(
            dict(
                spec,
                dataset=ds,
                row=row,
                col=col,
                source_row=coords[row],
                selected_rows=selected,
                field_indices=fields,
                context=context,
                original=group["original"],
                proposed=group["proposed"],
                reference=reference,
                response_evidence=evidence,
                verified_fact_text=verified_facts,
            )
        )
    return cases, views


def excerpt(value, case):
    prefix = case.get("output_omit_prefix")
    if prefix:
        assert value.startswith(prefix), "Output excerpt must omit an exact unchanged prefix"
        return "… " + value[len(prefix) :]
    suffix = case.get("output_omit_suffix")
    if suffix:
        assert value.endswith(suffix), "Output excerpt must omit an exact unchanged suffix"
        return value[: -len(suffix)] + "…"
    if case.get("output_excerpt") == "last_slash":
        assert "/" in value
        return "…" + value.rsplit("/", 1)[1].lstrip()
    return value


def comparison_text(case, role):
    """Keep no edit distinct from an empty replacement and mark the reference."""
    value = case["proposed"] if role == "astra" else case["reference"]
    if value is None:
        return "No edit", '<span class="no-edit">No edit</span>'
    other = case["reference"] if role == "astra" else case["proposed"]
    if role == "astra" and case.get("highlight_astra_edits", False):
        other = case["original"]
    if other is None:
        other = case["original"]
    value = excerpt(value, case)
    return value, marked(value, excerpt(other, case), "bad" if role == "astra" else "good")


def document(cases, views, *, layout="single-column", show_notes=True, compact_grid=False):
    assert layout in {"single-column", "one-row", "two-rows"}
    count = len(cases)
    assert 1 <= count <= 3
    printed_width = COLUMN_WIDTH if layout == "single-column" else FIGURE_WIDTH
    width = WIDTH if layout == "single-column" else 2 * WIDTH
    columns = {"single-column": 1, "one-row": count, "two-rows": min(2, count)}[layout]
    scale = width / (printed_width * 72)
    gap = (2 if columns == 1 else 6) * scale
    if layout == "two-rows":
        gap = (FIGURE_WIDTH - 2 * COLUMN_WIDTH) * 72 * scale
    row_gap = {"single-column": 2, "one-row": 6, "two-rows": 4}[layout] * scale
    panel_width = (width - 4 - gap * (columns - 1)) / columns
    panel_fractions = (0.8, 1.2, 1.0) if layout == "one-row" and count == 3 else (1.0,) * count
    size = FONT_SIZE * scale
    blocks = []
    expected = {}
    for letter, case, fraction in zip("abc"[:count], cases, panel_fractions, strict=True):
        source_width = panel_width * fraction
        if layout == "two-rows" and count == 3 and letter == "a":
            source_width = (width - 4 - 1.5 * scale) * 0.6
        available = source_width - 15 * scale
        weights = (
            case.get("one_row_column_weights", case["column_weights"])
            if layout == "one-row"
            else case["column_weights"]
        )
        assert len(weights) == len(case["field_indices"]) and min(weights) > 0
        table = views.table(
            case["dataset"],
            case["selected_rows"],
            case["field_indices"],
            [available * w / sum(weights) for w in weights],
            marks={(case["source_row"], case["col"]): "focus"},
            wrap_columns=case["field_indices"],
            coordinate_width=15 * scale,
        )
        comparison = []
        for role, label in [("astra", "Astra"), ("reference", "Reference")]:
            value, text = comparison_text(case, role)
            expected[case["id"], role] = value
            comparison.append(
                f'<div class="outcome {role}"><span class="label">{label}:</span>'
                f'<span class="value" data-role="{role}">{text}</span></div>'
            )
        heading = DISPLAY_GROUPS.get(case["analysis_group"], case["analysis_group"])
        blocks.append(f"""<section data-case="{case["id"]}">
          <div class="heading"><b>({letter}) {html.escape(heading)}</b></div>
          {f'<div class="context">{html.escape(case["context"])}</div>' if case["context"] else ''}
          <div class="evidence-row"><div class="source-block">{table}</div>
            <div class="comparisons">{"".join(comparison)}</div></div>
          {f'<div class="note">{html.escape(case["note"])}</div>' if show_notes else ''}
        </section>""")
    fonts = PAPER / "build/fonts"
    css = f"""
      @font-face {{font-family:Libertine;src:url('{(fonts/"LinLibertine_Rah.ttf").as_uri()}')}}
      @font-face {{font-family:Libertine;src:url('{(fonts/"LinLibertine_RBah.ttf").as_uri()}');font-weight:700}}
      * {{box-sizing:border-box}}body {{margin:0;background:white;color:#17212b;font:{size}px/1.2 Libertine}}
      #figure {{width:{width}px;padding:2px;display:grid;
        grid-template-columns:repeat({columns},minmax(0,1fr));
        column-gap:{gap}px;row-gap:{row_gap}px;align-items:start}}
      section {{min-width:0}}
      .heading {{display:flex;align-items:baseline;justify-content:space-between;
        border-bottom:1px solid #9aabb7;padding-bottom:{0.75 * scale}px}}
      .context {{font-size:{7 * scale}px;color:#596470;margin:{1.5 * scale}px 0}}
      .evidence-row {{display:grid;gap:{1.5 * scale}px;align-items:start;margin-top:{1 * scale}px}}
      .comparisons {{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:{4 * scale}px}}
      .outcome {{display:flex;align-items:baseline;gap:{2 * scale}px;min-width:0;
        padding:{1 * scale}px {3 * scale}px;border:1px solid;border-radius:0}}
      .outcome.astra {{background:#fff3ef;border-color:#dcb6ac}}
      .outcome.reference {{background:#f0f7f2;border-color:#aec9b6}}
      .label {{flex:none;font-size:{6.5 * scale}px;font-weight:700;color:#34414b;white-space:nowrap}}
      .value {{display:block;min-width:0;
        font:{7 * scale}px/1.2 "Liberation Sans",Arial,sans-serif;white-space:pre}}
      .bad {{color:#bd2820}}.good {{color:#08753f}}
      .no-edit {{color:#bd2820;font-style:italic}}
      .note {{font-size:{7 * scale}px;margin-top:{1 * scale}px}}
    """ + worksheet_css(width, printed_width)
    if layout == "one-row":
        if count == 3:
            css += """
              #figure {grid-template-columns:minmax(0,.8fr) minmax(0,1.2fr) minmax(0,1fr)}
            """
        css += """
          .comparisons {grid-template-columns:minmax(0,1fr)}
        """
    elif layout == "two-rows" and count == 3:
        css += """
          section:first-child {grid-column:1/-1}
          section:first-child .evidence-row {grid-template-columns:minmax(0,3fr) minmax(0,2fr)}
          section:first-child .comparisons {grid-template-columns:minmax(0,1fr)}
        """
    css += f"""
      #figure .sheet-bar {{display:none}}
      #figure table.source {{line-height:1.15}}
      #figure table.source th,#figure table.source td {{padding:{0.8 * scale}px {2.5 * scale}px;
        border-color:#a5b6bf;overflow-wrap:anywhere}}
      #figure .field-names th:not(.coord) {{padding-right:{8 * scale}px}}
      #figure .column-letters th,#figure .coord {{font-size:{5.5 * scale}px}}
      #figure table.source tbody tr.selected {{outline:none}}
      #figure table.source td.marked {{outline:2px solid #16854e;outline-offset:-1px;z-index:1}}
    """
    if compact_grid and layout == "single-column":
        # Keep the source fields and font sizes; omit repeated worksheet chrome.
        css += f"""
          #figure .column-letters {{display:none}}
          #figure {{row-gap:{scale}px}}
          #figure .outcome {{padding:{0.5 * scale}px {3 * scale}px}}
          #figure .evidence-row {{gap:{scale}px;margin-top:{0.75 * scale}px}}
          #figure .heading {{padding-bottom:{0.5 * scale}px}}
          #figure table.source th,#figure table.source td {{
            padding:{0.5 * scale}px {2.5 * scale}px}}
        """
    return (
        '<!doctype html><html lang="en"><meta charset="utf-8">'
        f'<style>{css}</style><body><main id="figure">{"".join(blocks)}</main></body></html>'
    ), expected


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--browser", type=Path, required=True)
    parser.add_argument("--layout", choices=("single-column", "one-row", "two-rows"))
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    config_path = PAPER / "figures/failure_type_examples.json"
    config = json.loads(config_path.read_text())
    assert len(config["examples"]) == 2
    layout = args.layout or config.get("layout", "single-column")
    printed_width = COLUMN_WIDTH if layout == "single-column" else FIGURE_WIDTH
    width = WIDTH if layout == "single-column" else 2 * WIDTH
    assert [s["id"] for s in config["examples"]] == ["KFN04", "N030"]
    assert [s["analysis_group"] for s in config["examples"]] == list(GROUPS[:2])
    cases, views = audited_examples(config)
    show_notes = config.get("show_notes", True)
    compact_grid = config.get("compact_grid", False) and layout == "single-column"
    markup, expected = document(
        cases, views, layout=layout, show_notes=show_notes, compact_grid=compact_grid
    )
    folder = PAPER / "build/failure_type_examples" / layout
    folder.mkdir(exist_ok=True, parents=True)
    source = folder / "index.html"
    source.write_text(markup)
    pdf = args.output or PAPER / "figures/paper/failure_type_examples.pdf"
    pdf.parent.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=str(args.browser), headless=True)
        page = browser.new_page(viewport={"width": width, "height": 1600}, device_scale_factor=3)
        page.goto(source.as_uri())
        page.evaluate("document.fonts.ready")
        assert page.locator(".note").count() == (len(cases) if show_notes else 0)
        for cell in page.locator("[data-cell]").evaluate_all(
            "es=>es.map(e=>({key:e.dataset.cell,value:e.textContent}))"
        ):
            assert views.cells[cell["key"]] == cell["value"]
        for (case_id, role), value in expected.items():
            assert (
                page.locator(f'[data-case="{case_id}"] [data-role="{role}"]').text_content()
                == value
            )
        assert "run" not in page.locator("body").inner_text().casefold()
        overflow = page.locator("td,th,.heading,.context,.note,.value").evaluate_all(
            "es=>es.filter(e=>e.scrollWidth>e.clientWidth+1).map(e=>e.textContent)"
        )
        assert not overflow, overflow
        style = check_worksheet_style(page)
        canvas = page.locator("#figure").bounding_box()
        page.locator("#figure").screenshot(path=str(folder / "preview.png"))
        page.pdf(
            path=str(pdf),
            width=f"{width}px",
            height=f"{canvas['height']}px",
            print_background=True,
            margin=dict(top="0", bottom="0", left="0", right="0"),
        )
        browser.close()
    (folder / "evidence.json").write_text(
        json.dumps(
            dict(
                config_sha256=digest(config_path),
                pdf_sha256=digest(pdf),
                examples=cases,
                canvas=canvas,
                source_cells=views.cells,
                printed_width_inches=printed_width,
                layout=layout,
                show_notes=show_notes,
                compact_grid=compact_grid,
                font_size_bp=FONT_SIZE,
                table_font_size_bp=TABLE_FONT_BP,
                worksheet_style=style,
                additional_model_calls=0,
            ),
            indent=2,
        )
        + "\n"
    )
    print(
        "Verified KFN04 and N030 against source cells, scored outputs and saved Astra explanations."
    )


if __name__ == "__main__":
    main()
