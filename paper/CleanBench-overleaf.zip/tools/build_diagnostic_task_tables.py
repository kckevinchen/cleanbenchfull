"""Render detection-only, repair-only, and end-to-end macro result tables.

Default: redraw frozen aggregates. --refresh-repair rescores the full-version
repair-only outputs using the Table 3 scorer.
--macro-only renders frozen table-macro scores for the end-to-end task.
No inference, prompt selection, or changes to the end-to-end results.
"""

from __future__ import annotations

import argparse
import csv
import math
import statistics
import subprocess
import sys
from pathlib import Path

import matplotlib.pyplot as plt
from build_accuracy_presentation import TYPES, colorbar, panel, positions, read
from build_empty_match_metrics import combine
from experiment_presentation import reported_method
from figure_style import FIGURE_WIDTH, configure, save
from repetition_inputs import load_baseline_runs, replacement_groups

PAPER = Path(__file__).resolve().parents[1]
REPO = PAPER.parent
GENERATED = PAPER / "assets/generated"


def detection_rows(roster, type_scores, clean_cells):
    """Retain overall scores and type recall; use only clean-cell FP for FPR."""
    result = []
    for row in roster:
        if row["task"] != "detection" or row["method"].endswith(" (Base)"):
            continue
        if not reported_method(row["method"]):
            continue
        slices = [type_scores["detection", row["method"], kind] for kind, _ in TYPES]
        background = float(slices[0]["shared_background_fp"])
        for (kind, _), score in zip(TYPES, slices, strict=True):
            assert score["repetitions"] == row["repetitions"]
            assert math.isclose(float(score["shared_background_fp"]), background)
            assert math.isclose(float(score["recall"]), float(row[f"recall_{kind}"]))
        result.append({**row, "fpr": 100 * background / clean_cells})
    return result


def macro_rows(roster, overall, type_scores, additional_runs=(), replacement_runs=()):
    """Join all-1,000-table means to Table 3's roster and verify their provenance."""
    overall = {row["method"]: row for row in overall}
    indexed = {(row["method"], row["error_type"]): row for row in type_scores}
    replacements = replacement_groups(
        replacement_runs,
        {
            row["method"]
            for row in roster
            if row["task"] == "e2e"
            and row["category"] not in {"Coding agents", "Direct LLMs (API)"}
        },
    )
    cohorts = {"overall": 164, "typo-spelling": 106, "typo-formatting": 79, "inconsistency": 61}
    result = []
    identities = [run["identity"] for run in additional_runs]
    assert len(identities) == len(set(identities)), "Duplicate additional run"
    agent_methods = {
        row["method"]
        for row in roster
        if row["task"] == "e2e" and row["category"] == "Coding agents"
    }
    assert all(run["method"] in agent_methods for run in additional_runs)
    assert all((run["tables"], run["targets"]) == (1000, 1093) for run in additional_runs)
    for row in roster:
        if row["task"] != "e2e" or row["method"].endswith(" (Base)"):
            continue
        if not reported_method(row["method"]):
            continue
        method = row["method"]
        summary = overall[method]
        assert int(summary["runs"]) == int(row["repetitions"])
        assert int(summary["tables"]) == 1000
        assert int(summary["target_tables"]) == 164
        assert int(summary["zero_target_tables"]) == 836
        for metric in ("precision", "recall", "f1"):
            assert math.isclose(float(summary[f"micro_{metric}"]), float(row[metric]))
            expected = combine(
                float(summary[f"macro_{metric}"]),
                float(summary["preservation"]),
                int(summary["target_tables"]),
                int(summary["zero_target_tables"]),
            )
            assert math.isclose(
                expected, float(indexed[method, "overall"][f"macro_{metric}"]), abs_tol=1e-12
            )
        for kind, cohort in cohorts.items():
            score = indexed[method, kind]
            assert int(score["runs"]) == int(row["repetitions"])
            assert int(score["target_tables"]) == cohort
            for metric in ("precision", "recall", "f1"):
                assert int(score[f"macro_{metric}_tables"]) == 1000
                value = float(score[f"macro_{metric}"])
                assert math.isfinite(value) and 0 <= value <= 100
        output = {
            **row,
            **{
                metric: indexed[method, "overall"][f"macro_{metric}"]
                for metric in ("precision", "recall", "f1")
            },
            **{f"recall_{kind}": indexed[method, kind]["macro_recall"] for kind, _ in TYPES},
        }
        extra = [run for run in additional_runs if run["method"] == method]
        base_runs = int(row["repetitions"])
        for metric in ("precision", "recall", "f1", *(f"recall_{kind}" for kind, _ in TYPES)):
            values = [float(output[metric])] * base_runs
            values.extend(float(run["macro_metrics"][metric]) for run in extra)
            assert all(math.isfinite(value) and 0 <= value <= 100 for value in values)
            output[metric] = statistics.mean(values) if extra else output[metric]
        output["repetitions"] = base_runs + len(extra)
        if method in replacements:
            if extra:
                raise ValueError("Cannot combine fresh and additional trials for one method")
            for metric in ("precision", "recall", "f1", *(f"recall_{kind}" for kind, _ in TYPES)):
                values = [float(run["macro_metrics"][metric]) for run in replacements[method]]
                if any(not math.isfinite(value) or not 0 <= value <= 100 for value in values):
                    raise ValueError("Invalid replacement macro percentage")
                output[metric] = statistics.mean(values)
            output["repetitions"] = 3
        result.append(output)
    return result


def refresh_repair(full_repo):
    script = full_repo / "scripts/reproduce_table6.py"
    if not script.is_file():
        raise FileNotFoundError("Pass the cleanbenchfull checkout with --full-repo")
    subprocess.run(
        [sys.executable, str(script), "--output", str(GENERATED / "repair_type_metrics.csv")],
        check=True,
    )
    return read("repair_type_metrics.csv")


def draw(rows, task, *, overall_label="Overall (%)", output=None, review_methods=None):
    """Reuse Table 3's grouping, shading, printed font size, and score rounding."""
    configure()
    category_height = 0.88
    grid_height = positions(rows, category_height=category_height)[2] * 0.12
    height = grid_height + 0.41
    fig = plt.figure(figsize=(FIGURE_WIDTH, height))
    metrics = (
        ("precision", "recall", "f1", "fpr")
        if task == "detection"
        else ("precision", "recall", "f1")
    )

    def values(row):
        return [float(row[k]) for k in metrics] + [
            float(row[f"recall_{kind}"]) for kind, _ in TYPES
        ]

    panel(
        fig,
        rows,
        [overall_label, *(name for _, name in TYPES)],
        values,
        left=0.29,
        width=0.70,
        top=1 - 0.39 / height,
        height=grid_height / height,
        highlight_group=overall_label,
        header_legend=True,
        review_methods=review_methods,
        category_height=category_height,
        metrics_by_group=[
            ("P ↑", "R ↑", r"$F_1$ ↑", "FPR ↓")
            if task == "detection"
            else ("P ↑", "R ↑", r"$F_1$ ↑"),
            ("R ↑",),
            ("R ↑",),
            ("R ↑",),
        ],
        method_labels={
            "Excel": "Microsoft Excel Clean Data",
            "Google Sheets": "Google Sheets Smart Cleanup",
        },
    )
    colorbar(
        fig,
        1 / FIGURE_WIDTH,
        1 - 10 / (72 * height),
        70 / (72 * FIGURE_WIDTH),
        label=r"P/R/$F_1$ (%)",
    )
    target = output or PAPER / f"figures/paper/{task}_results_table.pdf"
    save(fig, target, check_layout=True)
    plt.close(fig)
    return target


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--refresh-repair", action="store_true")
    parser.add_argument("--full-repo", type=Path, default=REPO.parent / "cleanbenchfull")
    parser.add_argument(
        "--macro-only", action="store_true", help="Render only end-to-end table-macro scores"
    )
    parser.add_argument("--agent-repeat-root", type=Path)
    parser.add_argument("--baseline-repeat-root", type=Path)
    parser.add_argument("--recompute", action="store_true")
    args = parser.parse_args()
    if args.macro_only:
        from build_e2e_variance_table import load_agent_runs

        additional = (
            load_agent_runs(args.agent_repeat_root.resolve()) if args.agent_repeat_root else []
        )
        if (
            not (args.recompute or args.agent_repeat_root or args.baseline_repeat_root)
            and (GENERATED / "e2e_macro_results.csv").exists()
        ):
            rows = read("e2e_macro_results.csv")
            repetitions = {
                row["method"]: int(row["repetitions"]) for row in read("e2e_table_variability.csv")
            }
            if any(int(row["repetitions"]) != repetitions[row["method"]] for row in rows):
                raise ValueError(
                    "Saved macro and Table 3 run counts differ; recompute using the same run inputs"
                )
        else:
            rows = macro_rows(
                read("task_type_metrics.csv"),
                read("macro_metrics.csv"),
                read("empty_match_type_metrics.csv"),
                additional_runs=additional,
                replacement_runs=load_baseline_runs(args.baseline_repeat_root)
                if args.baseline_repeat_root
                else [],
            )
        assert len(rows) == 21
        with (GENERATED / "e2e_macro_results.csv").open("w", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
            writer.writeheader()
            writer.writerows(rows)
        print(draw(rows, "macro_e2e", overall_label="Overall macro (%)"))
        return
    type_scores = {
        (r["task"], r["method"], r["error_type"]): r for r in read("task_type_precision.csv")
    }
    denominators = {int(r["clean_cells"]) for r in read("e2e_table_metrics.csv")}
    assert len(denominators) == 1
    detection = detection_rows(read("task_type_metrics.csv"), type_scores, denominators.pop())
    assert len(detection) == 24
    repair = (
        refresh_repair(args.full_repo) if args.refresh_repair else read("repair_type_metrics.csv")
    )
    repair = [row for row in repair if reported_method(row["method"])]
    assert len(repair) == 16
    order = {row["method"]: index for index, (_, row) in enumerate(positions(detection)[0])}
    repair = sorted(repair, key=lambda row: order[row["method"]])
    print(draw(detection, "detection"))
    print(draw(repair, "repair"))


if __name__ == "__main__":
    main()
