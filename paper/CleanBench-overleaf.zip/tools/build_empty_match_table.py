"""Render a separate all-table empty-match correction table from frozen CSVs.

Target-table macro scores and preservation scores supply disjoint populations.
Their weighted mean gives the alternate macro score on all 1,000 tables. This
script leaves the original target-table CSVs, tables, and renderers unchanged.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from build_accuracy_presentation import CMAP, NORM, TYPES, positions
from build_macro_heatmap import category_label, read_csv, score
from figure_style import FIGURE_WIDTH, configure, save
from matplotlib.cm import ScalarMappable
from matplotlib.patches import Rectangle

PAPER = Path(__file__).resolve().parents[1]
GENERATED = PAPER / "assets/generated"
SOURCE = GENERATED / "macro_type_metrics.csv"
OVERALL = GENERATED / "empty_match_metrics.csv"
ROSTER = GENERATED / "task_type_metrics.csv"
CSV_TARGET = GENERATED / "empty_match_type_metrics.csv"
PDF_TARGET = GENERATED / "empty_match_e2e_heatmap.pdf"
BLOCKS = (("overall", "All tables (%)", ("P", "R", "F1")),) + tuple(
    (key, label, ("P", "R")) for key, label in TYPES
)
FIELDS = {"P": "macro_precision", "R": "macro_recall", "F1": "macro_f1"}
CSV_FIELDS = (
    "method",
    "category",
    "group",
    "error_type",
    "error_type_label",
    "runs",
    "tables",
    "target_tables",
    "preservation_tables",
    "preservation",
    "target_macro_precision",
    "target_macro_recall",
    "target_macro_f1",
    "macro_precision",
    "macro_recall",
    "macro_f1",
    "all_table_macro_f1",
    "macro_precision_tables",
    "macro_recall_tables",
    "macro_f1_tables",
)


def inputs():
    roster = [
        row
        for row in read_csv(ROSTER)
        if row["task"] == "e2e"
        and not (row["category"] == "Direct LLMs (API)" and row["method"].endswith(" (Base)"))
    ]
    if len(roster) != 23 or len({row["method"] for row in roster}) != 23:
        raise ValueError("Expected the 23 published correction workflows")
    source_rows = read_csv(SOURCE)
    source = {(row["method"], row["error_type"]): row for row in source_rows}
    expected = {(row["method"], key) for row in roster for key, _, _ in BLOCKS}
    if len(source_rows) != 92 or source.keys() != expected:
        raise ValueError("Expected each of the 23 workflows and four score groups once")
    overall_rows = read_csv(OVERALL)
    overall = {row["method"]: row for row in overall_rows}
    if len(overall_rows) != 23 or overall.keys() != {row["method"] for row in roster}:
        raise ValueError("Alternate overall results have a different workflow roster")
    derived = []
    for method in (row["method"] for row in roster):
        for key, _, _ in BLOCKS:
            row = source[method, key]
            tables = int(row["tables"])
            targets = int(row["target_tables"])
            preservation_tables = int(row["preservation_tables"])
            if tables != 1000 or targets + preservation_tables != tables:
                raise ValueError(f"Invalid disjoint table populations: {method}, {key}")
            preservation = score(row, "preservation")
            if preservation is None:
                raise ValueError(f"Undefined preservation: {method}, {key}")
            result = {field: row[field] for field in CSV_FIELDS if field in row}
            for metric in ("precision", "recall", "f1"):
                target_score = score(row, f"macro_{metric}")
                if target_score is None:
                    raise ValueError(f"Undefined target macro: {method}, {key}, {metric}")
                value = (targets * target_score + preservation_tables * preservation) / tables
                if not 0 <= value <= 100:
                    raise ValueError(f"Invalid all-table macro: {method}, {key}, {metric}")
                if metric == "f1" and not math.isclose(
                    value, float(row["all_table_macro_f1"]), abs_tol=1e-10
                ):
                    raise ValueError(f"Retained all-table F1 differs: {method}, {key}")
                if key == "overall" and not math.isclose(
                    value, float(overall[method][f"macro_{metric}"]), abs_tol=1e-10
                ):
                    raise ValueError(f"Alternate overall macro differs: {method}, {metric}")
                result[f"target_macro_{metric}"] = row[f"macro_{metric}"]
                result[f"macro_{metric}"] = repr(value)
                result[f"macro_{metric}_tables"] = str(tables)
            derived.append(result)
    return roster, derived


def draw(roster, rows):
    indexed = {(row["method"], row["error_type"]): row for row in rows}
    methods, categories, extent = positions(roster)
    grid_height = extent * 0.125
    height = grid_height + 0.86
    fig = plt.figure(figsize=(FIGURE_WIDTH, height))
    left, width, top = 0.29, 0.70, 1 - 0.53 / height
    ax = fig.add_axes([left, top - grid_height / height, width, grid_height / height])
    starts, end = [], 0.0
    for _, _, metrics in BLOCKS:
        starts.append(end)
        end += len(metrics) + 0.16
    xmax = end - 0.16
    label_x = (0.01 - left) / width * xmax
    label_pad = 0.04 / (width * FIGURE_WIDTH) * xmax
    ink = "#253342"
    ax.set_xlim(0, xmax)
    ax.set_ylim(extent, 0)
    ax.axis("off")
    for y, thickness in ((-3.35, 0.8), (-0.05, 0.6), (extent, 0.8)):
        ax.plot([label_x, xmax], [y, y], color=ink, linewidth=thickness, clip_on=False)
    for start, (key, label, metrics) in zip(starts, BLOCKS, strict=True):
        center = start + len(metrics) / 2
        ax.text(center, -2.75, label, ha="center", va="center", weight="bold", color=ink)
        population = int(indexed[roster[0]["method"], key]["tables"])
        ax.text(center, -1.72, f"n = {population:,}", ha="center", va="center", color=ink)
        ax.plot(
            [start + 0.05, start + len(metrics) - 0.05],
            [-1.20, -1.20],
            color="#a8b2bd",
            linewidth=0.45,
            clip_on=False,
        )
        for index, metric in enumerate(metrics):
            ax.text(start + index + 0.5, -0.66, metric, ha="center", va="center", color=ink)
    ax.text(label_x + label_pad, -0.66, "Method", ha="left", va="center", weight="bold", color=ink)
    for y, label in categories:
        ax.add_patch(
            Rectangle(
                (label_x, y - 0.4),
                xmax - label_x,
                0.8,
                facecolor="#edf1f5",
                edgecolor="none",
                clip_on=False,
            )
        )
        ax.text(
            label_x + label_pad,
            y,
            category_label(label),
            ha="left",
            va="center",
            weight="bold",
            color=ink,
        )
    displayed = []
    for y, row in methods:
        method = row["method"]
        ax.text(
            label_x + label_pad, y, method.removesuffix(" (Prompt-tuned)"), ha="left", va="center"
        )
        ax.plot(
            [label_x, xmax],
            [y + 0.5, y + 0.5],
            color="#e4e9ee",
            linewidth=0.3,
            clip_on=False,
            zorder=0,
        )
        for start, (key, _, metrics) in zip(starts, BLOCKS, strict=True):
            for index, metric in enumerate(metrics):
                value = score(indexed[method, key], FIELDS[metric])
                text = format(value, ".2f" if key == "overall" else ".1f")
                x = start + index
                ax.add_patch(
                    Rectangle(
                        (x, y - 0.5),
                        1,
                        1,
                        facecolor=CMAP(NORM(value)),
                        edgecolor="white",
                        linewidth=0.45,
                    )
                )
                ax.text(
                    x + 0.5,
                    y,
                    text,
                    ha="center",
                    va="center",
                    color="white" if value >= 80 else "black",
                    weight="bold" if key == "overall" else "normal",
                )
                displayed.append(
                    {
                        "method": method,
                        "error_type": key,
                        "metric": metric,
                        "value": value,
                        "text": text,
                    }
                )
    color_ax = fig.add_axes([0.75, 0.22 / height, 0.22, 0.065 / height])
    bar = fig.colorbar(ScalarMappable(norm=NORM, cmap=CMAP), cax=color_ax, orientation="horizontal")
    bar.solids.set_rasterized(False)
    bar.solids.set_edgecolor("face")
    bar.set_ticks([0, 50, 100])
    bar.ax.tick_params(length=2, pad=2)
    bar.ax.text(-0.10, 0.5, "Score (%)", ha="right", va="center", transform=bar.ax.transAxes)
    bar.outline.set_linewidth(0.4)
    save(fig, PDF_TARGET, check_layout=True)
    plt.close(fig)
    return displayed, height


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--validate-only", action="store_true", help="Check inputs without writing derived assets"
    )
    arguments = parser.parse_args()
    source_hashes = {
        path.name: hashlib.sha256(path.read_bytes()).hexdigest()
        for path in (SOURCE, OVERALL, ROSTER)
    }
    roster, rows = inputs()
    if arguments.validate_only:
        print("Validated 92 all-table score rows against retained F1 and alternate overall results")
        return
    with CSV_TARGET.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    configure()
    displayed, height = draw(roster, read_csv(CSV_TARGET))
    if len(displayed) != 23 * 9:
        raise ValueError("Expected nine displayed metrics for each of the 23 workflows")
    for path in (SOURCE, OVERALL, ROSTER):
        if hashlib.sha256(path.read_bytes()).hexdigest() != source_hashes[path.name]:
            raise ValueError(f"Source changed during rendering: {path.name}")
    evidence = {
        "sources_sha256": source_hashes,
        "derived_csv_sha256": hashlib.sha256(CSV_TARGET.read_bytes()).hexdigest(),
        "workflows": 23,
        "method_subgroups": len(positions(roster)[1]),
        "score_rows": len(rows),
        "numeric_cells": len(displayed),
        "table_population_each_type": 1000,
        "width_inches": FIGURE_WIDTH,
        "height_inches": height,
        "font_size_bp": 8,
        "aggregation": "(target_tables * target_macro_metric + preservation_tables * preservation) / tables",
        "displayed_values": displayed,
    }
    destination = PAPER / "build/generated/empty_match_table_evidence.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(evidence, indent=2) + "\n", encoding="utf-8")
    print(f"Rendered 23 workflows and 207 values: {PDF_TARGET.relative_to(PAPER)}")


if __name__ == "__main__":
    main()
