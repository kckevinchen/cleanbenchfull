"""Preserve frozen task scores and distinguish task eligibility from zero scores."""

import copy
import re
from pathlib import Path
from zipfile import ZipFile

import pytest
from build_diagnostic_task_tables import detection_rows, macro_rows, read

PAPER = Path(__file__).resolve().parents[1]


def detection():
    types = {(r["task"], r["method"], r["error_type"]): r for r in read("task_type_precision.csv")}
    return detection_rows(read("task_type_metrics.csv"), types, 362393)


def test_detection_retains_every_supported_method_and_the_original_scores():
    rows = detection()
    assert len(rows) == 24
    original = {r["method"]: r for r in read("task_type_metrics.csv") if r["task"] == "detection"}
    assert {r["method"] for r in rows} >= {"dBoost", "FAHES", "Auto-Test"}
    assert "FM data tasks" not in {r["method"] for r in rows}
    for row in rows:
        assert not row["method"].endswith(" (Base)")
        assert not row["method"].startswith("Opus ")
        assert all(row[k] == value for k, value in original[row["method"]].items())


def test_detection_fpr_uses_clean_cell_false_positives_from_the_same_runs():
    types = read("task_type_precision.csv")
    for row in detection():
        scores = [r for r in types if r["task"] == "detection" and r["method"] == row["method"]]
        assert len(scores) == 3
        assert all(r["repetitions"] == row["repetitions"] for r in scores)
        for score in scores:
            assert row["fpr"] == pytest.approx(100 * float(score["shared_background_fp"]) / 362393)


def test_autotest_is_grouped_with_constraints_in_frozen_detection_results():
    from build_accuracy_presentation import positions

    methods, categories, _ = positions(detection())
    location = {row["method"]: y for y, row in methods}
    headings = {name: y for y, name in categories}
    assert (
        headings["Constraint-based data cleaning"]
        < location["Auto-Test"]
        < headings["Knowledge-based data cleaning"]
    )
    assert (
        headings["Spelling correction methods"]
        < location["NeuSpell"]
        < headings["LLM-prompt cleaning"]
    )


def test_repair_overall_scores_match_the_archived_published_table():
    with ZipFile(PAPER / "assets/generated/tex_snapshots.zip") as archive:
        frozen = archive.read("all_correction_table.tex").decode()
    expected = {
        name: (p, r, f)
        for name, p, r, f in re.findall(
            r"^([^%\\\n][^\n]*?) & ([\d.]+) & ([\d.]+) & ([\d.]+) \\", frozen, re.M
        )
    }
    rows = read("repair_type_metrics.csv")
    assert len(rows) == len(expected) == 17
    for row in rows:
        method = row["method"].removesuffix(" (Prompt-tuned)")
        assert (
            tuple(f"{float(row[k]):.2f}" for k in ("precision", "recall", "f1")) == expected[method]
        )
        assert all(
            0 <= float(row[f"recall_{kind}"]) <= 100
            for kind in ("typo-spelling", "typo-formatting", "inconsistency")
        )


def test_unsupported_repairs_are_omitted_while_measured_zeros_remain():
    methods = {r["method"]: r for r in read("repair_type_metrics.csv")}
    unsupported = {
        "dBoost",
        "FAHES",
        "Auto-Test",
        "LLUNATIC",
        "UniClean",
        "KATARA (KB)",
        "Excel",
        "Google Sheets",
    }
    assert not methods.keys() & unsupported
    assert float(methods["DaisyP"]["f1"]) == 0
    assert float(methods["Relative Trust"]["f1"]) == 0
    assert int(methods["GPT-6-astra (Prompt-tuned)"]["repetitions"]) == 3
    assert int(methods["GPT-6-astra (Codex)"]["repetitions"]) == 1


def test_macro_table_uses_table_3_roster_and_all_1000_table_means():
    roster, overall, slices = (
        read("task_type_metrics.csv"),
        read("macro_metrics.csv"),
        read("empty_match_type_metrics.csv"),
    )
    rows = macro_rows(roster, overall, slices)
    expected = {r["method"]: r for r in read("empty_match_metrics.csv")}
    by_type = {(r["method"], r["error_type"]): r for r in slices}
    assert len(rows) == 21
    assert {r["method"] for r in rows} == {r["method"] for r in read("e2e_table_metrics.csv")}
    for row in rows:
        assert "fpr" not in row
        for metric in ("precision", "recall", "f1"):
            assert float(row[metric]) == pytest.approx(
                float(expected[row["method"]][f"macro_{metric}"])
            )
        for kind in ("typo-spelling", "typo-formatting", "inconsistency"):
            assert row[f"recall_{kind}"] == by_type[row["method"], kind]["macro_recall"]
        for kind in ("overall", "typo-spelling", "typo-formatting", "inconsistency"):
            for metric in ("precision", "recall", "f1"):
                assert int(by_type[row["method"], kind][f"macro_{metric}_tables"]) == 1000


def test_macro_f1_is_not_recomputed_from_averaged_precision_and_recall():
    rows = macro_rows(
        read("task_type_metrics.csv"),
        read("macro_metrics.csv"),
        read("empty_match_type_metrics.csv"),
    )
    row = next(r for r in rows if r["method"] == "SymSpell")
    p, r, f = (float(row[k]) for k in ("precision", "recall", "f1"))
    assert f == pytest.approx(59.71013333590667)
    assert f != pytest.approx(2 * p * r / (p + r))


def test_macro_table_rejects_excluded_tables_and_changed_source_runs():
    roster, overall, slices = (
        read("task_type_metrics.csv"),
        read("macro_metrics.csv"),
        read("empty_match_type_metrics.csv"),
    )
    for field, value in (("target_tables", "1000"), ("runs", "99")):
        altered = copy.deepcopy(overall)
        altered[0][field] = value
        with pytest.raises(AssertionError):
            macro_rows(roster, altered, slices)
    altered = copy.deepcopy(slices)
    next(r for r in altered if r["error_type"] == "typo-spelling")["macro_recall_tables"] = "164"
    with pytest.raises(AssertionError):
        macro_rows(roster, overall, altered)


def test_macro_additional_agent_runs_use_same_three_trials_as_table_3():
    inputs = (
        read("task_type_metrics.csv"),
        read("macro_metrics.csv"),
        read("empty_match_type_metrics.csv"),
    )
    base = {r["method"]: r for r in macro_rows(*inputs)}
    method = "GPT-6-astra (Codex)"
    fields = (
        "precision",
        "recall",
        "f1",
        *(f"recall_{kind}" for kind in ("typo-spelling", "typo-formatting", "inconsistency")),
    )
    extra = [
        {
            "identity": f"trial-{index}",
            "method": method,
            "tables": 1000,
            "targets": 1093,
            "macro_metrics": dict.fromkeys(fields, value),
        }
        for index, value in ((2, 20), (3, 40))
    ]
    rows = {r["method"]: r for r in macro_rows(*inputs, additional_runs=extra)}
    assert rows[method]["repetitions"] == 3
    for metric in fields:
        assert rows[method][metric] == pytest.approx((float(base[method][metric]) + 60) / 3)
    assert rows["SymSpell"] == base["SymSpell"]
    with pytest.raises(AssertionError, match="Duplicate"):
        macro_rows(*inputs, additional_runs=extra + extra[:1])
    extra[0]["tables"] = 999
    with pytest.raises(AssertionError):
        macro_rows(*inputs, additional_runs=extra)
