"""Audit frozen Astra failures and plot their primary analysis requirements.

The default figure uses frozen Azure GPT classifications with explicit author
adjudications; --source draft renders
the archived manual assignments in figures/failure_requirements.json. Neither
changes benchmark labels or scores. Private cell-level review files stay under
build/; only aggregate counts and the figure are publication assets.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
import math
import shutil
import sys
from collections import Counter, defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from figure_style import COLUMN_WIDTH, configure, paired_pies, save
from matplotlib.patches import Patch

if __package__:
    from .tex_sources import generated_asset
else:
    from tex_sources import generated_asset

PAPER = Path(__file__).resolve().parents[1]
CONFIG = PAPER / "figures/failure_requirements.json"
OUT = PAPER / "build/failure_requirement_pies"
GENERATED = PAPER / "assets/generated"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_csv(path, rows):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def audited_groups(config):
    for name, expected in config["source_sha256"].items():
        assert digest(PAPER / name) == expected, name
    groups = {}
    events = set()
    with gzip.open(PAPER / config["inventory"], "rt") as stream:
        for line in stream:
            row = json.loads(line)
            if row["method"] != config["method"]:
                continue
            event = row["run"], row["dataset"], row["row"], row["col"]
            assert event not in events, event
            assert row["execution"] == "complete"
            assert row["run"] in config["repetitions"]
            events.add(event)
            key = (
                row["outcome"],
                row["dataset"],
                row["col"],
                row["original"],
                row["proposed"],
                tuple(row["accepted"]),
            )
            if key not in groups:
                groups[key] = dict(row, group_id=f"G{len(groups) + 1:03d}", occurrences=[])
            groups[key]["occurrences"].append(event)
    assignments = {}
    for category in config["categories"]:
        for group_id in config["assignments"][category]:
            assert group_id not in assignments
            assignments[group_id] = category
    assert set(assignments) == {row["group_id"] for row in groups.values()}

    predictions = {}
    with (PAPER / config["predictions"]).open() as stream:
        for line in stream:
            row = json.loads(line)
            if not row["detector"].endswith("/gpt-6-astra/selected"):
                continue
            run = int(row["detector"].split("/")[0].removeprefix("rep_"))
            key = run, row["dataset"], row["row"], row["col"]
            assert key not in predictions
            predictions[key] = row["corrected_value"]

    sys.path.insert(0, str(PAPER.parent))
    from src.evaluation.paper_evaluation.analysis import GroundTruth

    snapshot = PAPER / config["snapshot"]
    manifest = json.loads((snapshot / "_manifest.json").read_text())
    truth = GroundTruth(snapshot, manifest)
    sources = {}
    by_run = defaultdict(Counter)
    for row in groups.values():
        ds = row["dataset"]
        if ds not in sources:
            source = snapshot / ds / "dirty.csv"
            assert digest(source) == manifest["datasets"][ds]["dirty_sha256"]
            with source.open(newline="") as stream:
                sources[ds] = list(csv.reader(stream))[1:]
        for run, ds, index, col in row["occurrences"]:
            key = ds, index, col
            assert sources[ds][index][col] == row["original"]
            assert not truth.immune(key) and key not in truth.ambiguous
            assert predictions.get((run, *key)) == row["proposed"]
            if row["outcome"] == "clean_edit":
                assert key not in truth.errors
            else:
                assert key in truth.eligible
                assert sorted(truth.accepted[key]) == row["accepted"]
                assert row["proposed"] not in truth.accepted[key]
            by_run[run][row["outcome"]] += 1
        row["analysis_category"] = assignments[row["group_id"]]
        row["review_note"] = config["review_notes"].get(row["group_id"], "")
    with (GENERATED / "failure_taxonomy_runs.csv").open() as stream:
        expected = {
            int(row["run"]): row
            for row in csv.DictReader(stream)
            if row["method"] == config["method"]
        }
    assert set(by_run) == set(expected) == set(config["repetitions"])
    for run, observed in by_run.items():
        reference = expected[run]
        assert observed == {
            "clean_edit": int(reference["clean_edits"]),
            "wrong_value": int(reference["wrong_value"]),
            "unchanged_error": int(reference["unchanged_completed"]),
        }
        assert int(reference["unchanged_failed"]) == int(reference["unchanged_unknown"]) == 0
    return list(groups.values()), dict(by_run)


def aggregate(groups, config, *, deduplicate=False):
    """Count original values per FP/FN outcome, or occurrences for source audits."""
    counts = defaultdict(Counter)
    seen = {}
    for group in groups:
        occurrences = Counter(event[0] for event in group["occurrences"])
        weights = dict.fromkeys(occurrences, 1) if deduplicate else dict(occurrences)
        weights["pooled"] = 1 if deduplicate else sum(occurrences.values())
        for run, weight in weights.items():
            for outcome, applicable in (
                ("FP", group["outcome"] in {"clean_edit", "wrong_value"}),
                ("FN", group["outcome"] in {"unchanged_error", "wrong_value"}),
            ):
                if applicable:
                    if deduplicate:
                        key = run, outcome, group["original"]
                        category = group["analysis_category"]
                        assert key not in seen or seen[key] == category, (
                            "Repeated value has conflicting analysis categories",
                            key,
                        )
                        if key in seen:
                            continue
                        seen[key] = category
                    counts[run, outcome][group["analysis_category"]] += weight
    rows = []
    for run in [*config["repetitions"], "pooled"]:
        for outcome in ("FP", "FN"):
            values = counts[run, outcome]
            total = sum(values.values())
            assert total > 0
            for category in config["categories"]:
                rows.append(
                    dict(
                        run=run,
                        outcome=outcome,
                        category=category,
                        count=values[category],
                        total=total,
                        percentage=100 * values[category] / total,
                    )
                )
    return rows


def draw(rows, config, *, output=None):
    configure(font_size=8)
    fig = plt.figure(figsize=(COLUMN_WIDTH, 1.73))
    categories = ("Knowledge", "Reasoning", "Formatting convention")
    counts = {
        (row["outcome"], row["category"]): int(row["count"])
        for row in rows
        if row["run"] == "pooled"
    }
    colors = dict(zip(config["categories"], config["colors"], strict=True))
    values = [[counts[outcome, category] for category in categories] for outcome in ("FP", "FN")]
    paired_pies(
        fig,
        values,
        sources=("False positives", "False negatives"),
        categories=("Knowledge", "Reasoning", "Formatting"),
        colors=[colors[category] for category in categories],
        text_colors=("white", "white", "black"),
        title="",
        small_sector_pctdistance=0.74,
    )
    save(
        fig,
        output or PAPER / "figures/paper/failure_requirements.pdf",
        width=COLUMN_WIDTH,
        font_size=8,
        check_layout=True,
    )
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / "preview.png", dpi=240, bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)


def llm_rows(records, metadata, expected_totals):
    """Validate frozen judge aggregates without dropping unclassified failures."""
    categories = ("Knowledge", "Formatting convention", "Reasoning", "Uncertain")
    assert metadata["completed_groups"] == metadata["total_groups"] == 492
    assert metadata["source_method"] == "GPT-6-astra (Prompt-tuned)"
    assert metadata["repetitions"] == [1, 2, 3]
    indexed = {(r["outcome"], r["category"]): r for r in records}
    assert len(indexed) == len(records) == 8
    assert set(indexed) == {
        (outcome, category) for outcome in ("FP", "FN") for category in categories
    }
    result = []
    for outcome in ("FP", "FN"):
        total = expected_totals[outcome]
        values = []
        for category in categories:
            row = indexed[outcome, category]
            count = int(row["count"])
            assert 0 <= count <= total and int(row["total"]) == total
            assert math.isclose(float(row["percentage"]), 100 * count / total)
            values.append(count)
            result.append(
                dict(
                    run="pooled",
                    outcome=outcome,
                    category=category,
                    count=count,
                    total=total,
                    percentage=100 * count / total,
                )
            )
        assert sum(values) == total
    return result


def adjudicate(judgments, review):
    """Apply documented reviews while retaining each original model judgment."""
    active = {row["group_id"]: dict(row) for row in judgments}
    assert len(active) == len(judgments)
    seen = set()
    for decision in review["assignments"]:
        group_id = decision["group_id"]
        assert group_id not in seen
        seen.add(group_id)
        row = active[group_id]
        assert row["primary_category"] == decision["previous_category"]
        assert decision["category"] in {"Knowledge", "Formatting convention", "Reasoning"}
        assert decision["rationale"]
        reviewer = decision.get("reviewer", "author")
        assert reviewer in {"author", "assistant"}
        row.update(
            llm_primary_category=row["primary_category"],
            llm_issue_kind=row["issue_kind"],
            llm_rationale=row["rationale"],
            primary_category=decision["category"],
            issue_kind=decision["issue_kind"],
            rationale=decision["rationale"],
            author_adjudicated=reviewer == "author",
            review_source=reviewer,
        )
    return list(active.values())


def draw_llm(rows, config):
    """Keep small unclassified sectors visible without normalizing them away."""
    configure(font_size=8)
    fig = plt.figure(figsize=(COLUMN_WIDTH, 2.0))
    colors = [*config["colors"], "#aab2bb"]
    for index, outcome in enumerate(("FP", "FN")):
        data = [r for r in rows if r["outcome"] == outcome]
        values = [r["count"] for r in data]
        percentages = [r["percentage"] for r in data]
        ax = fig.add_axes([0.015 + index * 0.51, 0.25, 0.465, 0.55])
        wedges, _, labels = ax.pie(
            values,
            colors=colors,
            startangle=90,
            counterclock=False,
            autopct=lambda value: f"{value:.1f}" if value >= 8 else "",
            pctdistance=0.69,
            wedgeprops=dict(edgecolor="white", linewidth=0.8),
            textprops=dict(fontsize=8),
        )
        for category_index, (wedge, label, value) in enumerate(
            zip(wedges, labels, percentages, strict=True)
        ):
            label.set_color("black" if category_index in {1, 3} else "white")
            if value < 8:
                angle = math.radians((wedge.theta1 + wedge.theta2) / 2)
                anchor = (0.98 * math.cos(angle), 0.98 * math.sin(angle))
                target = (0.35, 1.2) if category_index == 3 else (-1.13, 0.73)
                ax.annotate(
                    f"{value:.1f}",
                    anchor,
                    xytext=target,
                    ha="left" if category_index == 3 else "right",
                    va="center",
                    color="#33424d",
                    arrowprops=dict(arrowstyle="-", color="#626f7c", lw=0.6),
                )
        ax.set_xlim(-1.5, 1.5)
        ax.set_ylim(-1.15, 1.45)
        ax.axis("off")
        fig.text(
            0.2475 + index * 0.51,
            0.86,
            f"({'ab'[index]}) {'False positives' if outcome == 'FP' else 'False negatives'}",
            ha="center",
            va="top",
            weight="bold",
        )
    fig.legend(
        [Patch(facecolor=c) for c in colors],
        ["Knowledge", "Formatting convention", "Reasoning", "Unclassified"],
        loc="upper center",
        bbox_to_anchor=(0.5, 0.23),
        ncol=2,
        frameon=False,
        handlelength=1,
        handletextpad=0.4,
        columnspacing=1.1,
        borderpad=0,
    )
    save(
        fig,
        PAPER / "figures/paper/failure_requirements.pdf",
        width=COLUMN_WIDTH,
        font_size=8,
        check_layout=True,
    )
    fig.savefig(OUT / "preview.png", dpi=240)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", choices=["llm", "draft"], default="llm")
    args = parser.parse_args()
    config = json.loads(CONFIG.read_text())
    OUT.mkdir(parents=True, exist_ok=True)
    groups, by_run = audited_groups(config)
    if args.source == "llm":
        source = config["llm_source"]
        metadata = json.loads((PAPER / source["metadata"]).read_text())
        assert metadata["source_sha256"] == config["source_sha256"]
        with (PAPER / source["counts"]).open() as stream:
            records = list(csv.DictReader(stream))
        totals = {
            "FP": sum(r["clean_edit"] + r["wrong_value"] for r in by_run.values()),
            "FN": sum(r["unchanged_error"] + r["wrong_value"] for r in by_run.values()),
        }
        rows = llm_rows(records, metadata, totals)
        adjudication = None
        active_judgments = None
        original_judgments = None
        if source.get("author_adjudication"):
            adjudication = json.loads((PAPER / source["author_adjudication"]).read_text())
            local_review = PAPER / source["local_review"]
            assert digest(local_review) == adjudication["base_review_sha256"]
            with local_review.open() as stream:
                judgments = list(csv.DictReader(stream))
            indexed = {r["group_id"]: r for r in judgments}
            original_judgments = indexed
            assert len(indexed) == len(judgments) == len(groups)
            assert set(indexed) == {g["group_id"] for g in groups}
            for group in groups:
                judgment = indexed[group["group_id"]]
                for field in ("dataset", "column", "original", "outcome"):
                    assert judgment[field] == group[field]
                assert judgment["proposed"] == (group["proposed"] or "")
                assert json.loads(judgment["accepted"]) == group["accepted"]
                assert int(judgment["occurrences"]) == len(group["occurrences"])
                group["analysis_category"] = judgment["primary_category"]
            categories = [*config["categories"], "Uncertain"]
            original = aggregate(groups, dict(config, categories=categories))
            assert [r for r in original if r["run"] == "pooled"] == rows
            active_judgments = adjudicate(judgments, adjudication)
            indexed = {r["group_id"]: r for r in active_judgments}
            for group in groups:
                group["analysis_category"] = indexed[group["group_id"]]["primary_category"]
            assert all(g["analysis_category"] in config["categories"] for g in groups)
            rows = [r for r in aggregate(groups, config) if r["run"] == "pooled"]
            for outcome in ("FP", "FN"):
                assert sum(r["count"] for r in rows if r["outcome"] == outcome) == totals[outcome]
    else:
        rows = aggregate(groups, config)
    occurrence_rows = rows
    if args.source == "llm" and active_judgments is None:
        with (PAPER / source["local_review"]).open() as stream:
            judgments = {row["group_id"]: row for row in csv.DictReader(stream)}
        for group in groups:
            group["analysis_category"] = judgments[group["group_id"]]["primary_category"]
    categories = list(dict.fromkeys(row["category"] for row in occurrence_rows))
    rows = aggregate(groups, dict(config, categories=categories), deduplicate=True)
    if args.source == "llm":
        rows = [row for row in rows if row["run"] == "pooled"]
    write_csv(GENERATED / "failure_requirement_counts.csv", rows)
    formatting = {
        row["outcome"]: row["percentage"]
        for row in rows
        if row["run"] == "pooled" and row["category"] == "Formatting convention"
    }
    reasoning = {
        row["outcome"]: row["percentage"]
        for row in rows
        if row["run"] == "pooled" and row["category"] == "Reasoning"
    }
    unclassified = {
        row["outcome"]: row["percentage"]
        for row in rows
        if row["run"] == "pooled" and row["category"] == "Uncertain"
    }
    (generated_asset("failure_requirement_numbers.tex", directory=GENERATED)).write_text(
        "% Generated from the active analysis-category source.\n"
        + "".join(
            rf"\newcommand{{\CBFailure{outcome}FormattingShare}}{{{value:.1f}}}" + "\n"
            for outcome, value in formatting.items()
        )
        + "".join(
            rf"\newcommand{{\CBFailure{outcome}ReasoningShare}}{{{value:.1f}}}" + "\n"
            for outcome, value in reasoning.items()
        )
        + "".join(
            rf"\newcommand{{\CBFailure{outcome}UnclassifiedShare}}{{{unclassified.get(outcome, 0):.1f}}}"
            + "\n"
            for outcome in ("FP", "FN")
        )
    )
    review = [
        dict(
            group_id=row["group_id"],
            category=row["analysis_category"],
            outcome=row["outcome"],
            occurrences=len(row["occurrences"]),
            dataset=row["dataset"],
            column=row["column"],
            original=row["original"],
            proposed=row["proposed"],
            accepted=json.dumps(row["accepted"], ensure_ascii=False),
            review_note=row["review_note"],
        )
        for row in groups
    ]
    if args.source == "draft":
        write_csv(OUT / "classification_review.csv", review)
        (OUT / "classification_review.json").write_text(json.dumps(groups, indent=2) + "\n")
        draw(rows, config)
    else:
        local_review = PAPER / config["llm_source"]["local_review"]
        if local_review.exists():
            old_review = OUT / "classification_review.csv"
            archive = OUT / "manual_draft_classification_review.csv"
            if old_review.exists() and not archive.exists():
                shutil.copyfile(old_review, archive)
            if active_judgments is None:
                shutil.copyfile(local_review, old_review)
                with local_review.open() as stream:
                    judgments = {r["group_id"]: r for r in csv.DictReader(stream)}
            else:
                fields = list(dict.fromkeys(k for r in active_judgments for k in r))
                with old_review.open("w", newline="") as stream:
                    writer = csv.DictWriter(stream, fieldnames=fields, lineterminator="\n")
                    writer.writeheader()
                    writer.writerows(active_judgments)
                judgments = {r["group_id"]: r for r in active_judgments}
            assert set(judgments) == {r["group_id"] for r in groups}
            old_json = OUT / "classification_review.json"
            archive_json = OUT / "manual_draft_classification_review.json"
            if old_json.exists() and not archive_json.exists():
                shutil.copyfile(old_json, archive_json)
            for group in groups:
                judgment = judgments[group["group_id"]]
                group["analysis_category"] = judgment["primary_category"]
                group["review_note"] = judgment["rationale"]
                group["llm_judgment"] = (
                    original_judgments[group["group_id"]] if original_judgments else judgment
                )
                group["author_adjudicated"] = judgment.get("author_adjudicated", False)
            old_json.write_text(json.dumps(groups, indent=2) + "\n")
        if all(r["category"] in config["categories"] for r in rows):
            draw(rows, config)
        else:
            draw_llm(rows, config)
    (OUT / "evidence.json").write_text(
        json.dumps(
            dict(
                config_sha256=digest(CONFIG),
                source_sha256=config["source_sha256"],
                classification_method=(
                    f"Azure {metadata['model']} classification of observed failures"
                    + (" with documented evidence review" if adjudication else "")
                    if args.source == "llm"
                    else config["classification_method"]
                ),
                classification_status=(
                    metadata["status"] if args.source == "llm" else config["classification_status"]
                ),
                active_source=args.source,
                llm_metadata=metadata if args.source == "llm" else None,
                author_adjudication=adjudication if args.source == "llm" else None,
                unclassified_patterns=sum(g["analysis_category"] == "Uncertain" for g in groups),
                groups=len(groups),
                failures_by_run=by_run,
                counting_unit=config["unit"],
                deduplication_key=config["deduplication_key"],
                occurrence_counts=occurrence_rows,
                counts=rows,
                pdf_sha256=digest(PAPER / "figures/paper/failure_requirements.pdf"),
                additional_model_calls=0,
            ),
            indent=2,
        )
        + "\n"
    )
    print(f"Audited {len(groups)} failure patterns against saved predictions, labels and scores.")
    for outcome in ("FP", "FN"):
        print(
            outcome,
            [
                (r["category"], r["count"], round(r["percentage"], 1))
                for r in rows
                if r["run"] == "pooled" and r["outcome"] == outcome
            ],
        )


if __name__ == "__main__":
    main()
