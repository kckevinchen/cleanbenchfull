"""Render complementary correction and preservation metrics on separate strata."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from build_accuracy_presentation import CMAP, NORM, positions
from build_macro_heatmap import category_label, read_csv, score
from figure_style import FIGURE_WIDTH, configure, save
from matplotlib.cm import ScalarMappable
from matplotlib.patches import Rectangle

PAPER = Path(__file__).resolve().parents[1]
GENERATED = PAPER / "assets/generated"
SOURCE = GENERATED / "stratified_metrics.csv"
ROSTER = GENERATED / "task_type_metrics.csv"
TARGET = GENERATED / "stratified_correction_heatmap.pdf"
FIELDS = (
    ("conditional_precision", "P ↑"),
    ("target_conditional_precision", "P ↑"),
    ("target_recall", "R ↑"),
    ("coverage", "Coverage ↑"),
    ("target_f1", "F1 ↑"),
    ("false_alarm_rate", "Alarm ↓"),
    ("failed_no_target_rate", "Failed ↓"),
    ("balanced_score", "Score ↑"),
)


def main():
    rows = [r for r in read_csv(SOURCE) if r["error_type"] == "overall"]
    indexed = {r["method"]: r for r in rows}
    roster = [
        r
        for r in read_csv(ROSTER)
        if r["task"] == "e2e"
        and not (r["category"] == "Direct LLMs (API)" and r["method"].endswith(" (Base)"))
    ]
    assert len(rows) == len(indexed) == len(roster) == 23
    assert set(indexed) == {r["method"] for r in roster}
    for row in rows:
        assert (int(row["tables"]), int(row["target_tables"]), int(row["no_target_tables"])) == (
            1000,
            164,
            836,
        )
    reference = {
        "conditional_precision": "",
        "target_conditional_precision": "",
        "target_recall": "0",
        "coverage": "0",
        "target_f1": "0",
        "false_alarm_rate": "0",
        "failed_no_target_rate": "0",
        "balanced_score": "50",
    }
    configure()
    methods, categories, extent = positions(roster)
    reference_y = extent + 0.6
    extent += 1.35
    grid_height = extent * 0.125
    height = grid_height + 0.86
    fig = plt.figure(figsize=(FIGURE_WIDTH, height))
    left, width, top = 0.29, 0.70, 1 - 0.53 / height
    ax = fig.add_axes([left, top - grid_height / height, width, grid_height / height])
    centers = (0.5, 1.66, 2.66, 3.66, 4.66, 5.82, 6.82, 7.98)
    xmax = 8.48
    label_x = (0.01 - left) / width * xmax
    label_pad = 0.04 / (width * FIGURE_WIDTH) * xmax
    ink = "#253342"
    ax.set_xlim(0, xmax)
    ax.set_ylim(extent, 0)
    ax.axis("off")
    for y, thickness in ((-3.35, 0.8), (-0.05, 0.6), (extent, 0.8)):
        ax.plot([label_x, xmax], [y, y], color=ink, linewidth=thickness, clip_on=False)
    for start, end, label, population in (
        (0, 1, "All tables", "with edits"),
        (1.16, 5.16, "Requires correction", "n = 164"),
        (5.32, 7.32, "No correction", "n = 836"),
        (7.48, 8.48, "Balanced", "50 / 50"),
    ):
        center = (start + end) / 2
        ax.text(center, -2.75, label, ha="center", va="center", weight="bold", color=ink)
        ax.text(center, -1.72, population, ha="center", va="center", color=ink)
        ax.plot(
            [start + 0.05, end - 0.05], [-1.2, -1.2], color="#a8b2bd", linewidth=0.45, clip_on=False
        )
    ax.text(label_x + label_pad, -0.66, "Method", ha="left", va="center", weight="bold", color=ink)
    for center, (_, label) in zip(centers, FIELDS, strict=True):
        ax.text(center, -0.66, label, ha="center", va="center", color=ink)
    for y, label in categories:
        ax.add_patch(
            Rectangle(
                (label_x, y - 0.4),
                xmax - label_x,
                0.8,
                facecolor="#edf1f5",
                edgecolor="none",
                clip_on=False,
            )
        )
        ax.text(
            label_x + label_pad,
            y,
            category_label(label),
            ha="left",
            va="center",
            weight="bold",
            color=ink,
        )
    displayed = []
    render_rows = [(y, row["method"], indexed[row["method"]]) for y, row in methods]
    render_rows.append((reference_y, "Always empty (reference)", reference))
    ax.plot(
        [label_x, xmax],
        [reference_y - 0.6, reference_y - 0.6],
        color=ink,
        linewidth=0.6,
        clip_on=False,
    )
    for y, method, row in render_rows:
        ax.text(
            label_x + label_pad,
            y,
            method.removesuffix(" (Prompt-tuned)"),
            ha="left",
            va="center",
            style="italic" if row is reference else "normal",
        )
        ax.plot(
            [label_x, xmax],
            [y + 0.5, y + 0.5],
            color="#e4e9ee",
            linewidth=0.3,
            clip_on=False,
            zorder=0,
        )
        for center, (field, _) in zip(centers, FIELDS, strict=True):
            value = score({**row, "method": method}, field)
            quality = (
                100 - value
                if value is not None and field in {"false_alarm_rate", "failed_no_target_rate"}
                else value
            )
            text = "—" if value is None else f"{value:.2f}"
            ax.add_patch(
                Rectangle(
                    (center - 0.5, y - 0.5),
                    1,
                    1,
                    facecolor="#f3f5f7" if quality is None else CMAP(NORM(quality)),
                    edgecolor="white",
                    linewidth=0.45,
                )
            )
            ax.text(
                center,
                y,
                text,
                ha="center",
                va="center",
                color="white" if quality is not None and quality >= 80 else "black",
                weight="bold" if field == "balanced_score" else "normal",
            )
            displayed.append({"method": method, "field": field, "value": value, "text": text})
    color_ax = fig.add_axes([0.75, 0.22 / height, 0.22, 0.065 / height])
    bar = fig.colorbar(ScalarMappable(norm=NORM, cmap=CMAP), cax=color_ax, orientation="horizontal")
    bar.solids.set_rasterized(False)
    bar.solids.set_edgecolor("face")
    bar.set_ticks([0, 100], labels=["Worse", "Better"])
    bar.ax.tick_params(length=2, pad=2)
    bar.ax.text(-0.10, 0.5, "Shading", ha="right", va="center", transform=bar.ax.transAxes)
    bar.outline.set_linewidth(0.4)
    save(fig, TARGET, check_layout=True)
    plt.close(fig)
    assert len(displayed) == 192
    evidence = {
        "sources_sha256": {
            p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (SOURCE, ROSTER)
        },
        "workflows": 23,
        "reference_rows": 1,
        "numeric_cells": 190,
        "undefined_reference_precision_cells": 2,
        "width_inches": FIGURE_WIDTH,
        "height_inches": height,
        "font_size_bp": 8,
        "displayed_values": displayed,
        "shading": "Higher is better except alarm and failure rates, which use inverse shading.",
    }
    (PAPER / "build/generated/stratified_table_evidence.json").write_text(
        json.dumps(evidence, indent=2) + "\n"
    )
    print("Rendered 23 workflows and an always-empty reference with 8 complementary metrics")


if __name__ == "__main__":
    main()
