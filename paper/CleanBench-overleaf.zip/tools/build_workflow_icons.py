"""Render Microsoft Fluent Color icons as publication-sized vectors.

Requires CairoSVG for regeneration. LaTeX only needs the committed PDF assets.
No downloads, model calls, source-table changes, or rescaling of figure text.
The earlier collections remain available with --collection cleanbench/phosphor.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import xml.etree.ElementTree as ET
from pathlib import Path

import cairocffi as cairo
import cairosvg
from cairosvg.surface import PDFSurface
from figure_style import EXAMPLE_PALETTE

PAPER = Path(__file__).resolve().parents[1]
OUTPUT = PAPER / "figures/icons/generated"
# Physical size, foreground ink, and opaque secondary fill for each figure role.
STYLES = {
    "database": (24, "#3E678A", "#C3D6E6"),
    "table": (24, "#2B776A", "#BBDDD0"),
    "brain": (18, EXAMPLE_PALETTE["focus"], "#B9D4F8"),
    "user-check": (18, "#8C642C", "#F1D09B"),
    "files-check": (32, "#246C54", "#B7DBCA"),
    "list-checks": (18, EXAMPLE_PALETTE["muted"], "#D0DCE5"),
    "chart-bar": (10, EXAMPLE_PALETTE["muted"], "#D0DCE5"),
}


class ManuscriptPDFSurface(PDFSurface):
    """Match the manuscript's PDF 1.5 output before any paths are drawn."""

    def _create_surface(self, width, height):
        surface, width, height = super()._create_surface(width, height)
        surface.restrict_to_version(cairo.PDF_VERSION_1_5)
        return surface, width, height


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--icon", choices=STYLES, help="Render one icon; default: all icons")
    parser.add_argument(
        "--collection", choices=("fluent", "cleanbench", "phosphor"), default="fluent"
    )
    args = parser.parse_args()
    source = PAPER / "figures/icons" / args.collection
    manifest_path = source / "SOURCE.json"
    manifest = json.loads(manifest_path.read_text())
    assert set(manifest["icons"]) == set(STYLES)
    if args.collection in ("phosphor", "fluent"):
        assert (
            hashlib.sha256((source / "LICENSE").read_bytes()).hexdigest()
            == manifest["license_sha256"]
        )
    OUTPUT.mkdir(parents=True, exist_ok=True)
    ET.register_namespace("", "http://www.w3.org/2000/svg")
    allowed = {
        "svg", "path", "circle", "ellipse", "rect", "line", "polyline", "polygon", "g",
        "defs", "linearGradient", "radialGradient", "stop",
    }
    rendered = 0
    for name, (size, color, tone) in STYLES.items():
        record = manifest["icons"][name]
        raw = (source / f"{name}.svg").read_bytes()
        assert hashlib.sha256(raw).hexdigest() == record["svg_sha256"]
        if args.icon and args.icon != name:
            continue
        root = ET.fromstring(raw)
        expected_view_box = {
            "fluent": record.get("view_box"),
            "cleanbench": "0 0 64 64",
            "phosphor": "0 0 256 256",
        }[args.collection]
        assert root.get("viewBox") == expected_view_box
        local_ids = {element.get("id") for element in root.iter() if element.get("id")}
        for element in root.iter():
            assert element.tag.rsplit("}", 1)[-1] in allowed
            for key, value in element.attrib.items():
                assert "href" not in key
                if "url(" in value:
                    assert value.startswith("url(#") and value.endswith(")")
                    assert value[5:-1] in local_ids
                if args.collection == "phosphor" and value == "currentColor":
                    element.set(key, color)
            # Preserve both upstream contours while giving their fill a distinct tone.
            if args.collection == "phosphor" and element.get("opacity") == "0.2":
                element.set("opacity", "1")
                element.set("fill", tone)
        if args.collection in ("cleanbench", "fluent"):
            size = record["size_bp"]
        root.set("width", f"{size}pt")
        root.set("height", f"{size}pt")
        if args.collection == "phosphor":
            root.set("color", color)
        if args.collection == "phosphor" and name == "files-check":
            # Separate the front sheet from the tinted rear sheet and add verification.
            tag = "{http://www.w3.org/2000/svg}"
            root.insert(
                1,
                ET.Element(
                    tag + "path",
                    d="M56 64H136L176 104V216A8 8 0 0 1 168 224H56A8 8 0 0 1 48 216V72A8 8 0 0 1 56 64Z",
                    fill="white",
                ),
            )
            ET.SubElement(
                root,
                tag + "circle",
                cx="198",
                cy="190",
                r="42",
                fill=color,
                stroke="white",
                **{"stroke-width": "8"},
            )
            ET.SubElement(
                root,
                tag + "path",
                d="M177 190L192 205L217 178",
                fill="none",
                stroke="white",
                **{"stroke-width": "11", "stroke-linecap": "round", "stroke-linejoin": "round"},
            )
        target = OUTPUT / f"{name}.pdf"
        ManuscriptPDFSurface.convert(bytestring=ET.tostring(root), write_to=str(target))
        rendered += 1
        record["rendered"] = {
            "path": target.relative_to(PAPER).as_posix(),
            "size_bp": size,
            "collection": args.collection,
            "pdf_sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
        }
    manifest["renderer"] = {
        "name": "CairoSVG",
        "version": cairosvg.__version__,
        "pdf_version": "1.5",
    }
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    print(f"Verified {args.collection} sources and rendered {rendered} vector icons.")


if __name__ == "__main__":
    main()
