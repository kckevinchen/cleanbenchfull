"""Capture source-backed table views for the discovery and taxonomy figures, without model calls.

The browser displays literal CSV values from the frozen evaluation snapshot.
These are screenshots of a read-only viewer, not original workbook formatting.
Source files remain private; only the illustrated excerpts enter the paper.
"""

from __future__ import annotations

import argparse
import csv
import difflib
import hashlib
import html
import json
from datetime import datetime
from itertools import groupby
from pathlib import Path

from figure_style import COLUMN_WIDTH, EXAMPLE_PALETTE
from playwright.sync_api import sync_playwright
from worksheet_style import TABLE_FONT_BP, check_worksheet_style, worksheet_css

if __package__:
    from .tex_sources import generated_asset
else:
    from tex_sources import generated_asset

PAPER = Path(__file__).resolve().parents[1]
WIDTH = 480
FONT_SIZE_BP = 8
PROVIDERS = "203ff645e0e18e7ad21ee5011b5c2ba7085579d6.xlsx_c9caafb2"
RUNNING_CANDIDATES = [
    ("A", 81, "Group Specialty", "Acupunture", "Acupuncture", "typo-spelling", "Spelling"),
    ("B", 99, "Shipping City", "Augusta,", "Augusta", "typo-formatting", "Formatting"),
]
CALENDAR = "252479847_DimDate"
MONTHS = "300169893_summary"
EXAMPLE_REPAIRS = [
    (CALENDAR, 0, "Dayname", "Wednusday", "Wednesday", "typo-spelling", "Spelling"),
    (PROVIDERS, 99, "Shipping City", "Augusta,", "Augusta", "typo-formatting", "Formatting"),
    (
        MONTHS,
        2,
        "month",
        "July",
        "Jul",
        "inconsistency",
        "Inconsistency",
    ),
]


def esc(value):
    return html.escape(str(value), quote=True)


def column_letter(index):
    """Use the source column's position in the spreadsheet-style excerpt."""
    result = ""
    index += 1
    while index:
        index, digit = divmod(index - 1, 26)
        result = chr(65 + digit) + result
    return result


def worksheet_row(source_row):
    """The reconstructed sheet puts headers in row 1, then original records."""
    return source_row + 2


def highlight_edits(original, repair, *, show_repair=False):
    """Keep equal-length edits at their offsets, including repeated date digits."""
    if len(original) == len(repair):
        value = repair if show_repair else original
        pairs = [(original[i] != repair[i], char) for i, char in enumerate(value)]
        pieces = []
        for changed, group in groupby(pairs, key=lambda item: item[0]):
            text = esc("".join(char for _, char in group))
            pieces.append(f'<b class="edit">{text}</b>' if changed else text)
        return "".join(pieces)
    pieces = []
    for op, a, b, c, d in difflib.SequenceMatcher(None, original, repair).get_opcodes():
        text = esc(repair[c:d] if show_repair else original[a:b])
        if text:
            pieces.append(f'<b class="edit">{text}</b>' if op != "equal" else text)
    return "".join(pieces)


class SourceViews:
    def __init__(self, snapshot):
        self.snapshot = snapshot
        self.manifest = json.loads((snapshot / "_manifest.json").read_text())["datasets"]
        self.sources = {}
        self.cells = {}
        self.repairs = {}

    def load(self, dataset):
        path = self.snapshot / dataset / "dirty.csv"
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        metadata = self.manifest[dataset]
        assert digest == metadata["dirty_sha256"]
        with path.open(newline="") as handle:
            rows = list(csv.reader(handle))
        assert rows[0] == metadata["columns"]
        coords = metadata["exported_to_source"]
        assert len(rows) - 1 == len(coords)
        self.sources[dataset] = {
            "sha256": digest,
            "original_source": metadata["source"],
            "rows": len(coords),
            "columns": len(rows[0]),
        }
        return rows[0], dict(zip(coords, rows[1:], strict=True))

    def table(
        self,
        dataset,
        selected_rows,
        columns,
        widths,
        marks=None,
        repairs=None,
        preview=False,
        callouts=None,
        wrap_columns=(),
        coordinate_width=32,
    ):
        headers, rows = self.load(dataset)
        marks = marks or {}
        repairs = repairs or {}
        callouts = callouts or {}
        active_row, active_col = next(
            iter(marks), (next(row for row in selected_rows if row is not None), columns[0])
        )
        parts = [
            '<div class="worksheet"><div class="sheet-grid">'
            f'<table class="source"><colgroup><col style="width:{coordinate_width}px">'
        ]
        parts += [f'<col style="width:{width}px">' for width in widths]

        def column_classes(index, col):
            return (" active-heading" if col == active_col else "") + (
                " hidden-before" if index and col > columns[index - 1] + 1 else ""
            )

        parts += ['</colgroup><thead><tr class="column-letters"><th class="corner"></th>']
        parts += [
            f'<th class="{column_classes(i, col).strip()}">{column_letter(col)}</th>'
            for i, col in enumerate(columns)
        ]
        parts += ['</tr><tr class="field-names"><th class="coord">1</th>']
        parts += [
            f'<th class="{column_classes(i, col).replace(" active-heading", "").strip()}">'
            f'{esc(headers[col]).replace(chr(92) + "n", "<br>")}</th>'
            for i, col in enumerate(columns)
        ]
        parts += ["</tr></thead><tbody>"]
        for row in selected_rows:
            if row is None:
                parts.append('<tr class="omitted"><th class="coord">⋯</th>')
                parts += [
                    f'<td class="{column_classes(i, col).replace(" active-heading", "").strip()}">⋯</td>'
                    for i, col in enumerate(columns)
                ]
                parts.append("</tr>")
                continue
            row_class = " active-heading" if row == active_row else ""
            selected = "selected" if any(r == row for r, _ in marks) else ""
            parts.append(
                f'<tr class="{selected}" data-row="{row}"><th class="coord{row_class}" '
                f'data-source-row="{row}">{worksheet_row(row)}</th>'
            )
            for i, col in enumerate(columns):
                value = rows[row][col]
                key = f"{dataset}:{row}:{col}"
                self.cells[key] = value
                badge = marks.get((row, col))
                replacement = repairs.get((row, col))
                displayed = replacement if preview and replacement is not None else value
                attribute = "data-repair" if preview and replacement is not None else "data-cell"
                if attribute == "data-repair":
                    self.repairs[key] = displayed
                style = (
                    "repaired"
                    if preview and replacement is not None
                    else ("marked" if badge else "")
                )
                if col in wrap_columns:
                    style += " wrap-cell"
                if (row, col) == (active_row, active_col):
                    style += " active-cell"
                if i and col > columns[i - 1] + 1:
                    style += " hidden-before"
                if value.replace("/", "").replace("-", "").replace(".", "").isdigit():
                    style += " numeric"
                marker = f'<span class="badge">{esc(badge)}</span>' if badge == "NEW" else ""
                if (row, col) in callouts:
                    marker = (
                        f'<span class="cell-callout" aria-label="Example '
                        f'{esc(callouts[row, col])}">{esc(callouts[row, col])}</span>'
                    )
                    style += " has-callout"
                text = esc(displayed)
                if replacement is not None:
                    text = highlight_edits(value, replacement, show_repair=preview)
                parts.append(
                    f'<td class="{style.strip()}"><span {attribute}="{esc(key)}">{text}</span>{marker}</td>'
                )
            parts.append("</tr>")
        parts.append(
            '</tbody></table></div><div class="sheet-bar">'
            '<span class="sheet-navigation" aria-hidden="true"><i></i><i></i></span>'
            '<span class="sheet-tab">Source</span><span class="sheet-add" aria-hidden="true"></span>'
            '<span class="sheet-scroll" aria-hidden="true"></span></div></div>'
        )
        return "".join(parts)


class FrozenSourceViews(SourceViews):
    """Render frozen excerpts and check their recorded annotation provenance."""

    def __init__(self, reference):
        self.reference = json.loads(reference.read_text())
        self.sources = {}
        self.cells = {}
        self.repairs = {}

    def load(self, dataset):
        table = self.reference["tables"][dataset]
        width = max(map(int, table["columns"])) + 1
        headers = [None] * width
        for col, value in table["columns"].items():
            headers[int(col)] = value
        rows = {}
        for row, cells in table["rows"].items():
            rows[int(row)] = [cells.get(str(col)) for col in range(width)]
        self.sources[dataset] = {"provenance": "Frozen illustrated excerpts"}
        return headers, rows

    def verify(self):
        for record in self.reference["repairs"]:
            _, rows = self.load(record["dataset"])
            assert rows[record["row"]][record["column"]] == record["original"]
            self.repairs[f'{record["dataset"]}:{record["row"]}:{record["column"]}'] = record[
                "accepted"
            ]
        for audit in self.reference.get("annotation_audits", []):
            benchmark = audit["benchmark_record"]
            human = audit["human_label"]
            headers, rows = self.load(audit["dataset"])
            row, column = audit["original_row"], audit["original_column"]
            assert headers[column] == audit["column_name"] == benchmark["column"]
            assert benchmark["source"] == human["source"] == audit["source"]
            assert benchmark["row"] == row
            assert human["column"] == benchmark["column"]
            assert benchmark["status"] == "error" and human["status"] in ("tp", "partial", "fn")
            assert rows[row][column] == benchmark["original_value"]
            accepted = self.repairs[f'{audit["dataset"]}:{row}:{column}']
            choices = benchmark["corrected_value"]
            assert accepted in (choices if isinstance(choices, list) else [choices])
            if human["target"] == "column_cluster":
                # A cluster verdict confirms the finding, not a literal replacement.
                discovery = audit["discovery_record"]
                index = audit["selected_cluster_index"]
                assert human["row"] is None
                assert human["target_id"] == (
                    f'colclust\0{audit["source"]}\0{human["column"]}\0c{index + 1}'
                )
                assert discovery["source"] == audit["source"]
                assert discovery["column"] == human["column"]
                assert benchmark["original_value"] in discovery["draft_clusters"][index]["values"]
                suggestion = audit["correction_suggestion"]
                assert suggestion["source"] == audit["source"]
                assert suggestion["column"] == human["column"]
                assert suggestion["value"] == benchmark["original_value"]
                assert accepted in suggestion["possible_correct_values"]
            else:
                assert human["row"] == row
                reviewed = human.get("corrected_values", {}).get(
                    human["column"], human.get("corrected_value")
                )
                assert accepted in (reviewed if isinstance(reviewed, list) else [reviewed])
        return self.reference["provenance"]


def construction(views, history):
    """Connect highlighted source cells to their actual discovery and review records."""
    headers, _ = views.load(PROVIDERS)
    repairs = {(row, headers.index(col)): fix for _, row, col, _, fix, *_ in RUNNING_CANDIDATES}
    source = views.table(
        PROVIDERS,
        [80, 81, None, 98, 99],
        [2, 7],
        [112, 84],
        marks=dict.fromkeys(repairs, "error"),
        repairs=repairs,
        callouts={
            (row, headers.index(col)): candidate for candidate, row, col, *_ in RUNNING_CANDIDATES
        },
    )
    notes = []
    for candidate, row, column, _, repair, _, family in RUNNING_CANDIDATES:
        key = f"{PROVIDERS}:{row}:{headers.index(column)}"
        address = f"{column_letter(headers.index(column))}{worksheet_row(row)}"
        views.repairs[key] = repair
        passes = []
        for pass_id in history["displayed_passes"]:
            found = pass_id in history["passes"][candidate]
            newly_found = (
                found
                and pass_id == min(history["passes"][candidate])
                and pass_id > history["displayed_passes"][0]
            )
            label = "New" if newly_found else ("Found" if found else "Missed")
            status = "newly-found" if newly_found else ("known-found" if found else "missed")
            passes.append(
                f'<span data-candidate="{candidate}" data-pass="{pass_id}" '
                f'data-found="{str(found).lower()}" class="{status}">'
                f'<span class="pass-label">Pass {pass_id}</span>'
                f'<span class="pass-status"><i aria-hidden="true"></i>{label}</span></span>'
            )
        notes.append(
            f'<section class="review-note" data-target-row="{row}">'
            f'<div class="review-header"><span class="note-callout">{candidate}</span>'
            f'<span class="cell-address">{address}</span><span>{family}</span>'
            '<span class="review-verdict">Error</span></div>'
            '<div class="review-body"><div class="pass-history">'
            + '<span class="omitted-passes">⋯</span>'.join(passes)
            + '</div><div class="accepted-repair"><span class="accepted-label">Correction</span>'
            + '<div class="review-result">'
            + checkmark()
            + f'<span class="repaired" data-repair="{key}">{esc(repair)}</span>'
            + "</div></div></div></section>"
        )
    return (
        '<div class="construction"><section class="source-panel">'
        '<h2>Healthcare-provider table</h2><div class="tableview">'
        + source
        + '</div></section><section class="review-panel"><h2>Discovery and human review</h2>'
        + '<div class="review-stack">'
        + "".join(notes)
        + "</div></section></div>"
    )


def checkmark():
    return (
        '<svg class="checkmark" viewBox="0 0 20 20" aria-hidden="true">'
        '<path d="M3 10L8 15L17 4"/></svg>'
    )


def verify_construction(views, run):
    """Verify the running example against raw sightings, verdicts, and frozen repairs."""
    hashes = {}

    def records(path):
        raw = path.read_bytes()
        hashes[str(path)] = hashlib.sha256(raw).hexdigest()
        return [json.loads(line) for line in raw.splitlines() if line.strip()]

    source = views.manifest[PROVIDERS]["source"]
    headers, rows = views.load(PROVIDERS)
    labels = {
        (r["source"], r["row"], r["column"]): r
        for r in records(views.snapshot / "benchmark_cell.json")
    }
    latest = {(r["target"], r["target_id"]): r for r in records(run / "labels.jsonl")}
    passes = {candidate: [] for candidate, *_ in RUNNING_CANDIDATES}
    for path in sorted((run / "runs").glob("run_*/detections.jsonl")):
        pass_id = int(path.parent.name[4:]) + 1
        detections = records(path)
        for candidate, row, column, original, *_ in RUNNING_CANDIDATES:
            hits = [
                d
                for d in detections
                if d["source"] == source and d["row"] == row and column in d["columns"]
            ]
            if hits:
                assert all(d["observed"] == original for d in hits)
                passes[candidate].append(pass_id)
    for candidate, row, column, original, repair, historical_type, _ in RUNNING_CANDIDATES:
        label = labels[source, row, column]
        assert rows[row][headers.index(column)] == label["original_value"] == original
        assert label["status"] == "error" and historical_type in label["error_types"]
        assert label["corrected_value"] == repair
        verdicts = [
            r
            for r in latest.values()
            if r["target"] == "cluster"
            and r["source"] == source
            and r["row"] == row
            and r.get("column") == column
        ]
        assert len(verdicts) == 1 and verdicts[0]["status"] == "tp"
        # Saved edit instructions are resolved to replacement strings in the frozen export.
        assert repair in verdicts[0]["corrected_value"]
    assert passes == {"A": [1, 2, 3, 4], "B": [4, 7, 8]}
    return {"passes": passes, "displayed_passes": [1, 4], "source_sha256": hashes}


def examples(views):
    panels = []
    for title, context, dataset, rows, target, columns, widths in [
        (
            "(a) Spelling",
            "Calendar",
            CALENDAR,
            [0, 1, None, 3],
            0,
            [8],
            [116],
        ),
        (
            "(b) Formatting",
            "Healthcare providers",
            PROVIDERS,
            [96, 97, 98, 99],
            99,
            [7],
            [116],
        ),
        (
            "(c) Inconsistency",
            "Months",
            MONTHS,
            [0, 1, 2, 3],
            2,
            [1],
            [116],
        ),
    ]:
        headers, _ = views.load(dataset)
        repairs = {
            (row, headers.index(column)): repair
            for ds, row, column, _, repair, *_ in EXAMPLE_REPAIRS
            if ds == dataset and row == target
        }
        marks = dict.fromkeys(repairs, "error")
        source = views.table(dataset, rows, columns, widths, marks, repairs)
        # Pair the original and accepted strings without repeating the worksheet.
        (row, column), repair = next(iter(repairs.items()))
        key = f"{dataset}:{row}:{column}"
        views.repairs[key] = repair
        if dataset == CALENDAR:
            _, source_rows = views.load(dataset)
            date = datetime.strptime(source_rows[row][0], "%Y%m%d")
            assert date.strftime("%A") == repair
        panels.append(
            f'<section class="panel" aria-label="{esc(context)}"><h2>{title}</h2>'
            + f'<div class="tableview">{source}</div>'
            + '<div class="repair-strip">'
            + '<div class="repair-comparison">'
            + '<div class="comparison-original"><span class="comparison-label">Original</span>'
            + f'<span class="comparison-value" data-before="{esc(key)}">'
            + highlight_edits(views.cells[key], repair)
            + '</span></div><div class="comparison-accepted">'
            + '<span class="comparison-label">Correction</span>'
            + f'<span class="comparison-value repaired" data-repair="{esc(key)}">'
            + checkmark()
            + highlight_edits(views.cells[key], repair, show_repair=True)
            + "</span></div></div>"
            + "</div>"
            + "</section>"
        )
    return '<div class="families taxonomy">' + "".join(panels) + "</div>"


def verify_example_labels(views):
    """Check displayed errors and repairs against the frozen cell annotations."""
    path = views.snapshot / "benchmark_cell.json"
    records = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    by_key = {(r["source"], r["row"], r["column"]): r for r in records}
    checked = []
    for dataset, row, column, original, repair, historical_type, family in EXAMPLE_REPAIRS:
        source = views.manifest[dataset]["source"]
        record = by_key[source, row, column]
        headers, rows = views.load(dataset)
        assert rows[row][headers.index(column)] == record["original_value"] == original
        assert record["status"] == "error" and historical_type in record["error_types"]
        replacements = record["corrected_value"]
        if isinstance(replacements, str):
            replacements = [replacements]
        assert repair in replacements
        checked.append(
            {"source": source, "row": row, "column": column, "family": family, "repair": repair}
        )
    return {"sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "checked_cells": checked}


def document(content, font_root, font_size_bp=FONT_SIZE_BP):
    # Convert the printed size to CSS pixels on the single-column canvas.
    font_size = font_size_bp * WIDTH / (COLUMN_WIDTH * 72)
    palette = (
        ":root{"
        + ";".join(
            f"--cb-{name.replace('_', '-')}:{color}" for name, color in EXAMPLE_PALETTE.items()
        )
        + "}"
    )
    css = """
    * {box-sizing:border-box} body {margin:0;background:white}
    #figure {width:100%;padding:1px 0 2px;color:var(--text-main);
      --text-main:#33424f;--text-heading:#3d5366;--text-muted:#5f6e7a;
      --text-discovery:#456d8b;--text-repair:#2d6b59;--text-error:#a15345}
    section {margin:0;min-width:0}
    h2 {margin:0 0 5px;font-size:inherit;font-weight:700;line-height:22px;
      color:var(--text-heading)}
    .tableview {background:white;border:1px solid #aeb4b9;overflow:hidden}
    .worksheet {background:white;color:var(--text-main)}
    table {width:100%;border-collapse:collapse;table-layout:fixed;font-size:inherit}
    th,td {height:24px;padding:2px 6px;border:.75px solid #d0d0d0;text-align:left;
      vertical-align:middle;line-height:1.05;font-weight:normal}
    .column-letters th {height:18px;padding:0 4px;background:#f3f3f3;
      color:var(--text-muted);text-align:center;border-color:#c8c8c8;line-height:1}
    .corner {position:relative}
    .corner::after {content:'';position:absolute;right:5px;bottom:4px;width:0;height:0;
      border:6px solid transparent;border-right-color:#b8b8b8;border-bottom-color:#b8b8b8}
    .field-names th {height:28px;background:white;color:var(--text-heading);font-weight:700}
    .families tbody td {height:22px}
    .families .field-names th {height:38px;padding:1px 6px;line-height:1.05}
    tbody td {white-space:pre-wrap;position:relative;background:white}
    .wrap-cell {overflow-wrap:anywhere}
    .numeric {text-align:right}
    .coord,.field-names .coord {text-align:center;color:var(--text-muted);background:#f3f3f3;
      padding:3px;font-weight:400;border-color:#c8c8c8}
    .column-letters .active-heading,.coord.active-heading {background:#e1eee6;color:var(--text-repair)}
    .column-letters .active-heading {border-bottom:2px solid #217346}
    .coord.active-heading {border-right:2px solid #217346}
    .hidden-before {border-left:3px double #aaa}
    .omitted td {text-align:center;color:var(--text-muted);background:white}
    .marked {background:#fff2cc;outline:1px solid #c0504d;outline-offset:-1px}
    .active-cell {outline:2px solid #217346;outline-offset:-1.5px}
    .active-cell::after {content:'';position:absolute;right:0;bottom:0;
      width:5px;height:5px;background:#217346;border:1px solid white}
    .sheet-bar {height:20px;border-top:1px solid #bdbdbd;background:#f3f3f3;
      display:flex;align-items:center;gap:10px}
    .sheet-navigation {display:flex;gap:15px;margin:0 1px 0 12px}
    .sheet-navigation i {width:0;height:0;border:4px solid transparent;
      border-right-color:#8c8c8c}
    .sheet-navigation i+i {border-right-color:transparent;border-left-color:#8c8c8c}
    .sheet-tab {align-self:stretch;line-height:18px;padding:0 9px;background:white;
      color:var(--text-repair);border-bottom:2px solid #217346;font-weight:700}
    .sheet-add {height:10px;width:10px;position:relative;flex:0 0 10px}
    .sheet-add::before,.sheet-add::after {content:'';position:absolute;background:#777}
    .sheet-add::before {width:10px;height:1px;top:5px}
    .sheet-add::after {height:10px;width:1px;left:5px}
    .sheet-scroll {height:8px;border-radius:4px;background:#c9c9c9;
      width:22%;margin-left:auto;margin-right:7px}
    .edit {color:var(--text-error);font-weight:700}
    .repaired {color:var(--text-repair);font-weight:700;white-space:pre-wrap}
    .checkmark {width:16px;height:16px;flex:0 0 16px;color:var(--text-repair)}
    .checkmark path {fill:none;stroke:currentColor;stroke-width:2.3;stroke-linecap:round;stroke-linejoin:round}
    .review-result {display:flex;align-items:center;gap:6px;line-height:23px}
    .construction {position:relative;display:grid;grid-template-columns:235px 10px 235px}
    .construction .field-names th {height:42px}
    .source-panel {grid-column:1;display:flex;flex-direction:column}
    .source-panel>.tableview {flex:1;display:flex}
    .source-panel .worksheet {flex:1;min-width:0;display:flex;flex-direction:column}
    .source-panel .sheet-grid {flex:1;display:flex}
    .source-panel table.source {height:100%}
    .source-panel .sheet-bar {flex-shrink:0}
    .review-panel {grid-column:3;position:relative}
    .review-stack {display:grid;gap:8px}
    .review-note {border:1px solid #cdd8e1;border-radius:6px;overflow:hidden;background:white}
    .review-header {display:flex;align-items:center;gap:5px;padding:5px 6px;
      background:#f1f5f8;line-height:22px;border-bottom:1px solid #dde5eb}
    .cell-address {font-weight:700;color:var(--text-heading)}
    .review-verdict {margin-left:auto;padding:1px 3px;border:1px solid #e3c7bc;
      border-radius:4px;color:var(--text-error);background:#faf0eb;white-space:nowrap}
    .review-body {display:grid;grid-template-columns:minmax(0,1fr);gap:5px;
      padding:6px;align-items:center}
    .pass-history {display:flex;gap:5px;align-items:center;white-space:nowrap;line-height:20px}
    .pass-history>span:not(.omitted-passes) {display:grid;gap:1px;flex:1;padding:3px 6px;
      border:1px solid #cfdee9;border-radius:4px;background:#edf3f7}
    .pass-history>.missed {border:1px dashed #bfcad2;background:#fafbfc}
    .pass-label {font-weight:400;color:var(--text-muted)}
    .pass-status {display:flex;gap:6px;align-items:center}
    .pass-status i {width:7px;height:7px;border:1px solid var(--text-discovery);
      border-radius:50%;background:var(--text-discovery)}
    .missed .pass-status i {border-color:var(--text-muted);background:white}
    .accepted-repair {border-top:1px solid #d7e0e6;padding-top:4px;display:flex;gap:6px;
      align-items:center}
    .note-callout,.cell-callout {display:inline-flex;justify-content:center;align-items:center;
      width:20px;height:20px;flex:0 0 20px;border-radius:4px;
      color:var(--text-discovery);background:#eaf0f5;font-weight:700;line-height:1}
    .cell-callout {position:absolute;right:3px;bottom:2px}
    .has-callout {padding-top:3px;padding-bottom:23px;padding-right:6px;vertical-align:top}
    .found {color:var(--text-discovery);font-weight:700}
    .missed,.omitted-passes {color:var(--text-muted)}
    .families {display:grid;grid-template-columns:repeat(3,152px);gap:12px;justify-content:center}
    .panel {padding:0;background:white}
    .repair-strip {width:100%;margin-top:8px}
    .repair-comparison {border:1px solid #d5dfe4;border-radius:5px;overflow:hidden}
    .comparison-original,.comparison-accepted {display:grid;grid-template-columns:78px minmax(0,1fr);
      gap:6px;align-items:center;padding:5px 8px;line-height:22px}
    .comparison-original {background:#fbf2ec;border-bottom:1px solid #dce5e2}
    .comparison-accepted {background:#edf6f1}
    .comparison-label {color:var(--text-muted)}
    .comparison-value {white-space:nowrap}
    .taxonomy .comparison-original,.taxonomy .comparison-accepted {
      display:grid;grid-template-columns:minmax(0,1fr);gap:1px;padding:4px 6px;line-height:20px}
    .comparison-value .checkmark {vertical-align:-2px;margin-right:4px}
    .comparison-accepted .edit {color:var(--text-repair);background:#d3e8dc;border-radius:2px}
    .accepted-label {color:var(--text-muted)}
    /* Stronger print contrast for the source-excerpt figures. Keep these
       overrides scoped so other diagrams can reuse the base worksheet style. */
    .construction,.families {
      --text-main:#293949;--text-heading:#243e55;--text-muted:#506171;
      --text-discovery:#275c86;--text-repair:#1e624d;--text-error:#984535}
    :is(.construction,.families) .tableview {border-color:#62788c}
    :is(.construction,.families) th,:is(.construction,.families) td {border-color:#a5b1bc}
    :is(.construction,.families) .column-letters th,
    :is(.construction,.families) .coord {background:#e9eef2;border-color:#9cabb8}
    :is(.construction,.families) .field-names th:not(.coord) {background:#f4f7fa}
    :is(.construction,.families) .column-letters .active-heading,
    :is(.construction,.families) .coord.active-heading {
      background:#d7e5f1;color:#275c86;border-color:#315f85}
    :is(.construction,.families) .column-letters .active-heading {border-bottom:2px solid #315f85}
    :is(.construction,.families) .coord.active-heading {border-right:2px solid #315f85}
    :is(.construction,.families) .hidden-before {border-left-color:#788b9c}
    :is(.construction,.families) .marked {background:#f8e4c2;outline-color:#aa6448}
    :is(.construction,.families) .active-cell {outline-color:#315f85}
    :is(.construction,.families) .active-cell::after {background:#315f85}
    :is(.construction,.families) .sheet-bar {background:#e9eef2;border-top-color:#91a1af}
    :is(.construction,.families) .sheet-tab {color:#275c86;border-bottom-color:#315f85}
    .construction .review-note {border:1.5px solid #627b91}
    .construction .review-header {background:#e1ebf3;border-bottom-color:#8fa4b6}
    .construction .review-verdict {border-color:#b77660;background:#f5e4dc}
    .construction .pass-history>.known-found {border-color:#a0adb9;background:#f0f3f6;
      color:var(--text-muted)}
    .construction .known-found .pass-status i {background:#7b8d9b;border-color:#7b8d9b}
    .construction .pass-history>.newly-found {border:1.5px solid #315f85;background:#dfeaf3;
      color:var(--text-discovery);font-weight:700}
    .construction .pass-history>.missed {border-color:#94a3b0;background:#f4f6f8}
    .construction .accepted-repair {border-left-color:#91a7b5}
    .construction .note-callout,.construction .cell-callout {
      color:white;background:#315f85}
    .families .repair-comparison {border:1.5px solid #627b91}
    .families .comparison-original {background:#f5e5dc;border-bottom-color:#9eb3aa}
    .families .comparison-accepted {background:#deeee5}
    .families .comparison-original .edit {background:#eac1af;border-radius:2px}
    .families .comparison-accepted .edit {background:#b8d7c5}
    /* Keep the sheet identity; omit inactive application controls. */
    :is(.construction,.families) .sheet-navigation,
    :is(.construction,.families) .sheet-add,
    :is(.construction,.families) .sheet-scroll {display:none}
    :is(.construction,.families) .sheet-bar {height:18px;padding-left:8px}
    :is(.construction,.families) .sheet-tab {line-height:16px}
    """
    regular = font_root / "LinLibertine_Rah.ttf"
    bold = font_root / "LinLibertine_RBah.ttf"
    if not regular.exists():
        regular, bold = font_root / "LinLibertine_R.otf", font_root / "LinLibertine_RB.otf"
    assert regular.is_file() and bold.is_file(), "Linux Libertine font files are required"
    fonts = f"""@font-face {{font-family:Libertine;src:url('{regular.as_uri()}')}}
    @font-face {{font-family:Libertine;src:url('{bold.as_uri()}');font-weight:700}}
    body {{font-family:Libertine;font-size:{font_size}px}}"""
    alignment = """<script>document.fonts.ready.then(() => {
      document.documentElement.dataset.ready='true';
    });</script>"""
    css += worksheet_css(WIDTH)
    return f'<!doctype html><html lang="en"><meta charset="utf-8"><title>CleanBench source table excerpts</title><style>{fonts}{palette}{css}</style><body><main id="figure">{content}</main>{alignment}</body></html>'


def write_palette_tex():
    """Freeze the same colors for the native construction workflow."""
    lines = ["% Generated by tools/build_context_screenshots.py; colors from figure_style.py."]
    for name, color in EXAMPLE_PALETTE.items():
        latex_name = "cbExample" + "".join(part.title() for part in name.split("_"))
        lines.append(rf"\definecolor{{{latex_name}}}{{HTML}}{{{color.removeprefix('#')}}}")
    (generated_asset("illustration_palette.tex")).write_text("\n".join(lines) + "\n")


def write_workflow_example(views):
    """Export verified literal values for the editable overview illustration."""
    lines = ["% Generated after source, archived-pass, and frozen-label checks."]
    for candidate, row, column, original, repair, *_ in RUNNING_CANDIDATES:
        headers, rows = views.load(PROVIDERS)
        assert rows[row][headers.index(column)] == original
        for suffix, value in [
            ("Row", row),
            ("Column", column),
            ("Original", original),
            ("Repair", repair),
        ]:
            lines.append(rf"\newcommand{{\CBFlow{candidate}{suffix}}}{{\detokenize{{{value}}}}}")
    (generated_asset("workflow_example.tex")).write_text("\n".join(lines) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--snapshot",
        type=Path,
        default=PAPER.parent / "outputs/baseline_campaign/20260910/snapshot",
    )
    parser.add_argument("--browser", type=Path, help="Optional Chromium executable")
    parser.add_argument("--font-dir", type=Path, default=PAPER / "build/fonts")
    parser.add_argument(
        "--frozen-excerpts",
        type=Path,
        help="Reflow an existing illustrated reference without the private source snapshot",
    )
    parser.add_argument("--figure", choices=("construction", "examples", "both"), default="both")
    parser.add_argument(
        "--discovery-run",
        type=Path,
        default=PAPER.parent / "outputs/20260630T012247Z_model_a60d81db",
    )
    args = parser.parse_args()
    if args.frozen_excerpts:
        views = FrozenSourceViews(args.frozen_excerpts)
        annotation_checks = views.verify()
        discovery_checks = views.reference["history"]
    else:
        views = SourceViews(args.snapshot)
        discovery_checks = verify_construction(views, args.discovery_run)
        annotation_checks = verify_example_labels(views)
    folder = PAPER / "build/context_screenshots"
    folder.mkdir(parents=True, exist_ok=True)
    if not args.frozen_excerpts:
        write_palette_tex()
        write_workflow_example(views)
    evidence = {
        "sources": views.sources,
        "figures": {},
        "example_annotations": annotation_checks,
        "discovery_history": discovery_checks,
        "policy": "Compact Excel-style read-only views omit the name box and formula bar. Worksheet row 1 contains field names; record indices are displayed plus two. Source column letters and double rules for hidden columns are preserved. Teal field headers, gray coordinates, blue/white row bands, regular black sans-serif values, and green whole-row frames match Figure 1. Matched A/B callouts link source cells to review cards containing recorded pass outcomes, human verdicts, and accepted repairs. Paired Original/Correction rows beneath family excerpts contrast source strings with accepted values and highlight changed characters. Literal displayed cells, row coordinates, and replacements are verified against the selected rendering input before capture. Frozen-excerpt mode reuses the already illustrated values and does not perform a fresh benchmark annotation audit. Figures 3 and 4 use 7 bp Liberation Sans in tables and 8 bp Libertine for surrounding annotations at single-column width. The taxonomy examples show only their error-bearing columns; date context remains in the frozen source used to verify the weekday. Manuscript assets are vector PDFs; PNG previews use 6x and 8x density. No new judgments or inference are depicted.",
    }
    with sync_playwright() as p:
        options = {"headless": True, "args": ["--no-sandbox"]}
        if args.browser:
            options["executable_path"] = str(args.browser)
        browser = p.chromium.launch(**options)
        figures = []
        if args.figure in ("construction", "both"):
            figures.append(("construction_context", construction(views, discovery_checks)))
        if args.figure in ("examples", "both"):
            figures.append(("benchmark_context", examples(views)))
        for name, content in figures:
            font_size_bp = FONT_SIZE_BP
            pixel_density = 8 if name == "benchmark_context" else 6
            page = browser.new_page(
                viewport={"width": WIDTH, "height": 1600}, device_scale_factor=pixel_density
            )
            page.emulate_media(media="screen")
            path = folder / f"{name}.html"
            path.write_text(document(content, args.font_dir.resolve(), font_size_bp))
            page.goto(path.as_uri())
            page.evaluate("document.fonts.ready")
            page.evaluate("document.fonts.load('16px Libertine')")
            page.wait_for_function("document.documentElement.dataset.ready === 'true'")
            assert page.evaluate("document.fonts.check('16px Libertine')")
            displayed = page.locator("[data-cell]").evaluate_all(
                "els => els.map(e => [e.dataset.cell,e.textContent])"
            )
            assert displayed
            for key, value in displayed:
                assert value == views.cells[key], (key, value)
            assert page.locator(".formula-bar,.name-box,.function-symbol").count() == 0
            row_headers = page.locator("[data-source-row]").evaluate_all(
                "els => els.map(e => [Number(e.dataset.sourceRow),Number(e.textContent)])"
            )
            assert all(displayed_row == worksheet_row(row) for row, displayed_row in row_headers)
            assert page.locator(".active-cell").count() == page.locator("table").count()
            assert (
                page.locator(".sheet-tab").all_text_contents()
                == ["Source"] * page.locator("table").count()
            )
            displayed_repairs = page.locator("[data-repair]").evaluate_all(
                "els => els.map(e => [e.dataset.repair,e.textContent])"
            )
            for key, value in displayed_repairs:
                assert value == views.repairs[key], (key, value)
            assert len(displayed_repairs) == (2 if name == "construction_context" else 3)
            displayed_originals = page.locator("[data-before]").evaluate_all(
                "els => els.map(e => [e.dataset.before,e.textContent])"
            )
            for key, value in displayed_originals:
                assert value == views.cells[key], (key, value)
            if name == "construction_context":
                sightings = page.locator("[data-candidate]").evaluate_all(
                    "els => els.map(e => ({candidate:e.dataset.candidate,"
                    "pass:Number(e.dataset.pass),found:e.dataset.found==='true'}))"
                )
                assert len(sightings) == 4
                for sighting in sightings:
                    assert sighting["found"] == (
                        sighting["pass"] in discovery_checks["passes"][sighting["candidate"]]
                    )
            overflow = page.locator(
                "td,th,h2,.review-note,.tableview,.sheet-bar,"
                ".comparison-label,.comparison-value,.pass-history,.review-header,.accepted-repair"
            ).evaluate_all(
                "els => els.filter(e=>e.scrollWidth>e.clientWidth+1).map(e=>e.textContent)"
            )
            assert not overflow, overflow
            typography = page.locator("h2,.review-note span").evaluate_all(
                "els => [...new Set(els.map(e => getComputedStyle(e).fontSize))]"
            )
            assert len(typography) == 1, typography
            expected_size = FONT_SIZE_BP * WIDTH / (COLUMN_WIDTH * 72)
            assert abs(float(typography[0].removesuffix("px")) - expected_size) < 0.001
            worksheet_style = check_worksheet_style(page)
            clipped = page.locator(
                "[data-cell],[data-repair],[data-before],h2,.worksheet,.sheet-bar,.review-note"
            ).evaluate_all(
                "els => {const f=document.querySelector('#figure').getBoundingClientRect();"
                "return els.filter(e=>{const r=e.getBoundingClientRect();return r.left<f.left-1"
                "||r.right>f.right+1||r.top<f.top-1||r.bottom>f.bottom+1;}).map(e=>e.textContent)}"
            )
            assert not clipped, clipped
            layout = page.locator("table").evaluate_all(
                "els => els.map(e => {const r=e.getBoundingClientRect();"
                "return {top:r.top,height:r.height};})"
            )
            assert len({round(r["top"], 2) for r in layout}) == 1
            assert len({round(r["height"], 2) for r in layout}) == 1
            if name == "construction_context":
                panel_edges = page.locator(".source-panel>.tableview,.review-stack").evaluate_all(
                    "els => els.map(e => {const r=e.getBoundingClientRect();"
                    "return {top:r.top,bottom:r.bottom};})"
                )
                assert len(panel_edges) == 2
                assert abs(panel_edges[0]["top"] - panel_edges[1]["top"]) < 0.1, panel_edges
                assert abs(panel_edges[0]["bottom"] - panel_edges[1]["bottom"]) < 0.1, panel_edges
                card_gaps = page.locator(".review-note").evaluate_all(
                    "els => els.slice(1).map((e,i) => e.getBoundingClientRect().top"
                    "-els[i].getBoundingClientRect().bottom)"
                )
                assert all(gap >= 8 for gap in card_gaps), card_gaps
                assert page.locator(".cell-callout").all_text_contents() == ["A", "B"]
                assert page.locator(".note-callout").all_text_contents() == ["A", "B"]
                assert page.locator(".cell-address").all_text_contents() == ["C83", "H101"]
                assert page.locator(".review-verdict").all_text_contents() == ["Error"] * 2
                clearances = page.locator(".has-callout").evaluate_all(
                    "es => es.map(e => e.querySelector('.cell-callout').getBoundingClientRect().top"
                    "-e.querySelector('[data-cell]').getBoundingClientRect().bottom)"
                )
                assert all(gap >= 1 for gap in clearances), clearances
                assert page.locator(".review-links,.repair-link").count() == 0
            else:
                assert page.locator(".repair-comparison").count() == 3
                assert len(displayed_originals) == 3
                assert (
                    page.locator(".comparison-label").all_text_contents()
                    == ["Original", "Correction"] * 3
                )
                assert page.locator(".review-links,.repair-link").count() == 0
            out = PAPER / "assets/generated" / f"{name}.png"
            page.locator("#figure").screenshot(path=str(out))
            canvas = page.locator("#figure").bounding_box()
            vector = out.with_suffix(".pdf")
            page.pdf(
                path=str(vector),
                width=f"{WIDTH}px",
                height=f"{canvas['height']}px",
                margin={"top": "0", "bottom": "0", "left": "0", "right": "0"},
                print_background=True,
            )
            evidence["figures"][name] = {
                "sha256": hashlib.sha256(out.read_bytes()).hexdigest(),
                "pdf_sha256": hashlib.sha256(vector.read_bytes()).hexdigest(),
                "displayed_cells": len(displayed),
                "displayed_repairs": len(displayed_repairs),
                "original_comparisons": len(displayed_originals),
                "worksheet_row_offset": 2,
                "formula_bar_visible": False,
                "canvas": canvas,
                "table_layout": layout,
                "font_size_bp": font_size_bp,
                "css_font_sizes": typography,
                "table_font_size_bp": TABLE_FONT_BP,
                "worksheet_style": worksheet_style,
                "png_pixel_density": pixel_density,
            }
            page.close()
        browser.close()
    (folder / "evidence.json").write_text(json.dumps(evidence, indent=2) + "\n")
    print(
        "Verified displayed text against frozen illustrated excerpts; captured selected figures."
        if args.frozen_excerpts
        else "Verified source hashes and literal cell text; captured selected context figures."
    )


if __name__ == "__main__":
    main()
