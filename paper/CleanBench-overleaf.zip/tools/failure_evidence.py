"""Read the saved Astra explanations behind frozen correction outputs."""

import hashlib
import json
from pathlib import Path


def saved_issue(paper, archive, *, run, dataset, row, column, original, proposed):
    phase = Path(paper) / archive["phase_template"].format(run=run)
    prompt = (phase / archive["stage"] / "prompt.txt").read_text()
    prompt_hash = hashlib.sha256(
        json.dumps(prompt, ensure_ascii=False, sort_keys=True).encode()
    ).hexdigest()
    path = phase / "requests" / archive["model"] / prompt_hash / f"{dataset}.json"
    receipt = json.loads(path.read_text())
    identities = json.loads((phase / "audited_request_hashes.json").read_text())
    assert receipt["status"] == "success"
    assert receipt["response_model"] == archive["model"]
    # Keep the transport and scoring-audit identities separately.
    audit_identity = identities[archive["stage"]][dataset]
    raw = json.loads(receipt["raw"]) if isinstance(receipt["raw"], str) else receipt["raw"]
    matches = [i for i in raw["issues"] if i["row"] == row and i["column"] == column]
    assert len(matches) <= 1
    issue = matches[0] if matches else None
    if issue:
        assert issue["observed"] == original
        value = issue.get("corrected_value")
        assert value == proposed or (proposed is None and value == original)
    else:
        assert proposed is None
    return dict(
        explanation=issue.get("explanation") if issue else None,
        issue=issue,
        receipt_path=str(path.resolve().relative_to(Path(paper).resolve().parent)),
        receipt_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        request_sha256=receipt["request_sha256"],
        scoring_audit_request_sha256=audit_identity,
        run=run,
    )
