"""Replay archived stopping decisions and join low-frequency proposals to reviews.

No model calls, label changes, or benchmark exports. Coordinate-level evidence
is written only under the ignored build directory; publication output is aggregate.
"""

from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import io
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

PAPER = Path(__file__).resolve().parents[1]
SCAN_ROUTES = {"typo", "semantic_incompatible", "numeric_outlier"}


def replay(history, minimum, budget, epsilon=0.05, consecutive=2):
    """Count new probes, not repeated frozen rows in the campaign-wide log."""
    status, streak, last_k = "active", 0, 0
    last_measurements = None
    for row in history:
        k = row["k_arm"]
        measurements = tuple(
            row[key]
            for key in (
                "n_observed",
                "n1",
                "n2",
                "total_hits",
                "good_turing_missing_mass",
                "chao1_ci_95_high",
            )
        )
        if k == last_k:
            assert measurements == last_measurements, "Frozen probe changed"
        else:
            assert k == last_k + 1 and status == "active"
            gap = max(0, row["chao1_ci_95_high"] - row["n_observed"]) / max(1, row["n_observed"])
            qualifies = (
                k >= minimum and row["good_turing_missing_mass"] <= epsilon and gap <= epsilon
            )
            streak = streak + 1 if qualifies else 0
            if streak >= consecutive:
                status = "saturated"
            elif k >= budget:
                status = "exhausted"
        assert row["status"] == status, (row, status)
        assert row["saturated_streak"] == streak, (row, streak)
        last_k, last_measurements = k, measurements
    assert status in {"saturated", "exhausted"}
    return status


def review_outcome(key, truth, reviews):
    """Absence from the error reference alone never establishes a false positive."""
    if key in truth:
        return truth[key]["status"]
    verdicts = {x["status"] for x in reviews.get(key, {}).get("provenance", [])}
    if verdicts == {"fp"}:
        return "rejected"
    return "mixed_review" if verdicts else "unreviewed"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--harness", type=Path, default=PAPER.parent)
    parser.add_argument("--output", type=Path, default=PAPER / "build/discovery_stopping")
    parser.add_argument("--publish", action="store_true")
    args = parser.parse_args()
    root, out = args.harness.resolve(), args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    proofs = {}

    def read(name):
        path = root / name
        data = path.read_bytes()
        proofs[str(path.relative_to(root))] = hashlib.sha256(data).hexdigest()
        return data.decode("utf-8")

    def obj(name):
        return json.loads(read(name))

    def lines(name):
        return [json.loads(line) for line in read(name).splitlines() if line.strip()]

    registry = next(
        ast.literal_eval(node.value)
        for node in ast.parse(read("experiments/export_cleanbench.py")).body
        if isinstance(node, ast.AnnAssign) and getattr(node.target, "id", None) == "REGISTRY"
    )
    annotation = obj("CleanBench/figures/annotation_funnel.json")
    for name, expected in annotation["source_sha256"].items():
        read(name)
        assert proofs[name] == expected, name
    snap = Path(annotation["snapshot"])
    manifest = obj(snap / "_manifest.json")
    tables = {v["source"]: (ds, v) for ds, v in manifest["datasets"].items()}
    row_maps = {
        source: {raw: local for local, raw in enumerate(meta["exported_to_source"])}
        for source, (_, meta) in tables.items()
    }

    def column(source, name):
        if source not in tables:
            return None
        columns = tables[source][1]["columns"]
        if name in columns:
            return name
        matches = [c for c in columns if c.strip() == name.strip()]
        return matches[0] if len(matches) == 1 else None

    def coordinate(species):
        source = species["source"]
        col = column(source, species["column"])
        row = row_maps.get(source, {}).get(species["row"])
        return None if col is None or row is None else (source, row, col)

    def key(row):
        return row["source"], row["row"], row["column"]

    truth = {key(r): r for r in lines(snap / "benchmark_cell.json")}
    reviews = {key(r): r for r in lines(annotation["recorded_labels"])}
    assert Counter(r["status"] for r in truth.values()) == {"error": 1409, "ambiguous": 842}
    sys.path.insert(0, str(root))
    from src.adaptive.cell_gt import aggregate_runs

    runs, arm_records, cell_records = [], [], []
    for pool, entries in registry.items():
        for route, _, run in entries:
            if route not in SCAN_ROUTES:
                continue
            directory = Path("outputs") / run
            estimates = obj(directory / "good_turing/estimates.json")
            assert estimates["target_missing_mass"] == 0.05
            assert estimates["num_runs_max"] == 15
            histories = defaultdict(list)
            for row in lines(directory / "good_turing/per_pass_per_arm.jsonl"):
                assert row["error_type"] == route
                histories[tuple(row["scope_id"])].append(row)
            counts, nonempty, exhausted = Counter(), Counter(), set()
            for (source, col), history in histories.items():
                status = replay(history, estimates["min_runs"], 15)
                if column(source, col) is None or not row_maps[source]:
                    continue
                counts[status] += 1
                final = history[-1]
                if final["n_observed"]:
                    nonempty[status] += 1
                if status == "exhausted":
                    exhausted.add((source, col))
                arm_records.append(dict(run=run, source=source, column=col, **final))

            archived = []
            for i in range(estimates["num_runs_completed"]):
                # Archives use two-digit or unpadded run indices in some campaigns.
                choices = [
                    p
                    for p in (root / directory / "runs").glob("run_*")
                    if int(p.name.split("_")[-1]) == i
                ]
                assert len(choices) == 1
                path = choices[0].relative_to(root)
                det = lines(path / "detections.jsonl")
                meta = obj(path / "run.json")
                assert meta["run_id"] == i and meta["detections"] == len(det)
                archived.append(det)
            species = lines(directory / "good_turing/species.jsonl")
            rebuilt = {k: v.to_dict() for k, v in aggregate_runs(archived).items()}
            saved = {(r["source"], r["column"], r["row"]): r for r in species}
            assert rebuilt == saved, "Species history does not match raw detections"
            outcomes = Counter()
            for record in species:
                if (record["source"], record["column"]) not in exhausted:
                    continue
                frozen = coordinate(record)
                if frozen is None:
                    continue
                passes = record["runs_by_error_type"].get(route, [])
                if len(passes) != 1:
                    continue
                outcome = review_outcome(frozen, truth, reviews)
                outcomes[outcome] += 1
                cell_records.append(
                    dict(
                        source=frozen[0],
                        row=frozen[1],
                        column=frozen[2],
                        original_row=record["row"],
                        run=run,
                        route=route,
                        pass_number=passes[0] + 1,
                        outcome=outcome,
                    )
                )
            runs.append(
                dict(
                    pool=pool,
                    route=route,
                    run=run,
                    archived_searches=len(histories),
                    retained_searches=sum(counts.values()),
                    stopping=dict(counts),
                    nonempty_stopping=dict(nonempty),
                    one_pass_candidates=dict(outcomes),
                )
            )

    # A cell occurring once in multiple selected searches must not be counted twice.
    assert len({key(row) for row in cell_records}) == len(cell_records)
    stopping = sum((Counter(r["stopping"]) for r in runs), Counter())
    nonempty = sum((Counter(r["nonempty_stopping"]) for r in runs), Counter())
    outcomes = Counter(r["outcome"] for r in cell_records)
    assert stopping == {"saturated": 17269, "exhausted": 215}
    assert outcomes == {"rejected": 1771, "error": 29, "ambiguous": 41, "mixed_review": 33}

    # Preserve a small verifiable example trail; no web-based reinterpretation.
    examples = []
    selected = {
        ("256038652_SalesReps.csv", 32, "Name"),
        ("221998519_Sales SalesPerson.csv", 11, "Bonus"),
        ("322444589_PMP.csv", 79, "Course Type"),
    }
    for row in cell_records:
        if key(row) not in selected:
            continue
        ds, meta = tables[row["source"]]
        path = snap / ds / "dirty.csv"
        grid = list(csv.reader(io.StringIO(read(path))))
        assert proofs[str(path)] == meta["dirty_sha256"]
        value = grid[row["row"] + 1][meta["columns"].index(row["column"])]
        search = next(
            a
            for a in arm_records
            if a["run"] == row["run"]
            and a["source"] == row["source"]
            and a["column"] == row["column"]
        )
        if row["column"] == "Bonus":
            assert value == "75" and row["outcome"] == "rejected"
            assert row["pass_number"] == 1 and search["k_arm"] == 15
            assert search["n_observed"] == search["n1"] == search["total_hits"] == 1
            assert search["good_turing_missing_mass"] == search["chao1_ci_95_high"] == 1
        examples.append(
            dict(row, value=value, search=search, review_provenance=reviews[key(row)]["provenance"])
        )
    assert len(examples) == len(selected)

    for name in (
        "src/adaptive/cell_gt.py",
        "src/adaptive/_chao1.py",
        "src/adaptive/scoped_gt.py",
        "CleanBench/tools/audit_discovery_stopping.py",
    ):
        read(name)

    result = dict(
        scope="Six archived column-scan campaigns; one search per retained column and prompted check. Includes empty searches; excludes other discovery routes.",
        epsilon_gt=0.05,
        epsilon_chao1=0.05,
        consecutive_checks=2,
        pass_limit=15,
        retained_searches=sum(stopping.values()),
        stopping=dict(stopping),
        stopping_percent=100 * stopping["saturated"] / sum(stopping.values()),
        nonempty_searches=sum(nonempty.values()),
        nonempty_stopping=dict(nonempty),
        nonempty_stopping_percent=100 * nonempty["saturated"] / sum(nonempty.values()),
        one_pass_candidates=len(cell_records),
        one_pass_outcomes=dict(outcomes),
        rejected_percent=100 * outcomes["rejected"] / len(cell_records),
        author_confirmed_procedure="On 2026-10-29, the author confirmed that reviewers additionally inspected the complete corresponding columns/tables after the pass limit, to search for missed errors. This is an author-provided procedure description, not a reconstructed per-table audit log.",
        runs=runs,
        source_sha256=dict(sorted(proofs.items())),
    )
    (out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    (out / "examples.json").write_text(json.dumps(examples, indent=2) + "\n")
    for name, rows in [("searches", arm_records), ("one_pass_candidates", cell_records)]:
        (out / f"{name}.jsonl").write_text("".join(json.dumps(r) + "\n" for r in rows))
    if args.publish:
        (PAPER / "figures/discovery_stopping.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {k: v for k, v in result.items() if k not in {"source_sha256", "runs"}}, indent=2
        )
    )


if __name__ == "__main__":
    main()
