"""Check relative coordinates, distinct errors, and cell exposure denominators."""

import csv

import numpy as np
import pytest
from tools.build_error_position import aggregate, position_bins, rates, read_counts, write_counts


def test_equal_width_bins_use_cell_centers_and_preserve_table_order():
    assert position_bins(10).tolist() == [0, 0, 1, 1, 2, 2, 3, 3, 4, 4]
    assert position_bins(5).tolist() == [0, 1, 2, 3, 4]
    assert position_bins(1).tolist() == [2]
    with pytest.raises(ValueError):
        position_bins(0)


def test_narrow_tables_leave_unoccupied_regions_without_duplicating_cells():
    assert position_bins(2).tolist() == [1, 3]
    counts = aggregate({"a": dict(source="BI", rows=10, columns=2)}, {("a", 9, 1)})
    assert counts["All"]["cells"].sum() == 20
    assert counts["All"]["cells"].sum(axis=0).tolist() == [0, 10, 0, 10, 0]
    assert counts["All"]["errors"][4, 3] == 1
    values = rates(counts["All"]["errors"], counts["All"]["cells"])
    assert np.isnan(values[:, 0]).all()
    assert values[4, 3] == 500


def test_row_and_column_axes_are_not_transposed_or_flipped():
    counts = aggregate({"a": dict(source="BI", rows=10, columns=10)}, {("a", 0, 9)})
    assert counts["All"]["errors"][0, 4] == 1
    assert counts["All"]["errors"].sum() == 1
    assert np.all(counts["All"]["cells"] == 4)
    assert rates(counts["All"]["errors"], counts["All"]["cells"])[0, 4] == 250


def test_duplicate_type_memberships_and_ambiguous_or_immune_cells():
    counts = aggregate(
        {"a": dict(source="BI", rows=5, columns=5)},
        [("a", 0, 0), ("a", 0, 0), ("a", 0, 2)],
        ambiguous=[("a", 0, 1)],
        immune=lambda cell: cell == ("a", 0, 2),
    )
    assert counts["All"]["errors"].sum() == 1
    assert counts["All"]["cells"].sum() == 23
    assert counts["All"]["cells"][0].tolist() == [1, 0, 0, 1, 1]


def test_pooling_uses_summed_counts_instead_of_mean_table_error_rates():
    counts = aggregate(
        {"a": dict(source="BI", rows=5, columns=5), "b": dict(source="Web", rows=10, columns=10)},
        {("a", 0, 0)},
    )
    assert counts["All"]["tables"] == 2
    assert counts["All"]["cells"].sum() == 125
    assert rates(counts["All"]["errors"], counts["All"]["cells"])[0, 0] == 200
    assert rates(counts["Relational"]["errors"], counts["Relational"]["cells"])[0, 0] == 1000
    assert counts["Spreadsheet"]["errors"].sum() == 0


def test_minimum_dimensions_filter_both_errors_and_cell_denominators():
    tables = {
        "short": dict(source="BI", rows=4, columns=8),
        "narrow": dict(source="Web", rows=8, columns=4),
        "boundary": dict(source="BI", rows=5, columns=5),
        "large": dict(source="Web", rows=7, columns=7),
    }
    errors = {(name, 0, 0) for name in tables}
    filtered = aggregate(
        tables,
        errors,
        ambiguous=[("boundary", 0, 1)],
        immune=lambda cell: cell == ("large", 0, 0),
        min_rows=5,
        min_columns=5,
    )
    assert filtered["All"]["tables"] == 2
    assert filtered["All"]["cells"].sum() == 25 + 49 - 2
    assert filtered["All"]["errors"].sum() == 1
    assert filtered["Relational"]["cells"].sum() == 24
    assert filtered["Spreadsheet"]["cells"].sum() == 48
    assert (filtered["All"]["cells"] > 0).all()
    full = aggregate(tables, errors)
    assert full["All"]["tables"] == 4
    assert full["All"]["cells"].sum() == 4 * 8 + 8 * 4 + 25 + 49
    assert full["All"]["errors"].sum() == 4
    with pytest.raises(ValueError, match="positive"):
        aggregate(tables, errors, min_rows=0)


def test_malformed_coordinates_and_conflicting_labels_are_rejected():
    tables = {"a": dict(source="BI", rows=5, columns=5)}
    for cell in (("a", -1, 0), ("a", 0, 5), ("missing", 0, 0)):
        with pytest.raises(ValueError, match="outside"):
            aggregate(tables, {cell})
    with pytest.raises(ValueError, match="both"):
        aggregate(tables, {("a", 0, 0)}, {("a", 0, 0)})


def test_frozen_aggregates_round_trip_and_reject_rate_changes(tmp_path):
    counts = aggregate({"a": dict(source="BI", rows=5, columns=5)}, {("a", 0, 0)})
    path = tmp_path / "position.csv"
    write_counts(path, counts)
    loaded = read_counts(path)
    for source in counts:
        for metric in ("errors", "cells"):
            assert np.array_equal(loaded[source][metric], counts[source][metric])
    with path.open(newline="") as stream:
        records = list(csv.DictReader(stream))
    records[0]["errors_per_1000"] = "0"
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=records[0])
        writer.writeheader()
        writer.writerows(records)
    with pytest.raises(AssertionError):
        read_counts(path)
