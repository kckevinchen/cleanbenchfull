"""Small scoring fixtures for shared negatives and overlapping positive types."""

import pytest
from build_type_precision import focused_metrics


def test_detection_keeps_shared_false_positives_but_ignores_other_type_hits():
    result = focused_metrics({1, 2, 3}, {1, 2, 3, 9, 10}, {"a": {1, 2, 4}, "b": {3, 5}}, 2)
    assert result["a"]["precision"] == 0.5
    assert result["a"]["recall"] == pytest.approx(2 / 3)
    assert result["b"]["precision"] == pytest.approx(1 / 3)
    assert result["b"]["fp"] == 2


def test_wrong_repair_uses_annotated_type_and_counts_as_false_negative():
    result = focused_metrics({1}, {1, 2, 3, 9}, {"a": {1, 2}, "b": {3, 4}}, 1)
    assert (result["a"]["tp"], result["a"]["fp"], result["a"]["fn"]) == (1, 2, 1)
    assert (result["b"]["tp"], result["b"]["fp"], result["b"]["fn"]) == (0, 2, 2)


def test_overlapping_labels_are_evaluated_in_each_slice_without_partitioning():
    result = focused_metrics({1}, {1, 2}, {"a": {1, 2}, "b": {1, 2, 3}}, 0)
    assert result["a"]["precision"] == result["b"]["precision"] == 0.5
    assert result["b"]["recall"] == pytest.approx(1 / 3)


def test_abstention_keeps_targets():
    result = focused_metrics(set(), set(), {"a": {1, 2}}, 0)["a"]
    assert result["precision"] == result["recall"] == 0
    assert result["fn"] == 2
