"""Present conditional macro P and fixed-target macro R in the main table layout."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path

from build_macro_heatmap import read_csv, score
from build_no_empty_recall_table import BLOCKS, draw
from build_stratified_metrics import harmonic
from figure_style import FIGURE_WIDTH, configure

PAPER = Path(__file__).resolve().parents[1]
GENERATED = PAPER / "assets/generated"
SOURCE = GENERATED / "stratified_metrics.csv"
RECALL_SOURCE = GENERATED / "macro_type_metrics.csv"
ROSTER = GENERATED / "task_type_metrics.csv"
CSV_TARGET = GENERATED / "conditional_macro_metrics.csv"
PDF_TARGET = GENERATED / "conditional_macro_heatmap.pdf"


def inputs():
    roster = [
        row
        for row in read_csv(ROSTER)
        if row["task"] == "e2e"
        and not (row["category"] == "Direct LLMs (API)" and row["method"].endswith(" (Base)"))
    ]
    source_rows, recall_rows = read_csv(SOURCE), read_csv(RECALL_SOURCE)
    source = {(r["method"], r["error_type"]): r for r in source_rows}
    recall = {(r["method"], r["error_type"]): r for r in recall_rows}
    expected = {(row["method"], kind) for row in roster for kind, _, _ in BLOCKS}
    assert len(roster) == 23 and len(expected) == len(source_rows) == len(recall_rows) == 92
    assert source.keys() == recall.keys() == expected
    rows = []
    for method in (r["method"] for r in roster):
        for kind, _, _ in BLOCKS:
            a, b = source[method, kind], recall[method, kind]
            assert a["runs"] == b["runs"] and a["target_tables"] == b["target_tables"]
            p = score({**a, "macro_precision": a["conditional_precision"]}, "macro_precision")
            r = score({**a, "macro_recall": a["target_recall"]}, "macro_recall")
            assert r is not None and math.isclose(r, float(b["macro_recall"]), abs_tol=1e-12)
            assert not p or r > 0, "Positive precision must imply positive recall"
            rows.append(
                {
                    **{
                        k: b[k]
                        for k in (
                            "method",
                            "category",
                            "group",
                            "error_type",
                            "error_type_label",
                            "runs",
                            "tables",
                            "target_tables",
                        )
                    },
                    "macro_precision_tables": a["predicted_tables"],
                    "macro_recall_tables": a["target_tables"],
                    "precision_defined_runs": a["precision_defined_runs"],
                    "macro_precision": a["conditional_precision"],
                    "macro_recall": a["target_recall"],
                    "macro_f1": harmonic(p, r),
                    "f1_aggregation": "harmonic_of_unrounded_conditional_precision_and_target_recall_summaries",
                }
            )
    return roster, rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--validate-only", action="store_true")
    args = parser.parse_args()
    sources = (SOURCE, RECALL_SOURCE, ROSTER)
    hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
    roster, rows = inputs()
    if args.validate_only:
        print("Validated 92 conditional-precision / target-recall rows and harmonic F1 values")
        return
    with CSV_TARGET.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    configure()
    displayed, height = draw(
        roster, read_csv(CSV_TARGET), target=PDF_TARGET, conditional_precision=True
    )
    assert len(displayed) == 207
    for path in sources:
        assert hashlib.sha256(path.read_bytes()).hexdigest() == hashes[path.name]
    receipt = {
        "source_sha256": hashes,
        "summary_rows": len(rows),
        "workflows": len(roster),
        "numeric_cells": len(displayed),
        "width_inches": FIGURE_WIDTH,
        "height_inches": height,
        "font_size_bp": 8,
        "precision": "Mean table precision only over completed outputs with scored edits, across all tables, including false alarms on no-target tables.",
        "recall": "Mean table recall over the fixed GT target population, including silent/failed target outputs as zero.",
        "f1": "Harmonic mean of the reported unrounded P/R summaries, after their run averaging.",
        "displayed_values": displayed,
    }
    (PAPER / "build/generated/conditional_macro_table_evidence.json").write_text(
        json.dumps(receipt, indent=2) + "\n"
    )
    print("Rendered 23 workflows with Overall P/R/F1 and three error-type P/R pairs")


if __name__ == "__main__":
    main()
