"""Audit retained API/agent inference resources, excluding unrelated search runs.

Run from the harness checkout: venv/bin/python CleanBench/tools/build_resource_usage.py
No model calls are made. API request identities recover reused development calls;
CLI records cover only the final retained invocation for each scored table.
"""

from __future__ import annotations

import hashlib
import json
import statistics
from collections import defaultdict
from pathlib import Path

from build_coding_agents import RUNS, successful
from experiment_presentation import reported_table

if __package__:
    from .tex_sources import generated_asset
else:
    from tex_sources import generated_asset

PAPER = Path(__file__).resolve().parents[1]
REPO = PAPER.parent
MODELS = ["gpt-4.1", "gpt-5.2", "gpt-5.5", "gpt-6-astra"]
SOURCES = {}


def read(path):
    SOURCES[str(path.relative_to(REPO))] = hashlib.sha256(path.read_bytes()).hexdigest()
    return json.loads(path.read_text())


def events(path):
    SOURCES[str(path.relative_to(REPO))] = hashlib.sha256(path.read_bytes()).hexdigest()
    result = []
    for line in path.read_text().splitlines():
        try:
            result.append(json.loads(line))
        except ValueError:
            # Native CLIs may interleave plain progress lines with JSON.
            assert path.name == "events.jsonl"
    return result


def digest_text(text):
    # Request caches use JSON-encoded strings, rather than file-byte hashes.
    return hashlib.sha256(json.dumps(text, ensure_ascii=False, sort_keys=True).encode()).hexdigest()


def ledger_index(roots):
    index, seen = defaultdict(list), {}
    for root in roots:
        for event in events(root / "telemetry.jsonl"):
            key = event["event_id"]
            if key in seen:
                assert seen[key] == event
                continue
            seen[key] = event
            index[event["repetition"], event["request_sha256"]].append(event)
    return index


def price(tokens, rate, tier):
    if tokens is None or tier not in (None, "default", "standard", "auto"):
        return None
    if tokens["input_tokens"] > rate["max_priced_input_tokens"]:
        return None
    cached, writes = tokens["cached_input_tokens"], tokens["cache_write_tokens"]
    if writes and rate.get("cache_write") is None:
        return None
    ordinary = tokens["input_tokens"] - cached - writes
    assert ordinary >= 0
    return (
        ordinary * rate["input"]
        + cached * rate["cached_input"]
        + writes * (rate.get("cache_write") or 0)
        + tokens["output_tokens"] * rate["output"]
    ) / 1e6


def api_run(folder, model, rep, index, rate, count, record):
    receipts = sorted(folder.glob("*.json"))
    assert len(receipts) == count, (folder, len(receipts))
    totals = defaultdict(float)
    times, identities = [], set()
    for path in receipts:
        receipt = read(path)
        identity = receipt["request_sha256"]
        assert identity not in identities
        identities.add(identity)
        matched = index[rep, identity]
        queries = [e for e in matched if e["event"] == "query"]
        calls = [e for e in matched if e["event"] == "sdk_invocation"]
        assert queries and calls, path
        if receipt["status"] == "success":
            assert any(
                e.get("response_text_sha256") == digest_text(receipt["raw"]) for e in calls
            ), path
        else:
            totals["failed_tables"] += 1
        starts = {e["invocation_id"] for e in matched if e["event"] == "sdk_invocation_started"}
        assert starts == {e["event_id"] for e in calls}, path
        times.append(sum(e["elapsed_seconds"] for e in queries))
        totals["queries"] += len(queries)
        totals["sdk_invocations"] += len(calls)
        for e in calls:
            tokens = e.get("tokens")
            if tokens:
                for key in [
                    "input_tokens",
                    "output_tokens",
                    "cached_input_tokens",
                    "cache_write_tokens",
                ]:
                    totals[key] += tokens[key]
            else:
                totals["missing_usage"] += 1
            cost = price(tokens, rate, e.get("service_tier"))
            if cost is None:
                totals["unpriced_calls"] += 1
            else:
                totals["usd"] += cost
    assert totals["failed_tables"] == (
        len(record["failed_tables"])
        if isinstance(record["failed_tables"], list)
        else record["failed_tables"]
    )
    return dict(
        totals,
        mean_seconds=statistics.mean(times),
        median_seconds=statistics.median(times),
        serial_hours=sum(times) / 3600,
        tables=count,
    )


def api_rows():
    root = REPO / "outputs/prompt_tuning/dev200_none_20260930_continuation"
    result = read(root / "final_report/RESULTS.json")
    pricing = result["pricing"]
    index = ledger_index([root])
    rows = []
    for model in MODELS:
        for arm in ["baseline", "selected"]:
            reps = []
            for rep in result["repetitions"]:
                record = next(r for r in rep["comparison"] if r["name"] == f"compare_{model}_{arm}")
                phase = root / f"rep_{rep['repetition']:02d}/recovered"
                prompt = (phase / record["name"] / "prompt.txt").read_text()
                folder = phase / "requests" / model / digest_text(prompt)
                reps.append(
                    api_run(
                        folder,
                        model,
                        rep["repetition"],
                        index,
                        pricing["models"][model],
                        1000,
                        record,
                    )
                )
            rows.append(
                dict(
                    task="Detection/repair",
                    model=model.replace("gpt", "GPT"),
                    interface="API Base" if arm == "baseline" else "API Tuned",
                    repetitions=reps,
                )
            )
    final = read(REPO / "outputs/prompt_tuning/correction_retuned_final_20261002/RESULTS.json")
    for model in MODELS:
        root = REPO / final["summary"][model]["source"]
        roots = [root]
        while (roots[-1] / "cache_provenance.json").exists():
            roots.append(REPO / read(roots[-1] / "cache_provenance.json")["source"])
            assert len(roots) == len(set(roots))
        index = ledger_index(roots)
        config = read(root / "config.json")
        assert config["pricing"] == pricing
        result = read(root / model / "RESULTS.json")
        for arm in ["baseline", "selected"]:
            reps = []
            for rep in result["comparisons"]:
                record = rep["arms"][arm]
                namespace = rep["repetition"] + 3
                phase = root / f"rep_{namespace:02d}"
                prompt = (phase / record["name"] / "prompt.txt").read_text()
                folder = phase / "requests" / model / digest_text(prompt)
                reps.append(
                    api_run(folder, model, namespace, index, pricing["models"][model], 164, record)
                )
            rows.append(
                dict(
                    task="Correction",
                    model=model.replace("gpt", "GPT"),
                    interface="API Base" if arm == "baseline" else "API Tuned",
                    repetitions=reps,
                )
            )
    return rows, pricing


def agent_rows():
    base = REPO / "outputs/coding_agents"
    mapping = read(base / "correction_full_once_20261002/arm_sources.json")["arms"]
    rows = []
    for task in ["Detection/repair", "Correction"]:
        for (run, agent, model, harness), arm in zip(
            RUNS, ["codex_astra", "copilot_astra", "claude_opus", "copilot_opus"]
        ):
            folder = base / run / agent if task == "Detection/repair" else REPO / mapping[arm]
            paths = sorted(folder.glob("table_*/receipt.json"))
            assert len(paths) == (1000 if task == "Detection/repair" else 164)
            totals, times = defaultdict(float), []
            for path in paths:
                r = read(path)
                times.append(r["elapsed_seconds"])
                totals["failed_tables"] += not successful(r)
                if agent == "copilot":
                    u = read(path.parent / "work/usage.json")
                    totals["premium_requests"] += u["totalPremiumRequestCost"]
                    totals["nano_aiu"] += u["totalNanoAiu"]
                    usages = [m["usage"] for m in u["modelMetrics"].values()]
                    assert len(usages) == 1
                    u = usages[0]
                    tokens = [
                        u[k]
                        for k in [
                            "inputTokens",
                            "outputTokens",
                            "cacheReadTokens",
                            "cacheWriteTokens",
                        ]
                    ]
                else:
                    ev = events(path.parent / "events.jsonl")
                    matches = [
                        e
                        for e in ev
                        if e.get("type") == ("turn.completed" if agent == "codex" else "result")
                    ]
                    if not matches:
                        assert not successful(r), path
                        totals["missing_usage"] += 1
                        continue
                    assert len(matches) == 1, path
                    e, u = matches[0], matches[0]["usage"]
                    if agent == "codex":
                        tokens = [
                            u[k]
                            for k in [
                                "input_tokens",
                                "output_tokens",
                                "cached_input_tokens",
                                "cache_write_input_tokens",
                            ]
                        ]
                    else:
                        tokens = [
                            sum(
                                u[k]
                                for k in [
                                    "input_tokens",
                                    "cache_creation_input_tokens",
                                    "cache_read_input_tokens",
                                ]
                            ),
                            u["output_tokens"],
                            u["cache_read_input_tokens"],
                            u["cache_creation_input_tokens"],
                        ]
                        # Preserve CLI telemetry for auditing, not subscription charges.
                        totals["usd"] += e["total_cost_usd"]
                for key, value in zip(
                    ["input_tokens", "output_tokens", "cached_input_tokens", "cache_write_tokens"],
                    tokens,
                ):
                    totals[key] += value
            if task == "Detection/repair":
                saved = read(base / run / "USAGE.json")["agents"][agent]
                assert saved["tasks_reporting_usage"] == len(paths) - totals["missing_usage"]
                assert totals["input_tokens"] == (
                    saved["totals"]["input_tokens"]
                    if agent == "codex"
                    else saved["totals"]["inputTokens"]
                    if agent == "copilot"
                    else sum(
                        saved["totals"][k]
                        for k in [
                            "input_tokens",
                            "cache_creation_input_tokens",
                            "cache_read_input_tokens",
                        ]
                    )
                )
            assert totals["failed_tables"] == (
                3
                if task == "Detection/repair" and agent == "codex"
                else 1
                if task == "Correction" and agent == "claude"
                else 0
            )
            rows.append(
                dict(
                    task=task,
                    model=model,
                    interface=harness,
                    repetitions=[
                        dict(
                            totals,
                            mean_seconds=statistics.mean(times),
                            median_seconds=statistics.median(times),
                            serial_hours=sum(times) / 3600,
                            tables=len(paths),
                        )
                    ],
                )
            )
    return rows


def main_table_resources():
    """Load the audited task-specific measurements used by the appendix table."""
    path = PAPER / "build/generated/resource_usage_evidence.json"
    data = json.loads(path.read_text())
    indexed = {}
    for row in data["rows"]:
        key = (row["task"], row["model"], row["interface"])
        assert key not in indexed
        expected_tables = 1000 if row["task"] == "Detection/repair" else 164
        assert row["task"] in {"Detection/repair", "Correction"}
        assert all(r["tables"] == expected_tables for r in row["repetitions"])
        for metric in ["mean_seconds", "usd", "premium_requests"]:
            if metric in row["mean"]:
                assert row["mean"][metric] == statistics.mean(
                    r.get(metric, 0) for r in row["repetitions"]
                )
        indexed[key] = row["mean"]
    return indexed, hashlib.sha256(path.read_bytes()).hexdigest()


def resource_pair(resources, model, interface):
    """Format correction / repair resources; keep historical lookup keys."""
    values = [resources[task, model, interface] for task in ["Detection/repair", "Correction"]]
    times = "/".join(f"{v['mean_seconds']:.1f}" for v in values)
    if interface.startswith("API"):
        cost = "/".join(f"{v['usd']:.2f}" for v in values)
    else:
        assert interface in {"Codex", "Copilot", "Claude Code"}
        cost = "--"
    return times, cost


def main():
    rows, pricing = api_rows()
    rows.extend(agent_rows())
    output = []
    for task in ["Detection/repair", "Correction"]:
        count = 1000 if task == "Detection/repair" else 164
        label = {
            "Detection/repair": "End-to-end correction / detection only",
            "Correction": "Repair only",
        }[task]
        output.append(rf"\multicolumn{{9}}{{l}}{{\textit{{{label}: {count:,} tables per run}}}} \\")
        for row in rows:
            if row["task"] not in ([task, "Detection"] if task == "Detection/repair" else [task]):
                continue
            mean = lambda key: statistics.mean(r.get(key, 0) for r in row["repetitions"])
            row["mean"] = {
                key: mean(key)
                for key in sorted(set().union(*(r.keys() for r in row["repetitions"])))
            }
            dollars = f"{mean('usd'):.2f}" if row["interface"].startswith("API") else "---"
            units = f"{mean('premium_requests'):.0f}" if row["interface"] == "Copilot" else "---"
            unpriced = (
                f"{mean('unpriced_calls'):.1f}" if row["interface"].startswith("API") else "---"
            )
            interface_label = (
                "API Prompt-tuned" if row["interface"] == "API Tuned" else row["interface"]
            )
            output.append(
                f"{row['model']} & {interface_label} & {mean('mean_seconds'):.1f} & {mean('serial_hours'):.2f} & "
                f"{mean('input_tokens')/1e6:.2f} & {mean('output_tokens')/1e3:.1f} & {dollars} & {units} & {unpriced}"
                + r" \\"
            )
        output.append(r"\midrule")
    output.pop()
    asset = generated_asset("resource_usage_table.tex")
    asset.write_text(
        reported_table(
            "\n".join(
                [
                    "% Generated by tools/build_resource_usage.py.",
                    r"\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}llrrrrrrr@{}}",
                    r"\toprule",
                    r"Model & Interface & s/table & Serial h & Input M & Output k & USD$^{a}$ & PR$^{b}$ & Unpriced$^{c}$ \\",
                    r"\midrule",
                    *output,
                    r"\bottomrule",
                    r"\end{tabular*}",
                ]
            )
            + "\n"
        )
    )
    evidence = dict(
        rows=rows,
        pricing=pricing,
        source_sha256=SOURCES,
        policy="API: all recorded attempts for full-scope request identities in the retained three repetitions, including reused selection-table requests. Agents: final retained invocation, including three Codex correction timeouts and the one invalid Claude known-location repair output. Excludes search-only requests, discarded runs, pilots, archived agent retries and experiment pauses. Cache read/write are subsets of normalized input. Missing usage is unknown, never zero cost.",
    )
    evidence_path = PAPER / "build/generated/resource_usage_evidence.json"
    evidence_path.parent.mkdir(parents=True, exist_ok=True)
    evidence_path.write_text(json.dumps(evidence, indent=2) + "\n")
    for row in rows:
        print(
            row["task"],
            row["model"],
            row["interface"],
            {
                k: round(v, 3)
                for k, v in row["mean"].items()
                if k
                in [
                    "mean_seconds",
                    "usd",
                    "input_tokens",
                    "output_tokens",
                    "unpriced_calls",
                    "serial_hours",
                ]
            },
        )


if __name__ == "__main__":
    main()
