"""Plot correction F1 against API resources and traditional references.

Frozen per-run evidence uses all 1,000 tables, including recorded retries and
reused development requests. Traditional CPU estimates are explicitly marked;
Constraint runtimes use matching local-job logs. No new inference is performed.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from figure_style import (
    COLUMN_WIDTH,
    MODEL_COLORS,
    TWO_PANEL_HEIGHT,
    TWO_PANEL_MARGINS,
    configure,
    save,
)
from matplotlib.lines import Line2D

if __package__:
    from .tex_sources import generated_asset
else:
    from tex_sources import generated_asset

PAPER = Path(__file__).resolve().parents[1]
GENERATED = PAPER / "assets/generated"
MODELS = ("GPT-4.1", "GPT-5.2", "GPT-5.5", "GPT-6-astra")
INPUTS = (
    "figure9_e2e_runs.csv",
    "llm_resources_table.tex",
    "e2e_table_point.csv",
    "price_quality_traditional.csv",
)


def write_csv(path, rows):
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def freeze_runtime(path):
    """Bind each recovered quality/cost run to its original per-table time."""
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    table = (generated_asset("llm_resources_table.tex", directory=GENERATED)).read_text()
    sources = json.loads(
        next(
            line.removeprefix("% Source SHA-256: ")
            for line in table.splitlines()
            if line.startswith("% Source SHA-256: ")
        )
    )
    assert sources["build/generated/resource_usage_evidence.json"] == digest
    evidence = json.loads(path.read_text())
    resources = {
        r["model"]: r
        for r in evidence["rows"]
        if r["task"] == "Detection/repair" and r["interface"] == "API Tuned"
    }
    quality_path = GENERATED / "figure9_runs.csv"
    with quality_path.open(newline="") as handle:
        quality = [r for r in csv.DictReader(handle) if r["task"] == "e2e"]
    assert len(quality) == 12
    rows = []
    for r in quality:
        model = r["model"].replace("gpt", "GPT")
        rep = int(r["repetition"])
        assert int(r["tables_scored"]) == int(r["tables_expected"]) == 1000
        assert int(r["original_repetition_id"]) == rep
        resource = resources[model]["repetitions"][rep - 1]
        assert resource["tables"] == 1000
        assert math.isclose(resource["usd"], float(r["recorded_cost_usd"]), rel_tol=1e-12)
        assert resource["sdk_invocations"] == int(r["priced_calls"]) + int(r["unpriced_calls"])
        rows.append(
            dict(
                task="e2e",
                model=model,
                repetition=rep,
                run_id=r["run_id"],
                configuration_id=r["configuration_id"],
                prompt_sha256=r["prompt_sha256"],
                tables_per_run=1000,
                f1_percent=float(r["f1_percent"]),
                recorded_cost_usd=float(r["recorded_cost_usd"]),
                mean_seconds_per_table=resource["mean_seconds"],
                unpriced_calls=int(r["unpriced_calls"]),
                quality_source="assets/generated/figure9_runs.csv",
                quality_source_sha256=hashlib.sha256(quality_path.read_bytes()).hexdigest(),
                runtime_source="build/generated/resource_usage_evidence.json",
                runtime_source_sha256=digest,
            )
        )
    write_csv(GENERATED / INPUTS[0], rows)


def collect():
    with (GENERATED / INPUTS[0]).open(newline="") as handle:
        runs = list(csv.DictReader(handle))
    assert len(runs) == 12 and {r["task"] for r in runs} == {"e2e"}
    assert len({(r["model"], r["repetition"]) for r in runs}) == 12
    with (GENERATED / INPUTS[2]).open(newline="") as handle:
        repair = {
            r["method"].removesuffix(" (Prompt-tuned)"): float(r["f1"])
            for r in csv.DictReader(handle)
            if r["task"] == "e2e"
            and r["category"] == "Direct LLMs (API)"
            and r["method"].endswith(" (Prompt-tuned)")
        }
    summaries = {}
    for line in generated_asset(INPUTS[1], directory=GENERATED).read_text().splitlines():
        if line.startswith(MODELS) and " & API Prompt-tuned & " in line:
            r = [part.strip() for part in line.removesuffix(r" \\").split(" & ")]
            summaries[r[0]] = r
    assert set(summaries) == set(MODELS)
    rows = []
    for model in MODELS:
        group = [r for r in runs if r["model"] == model]
        assert {r["repetition"] for r in group} == {"1", "2", "3"}
        assert all(r["tables_per_run"] == "1000" for r in group)
        mean = lambda key: statistics.mean(float(r[key]) for r in group)
        quality, cost, runtime = (
            mean(k) for k in ("f1_percent", "recorded_cost_usd", "mean_seconds_per_table")
        )
        summary = summaries[model]
        assert abs(quality - repair[model]) < 0.006
        assert abs(quality - float(summary[3])) < 0.006
        assert abs(cost - float(summary[7])) < 0.006
        assert abs(runtime - float(summary[5])) < 0.051
        rows.append(
            dict(
                task="e2e",
                model=model,
                f1_percent=quality,
                recorded_cost_usd=cost,
                mean_seconds_per_table=runtime,
                tables_per_run=1000,
                mean_unpriced_calls=mean("unpriced_calls"),
                repetitions=3,
            )
        )
    return rows


def collect_traditional():
    with (GENERATED / INPUTS[3]).open(newline="") as stream:
        rows = list(csv.DictReader(stream))
    with (GENERATED / INPUTS[2]).open(newline="") as stream:
        quality = {r["method"]: r for r in csv.DictReader(stream) if r["task"] == "e2e"}
    config = json.loads((PAPER / "figures/traditional_resource_estimates.json").read_text())
    assert [r["model"] for r in rows] == config["methods"]
    for r in rows:
        assert r["task"] == "e2e" and r["tables_per_run"] == "1000"
        assert int(r["repetitions"]) == int(quality[r["model"]]["repetitions"])
        assert r["recorded_cost_usd"] == "", "CPU estimates must not become measured charges"
        for key in (
            "f1_percent",
            "estimated_cost_usd",
            "mean_seconds_per_table",
            "cpu_worker_usd_per_hour",
        ):
            r[key] = float(r[key])
            assert math.isfinite(r[key]), (r["model"], key)
            assert (0 <= r[key] <= 100) if key == "f1_percent" else r[key] > 0, (r["model"], key)
        assert abs(r["f1_percent"] - float(quality[r["model"]]["f1"])) < 1e-10
        assert r["cpu_worker_usd_per_hour"] == config["cpu_worker_usd_per_hour"]
        assert math.isclose(
            r["estimated_cost_usd"],
            r["mean_seconds_per_table"] * 1000 / 3600 * r["cpu_worker_usd_per_hour"],
        )
        if int(r["repetitions"]) == 3:
            assert r["timing_kind"] in {
                "recorded_native_batch_elapsed",
                "recorded_repeated_local_job_elapsed",
            }
            assert r["timing_tables_recorded"] == "3000"
            assert 0 <= int(r["failed_jobs_included"]) <= 3000
        elif r["model"] in config["local_job_timing"]:
            timing = config["local_job_timing"][r["model"]]
            assert r["timing_kind"] == "recorded_local_job_elapsed"
            assert r["timing_tables_recorded"] == "1000"
            assert int(r["failed_jobs_included"]) == timing["expected_failed_jobs"]
            assert r["configuration"] == timing["configurations"][-1]
        else:
            assert r["timing_kind"] == "estimated_from_historical_cpu_notes"
            assert r["timing_tables_recorded"] == "0"
    return rows


def write_claims(rows, traditional):
    astra = next(row for row in rows if row["model"] == "GPT-6-astra")
    ratio = astra["recorded_cost_usd"] / max(row["estimated_cost_usd"] for row in traditional)
    rounded = round(ratio, 1 - math.floor(math.log10(ratio)))
    target = PAPER / "resource_comparison_claims.tex"
    target.write_text(f"\\newcommand{{\\CBTraditionalCostRatio}}{{{rounded:,.0f}}}\n")
    return target


def draw(rows, traditional, *, axes=None, panel_labels=("a", "b")):
    configure(font_size=8)
    standalone = axes is None
    if standalone:
        fig, axes = plt.subplots(2, 1, figsize=(COLUMN_WIDTH, TWO_PANEL_HEIGHT + 0.3), sharey=True)
        fig.subplots_adjust(**{**TWO_PANEL_MARGINS, "bottom": 0.24})
    for ax, metric, title, xlabel, offsets in zip(
        axes,
        ("recorded_cost_usd", "mean_seconds_per_table"),
        (
            f"({panel_labels[0]}) End-to-end F1 vs. cost",
            f"({panel_labels[1]}) End-to-end F1 vs. runtime",
        ),
        ("Cost per 1,000 tables (USD; log scale)", "Mean time per table (s; log scale)"),
        (((-6, 3), (-6, -6), (-6, 2), (-6, 5)), ((-6, 4), (6, 6), (-6, 2), (-6, 5))),
        strict=True,
    ):
        for row, color, marker, offset in zip(
            rows, MODEL_COLORS, ("o", "s", "^", "D"), offsets, strict=True
        ):
            x, y = row[metric], row["f1_percent"]
            ax.scatter(
                x, y, s=39, marker=marker, color=color, edgecolors="white", linewidths=0.7, zorder=3
            )
            ax.annotate(
                row["model"],
                (x, y),
                xytext=offset,
                textcoords="offset points",
                ha="right" if offset[0] < 0 else "left",
                va="center",
                color="#253342",
            )
        for row, marker, offset in zip(
            traditional,
            ("o", "s", "^", "D"),
            ((6, 10), (-6, 26), (6, 3), (14, 29))
            if metric == "recorded_cost_usd"
            else ((6, 10), (-25, 3), (8, 5), (-30, 20)),
            strict=True,
        ):
            estimated = metric == "recorded_cost_usd" or row["timing_kind"].startswith("estimated")
            x = row["estimated_cost_usd"] if metric == "recorded_cost_usd" else row[metric]
            y = row["f1_percent"]
            ax.scatter(
                x,
                y,
                s=20 if row["model"] == "BigDansing" else 30,
                marker=marker,
                facecolors="white" if estimated else "#626f7c",
                edgecolors="#626f7c",
                linewidths=1,
                zorder=4,
            )
            if not standalone:
                ax.annotate(
                    row["model"],
                    (x, y),
                    xytext=offset,
                    textcoords="offset points",
                    ha="right" if offset[0] < 0 else "left",
                    va="center",
                    color="#495663",
                    arrowprops={"arrowstyle": "-", "color": "#99a3ad", "lw": 0.55},
                )
        ax.set_title(title, loc="left", pad=8)
        ax.set_xlabel(xlabel)
        ax.set_xscale("log")
        ax.set_ylim(-5, 85)
        ax.set_yticks((0, 20, 40, 60, 80))
        ax.grid(linewidth=0.45, alpha=0.8, zorder=0)
    axes[0].set_ylabel("End-to-end F1 (%)")
    axes[1].set_ylabel("End-to-end F1 (%)")
    axes[0].set_xlim(0.00005, 100)
    axes[0].set_xticks((0.0001, 0.01, 1, 100))
    axes[1].set_xlim(0.003, 70)
    axes[1].set_xticks((0.01, 0.1, 1, 10))
    if not standalone:
        return
    fig.legend(
        handles=[
            Line2D(
                [],
                [],
                linestyle="none",
                marker="o",
                markerfacecolor="#626f7c",
                markeredgecolor="#626f7c",
                label="Recorded",
            ),
            Line2D(
                [],
                [],
                linestyle="none",
                marker="o",
                markerfacecolor="white",
                markeredgecolor="#626f7c",
                label="Estimated",
            ),
        ],
        loc="upper center",
        bbox_to_anchor=(0.58, 1),
        ncol=2,
        fontsize=7,
        frameon=False,
        handletextpad=0.35,
        columnspacing=1.4,
    )
    fig.legend(
        [axes[0].collections[len(rows) + i] for i in range(len(traditional))],
        [r["model"] for r in traditional],
        loc="lower center",
        bbox_to_anchor=(0.5, 0.005),
        ncol=4,
        fontsize=7,
        frameon=False,
        handlelength=0.8,
        handletextpad=0.3,
        columnspacing=0.7,
    )
    save(
        fig,
        GENERATED / "price_quality.pdf",
        width=COLUMN_WIDTH,
        font_size=8,
        legend_font_size=7,
        check_layout=True,
    )
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--resource-evidence",
        type=Path,
        help="Optionally refresh frozen per-run time from the audited original resource evidence",
    )
    args = parser.parse_args()
    if args.resource_evidence:
        freeze_runtime(args.resource_evidence)
    hashes = {
        name: hashlib.sha256((generated_asset(name, directory=GENERATED)).read_bytes()).hexdigest()
        for name in INPUTS
    }
    rows = collect()
    traditional = collect_traditional()
    write_claims(rows, traditional)
    draw(rows, traditional)
    write_csv(GENERATED / "price_quality.csv", rows)
    assert hashes == {
        name: hashlib.sha256((generated_asset(name, directory=GENERATED)).read_bytes()).hexdigest()
        for name in INPUTS
    }
    folder = PAPER / "build/price_quality"
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "evidence.json").write_text(
        json.dumps(
            {
                "source_sha256": hashes,
                "rows": rows,
                "traditional_rows": traditional,
                "traditional_config_sha256": hashlib.sha256(
                    (PAPER / "figures/traditional_resource_estimates.json").read_bytes()
                ).hexdigest(),
                "policy": "End-to-end quality uses the same run cohorts as Table 3. API resources use their recorded three-run evidence. Completed fresh traditional triples use matching native timing logs or local-job receipts, including failures. Methods without a new triple use the original matching references. CPU costs are estimates at the configured worker rate; recorded_cost_usd remains empty for CPU methods. Filled runtime markers indicate recorded durations; open markers indicate estimates.",
            },
            indent=2,
        )
        + "\n"
    )
    print(
        "Rendered four paired API points and four traditional references; estimates marked explicitly."
    )


if __name__ == "__main__":
    main()
