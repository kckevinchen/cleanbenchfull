"""Score benchmark-label type slices with shared clean-cell negatives, offline.

Other-type positive targets are excluded from each slice. A wrong replacement
at a target belongs to that target's annotated types. Untyped clean-cell false
positives remain in every slice. Overall scores are unchanged; Inconsistency merges historical types by cell union.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import statistics
import sys
from collections import defaultdict
from pathlib import Path

from build_error_types import IDENTITY
from build_table_strata import Evidence
from build_task_type_tables import SHORT, collect
from build_unified_task_tables import ARMS, MODELS
from paper_taxonomy import DISPLAY_TYPES, project_sets

PAPER = Path(__file__).resolve().parents[1]
REPO = PAPER.parent


def focused_metrics(correct, attempted, targets_by_type, background_fp):
    """Evaluate each annotated positive subset against the common negatives."""
    assert correct <= attempted and background_fp >= 0
    result = {}
    for kind, targets in targets_by_type.items():
        tp = len(correct & targets)
        wrong = len((attempted - correct) & targets)
        fp = background_fp + wrong
        fn = len(targets) - tp
        result[kind] = dict(
            tp=tp,
            fp=fp,
            fn=fn,
            shared_background_fp=background_fp,
            wrong_at_type=wrong,
            precision=tp / (tp + fp) if tp + fp else 0,
            recall=tp / len(targets) if targets else 0,
        )
    return result


def main():
    original, union_sources, union_runs = collect(include_runs=True)
    union_runs = {key: iter(value) for key, value in union_runs.items()}
    evidence = Evidence()
    evidence.hashes.update(union_sources)
    read = evidence.read
    sys.path.insert(0, str(REPO))
    from external.rein.score_repair import _extract_value
    from src.evaluation.paper_evaluation.analysis import GroundTruth

    config_path = REPO / "outputs/prompt_tuning/dev200_none_20260930_continuation/config.json"
    config = read(config_path)
    datasets = Path(config["datasets"])
    truth = GroundTruth(datasets, read(datasets / "_manifest.json"))
    for filename in ("benchmark_cell.json", "neutral_cells.jsonl", "ignored.jsonl"):
        p = datasets / filename
        if p.exists():
            evidence.hashes[str(p.relative_to(REPO))] = hashlib.sha256(p.read_bytes()).hexdigest()
    for dataset in truth.ids:
        p = datasets / dataset / "gt_cells.jsonl"
        evidence.hashes[str(p.relative_to(REPO))] = hashlib.sha256(p.read_bytes()).hexdigest()
    types = project_sets(truth.fine)
    targets = {k: types[k] & truth.eligible for k, _ in DISPLAY_TYPES}
    runs = []

    def jsonl(path, expected=None):
        path = Path(path)
        if not path.is_absolute():
            path = REPO / path
        blob = path.read_bytes()
        digest = hashlib.sha256(blob).hexdigest()
        if expected is not None:
            assert digest == expected, path
        evidence.hashes[str(path.relative_to(REPO))] = digest
        return [json.loads(line) for line in blob.splitlines() if line.strip()]

    def add_detection(method, overall, fine):
        frozen_overall, coarse = next(union_runs["detection", method])
        assert frozen_overall == overall
        metrics = {}
        for kind, _ in DISPLAY_TYPES:
            tp, fp, total = coarse[kind]["hit"], overall["fp"], coarse[kind]["gt"]
            assert total == len(types[kind])
            metrics[kind] = dict(
                tp=tp,
                fp=fp,
                fn=total - tp,
                shared_background_fp=fp,
                wrong_at_type=0,
                precision=tp / (tp + fp) if tp + fp else 0,
                recall=tp / total,
            )
        runs.append(dict(task="detection", method=method, metrics=metrics))

    def add_repair(method, records, overall, fine):
        keys = [(r["dataset"], int(r["row"]), int(r["col"])) for r in records]
        assert len(keys) == len(set(keys))
        scored = {}
        for key, row in zip(keys, records, strict=True):
            assert key[0] in truth.tables
            table = truth.tables[key[0]]
            assert 0 <= key[1] < table["rows"] and 0 <= key[2] < table["columns"]
            if truth.immune(key) or key in truth.ambiguous or key in truth.errors - truth.eligible:
                continue
            value = _extract_value(row)
            if isinstance(value, str):
                scored[key] = value
        attempted = set(scored)
        correct = {c for c, v in scored.items() if c in truth.eligible and v in truth.accepted[c]}
        assert [len(correct), len(attempted - correct), len(truth.eligible - correct)] == [
            overall[k] for k in ("tp", "fp", "fn")
        ], method
        background = len(attempted - truth.eligible)
        metric = focused_metrics(correct, attempted, targets, background)
        frozen_overall, coarse = next(union_runs["e2e", method])
        assert frozen_overall == overall
        for kind, _ in DISPLAY_TYPES:
            assert metric[kind]["tp"] == coarse[kind]["hit"]
            assert metric[kind]["tp"] + metric[kind]["fn"] == coarse[kind]["gt"]
        runs.append(dict(task="e2e", method=method, metrics=metric))

    folder = REPO / "outputs/paper_evaluation/20260920"
    selection = read(folder / "presentation_selection.json")
    selected = read(folder / "selected_results.json", selection["source_manifest_sha256"])
    candidates = selected["rows"][:]
    for name in ("excel_public", "cleanagent_repaired"):
        candidates.extend(read(folder / name / "selected_results.json")["rows"])
    for task in ("e2e", "detection"):
        for entry in selection["main"][task]:
            matches = [r for r in candidates if all(r.get(k) == entry.get(k) for k in IDENTITY)]
            assert len(matches) == 1
            row = matches[0]
            method = SHORT.get(row["method"], row["method"])
            if task == "detection":
                add_detection(method, entry["metrics"], row["analysis"]["per_type"])
            else:
                records = [
                    r
                    for r in jsonl(row["prediction_path"], row["prediction_sha256"])
                    if r["detector"] == row["configuration"]
                ]
                add_repair(method, records, entry["metrics"], row["analysis"]["per_type"])
    print("Historical type-slice counts audited.", flush=True)

    api = read(PAPER / "build/generated/llm_baseline_evidence.json")
    paths = api["source_sha256"]
    dpath = next(p for p in paths if p.endswith("final_report/RESULTS.json"))
    rpath = next(p for p in paths if p.endswith("e2e_scores.json"))
    detection = read(dpath, paths[dpath])
    repair = read(rpath, paths[rpath])
    api_records = defaultdict(list)
    for record in jsonl((REPO / rpath).parent / "valued_predictions.jsonl"):
        api_records[record["detector"]].append(record)
    for rep in detection["repetitions"]:
        for model in MODELS:
            for arm, label in ARMS:
                method = f"{model.replace('gpt', 'GPT')} ({label})"
                m = next(r for r in rep["comparison"] if r["name"] == f"compare_{model}_{arm}")
                add_detection(method, m, m["per_type_recall"])
                key = f"rep_{rep['repetition']:02d}/{model}/{arm}"
                m = repair["results"][key]
                add_repair(method, api_records[key], m, m["per_type_recall_fine"])
    agents = read(PAPER / "build/generated/coding_agent_evidence.json")
    for row in agents["rows"]:
        m = row["metrics"]
        add_detection(f"{row['model']} ({row['harness']})", m, m["per_type_recall_fine"])
    agents = read(PAPER / "build/generated/coding_agent_repair_evidence.json")
    agent_records = defaultdict(list)
    from build_coding_agents import END_TO_END_PREDICTIONS

    path = REPO / END_TO_END_PREDICTIONS
    for record in jsonl(path, agents["source_sha256"][str(path.relative_to(REPO))]):
        agent_records[record["detector"]].append(record)
    for row in agents["rows"]:
        m = row["metrics"]
        add_repair(
            f"{row['model']} ({row['harness']})",
            agent_records[row["arm"]],
            m,
            m["per_type_recall_fine"],
        )

    grouped = defaultdict(list)
    for run in runs:
        grouped[run["task"], run["method"]].append(run["metrics"])
    rows = []
    assert len(grouped) == len(original) == 58
    for old in original:
        trials = grouped[old["task"], old["method"]]
        assert len(trials) == old["repetitions"]
        for kind, _ in DISPLAY_TYPES:
            values = [t[kind] for t in trials]
            mean = lambda key: statistics.mean(v[key] for v in values)
            assert math.isclose(100 * mean("recall"), old[f"recall_{kind}"])
            rows.append(
                dict(
                    task=old["task"],
                    method=old["method"],
                    error_type=kind,
                    repetitions=len(trials),
                    precision=100 * mean("precision"),
                    recall=100 * mean("recall"),
                    mean_tp=mean("tp"),
                    mean_fp=mean("fp"),
                    mean_fn=mean("fn"),
                    shared_background_fp=mean("shared_background_fp"),
                    mean_wrong_at_type=mean("wrong_at_type"),
                    reported=True,
                )
            )
    assert all(next(runs, None) is None for runs in union_runs.values())
    path = PAPER / "assets/generated/task_type_precision.csv"
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    (PAPER / "build/generated/type_precision_evidence.json").write_text(
        json.dumps(
            dict(
                source_sha256=evidence.hashes,
                builder_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                policy=__doc__,
                runs=runs,
            ),
            indent=2,
        )
        + "\n"
    )
    print(
        "Audited all 58 task/method entries; coordinate-union type recall and unchanged overall scores verified."
    )


if __name__ == "__main__":
    main()
