import csv
import json

import build_price_quality as quality
import pytest
from build_traditional_resources import ROOT, repeated_resource_row


def test_three_native_batch_timings_replace_historical_estimates():
    trials = [
        dict(
            method="SymSpell",
            run=i,
            identity=str(ROOT / "dummy/symspell" / f"run_{i:02d}"),
            receipt_sha256="receipt",
            metrics={"f1": i},
        )
        for i in (1, 2, 3)
    ]

    def read(path, expected):
        assert expected == "receipt"
        return dict(status="complete", tables=1000, output_sha256={"native.log": "log"})

    def raw(path, expected):
        assert expected == "log"
        i = int(path.parent.name[-2:])
        return f"  symspell: 4 cells flagged in {i*10}.0s\n".encode()

    row, timings = repeated_resource_row("SymSpell", trials, 0.1, read, raw)
    assert row["repetitions"] == 3 and row["timing_tables_recorded"] == 3000
    assert row["mean_seconds_per_table"] == pytest.approx(0.02)
    assert row["estimated_cost_usd"] == pytest.approx(20 / 3600 * 0.1)
    assert row["f1_percent"] == 2
    assert row["recorded_cost_usd"] == ""
    assert [t["seconds"] for t in timings] == [10, 20, 30]
    trials[1]["identity"] = trials[0]["identity"]
    with pytest.raises(ValueError, match="independent"):
        repeated_resource_row("SymSpell", trials, 0.1, read, raw)


@pytest.fixture
def resource_csvs(tmp_path, monkeypatch):
    generated = tmp_path / "assets/generated"
    generated.mkdir(parents=True)
    (tmp_path / "figures").mkdir()
    methods = ["SymSpell", "NeuSpell", "NADEEF", "BigDansing"]
    (tmp_path / "figures/traditional_resource_estimates.json").write_text(
        json.dumps({"methods": methods, "cpu_worker_usd_per_hour": 0.1, "local_job_timing": {}})
    )
    point, resources = [], []
    for method in methods:
        point.append(dict(task="e2e", method=method, repetitions=3, f1=0))
        resources.append(
            dict(
                task="e2e",
                model=method,
                repetitions=3,
                f1_percent=0,
                recorded_cost_usd="",
                estimated_cost_usd=1000 / 3600 * 0.1,
                mean_seconds_per_table=1,
                tables_per_run=1000,
                timing_kind="recorded_native_batch_elapsed"
                if method in {"SymSpell", "NeuSpell"}
                else "recorded_repeated_local_job_elapsed",
                timing_tables_recorded=3000,
                failed_jobs_included=0,
                cpu_worker_usd_per_hour=0.1,
            )
        )

    def save(name, rows):
        with (generated / name).open("w", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)

    save("e2e_table_point.csv", point)
    save("price_quality_traditional.csv", resources)
    monkeypatch.setattr(quality, "PAPER", tmp_path)
    monkeypatch.setattr(quality, "GENERATED", generated)
    return save, point, resources


def test_resource_plot_accepts_measured_zero_f1_without_dropping_methods(resource_csvs):
    rows = quality.collect_traditional()
    assert len(rows) == 4
    assert all(row["f1_percent"] == 0 for row in rows)


def test_resource_plot_requires_the_same_quality_run_cohort(resource_csvs):
    save, point, _ = resource_csvs
    point[0]["repetitions"] = 1
    save("e2e_table_point.csv", point)
    with pytest.raises(AssertionError):
        quality.collect_traditional()


def test_resource_cost_comparison_uses_the_largest_cpu_estimate(tmp_path, monkeypatch):
    monkeypatch.setattr(quality, "PAPER", tmp_path)
    output = quality.write_claims(
        [dict(model="GPT-6-astra", recorded_cost_usd=47.7)],
        [dict(estimated_cost_usd=value) for value in (0.0001, 0.105, 0.03)],
    )
    assert "{450}" in output.read_text()
