"""Recompute full-version end-to-end results with consistency improvement.

Reads saved predictions only; never modifies the source benchmark or runs.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import importlib.util
import json
import statistics
from collections import defaultdict
from pathlib import Path

from build_defined_macro_results import run_scores
from build_diagnostic_task_tables import draw as draw_macro
from build_e2e_variance_table import METRICS
from build_e2e_variance_table import draw as draw_micro
from build_experiment_comparisons import METHODS, variation_figure
from build_failure_requirement_pies import adjudicate, aggregate
from build_failure_requirement_pies import draw as draw_failures
from build_resource_overview import draw_split, read_scaling
from consistency_scoring import components, score_tables

PAPER = Path(__file__).resolve().parents[1]
GENERATED = PAPER / "assets/generated"


def read_csv(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def grouped_scores(runs, reference, scoring):
    source, exact = [], []
    for method, *_ in METHODS:
        local_runs = runs[method]
        for dimension in ("source", "columns", "rows"):
            grouped = defaultdict(list)
            for tables in local_runs:
                buckets = defaultdict(dict)
                for name, row in tables.items():
                    table = reference["tables"][name]
                    bucket = (
                        (
                            "Relational"
                            if table["source_path"].startswith("pbi_500/")
                            else "Spreadsheet"
                        )
                        if dimension == "source"
                        else table[dimension]
                    )
                    buckets[bucket][name] = row
                for bucket, counts in buckets.items():
                    values, totals = scoring.metrics(counts)
                    grouped[bucket].append((values, totals))
            for bucket, values in grouped.items():
                totals = values[0][1]
                assert all(row[1]["targets"] == totals["targets"] for row in values)
                row = {
                    "task": "e2e",
                    "method": method,
                    "dimension": dimension,
                    "tables": totals["tables"],
                    "targets": totals["targets"],
                    "f1": statistics.mean(row[0]["f1"] for row in values),
                }
                if dimension == "source":
                    source.append({**row, "bucket": bucket, "source_filter": "All"})
                else:
                    defined = any(row[1]["tp"] + row[1]["fp"] + row[1]["fn"] for row in values)
                    exact.append({**row, "size": bucket, "f1_defined": str(defined)})
    return source, exact


def resource_rows(name, scores):
    rows = read_csv(GENERATED / name)
    for row in rows:
        method = row["model"]
        if method not in scores:
            method += " (Prompt-tuned)"
        row["f1_percent"] = scores[method]["f1"]
        for key in ("recorded_cost_usd", "estimated_cost_usd", "mean_seconds_per_table"):
            if key in row:
                row[key] = float(row[key]) if row[key] else None
    return rows


def failure_diagnostic(source, grouped):
    """Reuse reviewed categories only for individual-cell failures outside components."""
    config = json.loads((source / "figures/failure_requirements.json").read_text())
    spec = config["llm_source"]
    inventory = source / config["inventory"]
    assert (
        hashlib.sha256(inventory.read_bytes()).hexdigest()
        == config["source_sha256"][config["inventory"]]
    )
    review = json.loads((source / spec["author_adjudication"]).read_text())
    raw = source / spec["local_review"]
    assert hashlib.sha256(raw.read_bytes()).hexdigest() == review["base_review_sha256"]
    judgments = {r["group_id"]: r for r in adjudicate(read_csv(raw), review)}
    groups = {}
    with gzip.open(inventory, "rt") as stream:
        for line in stream:
            row = json.loads(line)
            if row["method"] != config["method"]:
                continue
            key = (
                row["outcome"],
                row["dataset"],
                row["col"],
                row["original"],
                row["proposed"],
                tuple(row["accepted"]),
            )
            if key not in groups:
                groups[key] = dict(row, group_id=f"G{len(groups)+1:03d}", occurrences=[])
            groups[key]["occurrences"].append((row["run"], row["dataset"], row["row"], row["col"]))
    selected = []
    for group in groups.values():
        judgment = judgments[group["group_id"]]
        assert all(judgment[k] == group[k] for k in ("dataset", "column", "original", "outcome"))
        group["analysis_category"] = judgment["primary_category"]
        group["occurrences"] = [e for e in group["occurrences"] if tuple(e[1:]) not in grouped]
        if group["occurrences"]:
            selected.append(group)
    rows = [r for r in aggregate(selected, config, deduplicate=True) if r["run"] == "pooled"]
    write_csv(GENERATED / "failure_requirements_consistency.csv", rows)
    draw_failures(rows, config, output=PAPER / "figures/paper/failure_requirements_consistency.pdf")
    return {
        str(path.relative_to(source)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in (inventory, raw, source / spec["author_adjudication"])
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--group-reference", type=Path, required=True)
    parser.add_argument(
        "--diagnostic-source",
        type=Path,
        required=True,
        help="Paper checkout containing private diagnostic review files",
    )
    args = parser.parse_args()
    root = args.artifacts.resolve()
    spec = importlib.util.spec_from_file_location(
        "frozen_table3", root.parent.parent / "src/reproducibility/table3.py"
    )
    scoring = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scoring)
    manifest = scoring.verify(root)
    reference = scoring.read(root / "reference.json")
    groups = scoring.read(args.group_reference)["groups"]
    targets = {(r["dataset"], r["row"], r["col"]): set(r["accepted"]) for r in reference["targets"]}
    types = {k: set(map(tuple, v)) for k, v in reference["types"].items()}
    joint = components(groups, targets)
    grouped = {c for g in joint for c in g["original"]}
    denominator = len(targets.keys() - grouped) + sum(g["d0"] for g in joint)
    assert (len(targets), len(grouped), len(joint), denominator) == (1093, 331, 40, 1178)
    runs = defaultdict(list)
    run_evidence, macro_evidence = [], []
    templates = {r["method"]: r for r in read_csv(GENERATED / "e2e_table_point.csv")}
    for run in manifest["runs"]:
        if not run["point_view"]:
            continue
        predictions = list(scoring.records(root / run["predictions"]))
        execution = scoring.read(root / run["metadata"])["execution"]
        old = scoring.score_run(predictions, reference, execution)
        saved = {
            r["dataset"]: {k: v for k, v in r.items() if k != "dataset"}
            for r in scoring.records(root / run["counts"])
        }
        assert old == saved, run["identity"]
        tables = score_tables(old, predictions, targets, types, joint)
        values, totals = scoring.metrics(tables)
        assert len(tables) == 1000 and totals["targets"] == denominator
        assert totals["fp_clean"] == sum(r["fp_clean"] for r in old.values())
        runs[run["method"]].append(tables)
        macro, sizes = run_scores(list(tables.values()))
        assert all(v is not None for v in macro.values())
        macro_evidence.append(dict(identity=run["identity"], scores=macro, defined_tables=sizes))
        run_evidence.append(
            dict(identity=run["identity"], method=run["method"], **totals, **values)
        )
    point, variance, macro = [], [], []
    for entry in manifest["methods"]:
        method = entry["method"]
        local = runs[method]
        measured = [scoring.metrics(t)[0] for t in local]
        row = dict(templates[method], repetitions=len(local))
        row.update({k: statistics.mean(s[k] for s in measured) for k in METRICS})
        point.append(row)
        variance.append(
            dict(
                row,
                variance_requested=len(local) > 1,
                **{
                    "sd_" + k: statistics.stdev(s[k] for s in measured) if len(local) > 1 else None
                    for k in METRICS
                },
            )
        )
        macro_runs = [run_scores(list(t.values()))[0] for t in local]
        macro.append(
            dict(row, **{k: statistics.mean(r[k] for r in macro_runs) for k in macro_runs[0]})
        )
    write_csv(GENERATED / "e2e_consistency_point.csv", point)
    write_csv(GENERATED / "e2e_consistency_variability.csv", variance)
    write_csv(GENERATED / "e2e_consistency_macro.csv", macro)
    write_csv(GENERATED / "e2e_consistency_runs.csv", run_evidence)
    draw_micro(variance, output=PAPER / "figures/paper/e2e_consistency.pdf")
    draw_macro(
        macro,
        "macro_e2e",
        overall_label="Overall macro (%)",
        output=PAPER / "figures/paper/macro_consistency.pdf",
    )
    source, exact = grouped_scores(runs, reference, scoring)
    write_csv(GENERATED / "source_consistency.csv", source)
    write_csv(GENERATED / "size_consistency.csv", exact)
    variation_figure(
        source,
        exact,
        targets=denominator,
        output=PAPER / "figures/paper/source_size_consistency.pdf",
    )
    scores = {r["method"]: r for r in point}
    quality = resource_rows("price_quality.csv", scores)
    traditional = resource_rows("price_quality_traditional.csv", scores)
    write_csv(GENERATED / "price_quality_consistency.csv", quality)
    write_csv(GENERATED / "price_quality_traditional_consistency.csv", traditional)
    draw_split(
        read_scaling(),
        quality,
        traditional,
        figures=("resource_tradeoff",),
        output_suffix="_consistency",
    )
    selected = [
        ("BigDansing", "BigDansing"),
        ("NADEEF", "NADEEF"),
        ("GPT-6-astra (Prompt-tuned)", "GPT-6-Astra"),
        ("GPT-6-astra (Codex)", "GPT-6-Astra (Codex)"),
        ("GPT-6-astra (Copilot)", "GPT-6-Astra (Copilot)"),
    ]
    lines, outcomes = [], []
    for method, label in selected:
        rows = [r for r in run_evidence if r["method"] == method]
        values = [statistics.mean(r[k] for r in rows) for k in ("tp", "fp_clean", "fn")]
        values.append(statistics.mean(r["fp"] - r["fp_clean"] for r in rows))
        lines.append(label + " & " + " & ".join(f"{v:,.1f}" for v in values) + r" \\")
        outcomes.append(
            dict(method=method, tp=values[0], fp_clean=values[1], fn=values[2], fp_error=values[3])
        )
    (PAPER / "failure_outcomes_consistency.tex").write_text(
        r"\newcommand{\CBConsistencyOutcomeRows}{%" + "\n" + "\n".join(lines) + "\n}\n"
    )
    write_csv(GENERATED / "failure_outcomes_consistency.csv", outcomes)
    diagnostic_hashes = failure_diagnostic(args.diagnostic_source, grouped)
    evidence = dict(
        diagnostic_source_sha256=diagnostic_hashes,
        artifact_manifest_sha256=hashlib.sha256((root / "manifest.json").read_bytes()).hexdigest(),
        group_reference_sha256=hashlib.sha256(args.group_reference.read_bytes()).hexdigest(),
        labeled_errors=1409,
        self_compatible_cells=316,
        groups=len(groups),
        components=len(joint),
        group_cells=len(grouped),
        overlapping_targets=len(grouped & targets.keys()),
        independent_cell_targets=len(targets.keys() - grouped),
        initial_distance=sum(g["d0"] for g in joint),
        denominator=denominator,
        methods=len(point),
        runs=sum(map(len, runs.values())),
        type_recall="Accepted-value cell matching for spelling and formatting; distance reduction for inconsistency components. Multi-labelled cells can appear in multiple type summaries; overall counts use each cell once.",
        macro=macro_evidence,
    )
    (GENERATED / "consistency_results.json").write_text(json.dumps(evidence, indent=2) + "\n")
    print("Recomputed", evidence["runs"], "runs;", denominator, "repair requirements.")


if __name__ == "__main__":
    main()
