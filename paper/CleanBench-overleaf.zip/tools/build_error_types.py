"""Apply the paper's coarse error types to frozen labels and result displays.

Run from the parent research harness after the historical reporting generators.
No labels, predictions, aggregate scores, or experiment selections are changed.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from collections import defaultdict
from pathlib import Path
from statistics import mean

if __package__:
    from .tex_sources import generated_asset
else:
    from tex_sources import generated_asset

if __package__:
    from .figure_style import FIGURE_WIDTH, configure, save
    from .paper_taxonomy import DISPLAY_TYPES, project_run, project_sets, read_predictions
else:
    from figure_style import FIGURE_WIDTH, configure, save
    from paper_taxonomy import DISPLAY_TYPES, project_run, project_sets, read_predictions

SEMANTIC = "semantic_incompatible"
NUMERIC = "numeric_outlier"
IDENTITY = ("method", "configuration", "task", "matching", "prediction_sha256")


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def merge_counts(semantic, numeric):
    """Combine disjoint target sets by counts, before averaging repetitions."""
    for row in (semantic, numeric):
        assert 0 <= row["hit"] <= row["gt"]
        assert math.isclose(row["recall"], row["hit"] / row["gt"] if row["gt"] else 0)
    hit = semantic["hit"] + numeric["hit"]
    support = semantic["gt"] + numeric["gt"]
    return {"hit": hit, "gt": support, "recall": hit / support if support else 0}


def select_rows(folder, selected, presentation):
    """Recover the exact displayed runs, including archived replacement rows."""
    candidates = list(selected["rows"])
    for name in ("excel_public", "cleanagent_repaired"):
        candidates.extend(read(folder / name / "selected_results.json")["rows"])
    rows = []
    for entry in presentation["main"]["e2e"]:
        matches = [
            row for row in candidates if all(row.get(key) == entry.get(key) for key in IDENTITY)
        ]
        assert len(matches) == 1, "Missing or duplicate displayed run"
        row = matches[0]
        assert row["analysis"]["full"] == entry["metrics"], "Aggregate scores changed"
        rows.append(row)
    return rows


def draw(rows, categories, target):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np

    grouped = defaultdict(list)
    for row in rows:
        grouped[row["method"]].append(row)
    methods = [m for group in categories.values() for m in group if m in grouped]
    short = {
        "Excel Clean Data": "Excel",
        "KATARA (KB component)": "KATARA (KB)",
        "Google Sheets Cleanup": "Google Sheets",
    }
    configure()
    values = []
    for method in methods:
        values.append(
            [
                100 * mean(row["analysis"]["per_type"][kind]["recall"] for row in grouped[method])
                for kind, _ in DISPLAY_TYPES
            ]
        )
    source_values = [
        [
            100 * mean(row["analysis"]["subsets"][s]["f1"] for row in grouped[m])
            for s in ("BI", "Web")
        ]
        for m in methods
    ]
    supports = [rows[0]["analysis"]["per_type"][kind]["gt"] for kind, _ in DISPLAY_TYPES]
    for row in rows:
        assert [row["analysis"]["per_type"][kind]["gt"] for kind, _ in DISPLAY_TYPES] == supports
    fig, axes = plt.subplots(
        1, 2, figsize=(FIGURE_WIDTH, 3.6), sharey=True, gridspec_kw={"width_ratios": [4, 2]}
    )
    for ax, matrix, ticks, title in [
        (
            axes[0],
            values,
            [f"{label}\n(n={n})" for (_, label), n in zip(DISPLAY_TYPES, supports, strict=True)],
            "Correction recall by error type (%)",
        ),
        (axes[1], source_values, ["Relational", "Spreadsheet"], "End-to-end F1 (%)"),
    ]:
        ax.imshow(matrix, vmin=0, vmax=100, cmap="Blues", aspect="auto")
        ax.set_xticks(range(len(ticks)), ticks)
        ax.set_title(title)
        for i, row in enumerate(matrix):
            for j, value in enumerate(row):
                ax.text(
                    j,
                    i,
                    f"{value:.1f}",
                    ha="center",
                    va="center",
                    color="white" if value > 55 else "black",
                )
    axes[0].set_yticks(np.arange(len(methods)), [short.get(m, m) for m in methods])
    fig.subplots_adjust(left=0.205, right=0.99, bottom=0.14, top=0.93, wspace=0.10)
    save(fig, target)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=Path("outputs/paper_evaluation/20260920"))
    parser.add_argument(
        "--snapshot", type=Path, default=Path("outputs/baseline_campaign/20260910/snapshot")
    )
    args = parser.parse_args()
    paper = Path(__file__).resolve().parents[1]
    selected_path = args.results / "selected_results.json"
    presentation_path = args.results / "presentation_selection.json"
    selected, presentation = read(selected_path), read(presentation_path)
    assert sha(selected_path) == presentation["source_manifest_sha256"]
    manifest_path = args.snapshot / "_manifest.json"
    label_path = args.snapshot / "benchmark_cell.json"
    for path in (
        manifest_path,
        label_path,
        args.snapshot / "neutral_cells.jsonl",
        args.snapshot / "ignored.jsonl",
    ):
        assert sha(path) == selected["source_proofs"][str(path)]
    manifest = read(manifest_path)
    sources = {
        v["source"]: selected["table_manifest"][k]["source"]
        for k, v in manifest["datasets"].items()
    }
    labels = [json.loads(line) for line in label_path.read_text().splitlines() if line.strip()]
    fine = defaultdict(set)
    for row in labels:
        if row["status"] == "error":
            for kind in row["error_types"]:
                fine[kind].add((row["source"], row["row"], row["column"]))
    original_supports = {kind: len(cells) for kind, cells in fine.items()}
    overlap = len(fine["inconsistency"] & (fine[SEMANTIC] | fine[NUMERIC]))
    fine = project_sets(fine)
    rows = select_rows(args.results, selected, presentation)
    sys.path.insert(0, str(paper.parent))
    from src.evaluation.paper_evaluation.analysis import GroundTruth

    truth = GroundTruth(args.snapshot, manifest)
    merged = []
    prediction_proofs = {}
    for row in rows:
        path = Path(row["prediction_path"])
        if not path.is_absolute():
            path = paper.parent / path
        assert sha(path) == row["prediction_sha256"]
        prediction_proofs[str(path)] = sha(path)
        per_type = project_run(
            row["analysis"]["per_type"],
            read_predictions(path, row["configuration"]),
            truth,
            "e2e",
        )
        row["analysis"]["per_type"] = per_type
        merged.append(
            {
                "method": row["method"],
                "configuration": row["configuration"],
                "replicate": row.get("replicate"),
                **per_type["inconsistency"],
            }
        )
    table = [
        r"\begin{tabular}{lrrr}",
        r"\toprule",
        r"Error type & \relationaldata{} & \spreadsheetdata{} & Total \\",
        r"\midrule",
    ]
    counts = {}
    for kind, label in DISPLAY_TYPES:
        cells = fine[kind]
        counts[kind] = {s: sum(sources[c[0]] == s for c in cells) for s in ("BI", "Web")}
        table.append(
            " & ".join([label, str(counts[kind]["BI"]), str(counts[kind]["Web"]), str(len(cells))])
            + r" \\"
        )
    table.extend([r"\bottomrule", r"\end{tabular}"])
    generated = paper / "assets/generated"
    # These are historical search routes, not mutually exclusive paper types.
    coverage = generated_asset("construction_coverage_table.tex", directory=generated)
    route_names = {
        "Inconsistency": "Representation grouping",
        "Incompatibility": "Semantic-domain check",
        "Semantic incompatibility": "Semantic-domain check",
    }
    coverage_lines = []
    for line in coverage.read_text().splitlines():
        label, separator, rest = line.partition(" & ")
        coverage_lines.append(route_names.get(label, label) + separator + rest)
    coverage.write_text("\n".join(coverage_lines) + "\n")
    (generated_asset("corpus_types.tex", directory=generated)).write_text("\n".join(table) + "\n")
    draw(rows, presentation["categories"], generated / "type_source_diagnostics.pdf")
    evidence = {
        "mapping": {SEMANTIC: "inconsistency", NUMERIC: "inconsistency"},
        "historical_type_overlap": overlap,
        "builder_sha256": sha(Path(__file__)),
        "taxonomy_builder_sha256": sha(paper / "tools/paper_taxonomy.py"),
        "prediction_sha256": prediction_proofs,
        "original_supports": original_supports,
        "merged_counts": counts,
        "merged_repair_runs": merged,
        "aggregate_scores_and_selection_unchanged": True,
        "source_sha256": {
            str(p): sha(p)
            for p in (
                selected_path,
                presentation_path,
                manifest_path,
                label_path,
                args.results / "excel_public/selected_results.json",
                args.results / "cleanagent_repaired/selected_results.json",
            )
        },
    }
    evidence_dir = paper / "build/generated"
    evidence_dir.mkdir(parents=True, exist_ok=True)
    (evidence_dir / "semantic_type_evidence.json").write_text(json.dumps(evidence, indent=2) + "\n")
    # Broader tasks retain their independently frozen row-pair/witness scores.
    # Their current assets must not be overwritten with an older snapshot.
    print("Updated three cell types using coordinate unions; overall scores unchanged.")


if __name__ == "__main__":
    main()
