"""Shared figure typography at the ACM manuscript's final printed width."""

from __future__ import annotations

import os
import re
from pathlib import Path

FONT_SIZE = 8
# Match paired single-column plots without reducing text after rendering.
TWO_PANEL_HEIGHT = 2.9
TWO_PANEL_MARGINS = dict(left=0.19, right=0.975, bottom=0.17, top=0.79, hspace=1.06)
# sigconf: US Letter minus two 54 TeX-point margins; Matplotlib uses inches.
FIGURE_WIDTH = 8.5 - 108 / 72.27
# acmart sigconf separates its two columns by 24 TeX points.
COLUMN_WIDTH = (FIGURE_WIDTH - 24 / 72.27) / 2
FONT_FAMILY = "Linux Libertine"
PRIMARY_COLOR = "#1767c6"
SOURCE_COLORS = {"Relational": PRIMARY_COLOR, "Spreadsheet": "#b65378"}
MODEL_COLORS = ["#8b949e", "#b65378", "#57a2ad", PRIMARY_COLOR]
WORKFLOW_COLORS = {
    "Direct LLMs (API)": PRIMARY_COLOR,
    "Coding agents": "#b65378",
    "Other workflows": "#a7afb9",
}
# Strong structural emphasis; error and accepted-repair colors remain semantic.
EXAMPLE_PALETTE = {
    "ink": "#263442",
    "muted": "#626f7c",
    "arrow": "#6a7887",
    "new": PRIMARY_COLOR,
    "focus": PRIMARY_COLOR,
    "focus_fill": "#edf4ff",
    "header": "#f1f4f7",
    "frame": "#778796",
    "grid": "#d2d9e0",
    "error": "#f4d4cb",
    "error_accent": "#ad4135",
    "error_edit": "#df8e7e",
    "repair": "#b4dccc",
    "repair_ink": "#174e40",
    "repair_edit": "#69b79b",
}


def paired_pies(
    fig,
    groups,
    *,
    sources,
    categories,
    colors,
    text_colors,
    title,
    small_sector_pctdistance=None,
):
    """Draw a fixed-size paired pie block at the top of a single-column figure."""
    from matplotlib.patches import Patch

    height = fig.get_figheight()
    assert len(groups) == len(sources) == 2
    assert len(categories) == len(colors) == len(text_colors)
    fig.text(0.5, 1 - 0.03 / height, title, ha="center", va="top", weight="bold")
    sector_labels = []
    for i, (source, values) in enumerate(zip(sources, groups, strict=True)):
        assert len(values) == len(categories) and min(values) > 0
        ax = fig.add_axes([0.015 + i * 0.51, 1 - 1.22 / height, 0.465, 0.95 / height])
        wedges, _, labels = ax.pie(
            values,
            colors=colors,
            startangle=90,
            counterclock=False,
            radius=1,
            autopct="%.1f",
            pctdistance=0.72,
            wedgeprops=dict(edgecolor="white", linewidth=1),
            textprops=dict(fontsize=FONT_SIZE, fontstyle="normal", fontweight="normal"),
        )
        assert abs(sum(w.theta2 - w.theta1 for w in wedges) - 360) < 0.001
        for label, value, color in zip(labels, values, text_colors, strict=True):
            assert label.get_text() == f"{100 * value / sum(values):.1f}"
            label.set_color(color)
            if small_sector_pctdistance is not None and value / sum(values) < 0.12:
                x, y = label.get_position()
                factor = small_sector_pctdistance / 0.72
                label.set_position((factor * x, factor * y))
        sector_labels.extend(zip(wedges, labels, strict=True))
        fig.text(
            0.2475 + i * 0.51,
            1 - 0.155 / height,
            f"({'ab'[i]}) {source}",
            ha="center",
            va="top",
            weight="bold",
        )
        ax.set_xlim(-1.1, 1.1)
        ax.set_ylim(-1.1, 1.1)
        ax.axis("off")
    fig.legend(
        [Patch(facecolor=c) for c in colors],
        categories,
        loc="upper center",
        bbox_to_anchor=(0.5, 1 - 1.19 / height),
        ncol=len(categories),
        frameon=False,
        handlelength=1,
        handletextpad=0.4,
        columnspacing=0.9,
    )
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    for sector, label in sector_labels:
        bounds = label.get_window_extent(renderer).expanded(1.03, 1.03)
        corners = (
            (bounds.x0, bounds.y0),
            (bounds.x0, bounds.y1),
            (bounds.x1, bounds.y0),
            (bounds.x1, bounds.y1),
        )
        shape = sector.get_path().transformed(sector.get_transform())
        assert all(shape.contains_points(corners)), label.get_text()


def configure(*, font_size=FONT_SIZE):
    import matplotlib as mpl
    from matplotlib import font_manager

    directory = Path(
        os.environ.get("CLEANBENCH_FONT_DIR", Path(__file__).resolve().parents[1] / "build/fonts")
    )
    # TrueType Libertine embeds correctly in Matplotlib's Type 42 PDF output.
    for path in directory.glob("LinLibertine_R*.ttf"):
        font_manager.fontManager.addfont(path)
    # Fail explicitly instead of silently substituting a different figure font.
    font_manager.findfont(FONT_FAMILY, fallback_to_default=False)
    mpl.rcParams.update(
        {
            "font.family": FONT_FAMILY,
            "font.size": font_size,
            "axes.labelsize": font_size,
            "axes.titlesize": font_size,
            "axes.titleweight": "bold",
            "xtick.labelsize": font_size,
            "ytick.labelsize": font_size,
            "legend.fontsize": font_size,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.edgecolor": "#7b8691",
            "axes.linewidth": 0.6,
            "xtick.major.width": 0.6,
            "ytick.major.width": 0.6,
            "xtick.minor.visible": False,
            "ytick.minor.visible": False,
            "grid.color": "#e6eaf0",
            "grid.linewidth": 0.4,
        }
    )


def validate_layout(fig):
    """Check visible glyph bounds, including labels in adjacent panels."""
    from matplotlib.text import Text

    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    objects = []

    def add(text):
        if text.get_visible() and text.get_text().strip() and text not in objects:
            objects.append(text)

    for text in fig.texts:
        add(text)
    for legend in fig.legends:
        for text in legend.get_texts():
            add(text)
    for ax in fig.axes:
        for text in (
            ax.title,
            ax._left_title,
            ax._right_title,
            ax.xaxis.label,
            ax.yaxis.label,
            *ax.texts,
        ):
            add(text)
        if not ax.axison:
            continue
        for axis in (ax.xaxis, ax.yaxis):
            lo, hi = sorted(axis.get_view_interval())
            for tick in axis.get_major_ticks():
                # Log locators can create labels outside the displayed range.
                if lo - 1e-9 <= tick.get_loc() <= hi + 1e-9:
                    add(tick.label1)
                    add(tick.label2)
    bounds = [Text.get_window_extent(text, renderer) for text in objects]
    for index, (text, box) in enumerate(zip(objects, bounds, strict=True)):
        assert fig.bbox.contains(box.x0, box.y0) and fig.bbox.contains(box.x1, box.y1), (
            "Clipped figure text",
            text.get_text(),
        )
        for other, other_box in zip(objects[index + 1 :], bounds[index + 1 :], strict=True):
            assert not box.overlaps(other_box), (
                "Overlapping figure text",
                text.get_text(),
                other.get_text(),
            )
    return {
        "visible_texts": len(objects),
        "font_sizes_bp": sorted({t.get_fontsize() for t in objects}),
    }


def model_label(text):
    """Use the manuscript model spelling without changing experiment identifiers."""
    return re.sub(r"\bastra\b", "Astra", text, flags=re.IGNORECASE)


def save(
    fig,
    target,
    *,
    width=FIGURE_WIDTH,
    font_size=FONT_SIZE,
    legend_font_size=None,
    check_layout=False,
):
    """Keep the intended print-width canvas and its shared-size text."""
    from matplotlib.text import Text

    # Tick formatters regenerate their text during save; normalize their labels too.
    for ax in fig.axes:
        if not ax.axison:
            continue
        for axis in (ax.xaxis, ax.yaxis):
            labels = [tick.get_text() for tick in axis.get_ticklabels()]
            if any(model_label(label) != label for label in labels):
                axis.set_ticklabels([model_label(label) for label in labels])
    for text in fig.findobj(Text):
        text.set_text(model_label(text.get_text()))
        text.set_fontfamily(FONT_FAMILY)
        text.set_fontsize(font_size)
    if legend_font_size is not None:
        for legend in fig.legends:
            for text in legend.get_texts():
                text.set_fontsize(legend_font_size)
    assert width in (FIGURE_WIDTH, COLUMN_WIDTH)
    assert abs(fig.get_figwidth() - width) < 1e-6
    if check_layout:
        validate_layout(fig)
    fig.savefig(target, metadata={"CreationDate": None, "ModDate": None})
    preview = target.with_suffix(".png")
    paper = Path(__file__).resolve().parents[1]
    if target.parent == paper / "figures/paper":
        # Keep manuscript PDFs separate from disposable raster previews.
        preview = paper / "build/figure_previews" / preview.name
    preview.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(preview, dpi=300)
