"""Combine the published scaling and correction-resource plots without rescoring."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from build_llm_scaling import draw as draw_scaling
from build_price_quality import collect, collect_traditional, write_claims
from build_price_quality import draw as draw_quality
from figure_style import COLUMN_WIDTH, FIGURE_WIDTH, configure, save
from matplotlib.lines import Line2D

if __package__:
    from .tex_sources import generated_asset
else:
    from tex_sources import generated_asset

PAPER = Path(__file__).resolve().parents[1]
GENERATED = PAPER / "assets/generated"


def read_scaling():
    with (GENERATED / "llm_scaling.csv").open(newline="") as stream:
        rows = list(csv.DictReader(stream))
    assert len(rows) == 40
    for row in rows:
        row["rows"] = int(row["rows"])
        row["plotted"] = row["plotted"] == "True"
        for key in ("median_seconds", "mean_public_price_usd"):
            row[key] = float(row[key]) if row[key] else None
        if row["plotted"]:
            assert row["median_seconds"] > 0 and row["mean_public_price_usd"] > 0
    return rows


def draw_split(
    scaling,
    quality,
    traditional,
    *,
    figures=("resource_scaling", "resource_tradeoff"),
    output_suffix="",
):
    """Separate input-size sensitivity from the accuracy/resource tradeoff."""
    configure()
    outputs = []
    for name in figures:
        if name == "resource_scaling":
            fig = plt.figure(figsize=(COLUMN_WIDTH, 2.05))
            axes = [fig.add_axes([left, 0.30, 0.35, 0.43]) for left in (0.13, 0.63)]
            draw_scaling(scaling, axes=axes, panel_labels=("a", "b"))
            for ax in axes:
                ax.set_title(ax._left_title.get_text(), loc="left", pad=4)
                ax.set_xlabel("Rows per table\n(log scale)", labelpad=2)
                ax.yaxis.labelpad = 2
                ax.tick_params(axis="both", pad=2)
                for tick, label in zip(ax.get_xticks(), ax.get_xticklabels(), strict=True):
                    if tick == 500:
                        label.set_ha("right")
                    elif tick == 1000:
                        label.set_ha("left")
            handles, labels = axes[0].get_legend_handles_labels()
            fig.legend(
                handles,
                [label.replace("GPT-6 Astra", "GPT-6-astra") for label in labels],
                loc="upper center",
                bbox_to_anchor=(0.5, 1 - 9 / (72 * fig.get_figheight())),
                ncol=4,
                fontsize=7,
                frameon=False,
                handlelength=0.9,
                columnspacing=0.6,
                handletextpad=0.3,
            )
        else:
            fig = plt.figure(figsize=(COLUMN_WIDTH, 1.95))
            axes = [fig.add_axes([left, 0.40, 0.35, 0.44]) for left in (0.13, 0.63)]
            draw_quality(quality, traditional, axes=axes, panel_labels=("a", "b"))
            # Use a shared method legend instead of crowding the narrow panels.
            for ax in axes:
                for label in list(ax.texts):
                    label.remove()
                ax.set_title(
                    ax.get_title(loc="left").replace(" F1 vs.", "\nF1 vs."),
                    loc="left",
                    pad=4,
                )
                ax.xaxis.labelpad = 2
                ax.yaxis.labelpad = 2
                ax.tick_params(axis="both", pad=2)
            axes[0].set_xlabel("Cost per 1,000 tables\n(USD; log scale)")
            axes[1].set_xlabel("Mean time per table\n(s; log scale)")
            handles, labels = [], []
            for index, (api, baseline) in enumerate(zip(quality, traditional, strict=True)):
                handles.extend(
                    (axes[0].collections[index], axes[0].collections[index + len(quality)])
                )
                labels.extend((api["model"], baseline["model"]))
            fig.legend(
                handles,
                labels,
                loc="lower center",
                bbox_to_anchor=(0.5, 2 / (72 * fig.get_figheight())),
                ncol=4,
                fontsize=7,
                frameon=False,
                handlelength=0.7,
                handletextpad=0.3,
                columnspacing=0.55,
                labelspacing=0.25,
                markerscale=0.85,
                borderpad=0,
                borderaxespad=0,
            )
        target = PAPER / "figures/paper" / f"{name}{output_suffix}.pdf"
        save(
            fig,
            target,
            width=COLUMN_WIDTH,
            legend_font_size=7,
            check_layout=True,
        )
        plt.close(fig)
        outputs.append(target.name)
    return outputs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--split-only",
        action="store_true",
        help="Render the two separate figures; preserve the old combined PDF.",
    )
    args = parser.parse_args()
    inputs = (
        "llm_scaling.csv",
        "price_quality.csv",
        "price_quality_traditional.csv",
        "figure9_e2e_runs.csv",
        "llm_resources_table.tex",
        "e2e_table_point.csv",
    )
    hashes = {
        name: hashlib.sha256((generated_asset(name, directory=GENERATED)).read_bytes()).hexdigest()
        for name in inputs
    }
    scaling = read_scaling()
    quality, traditional = collect(), collect_traditional()
    write_claims(quality, traditional)
    with (GENERATED / "price_quality.csv").open(newline="") as stream:
        frozen_quality = list(csv.DictReader(stream))
    for actual, frozen in zip(quality, frozen_quality, strict=True):
        assert actual["model"] == frozen["model"]
        for key in ("f1_percent", "recorded_cost_usd", "mean_seconds_per_table"):
            assert math.isclose(actual[key], float(frozen[key]), rel_tol=1e-12)

    split_outputs = draw_split(scaling, quality, traditional)
    if args.split_only:
        assert hashes == {
            name: hashlib.sha256(
                (generated_asset(name, directory=GENERATED)).read_bytes()
            ).hexdigest()
            for name in inputs
        }
        folder = PAPER / "build/resource_split"
        folder.mkdir(exist_ok=True, parents=True)
        (folder / "evidence.json").write_text(
            json.dumps(
                {
                    "input_sha256": hashes,
                    "outputs": split_outputs,
                    "scaling_points": len(scaling),
                    "api_quality_points": len(quality),
                    "traditional_points": len(traditional),
                    "scores_unchanged": True,
                },
                indent=2,
            )
            + "\n"
        )
        print(
            "Separated input-size sensitivity and correction-resource tradeoffs; all scores unchanged."
        )
        return

    configure()
    fig, axes = plt.subplots(2, 2, figsize=(FIGURE_WIDTH, 3.25))
    fig.subplots_adjust(left=0.08, right=0.98, bottom=0.14, top=0.81, wspace=0.38, hspace=1.18)
    draw_scaling(scaling, axes=axes[0], panel_labels=("a", "b"))
    draw_quality(quality, traditional, axes=axes[1], panel_labels=("c", "d"))
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(
        handles,
        [label.replace("GPT-6 Astra", "GPT-6-astra") for label in labels],
        loc="upper center",
        bbox_to_anchor=(0.31, 1),
        ncol=4,
        frameon=False,
        handlelength=1.7,
        columnspacing=1.0,
        handletextpad=0.4,
    )
    fig.legend(
        handles=[
            Line2D([], [], linestyle="none", marker="o", color="#626f7c", label="Recorded"),
            Line2D(
                [],
                [],
                linestyle="none",
                marker="o",
                color="#626f7c",
                markerfacecolor="white",
                label="Estimated",
            ),
        ],
        loc="upper center",
        bbox_to_anchor=(0.82, 1),
        ncol=2,
        frameon=False,
        handletextpad=0.35,
        columnspacing=1.0,
    )
    save(fig, GENERATED / "resource_overview.pdf", width=FIGURE_WIDTH, check_layout=True)
    plt.close(fig)
    assert hashes == {
        name: hashlib.sha256((generated_asset(name, directory=GENERATED)).read_bytes()).hexdigest()
        for name in inputs
    }
    folder = PAPER / "build/resource_overview"
    folder.mkdir(exist_ok=True, parents=True)
    (folder / "evidence.json").write_text(
        json.dumps(
            {
                "input_sha256": hashes,
                "scaling_points": len(scaling),
                "api_quality_points": len(quality),
                "traditional_points": len(traditional),
                "scores_unchanged": True,
            },
            indent=2,
        )
        + "\n"
    )
    print("Combined 40 scaling aggregates and seven quality/resource points; all scores unchanged.")


if __name__ == "__main__":
    main()
