"""No-edit comparisons must have a completed execution and exact saved values."""

import pytest
from build_astra_error_analysis_options import verify_phone_sources, verify_relation
from build_failure_examples import verify_comparison
from build_failure_type_examples import comparison_text


def test_failed_output_cannot_be_presented_as_no_edit():
    with pytest.raises(AssertionError, match="execution failure"):
        verify_comparison(None, None, "failed")
    with pytest.raises(AssertionError, match="execution failure"):
        verify_comparison(None, None, "unknown")


def test_empty_string_repair_is_distinct_from_no_edit():
    verify_comparison(None, None, "complete")
    verify_comparison("", "", "complete")
    with pytest.raises(AssertionError):
        verify_comparison("", None, "complete")
    with pytest.raises(AssertionError):
        verify_comparison("Jolly", "Jolie", "complete")


def test_no_edit_card_preserves_the_source_reference_difference():
    case = dict(original="Frankie Pesto", proposed=None, reference="Frankie Presto")
    value, markup = comparison_text(case, "astra")
    assert value == "No edit" and 'class="no-edit"' in markup
    value, markup = comparison_text(case, "reference")
    assert value == "Frankie Presto" and '<b class="good">Presto</b>' in markup
    case["proposed"] = ""
    assert comparison_text(case, "astra") == ("", "")


def test_published_phone_evidence_checks_digits_and_selected_failure():
    verification = dict(
        scope="published_number",
        sources=[
            dict(
                published_number=value,
                url="https://example.org/directory",
                snapshot_sha256="a" * 64,
            )
            for value in ("021 0876 0866", "+64 210 876 086 6")
        ],
    )
    verify_phone_sources("+64 210 876 086 6", "+64 21 087 6086", verification)
    with pytest.raises(AssertionError, match="final-digit loss"):
        verify_phone_sources("+64 210 876 086 6", "+64 21 087 60866", verification)
    verification["sources"][0]["published_number"] = "021 0876 0865"
    with pytest.raises(AssertionError, match="Published number differs"):
        verify_phone_sources("+64 210 876 086 6", "+64 21 087 6086", verification)


def test_composite_key_claim_requires_source_relationship_and_a_broken_proposal():
    check = dict(kind="composite_key", target="Key", components=["Division", "Year"], separator="-")
    table = [dict(Division="Adult", Year="2012", Key="Adult-2012")]
    group = dict(row=0, column="Key", original="Adult-2012", proposed="Adult - 2012")
    assert "all 1 benchmark rows" in verify_relation(check, group, table)
    group["proposed"] = "Adult-2012"
    with pytest.raises(AssertionError):
        verify_relation(check, group, table)
    group["proposed"] = "Adult - 2012"
    table[0]["Year"] = "2013"
    with pytest.raises(AssertionError, match="Source key violates"):
        verify_relation(check, group, table)


def test_composite_key_audit_applies_all_edits_in_the_same_run():
    check = dict(kind="composite_key", target="Key", components=["Part", "Year"], separator="-")
    table = [dict(Part="Adult", Year="2012", Key="Adult-2012")]
    group = dict(
        dataset="example",
        row=0,
        col=2,
        column="Key",
        original="Adult-2012",
        proposed="Adult -2012",
        occurrences=[[1, "example", 0, 2], [2, "example", 0, 2]],
    )
    predictions = {
        (1, "example", 0, 0): "Adult ",
        (1, "example", 0, 2): "Adult -2012",
        (2, "example", 0, 2): "Adult -2012",
    }
    fact = verify_relation(
        check, group, table, predictions=predictions, headers=["Part", "Year", "Key"]
    )
    assert "Run 1: Part becomes 'Adult '; the recorded output preserves the composition." in fact
    assert (
        "Run 2: the component fields are unchanged; the recorded output breaks the composition."
        in fact
    )
    assert "do not establish a violation" in verify_relation(check, group, table)


def test_chronology_claim_requires_reference_inside_the_actual_period():
    check = dict(
        kind="date_within_period", start="Start", end="End", pay="Pay", date_format="%m/%d/%Y"
    )
    table = [dict(Start="12/30/2018", End="1/12/2019", Pay="1/18/2019")]
    group = dict(row=0, original="1/11/1919", accepted=["1/11/2019"])
    assert "before pay date 1/18/2019" in verify_relation(check, group, table)
    group["accepted"] = ["1/19/2019"]
    with pytest.raises(AssertionError, match="Date relationship is not supported"):
        verify_relation(check, group, table)


def test_isolated_phone_group_claim_checks_every_numeric_peer():
    table = [
        {"Mobile": "+64 210 876 086 6"},
        {"Mobile": "+64 21 278 2497"},
        {"Mobile": "+64 21 029 14247"},
        {"Mobile": "Not Applicable"},
    ]
    group = dict(row=0, column="Mobile", original=table[0]["Mobile"])
    assert "2 other numeric entries" in verify_relation(
        dict(kind="phone_terminal_groups"), group, table
    )
    table[1]["Mobile"] = "+64 21 278 249 7"
    with pytest.raises(AssertionError, match="Another phone"):
        verify_relation(dict(kind="phone_terminal_groups"), group, table)
