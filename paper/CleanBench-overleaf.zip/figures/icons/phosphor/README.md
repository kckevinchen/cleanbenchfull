# Duotone icons in the CleanBench workflow

This is the historical symbol collection. Figure 2 now uses the Microsoft
Fluent Color sources in `../fluent/`; the sources and license below are preserved.
To reproduce this older collection, pass `--collection phosphor` to the renderer.

Seven unmodified SVG sources come from [Phosphor Icons](https://github.com/phosphor-icons/core),
pinned to commit `2b75f3ad12b420c9504ef05df8d2564a28f8500e`.
`SOURCE.json` records primary download URLs, SHA-256 hashes, and rendering
settings. The complete upstream [MIT license](LICENSE) accompanies them.

| Local asset | Upstream duotone icon | Figure role | Printed size |
|---|---|---|---:|
| `database` | `database` | Relational source | 24 bp |
| `table` | `table` | Spreadsheet source | 24 bp |
| `brain` | `brain` | LLM discovery | 18 bp |
| `user-check` | `user-check` | Human verification | 18 bp |
| `files-check` | `files` | Reviewed benchmark | 32 bp |
| `list-checks` | `list-checks` | Quality check of sampled tables | 18 bp |
| `chart-bar` | `chart-bar` | Evaluation | 10 bp |

The renderer preserves upstream path geometry and its native duotone weight.
It replaces the secondary layer's opacity with an opaque light fill and uses
a coordinated darker foreground. Source icons use slate blue and teal;
discovery, review, and benchmark icons follow their blue, ochre, and green
panels. Audit and evaluation use blue gray.

The `files-check` derivative adds a white front-sheet backing and an original
circular check badge to the upstream document stack. These additions are
implemented in `tools/build_workflow_icons.py`; the vendored SVG remains
byte-identical to the upstream `files-duotone.svg`.

Regenerate offline after installing CairoSVG:

```bash
python -m pip install CairoSVG
python tools/build_workflow_icons.py --collection phosphor
```

Use `--icon list-checks` to regenerate only the review icon; the script still
verifies all original SVG hashes and the license.

The script verifies the SVG and license hashes and creates transparent,
vector-only PDF 1.5 assets under `figures/icons/generated/`. The figure uses
their native printed sizes. The PDFs contain no text, icon fonts, or bitmap
images; figure labels remain separate 9 bp Linux Libertine. Compilation needs
only the committed PDFs, with no SVG converter, network, or shell escape.
The Overleaf exporter includes the PDFs, original SVGs, manifest, and license.
