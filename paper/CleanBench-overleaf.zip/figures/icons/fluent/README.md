# Microsoft Fluent Color icons for Figure 2

These seven unmodified SVGs come from Microsoft's professionally designed
[Fluent UI System Icons](https://github.com/microsoft/fluentui-system-icons).
`SOURCE.json` pins the upstream commit, original download URLs, source hashes,
printed sizes, and rendered PDF hashes. The upstream MIT `LICENSE` and `NOTICE`
are included. Original contours, gradients, colors, and opacity are preserved.

| Stable figure key | Microsoft icon | Printed size |
|---|---|---:|
| `database` | Database | 24 bp |
| `table` | Table | 24 bp |
| `brain` | Bot Sparkle | 24 bp |
| `user-check` | Person Feedback | 24 bp |
| `files-check` | Book Database | 36 bp |
| `list-checks` | Clipboard Task | 20 bp |
| `chart-bar` | Data Bar Vertical Ascending | 12 bp |

Stable asset keys avoid changing the figure's layout. The model icon represents
LLM discovery, the person and speech bubble represent human adjudication, and
the book and database represent the reviewed dataset. The last two icons mark
the sampled quality check and evaluation. Figure labels remain separate native
TikZ text at 9 bp Linux Libertine.

Regenerate offline with CairoSVG and Cairo installed:

```bash
python tools/build_workflow_icons.py
```

Use `--icon brain` for one asset. The renderer validates source hashes and local
gradient references before producing transparent vector-only PDF 1.5 files.
The historical collections remain selectable with `--collection cleanbench` or
`--collection phosphor`; rerun the default command to restore Fluent afterward.
LaTeX uses only the committed PDFs, requiring no network access or converter.
The Overleaf exporter includes the SVGs, provenance, license, and active PDFs.
