# CleanBench workflow illustrations

This is the earlier custom collection. Figure 2 now uses the Microsoft Fluent
Color sources in `../fluent/`. Pass `--collection cleanbench` to reproduce the
custom collection, then rerun the renderer without options to restore Fluent.

Seven original vector illustrations replace the earlier Phosphor symbols in
Figure 2. They share a 64-unit grid, rounded strokes, opaque secondary fills,
and the manuscript's blue, teal, ochre, green, and slate palette. The artwork
contains no third-party paths, embedded fonts, labels, or raster images.
Historical Phosphor sources and their license remain in the adjacent directory.

| Asset key | Illustration | Printed size |
|---|---|---:|
| `database` | Database with a schema card | 24 bp |
| `table` | Workbook with selected cells | 24 bp |
| `brain` | Model assistant with an idea spark | 24 bp |
| `user-check` | Reviewer with an annotation board | 24 bp |
| `files-check` | Curated table cards with a verification seal | 36 bp |
| `list-checks` | Sampled-label clipboard and magnifier | 20 bp |
| `chart-bar` | Performance bars and comparison arrow | 12 bp |

Asset keys remain stable for LaTeX; `brain` now depicts a model assistant.
Source hashes, dimensions, and rendered hashes are recorded in `SOURCE.json`.
All labels remain separate 9 bp Linux Libertine text in the native TikZ figure.

Regenerate offline with CairoSVG and Cairo installed:

```bash
python tools/build_workflow_icons.py --collection cleanbench
```

Use `--collection cleanbench --icon brain` to regenerate one custom illustration.
All collection choices replace the active output files. The default collection
is now `fluent`. Compilation needs only the committed PDF 1.5 assets. The Overleaf
package includes all source collections and the active PDFs.
