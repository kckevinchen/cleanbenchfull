# Manuscript figures

Table 3 and the table-level macro results use consistency improvement. The
1,409 error annotations yield 1,178 repair requirements. In the full-version
repository, run `python scripts/reproduce_table3.py` to rescore 59 saved outputs.
The manuscript uses `e2e_consistency.pdf` and `macro_consistency.pdf`.

Appendix F uses the same scorer. Run `python scripts/reproduce_constraints.py`
in the full-version repository to verify all 147 method/input runs. Its
`thresholds.csv` and `comparison.csv` correspond to the two
`assets/generated/constraint_score_consistency_*.csv` files in the manuscript.
Run `python tools/build_constraint_score_analysis.py` to rebuild the heatmap
and tables. Violation coverage counts distinct annotated cells.

- `paper/`: PDF figures selected for the manuscript and appendix. LaTeX and
  their generators use these paths directly; filenames remain stable when
  figure numbers change.
- `*.json`: figure configurations, selected examples, and provenance.
- `icons/`: vector icon sources, licenses, and active PDFs in `icons/generated/`.
- `workbench/` and `evidence/`: source screenshots and evidence images.

Figure environments and native TikZ code are maintained directly in the root
author files. Figure 2 is declared in `main.tex` before Related Work so the
two-column overview can appear at the top of page 4. There are no author TeX
sources in this directory.
`main.tex` includes only the root `preamble.tex` and chapter files;
`appendix.tex` is the standalone supporting appendix. Keep all author `.tex`
files in the project root. Obsolete manuscript backups remain in Git history.

Frozen CSVs remain in `assets/generated/`. Tables and numeric macros used by the
paper are in the root author TeX files. Historical generated TeX inputs are
preserved with hashes in `assets/generated/tex_snapshots.zip`; offline builders
stage them and write proposed replacements to ignored `build/generated/tex/`.
Candidate example galleries and alternative figures also remain there until
selected for the paper. Temporary render previews belong in ignored `build/`;
Matplotlib previews of `paper/` PDFs go to `build/figure_previews/`.

The full-version Section 4 position heatmap uses `error_position.json` and
`assets/generated/error_position.csv`. Redraw with
`python tools/build_error_position.py`; add `--refresh` to recompute from the
frozen Section 4 snapshot. Cell centers determine the five row and column
intervals. Each region reports distinct errors per 1,000 eligible cells;
ambiguous and immune cells are excluded. Aggregate summaries are in
`assets/generated/error_position_summary.json`, and input hashes remain in
ignored `build/generated/error_position_provenance.json`.

The size-filtered comparison uses `figures/error_position_min5.json` and
retains only tables with at least five rows and five columns. Generate it with
`python tools/build_error_position.py --config figures/error_position_min5.json`;
add `--refresh` to recompute its separate counts and source verification.
The PDF, aggregate CSV, and summary are stored under
`assets/generated/error_position_min5*`; the manuscript uses this filtered
figure in Section 4. Both errors and cell
denominators are counted within the selected cohort, with the original cell
positions and immunity rules preserved.

The full-version detection-only and repair-only result tables reuse the
end-to-end table's visual style. Redraw them with
`python tools/build_diagnostic_task_tables.py`. The repair table uses
`assets/generated/repair_type_metrics.csv`. To regenerate it from repair-only
predictions, add `--refresh-repair --full-repo /path/to/cleanbenchfull`.
This applies the Table 3 consistency-improvement scorer to the supplied locations.
Use `python tools/build_diagnostic_task_tables.py --macro-only` to render the
full-version table-level end-to-end comparison from `macro_metrics.csv` and
`empty_match_type_metrics.csv`. It retains Table 3's roster and layout and
averages per-table scores over all 1,000 tables, including those without errors.
The all-table aggregates can be regenerated with
`python tools/build_empty_match_metrics.py` and
`python tools/build_empty_match_table.py`; the first command independently
checks all 37,000 frozen per-table count records.
Add `--agent-repeat-root ../outputs/coding_agents/e2e_variance_repetitions`
to both the variance and macro table commands to include the same three
Codex and Copilot trials. The final macro rows are also written to
`assets/generated/e2e_macro_results.csv`.
Fresh baseline series are verified by the research harness command
`python -m src.evaluation.baseline_repetition_report`. Add
`--baseline-repeat-root ../outputs/baseline_repetitions` to both table builders
to use those three-run series. A new series replaces its historical summary;
the historical run is not added as a fourth repetition. The variance builder's
`--refresh-point` option also updates the point-estimate figure and
`assets/generated/e2e_table_point.csv` using the same means.
Without repetition-root arguments, these commands redraw the saved published
summaries. `--recompute` explicitly returns to the original per-run inputs;
it must be combined with the repetition-root arguments to include fresh trials.

Switch versions in `preamble.tex`: `\togglefalse{full}` selects the
proceedings main text; `\toggletrue{full}` includes the additional analysis and
`full_appendix.tex` after the references. The appendix uses a single column
for wide prompts and result tables. Prompt examples, detailed method
configurations, diagnostic-task tables, and macro results live in that appendix.
The main text uses full-only appendix references and retains technical-report
citations in the proceedings branch. The historical standalone evidence
document `appendix.tex` remains a separate entry point.

In the full version, Table 3 adds run-to-run sample standard deviation for
all methods with repeated trials, including direct API models and
coding agents. Run
`python tools/build_e2e_variance_table.py` to redraw `e2e_type_variability.pdf`
from the published summary CSV. `--agent-repeat-root /path/to/repetitions`
also admits complete, receipt-verified agent repetitions with the same task,
models, population, and inference settings. Single-run SD is undefined and
displayed as a dash; independent runs are never synthesized from caches or
bootstrap draws. Means and SDs are saved in
`assets/generated/e2e_table_variability.csv`.
The builder also writes `build/e2e_variability/REPORT.md` and `evidence.json`
with the actual repetition counts, means, sample SDs, and sample variances.
The proceedings branch uses `figures/paper/e2e_type_heatmap.pdf` and its shorter
caption, with the same run means. Redraw that point figure with
`python tools/build_accuracy_presentation.py --e2e-table-only`; its default
inputs are `e2e_table_point.csv` and `e2e_table_variability.csv`. This leaves
the original `e2e_table_metrics.csv` unchanged. Use `--recompute` only to
explicitly rebuild the historical point estimates.

The error-analysis outcome counts use the same published runs as Table 3.
Refresh them with `python tools/build_failure_comparison.py --outcomes-table
--artifacts /path/to/CleanBench/reproducibility/table3`. Without `--artifacts`,
`--outcomes-table` rebuilds the LaTeX rows from the saved
`assets/generated/failure_outcomes_selected.csv` and checks its run counts
and scores against `e2e_table_point.csv`.

Cost/runtime plots also use Table 3's run means. Refresh their matching native
timings with `python tools/build_traditional_resources.py --baseline-repeat-root
/path/to/baseline_repetitions`, then redraw with
`python tools/build_price_quality.py` and
`python tools/build_resource_overview.py --split-only`. A completed fresh triple
replaces its historical resource reference. The native spell-checker logs record
batch processing time; constraint timings sum the matching per-table job
receipts. CPU charges use the configured worker-hour rate. Running the timing
builder without arguments leaves the published CSV unchanged. The plot builders
also update `resource_comparison_claims.tex` for the comparison stated in the text.

Regenerate a figure with its existing `tools/build_*.py` command. Generate the
self-contained source archive with `python tools/export_overleaf.py`; it includes
the selected figure PDFs at their manuscript paths.

Figure 7 keeps the live UI's left/right layout, shows `Datekey`, `Day`, and
`Dayname`, and displays one web evidence result. These pane widths produce a
nearly square capture. Capture it with
`python tools/capture_labeling_workbench.py --browser /path/to/chromium --paper-crop --paper-columns Datekey Day Dayname --paper-table-width 350 --paper-detail-width 420 --paper-evidence-limit 1`.
The capture changes browser presentation only; source cells, saved labels,
and verification results remain unchanged.
Regenerate its numbered paper version with
`python tools/build_labeling_workbench_numbered.py`. This embeds the original
screenshot unchanged and adds vector frames and numbered badges for the
explanation, web verification, and human verdict regions.

Additional error-analysis candidates are configured in
`astra_error_analysis_more_options.json` (60 new cases) and
`astra_error_analysis_more_shortlist.json` (12 priorities). Their review PDFs
are in `assets/generated/`. Regenerate with
`tools/build_astra_error_analysis_options.py --config ... --output-dir build/... --pdf assets/generated/... --browser /path/to/chromium`.
Candidates preserve the frozen labels and all three recorded outputs. Composite
relationships are checked after applying every edited field in the same run;
source-row consistency alone does not demonstrate an output constraint violation.

Further candidates N061–N096 are configured in
`astra_error_analysis_additional_options.json` (36 cases from 32 tables) and
`astra_error_analysis_additional_shortlist.json` (12 priorities), with matching
PDFs in `assets/generated/`. They are disjoint from the earlier 137 candidates
by failure group, target source row, and normalized original value. The cases
include missed punctuation, unnecessary casing changes, incomplete repairs,
sign changes, and deleted markers. Diagnostic categories retain the frozen
judgments used by the pie charts; choosing new illustrations does not relabel
the analysis or change its counts.

The FP-focused gallery is `astra_fp_options.json` (40 new cases, N097–N136,
from 33 tables), with twelve priorities in `astra_fp_shortlist.json` and
matching PDFs in `assets/generated/`. It includes 35 reference-clean edits
and five wrong replacements at erroneous cells; the latter count as both FP
and FN. Categories remain the frozen judgments: 10 Knowledge, 24 Reasoning,
and 6 Formatting convention cases. All targets are disjoint from the earlier
173 candidates by group, source row, and normalized original value. The
composite-key example applies every same-run component edit and explicitly
preserves the edited composition. Potential reference-label issues in several
numeric and entity-name cases are recorded as exclusions in the configuration.

The manuscript error-example figure uses KFN04 and N030 for Knowledge and
Formatting convention. N030 shows a trailing comma left unchanged in all three
runs. Reasoning refers back to Figure 5(c): Astra's recorded run-1 casing edit
leaves the conflicting identifiers unchanged. N046 remains in the candidate
gallery for later comparison.
Paper figure and table labels display the model as `Astra`; experiment keys
and source values retain their original spelling.

`astra_payee_reasoning_example.json` configures a separate Payee candidate.
It uses the recorded run-1 casing edit and an author-selected reference that
holds Payee Identification fixed. The frozen Payee benchmark label remains
ambiguous; this preview does not update scoring labels, failure counts, or the
selected manuscript figure. Its standalone and three-panel PDFs are
`assets/generated/astra_payee_reasoning_example.pdf` and
`assets/generated/astra_error_examples_payee_preview.pdf`. Regenerate with
`python tools/build_payee_reasoning_example.py --browser /path/to/chromium`.
In this candidate, Astra highlighting compares with the source value, so only
its actual casing edit is colored; the unchanged `95416` remains unhighlighted.

Build with `latexmk -pdf main.tex` to use pdfLaTeX, matching the Overleaf
compiler setting. Check pagination again after manuscript updates.
Use `364.8k` total cells, `28.7k` candidate/labeled cells, and `1.4k` errors
for rounded manuscript counts, with a lowercase `k`. Statistical tables and
definitions of exact counts retain their full integer values.
Shared float/text, in-text, and caption gaps are 9 pt, 8 pt, and 5 pt;
Section 5.4 uses 13 pt in-text gaps and 7 pt caption gaps.
The main results table places its unchanged color scale in the header; all
method labels and numbers remain at 8 bp. The single-column error-example
figure fills the column and uses normal grid padding with column letters
visible, retaining source fields, cell values, comparisons, and fonts.
